const MasterRoute = require("express").Router();

const Country = require("./master.country");
const State = require("./master.state");
const Company = require("./master.company");
const City = require("./master.city");
const Industry = require("./master.industry");

const Starsize = require("./master.starsize");
const Starperiod = require("./master.starperiod");
const Discountterms = require("./master.discountterms");
const Creditperiod = require("./master.creditperiod");

const VedioModal = require("./master.modalvedio");
const SubscriptionPlan = require("./master.subscription");
const Agencies = require("./master.agencies");

const ImageVideoSubscription = require("./master.imagevideosubscription");
const Imagetype = require("./master.imagetype");
const Imagesize = require("./master.imagesize");

const PriceDetails = require("./master.pricedetails")
const SimilarGroup = require("./master.similargroup");

const MAdmin = require("./master.adminlist");
const SuspendImage = require("./master.suspendedImage");

const ChangePriceModel = require("./master.changepricemodecategory")

MasterRoute.use("/master", Country);
MasterRoute.use("/master", State);
MasterRoute.use("/master", Company);
MasterRoute.use("/master", City);
MasterRoute.use("/master", Industry);

MasterRoute.use("/master", Starsize);
MasterRoute.use("/master", Starperiod);
MasterRoute.use("/master", Discountterms);
MasterRoute.use("/master", Creditperiod);

MasterRoute.use("/master", VedioModal);
MasterRoute.use("/master", SubscriptionPlan);
MasterRoute.use("/master", Agencies);

MasterRoute.use("/master", ImageVideoSubscription);
MasterRoute.use("/master", Imagetype);
MasterRoute.use("/master", Imagesize);

MasterRoute.use("/master", PriceDetails);
MasterRoute.use("/master", SimilarGroup);

MasterRoute.use("/master", MAdmin);
MasterRoute.use("/master", SuspendImage);

MasterRoute.use("/master", ChangePriceModel);

module.exports = MasterRoute;