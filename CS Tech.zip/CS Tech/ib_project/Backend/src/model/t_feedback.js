const mongoose = require("mongoose");

const t_feedbackSchema = mongoose.Schema(
    {
        f_sno: { type: String },
        cs_userid: { type: String },
        CS_username: { type: String },
        f_feedback: { type: String },
        f_status: { type: Number },
        f_createdate: { type: Date },
        f_name: { type: String },
        f_mobile: { type: String },
    },
    { collection: "t_feedback" }
);

module.exports = t_feedback = mongoose.model(
    "t_feedback",
    t_feedbackSchema
);