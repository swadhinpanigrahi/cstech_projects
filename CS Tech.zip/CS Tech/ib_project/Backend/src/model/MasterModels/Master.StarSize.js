const mongoose = require("mongoose");

const MasterStarSizeSchema = mongoose.Schema(
    {
        f_sno: { type: String },
        f_size: { type: String },
        f_cal: { type: String },
    },
    { collection: "t_star_size" }
);

module.exports = M_STARSIZE = mongoose.model(
    "t_star_size",
    MasterStarSizeSchema
);