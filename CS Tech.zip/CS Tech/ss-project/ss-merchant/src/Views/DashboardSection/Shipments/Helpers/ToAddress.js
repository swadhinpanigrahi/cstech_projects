import React from 'react'
import { Row, Col } from "react-bootstrap";
import { useTranslation } from "react-i18next";

const ToAddress = ({ info }) => {
    const { t } = useTranslation();
    const ToAddressFields = [
        { label: "name", value: info.name },
        { label: "c_name", value: info.company_name },
        { label: "addr", value: info.address_1 },
        { label: "email", value: info.email },
        { label: "city", value: info.city },
        { label: "state", value: info.state },
        { label: "zip", value: info.zip },
        { label: "country", value: info.country },
        { label: "phone", value: info.phone }
    ]
    return (
        <>
            <div style={{ paddingLeft: "5px", paddingRight: "5px" }}>
                {ToAddressFields.map((data, inx) => {
                    let { label, value } = data
                    return (
                        <Row className="form-group" key={"FROMADD" + inx}>
                            <Col lg={4} md={4}>
                                <h6 className="pwdc">{t(`change.${label}`)}</h6>
                            </Col>
                            <Col lg={8} md={8}>
                                <h6 className="namep">{value}</h6>
                            </Col>
                        </Row>
                    )
                })}
            </div>
        </>
    )
}

export default ToAddress
