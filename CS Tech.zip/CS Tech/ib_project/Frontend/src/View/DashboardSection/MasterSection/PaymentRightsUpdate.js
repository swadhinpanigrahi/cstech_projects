import React, { useState, useEffect } from 'react';
import * as RB from 'react-bootstrap';
import { Row } from "react-bootstrap";

import { GET_R_PAYMENTEDETAIL, UPDATE_R_PAYMENTEDETAIL } from "../../../Utils/api";

import Modal from "../../../Components/Common/Modal";

const checkArrays = [
  { name: "HDFC", chacked: "f_hdfc" }, { name: "ICICI", chacked: "f_icici" },
  { name: "American Express", chacked: "f_ameriexp" },
  { name: "EBS", chacked: "f_ebs" },
  { name: "Electronic fund transfer", chacked: "f_elecfund" }, { name: "Paypal", chacked: "f_paypall" },
  { name: "PayZippy", chacked: "f_payzippy" }, { name: "Mobikwik", chacked: "f_Mobikwik" },
  // { name: "Cell Pay", chacked: "f_cellpay" },
]




export const PaymentRightsUpdate = () => {
  const [FormData, setFormData] = useState({});

  const [isOpen, setIsOpen] = useState(false);
  const [ModelMsg, setModelMsg] = useState("");

  const handleChange = (e) => {
    let { name, checked } = e.target;
    const data = { ...FormData };
    data[name] = checked;
    setFormData(data)
  }

  const modelSet = async () => {
    setIsOpen(true);
  };


  const updatePaymentRights = async () => {
    const res = await UPDATE_R_PAYMENTEDETAIL(FormData);
    let { message } = res;
    setModelMsg(message);
    modelSet()
    console.log(FormData)
  }

  const apiCall = async () => {
    const res = await GET_R_PAYMENTEDETAIL();
    let { data } = res;
    setFormData(data)
  }

  useEffect(() => {
    apiCall()
  }, [])
  return (
    <RB.Row className="rownew1">
      <RB.Col lg={12}>
        <RB.Row className="rownew1" style={{ paddingTop: "25px" }}>
          <div className="tableHeader tableHeader1 order_btntable">
            <RB.Col md={12} xs={12} className="table_span">
              <h3 className="page-title d-flex userv">
                <span>Payment Getway Rights Update</span>
              </h3>
            </RB.Col>
          </div>
        </RB.Row>
      </RB.Col>

      <div className="col-md-12" style={{ paddingTop: "7px" }}>
        <div
          className="box_detail"
          style={{
            paddingLeft: "0px",
            paddingRight: "0px",
            borderRadius: "4px",
            paddingTop: "0px",
          }}
        >
          <div className="page-header row no-gutters inside_header">
            <div className="col-md-12">
              <h3
                className="page-title"
                style={{
                  color: "#000",
                  marginBottom: "0px",
                  paddingBottom: "0px",
                  fontSize: "1.5rem",
                }}
              >
                Master
              </h3>
            </div>
          </div>
          <hr className="m-t-25 m-b-25" />
          <div className="form-body">
            <RB.Form>
              <RB.Form.Group as={Row} >
                <RB.Col lg={4} md={5}>
                  <RB.Form.Label>Please Check the Payment Getway Rights :</RB.Form.Label>
                </RB.Col>
                <RB.Col lg={8} md={7} className="checkpayment">
                  {checkArrays.map((data, inx) => {
                    let { name, chacked } = data;
                    return (

                      <RB.Row key={`RIGHTS_${inx}`}>
                        <RB.Form.Check
                          name={chacked}
                          checked={FormData[chacked]}
                          label={name}
                          onChange={handleChange}
                        />
                      </RB.Row>

                    );
                  })}
                </RB.Col>
              </RB.Form.Group>
              <RB.Row>
                <RB.Col lg={4} md={5}></RB.Col>
                <RB.Col lg={3} md={3}>
                  <RB.Button size="sm" variant="primary"
                    onClick={updatePaymentRights}>
                    SUBMIT
                  </RB.Button>
                </RB.Col>
              </RB.Row>
            </RB.Form>
          </div>
        </div>
      </div>

      <Modal text={ModelMsg} open={isOpen} onClose={() => setIsOpen(false)} />


    </RB.Row>
  )
}

export default PaymentRightsUpdate