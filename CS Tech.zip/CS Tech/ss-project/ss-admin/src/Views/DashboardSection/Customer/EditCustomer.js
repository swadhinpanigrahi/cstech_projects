import React, { useState, useEffect } from "react";
import { Row, Col, Form, Button, Modal } from "react-bootstrap";
import { customerDetailsForm, customerBankDetails } from "../../../Components/FormData/FormElements";
import { getCustomerDetails, updateCustomerDetails } from "../../../Utils/api"
import { inputFieldsValidetor } from "../../../Utils/FormValidetor";
import Model from '../../../Components/Common/Model'

const EditCustomer = ({ _id, show, handleClose }) => {
  const [FormData, setFormData] = useState({})
  const [Errors, setErrors] = useState({
    errors: {},
    errMsg1: "",
    errClr: "",
  });
  const [Password, setPassword] = useState("password");
  const [isOpen, setIsOpen] = useState(false);
  const [ModelMsg, setModelMsg] = useState("");

  const changePasswordType = () => {
    Password === "password" ? setPassword("text") : setPassword("password")
  }

  const handleChange = (e) => {
    let { name, value } = e.target
    let data = { ...FormData }
    data[name] = value;
    setFormData({ ...data })
    const updateError = { ...Errors };
    updateError.errors = inputFieldsValidetor(data);
    updateError.errMsg = "";
    updateError.errClr = "";
    setErrors({ ...updateError });
  }

  const modelSet = () => {
    setIsOpen(true);
  };

  const onSubmit = async (e) => {
    e.preventDefault();
    if (FormData["name"] && FormData["email"] && FormData["phone"] && FormData["password"] && FormData["companyName"] && FormData["address"]
      && FormData["pincode"] && FormData["city"] && FormData["state"] && FormData["country"]) {
      const res = await updateCustomerDetails(_id, FormData);
      let { status, message, updatedCustomer, error } = res;
      if (!error) {
        if (status === 200 && updatedCustomer) {
          setModelMsg("Profile Updated Successfully");
          modelSet()
          handleClose()
        } else {
          window.alert(message)
        }
      } else {
        window.alert("network error")
      }
    } else {
      const updatedError = { ...Errors };
      updatedError.errors = inputFieldsValidetor(FormData);
      updatedError.errMsg = "";
      updatedError.errClr = "border-danger";
      setErrors({ ...updatedError });
    }
  }

  useEffect(() => {
    const getCustomerApiCall = async () => {
      const res = await getCustomerDetails(_id)
      let { status, customerData } = res
      if (status === 200) {
        setFormData({ ...customerData })
        // const updatedError = { ...Errors };
        // updatedError.errors = {};
        // updatedError.errMsg = "";
        // updatedError.errClr = "";
        // setErrors({ ...updatedError });
      }
    }
    getCustomerApiCall()
  }, [_id])

  let { errors, errClr } = Errors;

  return (
    <>
      <Modal show={show} onHide={handleClose} className="main_reportmodal">
        <Col md={12} className="modal_reports">
          <Form>
            <div className="box_detail mb-0 addc-detailh report_modaltest" style={{ padding: "15px 0px 10px" }}>
              <Col lg={12} style={{ padding: "0px" }}>
                <div className="head-title1 row no-gutters">
                  <Col md={6} xs={9}>
                    <h3 class="page-title subtitile">PERSONAL DETAILS</h3>
                  </Col>
                  <Col md={6} xs={3} className="text-right">
                    <i variant="secondary" onClick={handleClose} className="fa fa-times close_modalreport"></i>
                  </Col>
                  <hr /></div>
              </Col>

              <Row id="main_form">
                {customerDetailsForm.map((data, inx) => {
                  let { label, type, name, placeholder, controlId } = data
                  if (name === "address") {
                    return (
                      <Col lg={6} key={controlId + inx}>
                        <Form.Group as={Row} controlId={controlId}>
                          <Form.Label column sm="5">
                            {label}
                          </Form.Label>

                          <Col sm="7">
                            <Form.Control type={type} as="textarea" value={FormData[name]} placeholder={placeholder} name={name} onChange={handleChange} className={errClr ? errClr : ""} />
                            <Form.Text className="text-danger">
                              {errors[name]}
                            </Form.Text>
                          </Col>
                        </Form.Group>
                      </Col>
                    )
                  } else if (name === "password") {
                    return (
                      <Col lg={6} key={controlId + inx}>
                        <Form.Group as={Row} controlId={controlId}>
                          <Form.Label column sm="5">
                            {label}
                          </Form.Label>
                          <Col sm="7">
                            <Form.Control type={Password} value={FormData[name]} placeholder={placeholder} name={name} onChange={handleChange} className={errClr ? errClr : ""} />
                            <Form.Text className="text-danger">
                              {errors[name]}
                            </Form.Text>
                            <Button onClick={changePasswordType} className="see_password"><i className="fa fa-eye"></i></Button>

                          </Col>
                        </Form.Group>
                      </Col>
                    )
                  } else {
                    return (
                      <Col lg={6} key={controlId + inx}>
                        <Form.Group as={Row} controlId={controlId}>
                          <Form.Label column sm="5">
                            {label}
                          </Form.Label>
                          <Col sm="7">
                            <Form.Control type={type} value={FormData[name]} placeholder={placeholder} name={name} onChange={handleChange} className={errClr ? errClr : ""} />
                            <Form.Text className="text-danger">
                              {errors[name]}
                            </Form.Text>
                          </Col>
                        </Form.Group>
                      </Col>
                    )
                  }
                })}
              </Row>
            </div>

            <Row style={{ margin: "20px 0px 0px 0px" }}>
              <div className="box_detail mb-0 addc-detailh report_modaltest" style={{ padding: "15px 0px 10px", marginBottom: "0px" }}>
                <Col lg={12} style={{ padding: "0px" }}>
                  <div className="head-title1 row no-gutters">
                    <Col lg={12} style={{ padding: "0px" }}>
                      <h3 class="page-title subtitile">BANK DETAILS</h3>
                    </Col><hr /></div>
                </Col>

                <Row id="main_form">
                  {customerBankDetails.map((data, inx) => {
                    let { label, type, name, placeholder, controlId } = data
                    return (
                      <Col lg={6} key={controlId + inx}>
                        <Form.Group as={Row} controlId={controlId}>
                          <Form.Label column sm="5">{label}</Form.Label>

                          <Col sm="7">
                            <Form.Control type={type} value={FormData[name]} placeholder={placeholder} name={name} onChange={handleChange} />
                            <Form.Text className="text-muted">

                            </Form.Text>
                          </Col>
                        </Form.Group>

                      </Col>
                    )
                  })}
                </Row>
                <Row className="form-group">
                  <Col lg={6}>
                    <Row>
                      <Col sm={5}></Col>
                      <Col sm={7} className="">
                        <div className="demo-btn-group" id="probtnt">
                          <Button onClick={onSubmit} className="subtn_cls">SUBMIT</Button>
                          <Button onClick={handleClose} className="subtn_clsc">CLOSE</Button>
                        </div>
                      </Col>
                    </Row>
                  </Col>
                  <Col lg={6}></Col>
                </Row>
              </div>
            </Row>
          </Form>
        </Col>
      </Modal>

      <Model
        text={ModelMsg}
        open={isOpen}
        onClose={() => setIsOpen(false)}
      />
    </>
  );
};

export default EditCustomer;
