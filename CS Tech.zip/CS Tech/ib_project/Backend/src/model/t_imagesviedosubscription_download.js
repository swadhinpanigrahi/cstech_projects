const mongoose = require("mongoose");

const t_imagesviedosubscription_downloadSchema = mongoose.Schema(
    {
        f_sno: { type: Number },
        f_orderid: { type: String },
        f_planid: { type: String },
        f_imgid: { type: String },
        f_userid: { type: String },
        f_downloaddate: { type: Date },
        f_imgname: { type: String },
        f_pack: { type: String },
        f_client: { type: Number },
        f_amount: { type: String },
        t_quality: { type: String },
        f_donloadID: { type: String },
        f_disc_price: { type: String },
        ph_paymentdate: { type: Number },
        ph_paymentstatus: { type: String },
        f_ccemail: { type: String },
        f_orderby: { type: String },
        f_planConnect: { type: String },
        f_rank: { type: String },
        videogroup: { type: String },
    },
    { collection: "t_imagesviedosubscription_download" }
);

module.exports = t_imagesviedosubscription_download = mongoose.model(
    "t_imagesviedosubscription_download",
    t_imagesviedosubscription_downloadSchema
);