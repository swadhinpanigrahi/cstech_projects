const { M_CREDITPERIOD } = require("../../model");

exports.addCreditPeriod = async (req, res) => {
    const { f_creditperiod, f_description } = req.body;
    try {
        const existingData = await M_CREDITPERIOD.findOne({ f_creditperiod });
        if (existingData) {
            res.json({ status: 400, message: "credit period already exist" })
        }
        if (!existingData) {
            const Data = await new M_CREDITPERIOD({ f_creditperiod, f_description }).save();
            if (Data) {
                res.json({ status: 200, message: "credit period added successfully" })
            }
        }
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

exports.getCreditPeriodList = async (req, res) => {
    const { currentPage, itemPerPage, searchData } = req.query;
    const num = parseInt(itemPerPage)
    const start = parseInt(currentPage);
    let pipeline;
    let countline;
    try {
        if (!searchData || searchData === "") {
            pipeline = [
                { $skip: (start - 1) * num },
                { $limit: num },
                { $sort: { _id: -1 } }
            ]
            countline = [
                { $count: "totalcount" }
            ]
        } else {
            pipeline = [
                { $match: { f_creditperiod: { $regex: searchData, $options: "im" } } },
                { $skip: (start - 1) * num },
                { $limit: num },
                { $sort: { _id: -1 } }
            ]
            countline = [
                { $match: { f_creditperiod: { $regex: searchData, $options: "im" } } },
                { $count: "totalcount" }
            ]
        }
        const data = await M_CREDITPERIOD.aggregate(pipeline)
        const totalrecord = await M_CREDITPERIOD.aggregate(countline)
        res.json({ status: 200, data, totalrecord })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

exports.getCreditPeriodDetail = async (req, res) => {
    const { _id } = req.params;
    try {
        const CreditDetail = await M_CREDITPERIOD.findOne({ _id });
        res.json({ status: 200, CreditDetail })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

exports.editCreditPeriodDetail = async (req, res) => {
    const { _id, f_creditperiod, f_description } = req.body;
    try {
        const updateData = await M_CREDITPERIOD.findByIdAndUpdate({ _id }, { $set: { f_creditperiod, f_description } })
        res.json({ status: 200, message: "credit period updated successfully!" })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

exports.deleteCreditPeriodDetail = async (req, res) => {
    const { _id } = req.params;
    try {
        const deletedData = await M_CREDITPERIOD.findByIdAndRemove({ _id });
        res.json({ status: 200, message: "credit period deleted successfully!" })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}