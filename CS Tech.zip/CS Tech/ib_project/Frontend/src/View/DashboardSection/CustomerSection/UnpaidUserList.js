import React from 'react';
import { Row, Col, Form, Button, Table } from 'react-bootstrap';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { UnpaidUserAPI } from "../../../Utils/api";
import PaginationComponent from "../../../Components/Common/PaginationComponent";


const UnpaidUserList = () => {
    const [Data, setData] = React.useState([]);
    const [Count, setCount] = React.useState(0);
    const [startDate, setStartDate] = React.useState(null);
    const [endDate, setEndDate] = React.useState(null);
    const [currentPage, setCurrentPage] = React.useState(1);
    const [itemPerPage, setItemPerPage] = React.useState(20);
    const [Loading, setLoading] = React.useState(false);

    const handleChange = async (e) => {
        // console.log(currentPage, itemPerPage, e.target.value);
        // const res = await UnpaidUserAPI(currentPage, itemPerPage, e.target.value)
        // let { customerCount, customerData } = res;
        // setData(customerData);
        // customerCount.length === 1 ? setCount(customerCount[0].totalCount) : setCount(0);
        // setLoading(false)
    }

    const onSearch = async () => {
        // console.log(currentPage, itemPerPage, startDate, endDate)
        // const res = await UnpaidUserAPI(currentPage, itemPerPage, startDate, endDate);
        //     let { customerCount, customerData } = res;
        //     setData(customerData);
        //     customerCount.length === 1 ? setCount(customerCount[0].totalCount) : setCount(0);
        //     setLoading(false)
    }



    React.useEffect(() => {
        setLoading(true)
        const apiCall = async () => {
            const res = await UnpaidUserAPI(currentPage, itemPerPage);
            let { customerCount, customerData } = res;
            setData(customerData);
            customerCount.length === 1 ? setCount(customerCount[0].totalCount) : setCount(0);
            setLoading(false)
        }
        apiCall();
    }, [currentPage, itemPerPage])

    return (
        <>
            <Row className="rownew1">
                <Col lg={12}>
                    <Row className="page_header1 rownew1">
                        <div className="tableHeader tableHeader1 search_new">
                            <Col md={12} className="table_span">
                                <h3 className="page-title d-flex userv">
                                    <span>Search Results</span>
                                </h3>
                            </Col>
                        </div>
                    </Row>
                </Col>
            </Row>

            <Col lg={12}>
                <div className="box_detail" style={{ borderRadius: "4px" }}>
                    <div className="page-header row">
                        <Col md={12}>
                            <Form className="manage_searchorder">
                                < Row className="mg_row0">
                                    < Col lg={6} md={6}>
                                        < Row className="mg_row0">
                                            < Col lg={6} md={6}>
                                                <DatePicker className="startdate"
                                                    placeholderText="Start Date"
                                                    selected={startDate}
                                                    onChange={(date) => setStartDate(date)}
                                                    dateFormat="dd-MM-yyyy"
                                                />
                                            </ Col>
                                            < Col lg={6} md={6} className="customer_sdate order_sdate">
                                                <DatePicker className="enddate"
                                                    placeholderText="End Date"
                                                    selected={endDate}
                                                    onChange={(date) => setEndDate(date)}
                                                    dateFormat="dd-MM-yyyy"
                                                />
                                            </ Col>
                                        </ Row>
                                    </ Col>
                                    < Col lg={2} md={2} className="customer_sdate">
                                        < Col lg={12} className="customer_sdate1">
                                            <Button size="sm"
                                                className="customer_srhbtn"
                                                variant="primary"
                                                onClick={onSearch}
                                            >
                                                SEARCH
                                            </Button>
                                        </ Col>
                                    </ Col>
                                    < Col lg={4} md={4}>
                                        < Row className="mg_row0">
                                            < Col lg={4}></ Col>
                                            < Col lg={8} className="">
                                                <Form.Group>
                                                    <Form.Control
                                                        type="text"
                                                        placeholder="Search by Text/Order ID"
                                                        onChange={handleChange}
                                                    />
                                                </Form.Group>
                                            </ Col>
                                        </ Row>
                                    </ Col>
                                </Row>
                            </Form>
                        </Col>
                    </div>
                </div>
            </Col>

            <Col lg={12}>
                <Row className="rownew1">
                    <div className="tableHeader tableHeader1 search_new">
                        <Col lg={6} md={6} xs={7} className="table_span">
                            <h3 className="page-title d-flex userv">
                                <span>Unpaid List</span>
                            </h3>
                        </Col>
                        <Col lg={6} md={6} xs={5} className="table_span text-right">
                            Total Count : {Count}
                        </Col>
                    </div>
                </Row>

                <div
                    className="box_detail table_boxdtl manage_order"
                    style={{ marginBottom: "0px" }}
                >
                    <Table striped bordered hover variant="dark" responsive>
                        <thead>
                            <tr>
                                <th>Id</th>
                                <th>User Name</th>
                                <th>CCEmail</th>
                            </tr>
                        </thead>
                        <tbody>
                            {Loading ?
                                <>
                                    <td className="no_records" colSpan="11">
                                        Loading...
                                    </td>
                                </> : Data.length > 0 ?
                                    Data.map((info) => {
                                        let { _id } = info;
                                        let { cs_ccmail, CS_userid } = info.TUR;
                                        return (
                                            <tr key={_id}>
                                                <td>{CS_userid}</td>
                                                <td>{_id}</td>
                                                <td>{cs_ccmail}</td>
                                            </tr>
                                        )
                                    }) :
                                    <>
                                        <td className="no_records" colSpan="11">
                                            No Records Found
                                        </td>
                                    </>
                            }
                        </tbody>
                    </Table>
                </div>
                <PaginationComponent
                    MOCK_DATA={Count}
                    currentPage={currentPage}
                    setCurrentPage={setCurrentPage}
                    itemPerPage={itemPerPage}
                    setItemPerPage={setItemPerPage}
                />
            </Col>
        </>
    )
}

export default UnpaidUserList
