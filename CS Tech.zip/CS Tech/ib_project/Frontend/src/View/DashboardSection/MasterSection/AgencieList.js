import React, { useState, useEffect } from 'react';
import * as RB from 'react-bootstrap';
import { MdAddCircleOutline } from 'react-icons/md';
import { BiCommentEdit } from "react-icons/bi";

import PaginationComponent from "../../../Components/Common/PaginationComponent";

import Modal from "../../../Components/Common/Modal";

import { GET_AGENCIESLIST } from "../../../Utils/api";

const AgencieList = () => {
    const [Agencie, setAgencie] = useState([]);

    const [currentPage, setCurrentPage] = useState(1);
    const [itemPerPage, setItemPerPage] = useState(20);
    let [searchData, setSearchData] = useState("");
    const [TotalCount, setTotalCount] = useState(0);
    const [Loading, setLoading] = useState(false)


    const [isOpen, setIsOpen] = useState(false);
    const [ModelMsg, setModelMsg] = useState("");

    const modelSet = async () => {
        setIsOpen(true);
    };

    const SearchDataFun = async (e) => {
        setSearchData(e.target.value)
        const res = await GET_AGENCIESLIST(currentPage, itemPerPage, (searchData = e.target.value));
        let { data, totalrecord } = res;
        setAgencie(data);
        totalrecord.length === 1
            ? setTotalCount(totalrecord[0].totalcount)
            : setTotalCount(0);
    }

    const ActiveDeactive = async (id) => {
        setModelMsg(id);
        modelSet()
    }

    const apiCall = async () => {
        setLoading(true)
        const res = await GET_AGENCIESLIST(currentPage, itemPerPage, searchData);
        let { data, totalrecord } = res;
        setAgencie(data);
        setTotalCount(totalrecord[0].totalcount)
        setLoading(false)
    }

    useEffect(() => {
        apiCall();
    }, [currentPage, itemPerPage])
    return (
        <RB.Row className="rownew1">
            <RB.Col lg={12}>
                <RB.Row className="rownew1" style={{ paddingTop: "25px" }}>
                    <div className="tableHeader tableHeader1 order_btntable">
                        <RB.Col md={6} xs={12} className="table_span">
                            <h3 className="page-title d-flex userv">
                                <span>Search Results</span>
                            </h3>
                        </RB.Col>
                        <RB.Col md={6} xs={12} className="table_span">
                            {/* <div className="float-right responsive_floatbtn">
                                <RB.Button size="sm" variant="primary" className="btn_svg" onClick={addstateShow}
                                >
                                    <MdAddCircleOutline style={{ marginRight: "3px" }} />
                                    ADD STATE
                                </RB.Button>
                            </div> */}
                        </RB.Col>
                    </div>
                </RB.Row>
            </RB.Col>

            <RB.Col lg={12}>
                <div className="box_detail" style={{ borderRadius: "4px" }}>
                    <div className="page-header row">
                        <RB.Col md={12}>
                            <RB.Form className="manage_searchorder">
                                <RB.Row className="mg_row0">
                                    <RB.Col lg={12} md={12} className="customer_leftsrh">
                                        <RB.Row className="mg_row0">
                                            <RB.Col lg={3} md={3} className="customer_sdate">
                                                <RB.Form.Group>
                                                    <RB.Form.Control
                                                        id="searchText"
                                                        type="text"
                                                        placeholder="Search by Text"
                                                        onChange={SearchDataFun}
                                                    />
                                                </RB.Form.Group>
                                            </RB.Col>
                                        </RB.Row>
                                    </RB.Col>

                                </RB.Row>
                            </RB.Form>
                        </RB.Col>
                    </div>
                </div>
            </RB.Col>

            <RB.Col lg={12}>
                <RB.Row className="rownew1">
                    <div className="tableHeader tableHeader1 search_new">
                        <RB.Col lg={6} md={6} className="table_span">
                            <h3 className="page-title d-flex userv">
                                <span>Agencies List</span>
                            </h3>
                        </RB.Col>
                        <RB.Col lg={6} md={6} className="table_span total_recordt">
                            <span>Total Records: {TotalCount}</span>
                        </RB.Col>
                    </div>
                </RB.Row>
                <div
                    className="box_detail table_boxdtl manage_order"
                    style={{}}
                >
                    <RB.Table striped bordered hover variant="dark" responsive>
                        <thead>
                            <tr class="vtable">
                                <th className="">IP Address</th>
                                <th className="">Email</th>
                                <th className="">Company Name</th>
                                <th className="text-center action_align">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            {Loading ? <tr><td className="no_records" colSpan="11">Loading...</td></tr> : Agencie.length > 0 ? Agencie.map((info, inx) => {
                                return (
                                    <tr key={`MASTER_TOPAGENCIE-${inx}`}>
                                        <td className="s_notm text-center">{info.f_ip}</td>
                                        <td className="">{info.f_email}</td>
                                        <td className="">{info.f_Cname}</td>
                                        <td className="td_comments text-center">
                                            <BiCommentEdit title="Edit State" onClick={() => ActiveDeactive(info._id)} />
                                        </td>
                                    </tr>
                                )
                            }) : <tr><td className="no_records" colSpan="11">No Records Found</td></tr>}
                        </tbody>
                    </RB.Table>
                </div>
            </RB.Col>

            <PaginationComponent
                MOCK_DATA={TotalCount}
                currentPage={currentPage}
                setCurrentPage={setCurrentPage}
                itemPerPage={itemPerPage}
                setItemPerPage={setItemPerPage}
            />

            <Modal text={ModelMsg} open={isOpen} onClose={() => setIsOpen(false)} />


        </RB.Row>
    )
}

export default AgencieList
