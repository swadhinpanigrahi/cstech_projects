import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Line } from "react-chartjs-2";
import icon1 from "../../../Images/icon1.png";
import icon3 from "../../../Images/icon3.png";
import Cookie from "js-cookie";

const CountCard = ({ userCount, orderCount, graph }) => {
    const [charData, setCharData] = useState({});
    const [GraphAuth, setGraphAuth] = useState({
        graph_view: "",
        order_list: "",
        register_list: ""
    })

    useEffect(() => {
        const Chart = () => {
            let userNum = [];
            let dateNum = [];
            for (const dataObj of graph) {
                userNum.push(parseInt(dataObj.count));
                dateNum.push(dataObj._id);
            }
            setCharData({
                labels: dateNum,
                datasets: [
                    {
                        label: "Total Order",
                        data: userNum,
                        backgroundColor: ["rgba(75, 192, 192, 0.6)"],
                    },
                ],
            });
        }
        Chart()
    }, [graph]);


    useEffect(() => {
        const fun = async () => {
            const graphAuth = await Cookie.get("graph");
            const orderAuth = await Cookie.get("order_list");
            const registerAuth = await Cookie.get("register_list");

            const updateState = { ...GraphAuth };
            updateState.graph_view = graphAuth;
            updateState.order_list = orderAuth;
            updateState.register_list = registerAuth;
            console.log("coming from storage", graphAuth, orderAuth, registerAuth)
            setGraphAuth({ ...updateState })
        }
        fun()
    }, [])

    let { graph_view, order_list, register_list } = GraphAuth

    return (
        <>
            <Line
                data={charData}
                className={graph_view === "true" ? null : "testingggg"}
                width={100}
                height={20}
                options={{
                    scales: { yAxes: [{ ticks: { beginAtZero: true } }] },
                }}
            />

            <div className="row" style={{ marginTop: "20px" }}>

                <div className="col-lg-6 col-md-6">
                    <div className={order_list === "true" ? "box_detail fstbox" : "testingggg"}>
                        <div className="row mg-0">
                            <div className="col-md-4 col-12 dash_cen">
                                <img src={icon1} alt="icon1" />
                            </div>
                            <div className="col-md-8 col-12 dash_cen">
                                <h5 className="titleh5 ordnew">Total Orders</h5>
                                <h5 className="titleh5 count-item">{orderCount}</h5>
                            </div>
                        </div>
                        <div className="row mg-0">
                            <p className="morei">
                                <Link to="/dashboard/shipments/get">More Info</Link>
                                <i className="fa fa-caret-right rightca"></i>
                            </p>
                        </div>
                    </div>
                </div>

                <div className="col-lg-6 col-md-6">
                    <div className={register_list === "true" ? "box_detail fstbox2" : "testingggg"}>
                        <div className="row mg-0">
                            <div className="col-md-4 col-12 dash_cen">
                                <img src={icon3} alt="icon3" />
                            </div>
                            <div className="col-md-8 col-12 dash_cen">
                                <h5 className="titleh5u ordnew">User Registrations</h5>
                                <h5 className="titleh5u count-item">
                                    {userCount}
                                </h5>
                            </div>
                        </div>
                        <div className="row mg-0">
                            <p className="moreiu more_info">
                                <Link to="/dashboard/customer/get">More Info</Link>
                                <i
                                    className="fa fa-caret-right rightca"
                                    style={{ color: "#000" }}
                                ></i>
                            </p>
                        </div>
                    </div>
                </div>

            </div>
        </>
    );
};

export default CountCard;