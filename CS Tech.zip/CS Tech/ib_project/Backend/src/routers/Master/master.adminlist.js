const MAdmin = require("express").Router();
const { getAdminList, addAdmin } = require("../../controllers/Master/master.madmin.controller")

MAdmin.route(`/getadminlist`).get(getAdminList);
MAdmin.route(`/addadmin`).post(addAdmin);

module.exports = MAdmin;