const { t_Images } = require("../../model");

exports.groupImagesList = async (req, res) => {
    const { currentPage, itemPerPage, searchData } = req.query;
    console.log(currentPage, itemPerPage, searchData)
    const num = parseInt(itemPerPage)
    const start = parseInt(currentPage);
    let pipeline;
    let countline;
    try {
        if (!searchData) {
            pipeline = [
                { $group: { _id: "$F_group" } },
                { $sort: { _id: -1 } },
                { $skip: (start - 1) * num },
                { $limit: num }
            ]
            countline = [
                { $count: "totalcount" }
            ]
        } else {
            pipeline = [
                { $match: { f_sizename: { $regex: searchData, $options: "im" } } },
                { $group: { _id: "$F_group" } },
                { $sort: { _id: -1 } },
                { $skip: (start - 1) * num },
                { $limit: num }
            ]
            countline = [
                { $match: { f_sizename: { $regex: searchData, $options: "im" } } },
                { $count: "totalcount" }
            ]
        }
        const data = await t_Images.aggregate(pipeline)
        const totalrecord = await t_Images.aggregate(countline)
        res.json({ status: 200, data, totalrecord })
    } catch (error) {
        res.json({ status: 200, message: "Internal Server Error!", error: error.message })
    }
}

exports.getPriceDetail = async (req, res) => {
    const { F_group } = req.params;
    try {
        let data = await t_Images.findOne({ F_group }, { F_group: 1, f_agencyname: 1, f_pricing: 1, nonexclusive: 1 });
        if (data.nonexclusive === false) {
            data.nonexclusive = 0
        } else {
            data.nonexclusive = 1
        }
        res.json({ status: 200, data })
    } catch (error) {
        res.json({ status: 200, message: "Internal Server Error!", error: error.message })
    }
}