import React, { useState, useEffect } from "react";
import logo from "../../Images/final_logon.png";
import { Link, useHistory } from "react-router-dom";
import user from "../../Images/user.png";
import { logOutApi } from "../../Utils/api";
import Cookie from "js-cookie";
import $ from "jquery";
import { useTranslation } from "react-i18next";

const Profilebar = () => {
  const lang = localStorage.getItem("lang") || "en";
  const { t, i18n } = useTranslation();

  const history = useHistory();
  const [AuthName, setAuthName] = useState("");


  const logOut = async () => {
    await logOutApi();
    history.push("/logout");
    setTimeout(() => {
      history.push("/")
    }, 3000);
  };

  const toggledrop = () => {
    if ($("#drop_menut").css("display") === "none") {
      $("#drop_menut").css("display", "block");
    } else {
      $("#drop_menut").css("display", "none");
    }
  };

  const change = (option) => {
    console.log("language mode", option)
    localStorage.setItem("lang", option.target.value);
    let language = localStorage.getItem("lang") || "en";
    console.log("calling", language)
    i18n.changeLanguage(language);
    window.location.reload();
  };

  useEffect(() => {
    const name = Cookie.get("name");
    setAuthName(name)
  }, []);

  return (
    <div>
      <div className="container-flud headtop" style={{}}>
        <div className="row" style={{ margin: "0px" }}>
          <div className="col-lg-5 col-md-12 col-12 logom_headp">
            <div className="row">
              <div id="logo1" className="col-lg-4 col-md-3 col-12">
                <Link to="/dashboard/analytics">
                  <img
                    src={logo}
                    alt="Storage Station"
                    className="logo_sticky new_logod"
                  />
                </Link>
              </div>
              <div className="texth col-lg-7 col-md-7 col-12">
                <h6 className="after_loginhead">{t("change.Mheader")}</h6>
              </div>
            </div>
          </div>

          <div className="col-lg-7 col-md-12 col-12 righttop">
            <ul className="topul after_loginhead">
              <li>
                <select
                  className="custom-select language_option"
                  onChange={change}
                  value={lang}
                >
                  <option value="en">English</option>
                  <option value="arab">Arabic</option>
                </select>
              </li>
              <li>
                <span className="welth">
                  {t("change.welcome")} <Link to="#">{t("change.SStorage")}</Link>
                </span>
              </li>
              <li className="nav-item dropdown" onClick={toggledrop}>
                <Link className="nav-link dropdown-toggle text-nowrap d-flex align-items-center justify-content-center">
                  <span className="main_profiledrop">
                    <img src={user} className="iconl" alt="profilebar_img" />
                    {AuthName}
                  </span>
                </Link>
                <div
                  id="drop_menut"
                  className="dropdown-menu dropdown-menu-small"
                  style={{ zIndex: "999999999" }}
                >
                  <Link
                    className="dropdown-item"
                    id="logout"
                  >
                    <i className="material-icons" style={{ color: "#000" }}>
                      person
                    </i>
                    <span
                      className="manage_toggle"
                      style={{
                        color: "#727b82",
                        position: "relative",
                        top: "-5px",
                      }}
                    >
                      <Link
                        to="/dashboard/editprofile"
                        style={{
                          color: "#000",
                          fontSize: "16px",
                          fontWeight: "600",
                          letterSpacing: ".5px",
                          display: "inline-block",
                        }}
                      >
                        Manage Profile
                      </Link>
                    </span>
                  </Link>
                  <div className="dropdown-divider"></div>
                  <a
                    className="dropdown-item employee nav-active"
                    href="change-password.html"
                  >
                    <i className="material-icons" style={{ color: "#000" }}>
                      vpn_key
                    </i>
                    <span
                      className="manage_toggle"
                      style={{
                        color: "#727b82",
                        position: "relative",
                        top: "-5px",
                      }}
                    >
                      <Link
                        to="/dashboard/changepassword"
                        style={{
                          color: "#000",
                          fontSize: "16px",
                          fontWeight: "600",
                          letterSpacing: ".5px",
                          display: "inline-block",
                        }}
                      >
                        Change Password
                      </Link>
                    </span>
                  </a>
                  <div className="dropdown-divider"></div>
                  <Link
                    className="dropdown-item text-danger"
                    id="logout"
                  // href="logout.aspx"
                  >
                    <i className="material-icons text-danger">&#xE879;</i>
                    <span
                      className="manage_toggle"
                      style={{
                        color: "#dc3545",
                        position: "relative",
                        top: "-5px",
                      }}
                      onClick={logOut}
                    >
                      Logout
                    </span>
                  </Link>
                  <div className="dropdown-divider"></div>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profilebar;
