import React, { useState, useEffect } from 'react';
import { Form, Row, Col, Button } from 'react-bootstrap';
import PageHeaders from '../../../Components/Common/PageHeaders';
import { addsubuserForm } from "../../../Components/FormData/FormElements";
import { useParams } from 'react-router-dom'
import { getSubUserDetails, editSubUserPermissions } from '../../../Utils/api'
import Model from "../../../Components/Common/Model";

const SubuserPermission = () => {
  const { _id } = useParams();

  const [UserDetails, setUserDetails] = useState({});
  const [Password, setPassword] = useState("password");
  const [isOpen, setIsOpen] = useState(false);
  const [ErrModel, setErrModel] = useState("");

  const changePasswordType = () => {
    Password === "password" ? setPassword("text") : setPassword("password")
  }

  const [FormData, setFormData] = useState({
    dashboard_graph: false, order_list: false, register_list: false, customers_viewlist: false, customers_exportfile: false,
    add: false, edit: false, active: false, payment: false, statement: false, shipments_viewlist: false, shipments_exportfile: false,
    shipments_track: false, codreports_viewlist: false, codreports_exportfile: false, codreports_track: false, outstanding_viewlist: false,
    outstanding_exportfile: false, opayment: false, ostatement: false, manage_profile: false, change_password: false
  })

  const handleChange = (e) => {
    let { name, checked } = e.target;
    const data = { ...FormData };
    data[name] = checked;
    setFormData(data)
  }

  const onSubmit = async (e) => {
    e.preventDefault();
    const res = await editSubUserPermissions({ ...FormData, _id });
    let { message } = res;
    if (message) {
      setErrModel(message);
      modelSet()
    }
  }

  const modelSet = () => {
    setIsOpen(true);
  };

  useEffect(() => {
    const apiCall = async () => {
      const res = await getSubUserDetails(_id);
      let { useData, accessData } = res;
      const updateFormData = { ...FormData };
      let { dashboard_graph, order_list, register_list } = accessData.dashboard;
      let { customers_action, customers_exportfile, customers_viewlist } = accessData.customers;
      let { shipments_viewlist, shipments_exportfile, shipments_track } = accessData.shipments;
      let { codreports_viewlist, codreports_exportfile, codreports_track } = accessData.codreports
      let { outstanding_action, outstanding_viewlist, outstanding_exportfile } = accessData.outstanding;
      let { change_password, manage_profile } = accessData
      updateFormData.dashboard_graph = dashboard_graph
      updateFormData.order_list = order_list
      updateFormData.register_list = register_list
      updateFormData.customers_viewlist = customers_viewlist
      updateFormData.customers_exportfile = customers_exportfile
      updateFormData.add = customers_action.add
      updateFormData.edit = customers_action.edit
      updateFormData.active = customers_action.active
      updateFormData.payment = customers_action.payment
      updateFormData.statement = customers_action.statement

      updateFormData.shipments_viewlist = shipments_viewlist
      updateFormData.shipments_exportfile = shipments_exportfile
      updateFormData.shipments_track = shipments_track

      updateFormData.codreports_viewlist = codreports_viewlist
      updateFormData.codreports_exportfile = codreports_exportfile
      updateFormData.codreports_track = codreports_track

      updateFormData.outstanding_viewlist = outstanding_viewlist
      updateFormData.outstanding_exportfile = outstanding_exportfile
      updateFormData.opayment = outstanding_action.opayment
      updateFormData.ostatement = outstanding_action.ostatement
      updateFormData.change_password = change_password
      updateFormData.manage_profile = manage_profile


      setFormData(updateFormData)
      setUserDetails(useData)
    }
    apiCall()
  }, [_id])

  return (
    <>
      <main className="">
        <Col lg={12}>
          <PageHeaders title="User-Permission" />
          <Col md={12}>
            <div
              className="box_detail"
              style={{ padding: "15px 0px 10px 0px", marginBottom: "20px" }}
            >
              <Col lg={12} style={{ padding: "0px" }}>
                <div className="page-header row no-gutters">
                  <Col md={12} style={{ color: "blue !important" }}>
                    <h3 className="page-title subtitile">USER DETAILS</h3>
                  </Col>
                  <hr />
                </div>
              </Col>
              <Col lg={12}>
                <Col lg={12}>
                  <form className="formcon row" id="main_form">
                    {addsubuserForm.map((data, inx) => {
                      let {
                        label,
                        name,
                        type,
                        placeholder,
                        controlId
                      } = data;
                      if (name === "password") {
                        return (
                          <Col lg={6} key={"PERMISSION" + inx}>
                            <Form.Group as={Row} controlId={controlId}>
                              <Form.Label column sm="4">
                                {label}
                              </Form.Label>
                              <Col sm="8">
                                <Form.Control type={Password} name={name}
                                  placeholder={placeholder}
                                  defaultValue={UserDetails[name]}
                                  disabled
                                />
                                <Button onClick={changePasswordType} className="see_password"><i className="fa fa-eye"></i></Button>
                              </Col>
                            </Form.Group>
                          </Col>
                        );
                      } else {
                        return (
                          <Col lg={6}>
                            <Form.Group as={Row} controlId={controlId}>
                              <Form.Label column sm="4">
                                {label}
                              </Form.Label>
                              <Col sm="8">
                                <Form.Control type={type} name={name}
                                  placeholder={placeholder}
                                  defaultValue={UserDetails[name]}
                                  disabled
                                />
                              </Col>
                            </Form.Group>
                          </Col>
                        );
                      }
                    })}
                  </form>
                </Col>
              </Col>
            </div>

            <div
              className="box_detail"
              style={{ padding: "15px 0px 10px 0px", marginBottom: "20px" }}
            >
              <Col lg={12} style={{ padding: "0px" }}>
                <div className="page-header row no-gutters">
                  <Col md={12} style={{ color: "blue !important" }}>
                    <h3 className="page-title subtitile">DASHBOARD</h3>
                  </Col>
                  <hr />
                </div>
              </Col>
              <Col lg={12}>
                <Col lg={12}>
                  <form className="formcon row main_forms" id="main_form">
                    <Col lg={6}>
                      <div className="form-group row">
                        <span className="user_labeln"><Form.Label>Dashboard Graph:</Form.Label></span>
                        <span className="user_checkbox">
                          <Form.Check type="checkbox" className="subuser_check" name="dashboard_graph"
                            checked={FormData["dashboard_graph"]} onChange={handleChange} />
                        </span>
                      </div>
                    </Col>
                    <Col lg={6}>
                      <div className="form-group row">
                        <span className="user_labeln"><Form.Label>Dashboard Order List:</Form.Label></span>
                        <span className="user_checkbox">
                          <Form.Check type="checkbox" className="subuser_check" name="order_list"
                            checked={FormData["order_list"]} onChange={handleChange} />
                        </span>
                      </div>
                    </Col>
                    <Col lg={6}>
                      <div className="form-group row">
                        <span className="user_labeln"><Form.Label>Register List:</Form.Label></span>
                        <span className="user_checkbox">
                          <Form.Check type="checkbox" className="subuser_check" name="register_list"
                            checked={FormData["register_list"]} onChange={handleChange} />
                        </span>
                      </div>
                    </Col>
                  </form>
                </Col>
              </Col>
            </div>

            <div
              className="box_detail"
              style={{ padding: "15px 0px 10px 0px", marginBottom: "20px" }}
            >
              <Col lg={12} style={{ padding: "0px" }}>
                <div className="page-header row no-gutters">
                  <Col md={12} style={{ color: "blue !important" }}>
                    <h3 className="page-title subtitile">CUSTOMERS</h3>
                  </Col>
                  <hr />
                </div>
              </Col>
              <Col lg={12}>
                <Col lg={12}>
                  <form className="formcon row main_forms" id="main_form">
                    <Col lg={6}>
                      <div className="form-group row">
                        <span className="user_labeln"><Form.Label>Customer View List:</Form.Label></span>
                        <span className="user_checkbox">
                          <Form.Check type="checkbox" className="subuser_check" name="customers_viewlist"
                            checked={FormData["customers_viewlist"]} onChange={handleChange} />
                        </span>
                      </div>
                    </Col>
                    <Col lg={6}>
                      <div className="form-group row">
                        <span className="user_labeln"><Form.Label>Customer Action:</Form.Label></span>
                        <span className="user_checkbox">
                          <Form.Check type="checkbox" inline className="subuser_check" label="Add" name="add" checked={FormData["add"]} onChange={handleChange} />
                          <Form.Check type="checkbox" inline className="subuser_check" label="Edit" name="edit" checked={FormData["edit"]} onChange={handleChange} />
                          <Form.Check type="checkbox" inline className="subuser_check" label="Active" name="active" checked={FormData["active"]} onChange={handleChange} />
                          <Form.Check type="checkbox" inline className="subuser_check" label="Payment" name="payment" checked={FormData["payment"]} onChange={handleChange} />
                          <Form.Check type="checkbox" inline className="subuser_check" label="Statement" name="statement" checked={FormData["statement"]} onChange={handleChange} />
                        </span>
                      </div>
                    </Col>
                    <Col lg={6}>
                      <div className="form-group row">
                        <span className="user_labeln"><Form.Label>Customer Export File:</Form.Label></span>
                        <span className="user_checkbox">
                          <Form.Check type="checkbox" className="subuser_check" name="customers_exportfile"
                            checked={FormData["customers_exportfile"]} onChange={handleChange} />
                        </span>
                      </div>
                    </Col>

                  </form>
                </Col>
              </Col>
            </div>

            <div
              className="box_detail"
              style={{ padding: "15px 0px 10px 0px", marginBottom: "20px" }}
            >
              <Col lg={12} style={{ padding: "0px" }}>
                <div className="page-header row no-gutters">
                  <Col md={12} style={{ color: "blue !important" }}>
                    <h3 className="page-title subtitile">SHIPMENTS</h3>
                  </Col>
                  <hr />
                </div>
              </Col>
              <Col lg={12}>
                <Col lg={12}>
                  <form className="formcon row main_forms" id="main_form">
                    <Col lg={6}>
                      <div className="form-group row">
                        <span className="user_labeln"><Form.Label>Shipment View List:</Form.Label></span>
                        <span className="user_checkbox">
                          <Form.Check type="checkbox" className="subuser_check" name="shipments_viewlist"
                            checked={FormData["shipments_viewlist"]} onChange={handleChange} />
                        </span>
                      </div>
                    </Col>
                    <Col lg={6}>
                      <div className="form-group row">
                        <span className="user_labeln"><Form.Label>Shipment Track:</Form.Label></span>
                        <span className="user_checkbox">
                          <Form.Check type="checkbox" className="subuser_check" name="shipments_track"
                            checked={FormData["shipments_track"]} onChange={handleChange} />
                        </span>
                      </div>
                    </Col>
                    <Col lg={6}>
                      <div className="form-group row">
                        <span className="user_labeln"><Form.Label>Shipment Export File:</Form.Label></span>
                        <span className="user_checkbox">
                          <Form.Check type="checkbox" className="subuser_check" name="shipments_exportfile"
                            checked={FormData["shipments_exportfile"]} onChange={handleChange} />
                        </span>
                      </div>
                    </Col>

                  </form>
                </Col>
              </Col>
            </div>

            <div
              className="box_detail"
              style={{ padding: "15px 0px 10px 0px", marginBottom: "20px" }}
            >
              <Col lg={12} style={{ padding: "0px" }}>
                <div className="page-header row no-gutters">
                  <Col md={12} style={{ color: "blue !important" }}>
                    <h3 className="page-title subtitile">COD REPORTS</h3>
                  </Col>
                  <hr />
                </div>
              </Col>
              <Col lg={12}>
                <Col lg={12}>
                  <form className="formcon row main_forms" id="main_form">
                    <Col lg={6}>
                      <div className="form-group row">
                        <span className="user_labeln"><Form.Label>Report View List:</Form.Label></span>
                        <span className="user_checkbox">
                          <Form.Check type="checkbox" className="subuser_check" name="codreports_viewlist"
                            checked={FormData["codreports_viewlist"]} onChange={handleChange} />
                        </span>
                      </div>
                    </Col>
                    <Col lg={6}>
                      <div className="form-group row">
                        <span className="user_labeln"><Form.Label>Report Track:</Form.Label></span>
                        <span className="user_checkbox">
                          <Form.Check type="checkbox" className="subuser_check" name="codreports_track"
                            checked={FormData["codreports_track"]} onChange={handleChange} />
                        </span>
                      </div>
                    </Col>
                    <Col lg={6}>
                      <div className="form-group row">
                        <span className="user_labeln"><Form.Label>Report Export File:</Form.Label></span>
                        <span className="user_checkbox">
                          <Form.Check type="checkbox" className="subuser_check" name="codreports_exportfile"
                            checked={FormData["codreports_exportfile"]} onChange={handleChange} />
                        </span>
                      </div>
                    </Col>
                  </form>
                </Col>
              </Col>
            </div>

            <div
              className="box_detail"
              style={{ padding: "15px 0px 10px 0px", marginBottom: "20px" }}
            >
              <Col lg={12} style={{ padding: "0px" }}>
                <div className="page-header row no-gutters">
                  <Col md={12} style={{ color: "blue !important" }}>
                    <h3 className="page-title subtitile">OUTSTANDING</h3>
                  </Col>
                  <hr />
                </div>
              </Col>
              <Col lg={12}>
                <Col lg={12}>
                  <form className="formcon row main_forms" id="main_form">
                    <Col lg={6}>
                      <div className="form-group row">
                        <span className="user_labeln"><Form.Label>Outstanding View List:</Form.Label></span>
                        <span className="user_checkbox">
                          <Form.Check type="checkbox" className="subuser_check" name="outstanding_viewlist"
                            checked={FormData["outstanding_viewlist"]} onChange={handleChange} />
                        </span>
                      </div>
                    </Col>
                    <Col lg={6}>
                      <div className="form-group row">
                        <span className="user_labeln"><Form.Label>Outstanding Action:</Form.Label></span>
                        <span className="user_checkbox">
                          {/* <Form.Check type="checkbox" inline className="subuser_check" label="Active" name="" checked={FormData["opayment"]} onChange={handleChange} /> */}
                          <Form.Check type="checkbox" inline className="subuser_check" label="Payment" name="opayment" checked={FormData["opayment"]} onChange={handleChange} />
                          <Form.Check type="checkbox" inline className="subuser_check" label="Statement" name="ostatement" checked={FormData["ostatement"]} onChange={handleChange} />
                        </span>
                      </div>
                    </Col>
                    <Col lg={6}>
                      <div className="form-group row">
                        <span className="user_labeln"><Form.Label>Outstanding Export File:</Form.Label></span>
                        <span className="user_checkbox">
                          <Form.Check type="checkbox" className="subuser_check" name="outstanding_exportfile"
                            checked={FormData["outstanding_exportfile"]} onChange={handleChange} />
                        </span>
                      </div>
                    </Col>
                  </form>
                </Col>
              </Col>
            </div>

            <div
              className="box_detail"
              style={{ padding: "15px 0px 10px 0px", marginBottom: "20px" }}
            >
              <Col lg={12} style={{ padding: "0px" }}>
                <div className="page-header row no-gutters">
                  <Col md={12} style={{ color: "blue !important" }}>
                    <h3 className="page-title subtitile">MANAGE USER LIST</h3>
                  </Col>
                  <hr />
                </div>
              </Col>
              <Col lg={12}>
                <Col lg={12}>
                  <form className="formcon row main_forms" id="main_form">
                    <Col lg={6}>
                      <div className="form-group row">
                        <span className="user_labeln"><Form.Label>User Profile:</Form.Label></span>
                        <span className="user_checkbox">
                          <Form.Check type="checkbox" className="subuser_check" name="manage_profile"
                            checked={FormData["manage_profile"]} onChange={handleChange} />
                        </span>
                      </div>
                    </Col>
                  </form>
                </Col>
              </Col>
            </div>

            <div
              className="box_detail"
              style={{ padding: "15px 0px 10px 0px", marginBottom: "20px" }}
            >
              <Col lg={12} style={{ padding: "0px" }}>
                <div className="page-header row no-gutters">
                  <Col md={12} style={{ color: "blue !important" }}>
                    <h3 className="page-title subtitile">CHANGE PASSWORD</h3>
                  </Col>
                  <hr />
                </div>
              </Col>
              <Col lg={12}>
                <Col lg={12}>
                  <form className="formcon row main_forms" id="main_form">
                    <Col lg={6}>
                      <div className="form-group row">
                        <span className="user_labeln"><Form.Label>Change Password:</Form.Label></span>
                        <span className="user_checkbox">
                          <Form.Check type="checkbox" className="subuser_check" name="change_password"
                            checked={FormData["change_password"]} onChange={handleChange} />
                        </span>
                      </div>
                    </Col>

                    <Col lg={12}>
                      <Row>
                        <Col lg={6}>
                          <Row className="form-group">
                            <span className="user_labeln change_ps"><Form.Label></Form.Label></span>
                            <span className="user_checkbox">
                              <button className="submit subuser_submit" onClick={onSubmit}>SUBMIT</button>
                            </span>
                          </Row>
                        </Col>
                      </Row>
                    </Col>
                  </form>
                </Col>
              </Col>
            </div>
          </Col>
        </Col>
      </main>
      <Model
        text={ErrModel}
        open={isOpen}
        onClose={() => setIsOpen(false)}
      />
    </>
  )
}

export default SubuserPermission
