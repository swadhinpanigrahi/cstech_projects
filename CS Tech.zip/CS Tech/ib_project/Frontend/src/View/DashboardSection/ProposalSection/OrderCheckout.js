import React, { useState, useEffect } from 'react';
import * as RB from 'react-bootstrap';
import { useHistory, Link, useParams } from 'react-router-dom';
import {
    getCartDetails_FATCH, DeleteFromCart, GetUserDetailsForOrder,
    InserOrderAPI
} from "../../../Utils/api";
import Cookie from "js-cookie";
import { OrderCheckoutForm } from '../../../Components/Forms/FormElements';
import Modal from "../../../Components/Common/Modal";

export const OrderCheckout = () => {
    const history = useHistory();
    const { CS_username } = useParams()

    const [FormData, setFormData] = useState({});
    const [AddItemInCart, setAddItemInCart] = useState([]);
    const [totalAmount, setTotalAmount] = useState("");
    const [TaxAmt, setTaxAmt] = useState("");

    const [isOpen, setIsOpen] = useState(false);
    const [ModelMsg, setModelMsg] = useState("");

    const modelSet = () => {
        setIsOpen(true);
    };

    const handleChange = (e) => {
        let { name, value, type } = e.target;
        if (type !== "checked" && type !== "radio") {
            const data = { ...FormData };
            data[name] = value;
            setFormData(data);
        }
        if (type === "radio") {
            const data = { ...FormData };
            data[name] = value;
            setFormData(data);
        }
    }

    const DeleteCart = async (imageDetail) => {
        const email = Cookie.get("email");
        const FormData = { CS_username: email, CS_imgCode: imageDetail.CS_imgCode };
        const res = await DeleteFromCart(FormData);
        let { status, message } = res
        if (status === 200) {
            const CS_username = Cookie.get("email");
            const res = await getCartDetails_FATCH(CS_username);
            let { ImageDetails } = res;
            setAddItemInCart(ImageDetails)
        }
    }

    const onSubmit = async (e) => {
        e.preventDefault();
        const T_username = await Cookie.get("email");
        console.log({ ...FormData, f_orderAmt: totalAmount, ImageArray: AddItemInCart, T_username });
        const res = await InserOrderAPI({ ...FormData, f_orderAmt: totalAmount, ImageArray: AddItemInCart, T_username });
        let { status, message } = res;
        if (status === 200) {
            setModelMsg(message);
            modelSet();
            setTimeout(() => {
                history.push("/dashboard/order/get")
            }, 1000)
        }
    }

    useEffect(() => {
        const getDetails = async () => {
            const CS_username = Cookie.get("email");
            const res = await getCartDetails_FATCH(CS_username);
            let { ImageDetails } = res;
            setAddItemInCart(ImageDetails);
            let price = 0
            ImageDetails.forEach((element) => price = price + element.CS_Price);
            let tex = price * (18 / 100);
            setTaxAmt(tex)
            let netPayble = tex + price;
            setTotalAmount(netPayble)
        }
        getDetails();
    }, []);

    useEffect(() => {
        const apiCall = async () => {
            const res = await GetUserDetailsForOrder(CS_username);
            let { status, userData } = res;
            if (status === 200) {
                console.log(userData)
                setFormData(userData);
            }
        }
        apiCall()
    }, [])

    return (
        <>
            <RB.Row className="rownew1">
                <RB.Col lg={12}>
                    <RB.Row className="page_header1 rownew1">
                        <div className="tableHeader tableHeader1 search_new">
                            <RB.Col md={12} className="table_span">
                                <h3 className="page-title d-flex userv">
                                    <span>Order Checkout</span>
                                </h3>
                            </RB.Col>
                        </div>
                    </RB.Row>
                </RB.Col>

                <RB.Col lg={7}>
                    <div className="box_detail"
                        style={{
                            paddingLeft: "0px",
                            paddingRight: "0px",
                            borderRadius: "4px",
                            paddingTop: "0px",
                        }}
                    >
                        <div className="page-header row no-gutters inside_header">
                            <div className="col-md-12">
                                <h3
                                    className="page-title"
                                    style={{
                                        color: "#000",
                                        marginBottom: "0px",
                                        paddingBottom: "0px",
                                        fontSize: "1.5rem",
                                    }}>
                                    Re-Confirm Billing Address
                                </h3>
                            </div>
                        </div>
                        <hr className="m-t-25 m-b-25" />
                        {OrderCheckoutForm.map((data, inx) => {
                            let { label, type, icon, formt, name, controlId } = data;
                            return (
                                <>

                                    {formt === "false" ?
                                        <div className="form-body">
                                            <RB.Row className="order_checkform firstcheck">
                                                <RB.Col lg={6} style={{ paddingLeft: "0px" }}>
                                                    <span className="name_text">{label} :</span>
                                                </RB.Col>
                                                {name === "t_disc_price"
                                                    ?
                                                    <RB.Col lg={6} style={{ paddingLeft: "0px" }}>
                                                        <RB.Form.Control
                                                            type={type}
                                                            name={name}
                                                            className="value_text"
                                                            onChange={handleChange}
                                                        />
                                                    </RB.Col>
                                                    :
                                                    <RB.Col lg={6} style={{ paddingLeft: "0px" }}>
                                                        <span className="value_text">{FormData[name]}</span>
                                                    </RB.Col>
                                                }

                                            </RB.Row>
                                        </div>
                                        :
                                        <div className="form-body">
                                            <RB.Form.Group as={RB.Row} controlId={controlId} key={controlId + inx} className="order_checkform secondcheck">
                                                <RB.Col lg={6} style={{ paddingLeft: "0px" }}>
                                                    <span className="name_text">{label}{icon} :</span>
                                                </RB.Col>
                                                <RB.Col lg={6} style={{ paddingLeft: "0px" }}>
                                                    <RB.Form.Control
                                                        type={type}
                                                        name={name}
                                                        disabled="disabled"
                                                        className="value_text"
                                                        value={FormData[name]}
                                                    />
                                                </RB.Col>
                                            </RB.Form.Group>
                                        </div>

                                    }
                                </>
                            )

                        })}
                        <RB.Col lg={12} className="form-body">
                            <p className="text-danger order_checkpara">
                                This will enable to avail credit of the taxes to be charged on services directly to your account as per GST regulations.
                            </p>
                        </RB.Col>
                        <RB.Form.Group as={RB.Row} className="order_checkform secondcheck form-body">
                            <RB.Col lg={6}>
                                <span className="name_text">Client/Designated End User<span style={{ color: "red" }}>*</span> :</span>
                            </RB.Col>
                            <RB.Col lg={6}>
                                <RB.Form.Control
                                    type="text"
                                    name="client_name"
                                    className="value_text"
                                    onChange={handleChange}
                                />
                            </RB.Col>
                        </RB.Form.Group>
                        <RB.Col lg={12}>
                            <p className="text-danger order_checkpara">
                                [The "Client/Designated End User" means the specific product, service or entity that is being promoted by the use of the item. It is important to name PRECISELY the intended end-user so that you do, indeed, secure the rights you actually need.]
                            </p>
                        </RB.Col>
                    </div>
                </RB.Col>

                <RB.Col lg={5}>
                    <div className="box_detail"
                        style={{
                            paddingLeft: "0px",
                            paddingRight: "0px",
                            borderRadius: "4px",
                            paddingTop: "0px",
                        }}
                    >
                        <div className="page-header row no-gutters inside_header">
                            <div className="col-md-12">
                                <h3
                                    className="page-title"
                                    style={{
                                        color: "#000",
                                        marginBottom: "0px",
                                        paddingBottom: "0px",
                                        fontSize: "1.5rem",
                                    }}>
                                    Order Summary
                                </h3>
                            </div>
                        </div>
                        <hr className="m-t-25 m-b-25" />
                        <div className="proposal_checkpayment">
                            {AddItemInCart.map((data, inx) => {
                                return (
                                    <RB.Col lg={12} key={`CONFIRM_ORDER_CART${inx}`}>
                                        <RB.Row className="proposal_checkrow">
                                            <RB.Col lg={12} xl={5} md={4} xs={12} className="img_checkoutop">
                                                <img className="img_dtlimg" src={`https://ibcdn.imagesbazaar.com/img170/${data.CS_imgId}-${data.CS_imgCode}.jpg`} alt="large_im2" />
                                            </RB.Col>
                                            <RB.Col lg={12} xl={7} md={8} xs={12} className="checkout_item">
                                                <RB.Row className="mglr-0">
                                                    <RB.Col lg={12} md={12} xs={12}>
                                                        <span>Image ID : <strong>{data.CS_imgCode}</strong></span>
                                                    </RB.Col>
                                                </RB.Row>
                                                <RB.Row className="mglr-0">
                                                    <RB.Col lg={12} md={12} xs={12}>
                                                        <span>Image Type : <strong>{data.CS_ImgType}</strong></span>
                                                    </RB.Col>
                                                </RB.Row>
                                                <RB.Row className="mglr-0">
                                                    <RB.Col lg={12} md={12} xs={12}>
                                                        <span>Amount (INR) : <strong>{data.CS_Price}</strong></span>
                                                    </RB.Col>
                                                </RB.Row>
                                                <RB.Row className="mglr-0">
                                                    <RB.Col lg={12} md={12} xs={12}>
                                                        <span>File Type :

                                                            {data.CS_ImgType === "LARGE" || data.CS_ImgType === "MEDIUM" ? <strong> TIFF</strong> : ""}
                                                            {data.CS_ImgType === "SMALL" || data.CS_ImgType === "WEB" ? <strong> JPEG</strong> : ""}



                                                        </span>
                                                    </RB.Col>
                                                </RB.Row>
                                            </RB.Col>
                                        </RB.Row>

                                    </RB.Col>
                                )
                            })}
                        </div>

                    </div>

                    <div className="box_detail"
                        style={{
                            paddingLeft: "0px",
                            paddingRight: "0px",
                            borderRadius: "4px",
                            paddingTop: "0px",
                        }}
                    >
                        <div className="page-header row no-gutters inside_header">
                            <div className="col-md-12">
                                <h3
                                    className="page-title"
                                    style={{
                                        color: "#000",
                                        marginBottom: "0px",
                                        paddingBottom: "0px",
                                        fontSize: "1.5rem",
                                    }}>
                                    Your Proposal Cart Amount
                                </h3>
                            </div>
                        </div>
                        <hr className="m-t-25 m-b-25" />
                        <RB.Col lg={12}>
                            <p className="total_paycheck">
                                <span className="total_paycheck1">Tax Amount @ 18%:</span>
                                <span className="total_paycheck2"><strong> INR {TaxAmt}</strong></span>
                            </p>
                            <p className="total_paycheck">
                                <span className="total_paycheck1">Total Amount Payable (Incl Tax) :</span>
                                <span className="total_paycheck2"><strong> INR {totalAmount}</strong></span>
                            </p>
                        </RB.Col>
                    </div>
                </RB.Col>

                <RB.Col lg={12}>
                    <div className="box_detail" style={{ borderRadius: "4px" }}>
                        <RB.Col md={12} className="Image_detailsp">
                            <h3 className="imgdetail-title">
                                <span>Payment Mode</span>
                            </h3>
                        </RB.Col>
                        <hr className="line_break" />
                        <RB.Form as={RB.Row} style={{ margin: "0px 0px 15px 0px" }}>
                            {["Cheque/Demand Draft", "NEFT/RTGS/Wire Transfer"].map((info, inx) => {
                                return (
                                    <RB.Col lg={3} key={`RADIO_ORDER${inx}`}>
                                        <RB.Form.Check className="radio_orderc">
                                            <RB.Form.Check.Input type="radio" value={info} name="T_paymode" onChange={handleChange} />
                                            <RB.Form.Check.Label>{info}</RB.Form.Check.Label>
                                        </RB.Form.Check>
                                    </RB.Col>
                                )
                            })}
                        </RB.Form>
                        <RB.Col lg={12} className="text-center" style={{ marginTop: "20px" }}>
                            <RB.Button
                                className="btn btn-sub"
                                onClick={onSubmit}
                            >
                                CONFIRM ORDER
                            </RB.Button>
                            &nbsp;
                            <Link to="/dashboard/Proposal/create" className="btn btn-sub">Back</Link>
                        </RB.Col>
                    </div>
                </RB.Col>

            </RB.Row>
            <Modal text={ModelMsg} open={isOpen} onClose={() => setIsOpen(false)} />

        </>
    )
}

export default OrderCheckout