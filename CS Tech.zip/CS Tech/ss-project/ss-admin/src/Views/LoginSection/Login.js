import React, { useState } from "react";
import logo from "../../Images/final_logon.png";
import { Form } from "react-bootstrap";
import { useAuth } from "../../Utils/auth";
import { logInApi } from "../../Utils/api";
import { loginForm } from "../../Components/FormData/FormElements";
import { useHistory, useLocation, Link } from "react-router-dom";
import { authLoginValidetor } from "../../Utils/FormValidetor";

const Login = () => {
  const history = useHistory();
  let location = useLocation();
  let auth = useAuth();
  const [FormData, setFormData] = useState({});
  const [Errors, setErrors] = useState({
    errors: {},
    errMsg: "",
    errClr: "",
  });

  const handleChange = (e) => {
    let { name, value } = e.target;
    const data = { ...FormData };
    data[name] = value;
    setFormData(data);
    const updateError = { ...Errors };
    updateError.errors = authLoginValidetor(data);
    updateError.errMsg = "";
    updateError.errClr = "";
    setErrors({ ...updateError });
  };

  let { from } = location.state || {
    from: { pathname: "/dashboard/analytical" },
  };

  const onSubmit = async (e) => {
    e.preventDefault();
    if (FormData["username"] && FormData["password"]) {
      const res = await logInApi(FormData);
      const { status, message, error } = res;
      if (!error) {
        if (status === 200) {
          auth.signin(() => {
            history.replace(from);
          });
        } else {
          const updatedError = { ...Errors };
          updatedError.errMsg = message;
          setErrors({ ...updatedError });
        }
      } else {
        const updatedError = { ...Errors };
        updatedError.errMsg = "Network Error!!";
        setErrors({ ...updatedError });
      }
    } else {
      const updatedError = { ...Errors };
      updatedError.errors = authLoginValidetor(FormData);
      updatedError.errMsg = "";
      updatedError.errClr = "border-danger";
      setErrors({ ...updatedError });
    }
  };

  let { errors, errMsg, errClr } = Errors;

  return (
    <>
      <div id="signin">
        <div className="logo">
          <img src={logo} alt="Storage Station" className="new_logod" />
        </div>
        <div className="boxes">
          <h4 className="title">Sign in with your ID</h4>
          <Form.Text className="text-danger">{errMsg ? errMsg : ""}</Form.Text>
          <Form id="form" onSubmit={onSubmit}>
            {loginForm.map((data, inx) => {
              let { name, type, placeholder, controlId } = data;
              return (
                <Form.Group controlId={controlId} key={inx + controlId}>
                  {/* <Form.Label>Email address</Form.Label> */}
                  <Form.Control
                    type={type}
                    placeholder={placeholder}
                    name={name}
                    className={errClr ? errClr : ""}
                    onChange={handleChange}
                  />
                  {errors[name] && (
                    <Form.Text className="text-danger">
                      {errors[name]}
                    </Form.Text>
                  )}
                </Form.Group>
              );
            })}
            <div className="form-group">
              <button className="btn-login" type="submit">
                SIGN IN
              </button>
            </div>
            <div className="forgot">
              <Link to="/sendemailtogetlink">Forgot Password?</Link>
            </div>
          </Form>
        </div>
        <div className="copy">
          copyright © 2021 www.storagestation.net, all rights reserved
        </div>
      </div>
    </>
  );
};

export default Login;
