const mongoose = require("mongoose");

const t_TUR0615518_IB_MongoDB_Schema = mongoose.Schema(
  {
    f_sno: { type: String },
    CS_userid: { type: String },
    CS_firstname: { type: String },
    CS_lastname: { type: String },
    CS_jobdesc: { type: String },
    CS_companynames: { type: String },
    CS_businesstype: { type: String },
    CS_country: { type: String },
    CS_address: { type: String },
    CS_state: { type: String },
    CS_pin: { type: String },
    CS_phone: { type: String },
    CS_mobile: { type: String },
    CS_subscribe: { type: String },
    CS_active: { type: Boolean },
    CS_lightboxname: { type: String },
    CS_comment: { type: String },
    cs_date: { type: Date },
    cs_discount: { type: String },
    cs_info: { type: String },
    cs_ecashamt: { type: Number },
    cs_status: { type: Boolean },
    cs_gold: { type: Boolean },
    cs_ccmail: { type: String },
    cs_proposal: { type: Boolean },
    cs_performaUser: { type: Boolean },
    cs_Commission: { type: Boolean },
    cs_subscriptionccmail: { type: String },
    cs_SubscriptionDiscount: { type: Boolean },
    f_Subscriptionconnectedto: { type: String },
    sortcmp_name: { type: String, lowercase: true, default: "" },
    Identify_User: { type: String },
    group_cmpname: { type: String },
    Identify_date: { type: Date },
    f_exclude: { type: Boolean },
    act_highres: { type: Boolean },
    ip_address: { type: String },
    limit_img: { type: Number },
    f_addcmpname: { type: String },
    f_pan: { type: String },
    ivs_download: { type: Boolean },
  },
  { collection: "t_TUR0615518_IB_MongoDB" }
);

module.exports = t_TUR0615518_IB_MongoDB = mongoose.model(
  "t_TUR0615518_IB_MongoDB",
  t_TUR0615518_IB_MongoDB_Schema
);
