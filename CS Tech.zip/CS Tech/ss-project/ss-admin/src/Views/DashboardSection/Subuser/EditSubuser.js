import React, { useState, useEffect } from "react";
import { AuthEditForm } from "../../../Components/FormData/FormElements";
import { Form, Row, Col } from 'react-bootstrap'
import Model from "../../../Components/Common/Model";
import { useParams, useHistory } from 'react-router-dom'
import { authProfiledValidetor } from '../../../Utils/FormValidetor';
import { getSubUserDetails, editSubUserDetails } from "../../../Utils/api";

const EditSubuser = () => {
    const { _id } = useParams();
    const history = useHistory()
    const [FormData, setFormData] = useState({});
    const [isOpen, setIsOpen] = useState(false);
    const [ErrModel, setErrModel] = useState("");
    const [Password, setPassword] = useState("password");
    const [Errors, setErrors] = useState({
        errors: {},
        errMsg: "",
        errClr: "",
    });

    const changePasswordType = () => {
        Password === "password" ? setPassword("text") : setPassword("password")
    }

    const handleChange = (e) => {
        let { name, value } = e.target;
        let data = { ...FormData };
        data[name] = value;
        setFormData(data);
        const updateError = { ...Errors };
        updateError.errors = authProfiledValidetor(data);
        updateError.errMsg = "";
        updateError.errClr = "";
        setErrors({ ...updateError });
    };

    const onSubmit = async (e) => {
        e.preventDefault();
        if (FormData["firstName"] && FormData["lastName"] && FormData["emailId"] && FormData["mobileNo"] && FormData["companyName"]) {
            const res = await editSubUserDetails(_id, FormData);
            console.log(_id, FormData)
            let { error, message } = res
            if (!error && message) {
                setErrModel(message)
                modelSet();
                setTimeout(() => { history.push("/dashboard/subuser/get") }, 1000)
            } else {
                setErrModel("network error!")
                modelSet()
            }
        } else {
            const updatedError = { ...Errors };
            updatedError.errors = authProfiledValidetor(FormData);
            updatedError.errMsg = "";
            updatedError.errClr = "border-danger";
            setErrors({ ...updatedError });
        }
    };

    useEffect(() => {
        const apiCall = async () => {
            const res = await getSubUserDetails(_id);
            let { useData } = res;
            console.log(useData);
            setFormData(useData)
        }
        apiCall()
    }, []);

    const modelSet = () => {
        setIsOpen(true);
    };

    let { errors, errMsg, errClr } = Errors;

    return (
        <div>
            <main className="">
                <div className="container-fluid">
                    <div className="col-12">
                        <div
                            className="page-header row no-gutters pym-4"
                            style={{ paddingBottom: ".5rem!important" }}
                        >
                            <div className="col-md-12">
                                <h3 className="page-title">Sub-Admin Manage Profile</h3>
                            </div>
                            <hr />
                        </div>
                    </div>
                    <div className="col-md-12">
                        <div className="box_detail">
                            <div className="row" style={{ padding: "20px 30px" }}>
                                <div className="col-md-12">
                                    <Form.Text className="text-danger">{errMsg ? errMsg : ""}</Form.Text>
                                    <form className="formcon" action="customer.html">
                                        {AuthEditForm.map((data, inx) => {
                                            let { label, name, type, placeholder, controlId } = data;
                                            return (
                                                <Form.Group as={Row} controlId={controlId} key={"AUTHCHANGEPASS" + inx}>
                                                    <Form.Label column sm="2">
                                                        {label}
                                                    </Form.Label>
                                                    <Col sm="5">
                                                        <Form.Control type={type} name={name}
                                                            placeholder={placeholder} value={FormData[name]}
                                                            onChange={handleChange}
                                                            className={errClr ? errClr : ""}
                                                        />
                                                        {errors[name] && (
                                                            <Form.Text className="text-danger">
                                                                {errors[name]}
                                                            </Form.Text>
                                                        )}
                                                    </Col>
                                                </Form.Group>
                                            )
                                        })}
                                        <div className="row">
                                            <div
                                                className="form-group col-lg-6 col-md-12"
                                                style={{ marginBottom: "0rem" }}
                                            >
                                                <div className="row">
                                                    <div className="col-md-4"></div>
                                                    <div className="col-md-8">
                                                        <button className="submit" onClick={onSubmit}>
                                                            SUBMIT
                                                        </button>
                                                        <Model
                                                            text={ErrModel}
                                                            open={isOpen}
                                                            onClose={() => setIsOpen(false)}
                                                        />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    );
};

export default EditSubuser;

