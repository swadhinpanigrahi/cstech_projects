import React, { useState, useEffect } from 'react';
import * as RB from 'react-bootstrap';
import { Form, Button, Row } from "react-bootstrap";
import imagec from "../../../Images/imagec.png";
import { IoIosArrowBack } from "react-icons/io";
import { useParams, Link } from "react-router-dom"
import {
    getInvoiceDetail, InvoiceEditAPI, InvoicedropData, InvoiceGroupData
} from "../../../Utils/api";
import { state } from "../../../Utils/state"
import Moment from 'moment';

let items = [];

export const InvoiceEdit = () => {
    const { f_orderid } = useParams();

    const [Invoice, setInvoice] = useState({
        find_info_mail: false
    });
    const [InvoiceArray, setInvoiceArray] = useState([]);

    const [suggestions, setSuggestions] = useState([]);
    const [text, setText] = useState("");
    const [ForClose, setForClose] = useState(false);

    const [TotalAmount, setTotalAmount] = useState("")

    const handleChange = (e) => {
        let { name, value, type, checked } = e.target;
        if (type !== "checkbox") {
            const Data = { ...Invoice };
            Data[name] = value;
            setInvoice(Data);
        }
        if (type === "checkbox") {
            const Data = { ...Invoice };
            Data[name] = checked;
            setInvoice(Data);
        }
    };

    const onOrderUpdate = async (e) => {
        e.preventDefault();
        const res = await InvoiceEditAPI(f_orderid, Invoice);
        let { status, message } = res;
    }

    /**
     * SUGGESTIONS
    */
    const onTextChanged = (e) => {
        const value = e.target.value;
        let suggestions = [];
        if (value.length > 0) {
            const regex = new RegExp(`^${value}`, "i");
            suggestions = items.sort().filter((v) => regex.test(v));
        }
        setSuggestions(suggestions);
        setText(value);
    };

    const suggestionsSelected = async (value) => {
        setSuggestions([]);
        setText(value);
        const res = await InvoiceGroupData({ CS_companynames: value });
        let { GroupData } = res;
        setInvoice({
            ...Invoice,
            ...{
                CS_companynames: GroupData.CS_companynames,
                group_cmpname: GroupData.group_cmpname,
            },
        });
    };

    const renderSuggestions = () => {
        if (suggestions.length === 0) {
            return null;
        }
        return (
            <ul className="auto_drop">
                {suggestions.map((item, inx) => (
                    <li key={`LIST${inx}`}
                        onClick={() => suggestionsSelected(item)}
                    >
                        {item}
                    </li>
                ))}
            </ul>
        );
    };

    const ClickForClose = () => {
        setForClose(!ForClose);
    };

    useEffect(() => {
        setSuggestions([]);
    }, [ForClose]);

    useEffect(() => {
        const apiCall = async () => {
            const res = await getInvoiceDetail(f_orderid);
            let { invoiceDetail, invoiceDetails, T_orderDetails, LUS, TUR } = res;
            setInvoice({ ...Invoice, ...invoiceDetail, ...T_orderDetails, ...LUS, ...TUR });
            setInvoiceArray(invoiceDetails);
            console.log("Invoice", Invoice)
            let TotalAmount = 0;
            invoiceDetails.forEach(element => TotalAmount = TotalAmount + element.f_price);
            setTotalAmount(TotalAmount)
        }
        const apiCall1 = async () => {
            const res = await InvoicedropData();
            let { dropData } = res;
            dropData.forEach((drop) => {
                items.push(drop._id);
            });
        }
        apiCall();
        apiCall1();
    }, []);

    let TaxAmount = (TotalAmount / 100) * 18;

    return (
        <RB.Row className="rownew1">
            <RB.Col lg={12}>
                <RB.Row className="page_header1 rownew1">
                    <div className="tableHeader tableHeader1 search_new">
                        <RB.Col md={12} className="table_span">
                            <h3 className="page-title d-flex userv">
                                <span>Invoice Edit</span>
                            </h3>
                        </RB.Col>
                    </div>
                </RB.Row>
            </RB.Col>
            <RB.Col lg={12}>
                <div className="box_detail" style={{ borderRadius: "4px", paddingTop: "25px" }}>
                    <RB.Row style={{ paddingLeft: "25px", paddingRight: "25px" }}>
                        <RB.Col lg={12}>
                            <form>
                                <RB.Row>
                                    <RB.Col lg={6}>
                                        <RB.Container>
                                            <div className="main_orders">
                                                <RB.Row className="headinv" id="invoicem" style={{ borderBottom: "0px" }}>
                                                    <RB.Col lg={12} className=" pd_0">
                                                        <RB.Table responsive className="order_dtltablen">
                                                            <tbody>
                                                                <tr className="border_btm">
                                                                    <td className="td_first text-left">
                                                                        <p class="mg-b-0">
                                                                            <strong>Order Status:</strong> P
                                                                        </p>
                                                                    </td>
                                                                    <td className="td_second2 text-left">
                                                                        <tr>
                                                                            <td className="td_first text-left">
                                                                                <p class="mg-b-0">
                                                                                    <strong>Order Confirmation No.:</strong> P
                                                                                </p>
                                                                            </td>
                                                                            <td className="text-left">
                                                                                <p class="mg-b-0">
                                                                                    <strong>Date:</strong> {Moment(Invoice.invoice_date).format('DD-MM-YYYY')}
                                                                                </p>
                                                                            </td>
                                                                        </tr>
                                                                    </td>
                                                                </tr>
                                                                <tr className="border_btm">
                                                                    <td className="td_first">
                                                                        <p class="mg-b-0">
                                                                            <strong>Mode of Payment:</strong> <br />{Invoice.f_paymode}
                                                                        </p>
                                                                    </td>
                                                                    <td className="td_second text-left">
                                                                        <p class="mg-b-0">
                                                                            <strong>Name:</strong> <br />{Invoice.Name}
                                                                        </p>
                                                                    </td>
                                                                </tr>
                                                                <tr className="border_btm">
                                                                    <td className="td_first">
                                                                        <p class="mg-b-0">
                                                                            <Form.Group className="mb-0" controlId="formBasicEmail">
                                                                                <Form.Label><strong>Company Name: </strong></Form.Label>
                                                                                <Form.Control type="text" name="Companyname" value={Invoice.Companyname} onChange={handleChange} />
                                                                            </Form.Group>
                                                                        </p>
                                                                    </td>
                                                                    <td className="td_second text-left vertical_middle">
                                                                        <p class="mg-b-0">
                                                                            <Form.Group className="mb-0" controlId="formBasicEmail">
                                                                                <Form.Label><strong>Client:</strong></Form.Label>
                                                                                <Form.Control type="text" name="f_client" value={Invoice.f_client} onChange={handleChange} />
                                                                            </Form.Group>
                                                                        </p>
                                                                    </td>
                                                                </tr>
                                                                <tr className="border_btm">
                                                                    <td className="td_first text-left">
                                                                        <p class="mg-b-0">
                                                                            <strong>Telephone:</strong> 0124 4121000
                                                                        </p>
                                                                    </td>
                                                                    <td className="td_second text-left">
                                                                        <p class="mg-b-0">
                                                                            <strong>Mobile:</strong> {Invoice.CS_mobile}
                                                                        </p>
                                                                    </td>
                                                                </tr>
                                                                <tr className="border_btm">
                                                                    <td className="td_first text-left" colspan={2}>
                                                                        <p class="mg-b-0">
                                                                            <Form.Group className="mb-0" controlId="formBasicEmail">
                                                                                <Form.Label><strong>Comment:</strong></Form.Label>
                                                                                <Form.Control
                                                                                    type="text"
                                                                                    as="textarea"
                                                                                    name="CS_comment"
                                                                                    value={Invoice.CS_comment}
                                                                                    onChange={handleChange}
                                                                                />
                                                                            </Form.Group>
                                                                        </p>
                                                                    </td>
                                                                </tr>
                                                                <tr className="border_btm">
                                                                    <td className="td_first text-left">
                                                                        <p class="mg-b-0">
                                                                            <strong>Agency:</strong> <br />Agent
                                                                        </p>
                                                                    </td>
                                                                    <td className="td_second text-left">
                                                                        <p class="mg-b-0">
                                                                            <strong>Email:</strong> <br /> {Invoice.T_username}
                                                                        </p>
                                                                    </td>
                                                                </tr>
                                                                <tr className="border_btm">
                                                                    <td className="td_first">
                                                                        <p class="mg-b-0">
                                                                            <Form.Group className="mb-0" controlId="formBasicEmail">
                                                                                <Form.Label><strong>Address:</strong></Form.Label>
                                                                                <Form.Control
                                                                                    type="text"
                                                                                    as="textarea"
                                                                                    name="address"
                                                                                    value={Invoice.address}
                                                                                    onChange={handleChange}
                                                                                />
                                                                            </Form.Group>
                                                                        </p>
                                                                    </td>
                                                                    <td className="td_second text-left">
                                                                        <p class="mg-b-0">
                                                                            <Form.Group className="mb-0" controlId="formBasicEmail">
                                                                                <Form.Label><strong>Order By:</strong></Form.Label>
                                                                                <Form.Control
                                                                                    type="text"
                                                                                    name="orderby"
                                                                                    value={Invoice.orderby}
                                                                                    onChange={handleChange}
                                                                                    placeholder="Order..."
                                                                                />
                                                                            </Form.Group>
                                                                        </p>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </RB.Table>
                                                    </RB.Col>
                                                </RB.Row>

                                                <RB.Row className="headinv" id="invoicem" style={{ borderBottom: "0px" }}>
                                                    <RB.Col lg={12} className="pd_0 table_leftord">
                                                        <RB.Table responsive className="top_modaltable">
                                                            <thead>
                                                                <tr>
                                                                    <th className="td_first text-center">Image</th>
                                                                    <th className="td_first text-center">Item ID</th>
                                                                    <th className="td_first text-center">Image Type</th>
                                                                    <th className="td_first text-center">Rights</th>
                                                                    <th className="td_first text-center">Dimensions (Px)</th>
                                                                    <th className="text-right">Amount (Rs.)</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody className="order_modaltable">
                                                                {InvoiceArray.map((data, inx) => {
                                                                    return (
                                                                        <tr className="border_btm" key={`ORDER_INVOICE${inx}`}>
                                                                            <td className="td_first text-center">

                                                                                <img src={`https://ibcdn.imagesbazaar.com/img170/${data.f_rank}-${data.t_imageid}.jpg`} alt="invoiceimg" />
                                                                            </td>
                                                                            <td className="td_first text-center">
                                                                                <p class="mg-b-0">{data.f_imgname}</p>
                                                                            </td>
                                                                            <td className="td_first text-center">
                                                                                <p class="mg-b-0">{data.f_imagetype}</p>
                                                                            </td>
                                                                            <td className="td_first text-center">
                                                                                <p class="mg-b-0">{data.f_mydimension}</p>
                                                                            </td>
                                                                            <td className="td_first text-center">
                                                                                <p class="mg-b-0">{data.CS_ImgType_up}</p>
                                                                            </td>
                                                                            <td className="td_second text-right">
                                                                                <p class="mg-b-0">{data.f_price}</p>
                                                                            </td>
                                                                        </tr>
                                                                    )
                                                                })}
                                                            </tbody>



                                                        </RB.Table>
                                                        <RB.Table responsive>
                                                            <tbody className="amount_modalt">
                                                                <tr className="border_btm">
                                                                    <td className="text-right td_first" colSpan="">
                                                                        <p className="mg-b-0 resblock">
                                                                            <strong>Total Value (INR)</strong>
                                                                        </p>
                                                                    </td>
                                                                    <td className="text-right">
                                                                        <p class="mg-b-0"><strong>{TotalAmount}</strong></p>
                                                                    </td>
                                                                </tr>
                                                                <tr className="border_btm">
                                                                    <td className="text-right td_first" colSpan="">
                                                                        <p className="mg-b-0 resblock">
                                                                            <strong>Tax @ 18%</strong>
                                                                        </p>
                                                                    </td>
                                                                    <td className="text-right">
                                                                        <p class="mg-b-0"><strong>{TaxAmount}</strong></p>
                                                                    </td>
                                                                </tr>
                                                                <tr className="border_btm" style={{ borderBottom: "0px solid #707070" }}>
                                                                    <td className="text-right td_first" colSpan="" >
                                                                        <p className="mg-b-0 resblock">
                                                                            <strong>Net Payable Amount</strong>
                                                                        </p>
                                                                    </td>
                                                                    <td className="text-right">
                                                                        <p class="mg-b-0"><strong>{TotalAmount + TaxAmount}</strong></p>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </RB.Table>

                                                    </RB.Col>
                                                </RB.Row>
                                            </div>
                                        </RB.Container>
                                    </RB.Col>
                                    <RB.Col lg={6}>
                                        <RB.Container>
                                            <div className="main_orders right_half">
                                                <RB.Row className="headinv" id="invoicem" style={{ borderBottom: "0px" }}>
                                                    <RB.Col lg={12} className=" pd_0">
                                                        <RB.Table responsive className="order_dtltablen1">
                                                            <tbody className="right_table">
                                                                <tr className="border_btm">
                                                                    <td className="td_first">
                                                                        <p class="mg-b-0">
                                                                            <Form.Group as={Row} className="mb-0 mglr-0" controlId="formBasicEmail">
                                                                                <Form.Label className="col-lg-3 col-md-4"><strong>State:</strong></Form.Label>
                                                                                <Form.Control
                                                                                    className="col-lg-9 col-md-8"
                                                                                    type="text"
                                                                                    placeholder="Haryana"
                                                                                    name="f_statecrm"
                                                                                    value={Invoice.f_statecrm}
                                                                                    onChange={handleChange}
                                                                                />
                                                                            </Form.Group>
                                                                        </p>
                                                                    </td>
                                                                    <td className="td_second text-left">
                                                                        <p class="mg-b-0">
                                                                            <Form.Group as={Row}
                                                                                className="mb-0 mglr-0"
                                                                                controlId="formBasicEmail"
                                                                            >
                                                                                <RB.Form.Control as="select"
                                                                                    name="f_statecrm"
                                                                                    onChange={handleChange}
                                                                                >
                                                                                    <option value={Invoice.f_statecrm}>{Invoice.f_statecrm}</option>
                                                                                    {state.map((data, inx) => {
                                                                                        let { name } = data
                                                                                        return (
                                                                                            <option key={`INVOICE_EDIT_STATE${inx}`} value={name}>{name}</option>
                                                                                        )

                                                                                    })}
                                                                                </RB.Form.Control>
                                                                            </Form.Group>
                                                                        </p>
                                                                    </td>
                                                                </tr>
                                                                <tr className="border_btm">
                                                                    <td className="td_first">
                                                                        <p class="mg-b-0" onClick={ClickForClose}>
                                                                            <Form.Group className="mb-0" controlId="formBasicEmail">
                                                                                <Form.Label><strong>Search Company: </strong></Form.Label>
                                                                                <Form.Control
                                                                                    value={text}
                                                                                    onChange={onTextChanged}
                                                                                    type="text"
                                                                                />
                                                                                {renderSuggestions()}
                                                                            </Form.Group>
                                                                        </p>
                                                                    </td>
                                                                    <td className="td_second text-left vertical_middle">
                                                                        <p class="mg-b-0">
                                                                            <Form.Group as={Row} className="mb-0 mglr-0" controlId="formBasicEmail">
                                                                                <Form.Label className="col-lg-12 col-md-12 col-12"><strong>Find Information By Email:</strong></Form.Label>
                                                                                <Form.Check
                                                                                    className="col-lg-12 col-md-12 col-12"
                                                                                    type="checkbox"
                                                                                    name="find_info_mail"
                                                                                    checked={Invoice.find_info_mail}
                                                                                    onChange={handleChange}
                                                                                />
                                                                            </Form.Group>
                                                                        </p>
                                                                    </td>
                                                                </tr>
                                                                <tr className="border_btm">
                                                                    <td className="td_first text-left vertical_middle">
                                                                        <p class="mg-b-0">
                                                                            <strong>Company Name</strong>
                                                                        </p>
                                                                    </td>
                                                                    <td className="td_second text-left">
                                                                        <p class="mg-b-0">
                                                                            <Form.Group as={Row} className="mb-0 mglr-0" controlId="formBasicEmail">
                                                                                <Form.Control
                                                                                    className="col-lg-12 col-md-12"
                                                                                    type="text"
                                                                                    name="CS_companynames"
                                                                                    value={Invoice.CS_companynames}
                                                                                    onChange={handleChange}
                                                                                />
                                                                            </Form.Group>
                                                                        </p>
                                                                    </td>
                                                                </tr>
                                                                <tr className="border_btm">
                                                                    <td className="td_first text-left vertical_middle">
                                                                        <p class="mg-b-0">
                                                                            <strong>Company Group</strong>
                                                                        </p>
                                                                    </td>
                                                                    <td className="td_second text-left">
                                                                        <p class="mg-b-0">
                                                                            <Form.Group as={Row} className="mb-0 mglr-0" controlId="formBasicEmail">
                                                                                <Form.Control
                                                                                    className="col-lg-12 col-md-12"
                                                                                    type="text"
                                                                                    name="group_cmpname"
                                                                                    value={Invoice.group_cmpname}
                                                                                    onChange={handleChange}
                                                                                />
                                                                            </Form.Group>
                                                                        </p>
                                                                    </td>
                                                                </tr>
                                                                <tr className="border_btm">
                                                                    <td className="td_first vertical_middle">
                                                                        <p class="mg-b-0">
                                                                            <Form.Group as={Row} className="mb-0 mglr-0" controlId="formBasicEmail">
                                                                                <Form.Label className="col-lg-8 col-md-8"><strong>Invoice Discount</strong></Form.Label>
                                                                                <Form.Control
                                                                                    className="col-lg-3 col-md-3"
                                                                                    type="text"
                                                                                    name="cs_discount"
                                                                                    value={Invoice.cs_discount}
                                                                                    onChange={handleChange}
                                                                                />
                                                                                <span className="after_formt">%</span>
                                                                            </Form.Group>
                                                                        </p>
                                                                    </td>
                                                                    <td className="td_second text-left vertical_middle">
                                                                        <p class="mg-b-0">
                                                                            <Form.Group as={Row} className="mb-0 mglr-0 radio_btnc" controlId="formBasicEmail">
                                                                                <Form.Check inline label="All orders" name="group1" type="radio" checked />
                                                                                <Form.Check inline label="Only this order" type="radio" name="radio" />
                                                                            </Form.Group>
                                                                        </p>
                                                                    </td>
                                                                </tr>
                                                                <tr className="border_btm">
                                                                    <td className="td_first text-left vertical_middle">
                                                                        <p class="mg-b-0">
                                                                            <strong>Discount Type</strong>
                                                                        </p>
                                                                    </td>
                                                                    <td className="td_second text-left">
                                                                        <p class="mg-b-0">
                                                                            <Form.Group as={Row} className="mb-0 mglr-0" controlId="formBasicEmail">
                                                                                <RB.Form.Control as="select" name="f_discountType" onChange={handleChange}>
                                                                                    <option value={Invoice.f_discountType}>{Invoice.f_discountType}</option>
                                                                                    <option>Select Discount Type</option>
                                                                                    <option value="Commission">Commission</option>
                                                                                    <option value="Corporate Deal">Corporate Deal</option>
                                                                                    <option value="No Discount">No Discount</option>
                                                                                </RB.Form.Control>
                                                                            </Form.Group>
                                                                        </p>
                                                                    </td>
                                                                </tr>
                                                                <tr className="border_btm">
                                                                    <td className="td_first text-left vertical_middle">
                                                                        <p class="mg-b-0">
                                                                            <strong>User Type</strong>
                                                                        </p>
                                                                    </td>
                                                                    <td className="td_second text-left">
                                                                        <p class="mg-b-0">
                                                                            <Form.Group as={Row} className="mb-0 mglr-0 radio_btnc" controlId="formBasicEmail">
                                                                                <Form.Check inline label="New" name="group3" type="radio" />
                                                                                <Form.Check inline label="Existing" type="radio" checked name="group4" />
                                                                            </Form.Group>
                                                                        </p>
                                                                    </td>
                                                                </tr>
                                                                <tr className="border_btm">
                                                                    <td className="td_first text-left vertical_middle">
                                                                        <p class="mg-b-0">
                                                                            <strong>Credit Period</strong>
                                                                        </p>
                                                                    </td>
                                                                    <td className="td_second text-left">
                                                                        <p class="mg-b-0">
                                                                            <Form.Group as={Row} className="mb-0 mglr-0" controlId="formBasicEmail">
                                                                                <RB.Form.Control as="select" name="f_CreaditPeriod" onChange={handleChange}>
                                                                                    <option value={Invoice.f_CreaditPeriod}>{`${Invoice.f_CreaditPeriod} days`}</option>
                                                                                    <option>Select Credit Period</option>
                                                                                    <option value="0">0 day</option>
                                                                                    <option value="15">15 days</option>
                                                                                    <option value="30">30 days</option>
                                                                                </RB.Form.Control>
                                                                            </Form.Group>
                                                                        </p>
                                                                    </td>
                                                                </tr>
                                                                <tr className="border_btm">
                                                                    <td className="td_first text-left vertical_middle">
                                                                        <p class="mg-b-0">
                                                                            <strong>Approval Mode</strong>
                                                                        </p>
                                                                    </td>
                                                                    <td className="td_second text-left">
                                                                        <p class="mg-b-0">
                                                                            <Form.Group as={Row} className="mb-0 mglr-0" controlId="formBasicEmail">
                                                                                <RB.Form.Control as="select">
                                                                                    <option>Select Approval Mode</option>
                                                                                    <option>Cheque copy/deposit slip</option>
                                                                                    <option>PO</option>
                                                                                    <option>PDC</option>
                                                                                </RB.Form.Control>
                                                                            </Form.Group>
                                                                        </p>
                                                                    </td>
                                                                </tr>
                                                                <tr className="border_btm">
                                                                    <td className="td_first text-left vertical_middle">
                                                                        <p class="mg-b-0">
                                                                            <strong>Special Comments</strong>
                                                                        </p>
                                                                    </td>
                                                                    <td className="td_second text-left">
                                                                        <p class="mg-b-0">
                                                                            <Form.Group as={Row} className="mb-0 mglr-0" controlId="formBasicEmail">
                                                                                <Form.Control type="text" as="textarea" />
                                                                            </Form.Group>
                                                                        </p>
                                                                    </td>
                                                                </tr>
                                                                <tr className="border_btm">
                                                                    <td className="td_first text-left vertical_middle">
                                                                        <p class="mg-b-0">
                                                                            <strong>Additional Email</strong>
                                                                        </p>
                                                                    </td>
                                                                    <td className="td_second text-left">
                                                                        <p class="mg-b-0">
                                                                            <Form.Group as={Row} className="mb-0 mglr-0" controlId="formBasicEmail">
                                                                                <Form.Control className="col-lg-12 col-md-12" type="text" />
                                                                            </Form.Group>
                                                                        </p>
                                                                    </td>
                                                                </tr>
                                                                <tr className="border_btm">
                                                                    <td className="td_first text-left vertical_middle">
                                                                        <p class="mg-b-0">
                                                                            <strong>Closed by</strong>
                                                                        </p>
                                                                    </td>
                                                                    <td className="td_second text-left">
                                                                        <p class="mg-b-0">
                                                                            <Form.Group as={Row} className="mb-0 mglr-0" controlId="formBasicEmail">
                                                                                <RB.Form.Control as="select">
                                                                                    <option>CS</option>
                                                                                    <option>Sales</option>
                                                                                    <option>Exclude</option>
                                                                                    <option>Renew</option>
                                                                                </RB.Form.Control>
                                                                            </Form.Group>
                                                                        </p>
                                                                    </td>
                                                                </tr>
                                                                <tr className="border_btm">
                                                                    <td className="td_first text-left vertical_middle">
                                                                        <p class="mg-b-0">
                                                                            <strong>State For Change</strong>
                                                                        </p>
                                                                    </td>
                                                                    <td className="td_second text-left">
                                                                        <p class="mg-b-0">
                                                                            <Form.Group as={Row} className="mb-0 mglr-0" controlId="formBasicEmail">
                                                                                <RB.Form.Control as="select"
                                                                                    name="f_statecrm"
                                                                                    onChange={handleChange}
                                                                                >
                                                                                    <option value={Invoice.f_statecrm}>{Invoice.f_statecrm}</option>
                                                                                    {state.map((data, inx) => {
                                                                                        let { name } = data
                                                                                        return (
                                                                                            <option key={`INVOICE_EDIT_STATE${inx}`} value={name}>{name}</option>
                                                                                        )

                                                                                    })}
                                                                                </RB.Form.Control>
                                                                            </Form.Group>
                                                                        </p>
                                                                    </td>
                                                                </tr>
                                                                <tr className="border_btm">
                                                                    <td className="td_first text-left vertical_middle">
                                                                        <p class="mg-b-0">
                                                                            <strong>Client GSTIN No.</strong>
                                                                        </p>
                                                                    </td>
                                                                    <td className="td_second text-left">
                                                                        <p class="mg-b-0">
                                                                            <Form.Group as={Row} className="mb-0 mglr-0" controlId="formBasicEmail">
                                                                                <Form.Control
                                                                                    className="col-lg-12 col-md-12"
                                                                                    type="text"
                                                                                    name="f_clientGSTIN_no"
                                                                                    onChange={handleChange}
                                                                                    value={Invoice.f_clientGSTIN_no}
                                                                                />
                                                                            </Form.Group>
                                                                        </p>
                                                                    </td>
                                                                </tr>
                                                                <tr className="border_btm" style={{ borderBottom: "0px" }}>
                                                                    <td colspan="2">
                                                                        <p className="mg-b-0 resblock">
                                                                            <RB.Button size="sm" variant="primary" className="btn_svg mr-2" onClick={onOrderUpdate}>
                                                                                Order Update
                                                                            </RB.Button>
                                                                            <RB.Button size="sm" variant="primary" className="btn_svg btn-backconf ">
                                                                                <Link to="/dashboard/order/get">
                                                                                    <IoIosArrowBack />Back
                                                                                </Link>
                                                                            </RB.Button>
                                                                        </p>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </RB.Table>
                                                    </RB.Col>
                                                </RB.Row>

                                            </div>
                                        </RB.Container>
                                    </RB.Col>
                                </RB.Row>
                            </form>
                        </RB.Col>
                    </RB.Row>
                </div>
            </RB.Col>
        </RB.Row>
    )
}

export default InvoiceEdit