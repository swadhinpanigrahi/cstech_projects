import React, { useState, useEffect } from "react";
import {
  trakin_details,
  SMSAchangeStatusApi,
  getSMSAshipments,
} from "./Utils/api";

const CronjobSMSA = () => {
  const [Loading, setLoading] = useState(true);

  const changeStatusFORsmsa = async (element) => {
    await SMSAchangeStatusApi(element);
  };

  const smsa = async () => {
    const res = await getSMSAshipments();
    let { trakingDetails } = res;
    console.log(trakingDetails);
    trakingDetails.forEach(async (element, inx) => {
      let { tracking_number, shipping_method } = element;
      const trakData = await trakin_details(tracking_number, shipping_method);
      let { statuses, error } = trakData;
      console.log(inx, tracking_number, statuses);
      if (!error && statuses) {
        statuses.forEach(async (element) => {
          if (element !== undefined) {
            await changeStatusFORsmsa(element);
          }
        });
      }
    });
    setLoading(false);
  };

  useEffect(() => {
    smsa();
  }, []);

  return (
    <div>
      <h2>SMSA Script is running.....</h2>
      <p>{Loading ? "Loading..." : "Done"}</p>
    </div>
  );
};

export default CronjobSMSA;
