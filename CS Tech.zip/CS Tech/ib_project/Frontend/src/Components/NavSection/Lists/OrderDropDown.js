import React, { useState } from "react";
import { Link } from "react-router-dom";
import "../Dropdown.css";

const MenuItems = [
    {
        nto: "/dashboard/order/pendingorder/get",
        title: "Pending Order",
        cName: "dropdown-link"
    },
    {
        nto: "/dashboard/order/get",
        title: "Order",
        cName: "dropdown-link"
    },
    {
        nto: "/dashboard/proposal/get",
        title: "Proposal",
        cName: "dropdown-link"
    },
    {
        nto: "/dashboard/dailysalesentry",
        title: "Daily Sales",
        cName: "dropdown-link"
    },
]


const OrderDropDown = () => {

    const [click, setClick] = useState(false);

    const handleClick = () => setClick(!click)

    return (
        <>
            <ul onClick={handleClick} className={click ? "dropdown-menu clicked" : "dropdown-menu"}>
                {MenuItems.map((item, index) => {
                    return (
                        <li key={`ORDER_LIST_${index}`}>
                            <Link className={item.cName} to={item.nto} onClick={() => setClick(false)}>
                                {item.title}
                            </Link>
                        </li>
                    )
                })}
            </ul>
        </>
    )
}

export default OrderDropDown