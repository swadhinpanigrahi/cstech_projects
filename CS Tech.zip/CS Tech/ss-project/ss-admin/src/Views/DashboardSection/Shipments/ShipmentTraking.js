import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import {
  trakin_details,
  getShipmentDetailsForView,
  AllUpdateStatus
} from "../../../Utils/api";

const ShipmentTraking = () => {
  const { tracking_number } = useParams();

  const [PageData, setPageData] = useState({
    trakingObject: {},
    trakingArray: [],
  });

  const changeStatus = async (element) => {
    console.log("2nd element", element);
    await AllUpdateStatus(element);
  };

  useEffect(() => {
    const apiCall1 = async () => {
      const res1 = await getShipmentDetailsForView(tracking_number);
      let { trakingData, error } = res1;
      const res = await trakin_details(tracking_number, trakingData.shipping_method);
      let { statuses } = res;
      statuses.forEach((element) => {
        if (element !== undefined) {
          if (
            element.code === "SH005" ||
            element.code === "SH006" ||
            element.code === "SH007" ||
            element.code === "SH034" ||
            element.code === "SH154" ||
            element.code === "SH234" ||
            element.code === "SH496" ||
            element.code === "SH534" ||
            element.code === "SH597" ||
            element.code === "completed" ||
            element.code === "SH069" ||
            element.code === "SH407" ||
            element.code === "SH559" ||
            element.code === "PROOF OF DELIVERY CAPTURED"
          ) {
            changeStatus(element);
          }
        }
      });
    };

    apiCall1();
  }, [tracking_number]);

  useEffect(() => {
    const apiCall = async () => {
      const res = await getShipmentDetailsForView(tracking_number);
      let { trakingData, error } = res;
      const res1 = await trakin_details(tracking_number, trakingData.shipping_method);
      let { statuses } = res1;
      if (!error) {
        const updateData = { ...PageData };
        updateData.trakingObject = trakingData;

        if (statuses !== undefined) {
          updateData.trakingArray = statuses;
          setPageData({ ...updateData });
        } else {
          updateData.trakingArray = [];
          setPageData({ ...updateData });
        }
      } else {
        window.alert("network error!");
      }
    };
    setTimeout(() => {
      apiCall();
    }, 5000);
  }, []);

  let { trakingObject, trakingArray } = PageData;

  return (
    <>
      <div className="container-fluid">
        <div className="col-12">
          <div
            className="page-header row no-gutters pym-4"
            style={{ paddingBottom: ".5rem!important" }}
          >
            <div className="col-md-6">
              <h3 className="page-title">Track Shipment</h3>
            </div>
            <div className="col-md-6 text-right backb">
            </div>
            <hr />
          </div>
        </div>
        <div className="col-md-12">
          <div
            className="box_detail tableboxdc"
            style={{
              paddingTop: "0px",
              paddingBottom: "0px",
              marginBottom: "0px",
              borderRadius: "13px",
            }}
          >
            <table
              className="table table-bordered table-responsive"
              id="table-to-xls"
            >
              <thead className="thead-dark">
                <tr>
                  <th className="nhead ohead text-center">DATE</th>
                  <th className="ohead"> ORDER ID </th>
                  <th className="nhead"> ORDER NUMBER </th>
                  <th className="deshead">STATUS</th>
                  <th className="deshead nhead "> SHOP NAME </th>
                  <th className="nhead text-center"> TRACKING NUMBER </th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="nhead ohead text-center">
                    {trakingObject.createdAt}
                  </td>
                  <td className="ohead"> {trakingObject.order_id} </td>
                  <td className="nhead"> {trakingObject.order_number} </td>
                  <td className="deshead">
                    {trakingObject.fulfillment_status}
                  </td>
                  <td className="deshead nhead "> {trakingObject.shop_name}</td>
                  <td className="nhead text-center">
                    {trakingObject.tracking_number}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
      <div className="container-fluid">
        <div className="col-12">
          <div
            className="page-header row no-gutters pym-4"
            style={{ paddingBottom: ".5rem!important" }}
          >
            <div className="col-md-6">
              <h3 className="page-title">
                History (Where Your Shipment Has Been)
              </h3>
            </div>
            <div className="col-md-6 text-right backb">
            </div>
            <hr />
          </div>
        </div>
        <div className="col-md-12">
          <div
            className="box_detail tableboxdc"
            style={{
              paddingTop: "0px",
              paddingBottom: "0px",
              marginBottom: "0px",
              borderRadius: "13px",
            }}
          >
            <table
              className="table table-bordered table-responsive"
              id="table-to-xls"
            >
              <thead className="thead-dark">
                <tr>
                  <th className="ohead"> WAYBILL </th>
                  <th className="nhead"> CODE </th>
                  <th className="deshead">DESCRIPTION</th>
                  <th className="deshead nhead "> TIME </th>
                  <th className="nhead ohead">LOCATION</th>
                  <th className="nhead"> COMMENT </th>
                </tr>
              </thead>
              <tbody>
                {trakingArray.map((val, inx) => {
                  return (
                    <tr key={inx + "taking_id"}>
                      <td>{val.waybill}</td>
                      <td>{val.code}</td>
                      <td>{val.description}</td>
                      <td>{val.time}</td>
                      <td>{val.location}</td>
                      <td>{val.comment}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </>
  );
};

export default ShipmentTraking;
