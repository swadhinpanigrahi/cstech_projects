import React, { useState, useEffect } from 'react';
import { getDataForGraph } from "../../../Utils/api";
import CountCard from "./CountCard"

const Graph = () => {
    const [AnalaticData, setAnalaticData] = useState({
        graphArray: [],
        totalAmount: 0,
        balanceAmount: 0
    })

    useEffect(() => {
        const apiCall = async () => {
            const res = await getDataForGraph();
            let { graph, creditAmount, debitAmount } = res;
            const updatedState = { ...AnalaticData }
            updatedState.graphArray = graph;
            updatedState.totalAmount = creditAmount;
            updatedState.balanceAmount = debitAmount;
            setAnalaticData({ ...updatedState })
        }
        apiCall()
    }, [])

    return (
        <>
            <CountCard totalAmount={AnalaticData.totalAmount} balanceAmount={AnalaticData.balanceAmount} graph={AnalaticData.graphArray} />
        </>
    )
}

export default Graph
