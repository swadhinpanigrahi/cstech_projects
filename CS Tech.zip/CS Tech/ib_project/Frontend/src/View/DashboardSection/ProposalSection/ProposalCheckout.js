import React, { useState, useEffect } from 'react';
import * as RB from 'react-bootstrap';
import { ProposalForm } from '../../../Components/Forms/FormElements';
import { useHistory, useParams } from 'react-router-dom';
import { state } from '../../../Utils/state';
import {
    getCartDetails_FATCH, DeleteFromCart,
    FinalizeProposalAPI
} from "../../../Utils/api";
import Cookie from "js-cookie";

export const ProposalCheckout = () => {
    const history = useHistory();

    const [FormData, setFormData] = useState({});
    const [AddItemInCart, setAddItemInCart] = useState([]);
    const [TotalAmount, setTotalAmount] = useState(0);
    const [TaxAmt, setTaxAmt] = useState(0);
    const [NetAmount, setNetAmount] = useState(0);

    const [f_discount, setf_discount] = useState(0);

    const handleChange = (e) => {
        let { name, value } = e.target;
        if (name !== "f_discount") {
            const data = { ...FormData };
            data[name] = value;
            setFormData(data);
        } else {
            setf_discount(value)
        }

    }

    const DeleteCart = async (imageDetail) => {
        const email = Cookie.get("email");
        const FormData = { CS_username: email, CS_imgCode: imageDetail.CS_imgCode };
        const res = await DeleteFromCart(FormData);
        let { status, message } = res
        if (status === 200) {
            const CS_username = Cookie.get("email");
            const res = await getCartDetails_FATCH(CS_username);
            let { ImageDetails } = res;
            setAddItemInCart(ImageDetails)
        }
    }

    const onSubmit = async (e) => {
        e.preventDefault();
        const email = Cookie.get("email");
        console.log({ ...FormData, ImageArray: AddItemInCart, T_username: email, f_totimg: AddItemInCart.length, f_discount });
        const res = await FinalizeProposalAPI(
            { ...FormData, ImageArray: AddItemInCart, T_username: email, f_totimg: AddItemInCart.length, f_discount }
        )
        let { status } = res;
        if (status === 200) {
            history.push("/dashboard/proposal/print")
        }
    }

    useEffect(() => {
        const getDetails = async () => {
            const CS_username = Cookie.get("email");
            const res = await getCartDetails_FATCH(CS_username);
            let { ImageDetails } = res;
            setAddItemInCart(ImageDetails);
            let price = 0
            ImageDetails.forEach((element) => price = price + element.CS_Price);
            let tex = price * (18 / 100);
            let netPayble = tex + price;
            setTotalAmount(price);
            setTaxAmt(tex);
            setNetAmount(netPayble);
            setFormData({ ...FormData, f_amt: price, f_amtpay: price, f_sertax: tex, f_finalamt: netPayble })
        }
        getDetails();
    }, []);

    useEffect(() => {
        const ActualPrice = TotalAmount - f_discount;
        const Tax = ActualPrice * (18 / 100);
        const netPayble = ActualPrice + Tax;
        const updateFormData = { ...FormData };
        // updateFormData.f_amt = ActualPrice
        updateFormData.f_amtpay = ActualPrice
        updateFormData.f_sertax = Tax
        updateFormData.f_finalamt = netPayble;
        setFormData(updateFormData)
        setTaxAmt(Tax);
        setNetAmount(netPayble);
    }, [f_discount])

    return (
        <>
            <RB.Row className="rownew1">
                <RB.Col lg={12}>
                    <RB.Row className="page_header1 rownew1">
                        <div className="tableHeader tableHeader1 search_new">
                            <RB.Col md={12} className="table_span">
                                <h3 className="page-title d-flex userv">
                                    <span>Checkout Proposal</span>
                                </h3>
                            </RB.Col>
                            {/* <RB.Col md={6} className="table_span text-right">
                                <RB.Button
                                    as={Link}
                                    to="/dashboard/Proposal/create"
                                    className="back_proposal btn btn-sm"
                                ><AiOutlineArrowLeft />BACK
                                </RB.Button>
                            </RB.Col> */}
                        </div>
                    </RB.Row>
                </RB.Col>
                <RB.Col lg={7}>
                    <div className="box_detail"
                        style={{
                            paddingLeft: "0px",
                            paddingRight: "0px",
                            borderRadius: "4px",
                            paddingTop: "0px",
                        }}
                    >
                        <div className="page-header row no-gutters inside_header">
                            <div className="col-md-12">
                                <h3
                                    className="page-title"
                                    style={{
                                        color: "#000",
                                        marginBottom: "0px",
                                        paddingBottom: "0px",
                                        fontSize: "1.5rem",
                                    }}>
                                    Your Proposal Cart Details
                                </h3>
                            </div>
                        </div>
                        <hr className="m-t-25 m-b-25" />
                        <RB.Form>
                            <RB.Row style={{ margin: "0px" }}>
                                {ProposalForm.map((data, inx) => {
                                    let { type, controlId, name, placeholder, label, icon, disabled,maxLength } = data;
                                    return (
                                        <>
                                            {name === "f_state" ?
                                                <RB.Col lg={6} className="form-body">
                                                    <RB.Form.Group controlId={controlId} key={controlId + inx} className="proposal_formchk">
                                                        <label>{label}{icon} :</label>
                                                        <RB.Form.Control as="select" name={name} aria-label="Default select example" onChange={handleChange}>
                                                            <option>Select State</option>
                                                            {state.map((data, inx) => {
                                                                let { name } = data
                                                                return (
                                                                    <option key={`PROPOSAL_STATE${inx}`} value={name}>{name}</option>
                                                                )

                                                            })}

                                                        </RB.Form.Control>
                                                    </RB.Form.Group>
                                                </RB.Col>
                                                :
                                                <RB.Col lg={6} className="form-body">
                                                    <RB.Form.Group controlId={controlId} key={controlId + inx} className="proposal_formchk">
                                                        <label>{label}{icon} :</label>
                                                        <RB.Form.Control
                                                            type={type}
                                                            name={name}
                                                            placeholder={placeholder}
                                                            onChange={handleChange}
                                                            value={FormData[name]}
                                                            disabled={disabled}
                                                            maxLength={maxLength}
                                                        />
                                                    </RB.Form.Group>
                                                </RB.Col>
                                            }
                                        </>
                                    );
                                })}

                            </RB.Row>
                        </RB.Form>
                    </div>
                </RB.Col>
                <RB.Col lg={5}>
                    <div className="box_detail"
                        style={{
                            paddingLeft: "0px",
                            paddingRight: "0px",
                            borderRadius: "4px",
                            paddingTop: "0px",
                        }}
                    >
                        <div className="page-header row no-gutters inside_header">
                            <div className="col-md-12">
                                <h3
                                    className="page-title"
                                    style={{
                                        color: "#000",
                                        marginBottom: "0px",
                                        paddingBottom: "0px",
                                        fontSize: "1.5rem",
                                    }}>
                                    Order Summary
                                </h3>
                            </div>
                        </div>
                        <hr className="m-t-25 m-b-25" />

                        <div className="proposal_checkpayment">
                            {AddItemInCart.map((data, inx) => {

                                return (
                                    <RB.Col lg={12} key={`FINALISE_PROPOSAL${inx}`}>
                                        <RB.Row className="proposal_checkrow">
                                            <RB.Col lg={12} xl={5} md={4} xs={12} className="img_checkoutop">
                                                <img className="img_dtlimg" src={`https://ibcdn.imagesbazaar.com/img170/${data.CS_imgId}-${data.CS_imgCode}.jpg`} alt="large_im2" />
                                            </RB.Col>
                                            <RB.Col lg={12} xl={7} md={8} xs={12} className="checkout_item">
                                                <RB.Row className="mglr-0">
                                                    <RB.Col lg={12} md={12} xs={12}>
                                                        <span>Image ID : <strong>{data.CS_imgCode}</strong></span>
                                                    </RB.Col>
                                                </RB.Row>
                                                <RB.Row className="mglr-0">
                                                    <RB.Col lg={12} md={12} xs={12}>
                                                        <span>Image Type : <strong>{data.CS_ImgType}</strong></span>
                                                    </RB.Col>
                                                </RB.Row>
                                                <RB.Row className="mglr-0">
                                                    <RB.Col lg={12} md={12} xs={12}>
                                                        <span>Amount (INR) : <strong>{data.CS_Price}</strong></span>
                                                    </RB.Col>
                                                </RB.Row>
                                                <RB.Row className="mglr-0">
                                                    <RB.Col lg={12} md={12} xs={12}>
                                                        <span>File Type :
                                                            {data.CS_ImgType === "LARGE" || data.CS_ImgType === "MEDIUM" ? <strong> TIFF</strong> : ""}
                                                            {data.CS_ImgType === "SMALL" || data.CS_ImgType === "WEB" ? <strong> JPEG</strong> : ""}
                                                        </span>
                                                    </RB.Col>
                                                </RB.Row>
                                            </RB.Col>
                                        </RB.Row>
                                    </RB.Col>
                                )
                            })}
                        </div>

                    </div>


                    <div className="box_detail"
                        style={{
                            paddingLeft: "0px",
                            paddingRight: "0px",
                            borderRadius: "4px",
                            paddingTop: "0px",
                        }}
                    >
                        <div className="page-header row no-gutters inside_header">
                            <div className="col-md-12">
                                <h3
                                    className="page-title"
                                    style={{
                                        color: "#000",
                                        marginBottom: "0px",
                                        paddingBottom: "0px",
                                        fontSize: "1.5rem",
                                    }}>
                                    Your Order Cart Amount
                                </h3>
                            </div>
                        </div>
                        <hr className="m-t-25 m-b-25" />
                        <RB.Col lg={12} className="form-body">
                            <p className="total_paycheck">
                                <span className="total_paycheck1">Tax Amount @ 18% : </span>
                                <span className="total_paycheck2"><strong>{`INR ${TaxAmt}`}</strong></span>
                            </p>
                            <p className="total_paycheck">
                                <span className="total_paycheck1">Total Amount Payable (Incl Tax) : </span>
                                <span className="total_paycheck2"><strong>{`INR ${NetAmount}`}</strong></span>
                            </p>
                        </RB.Col>
                    </div>

                    <div className="demo-btn-group col-md-12 pd-r-0 float-right" id="probtnt">
                        <RB.Button size="sm" variant="primary" onClick={onSubmit}>CONFIRM ORDER</RB.Button>
                    </div>
                </RB.Col>
            </RB.Row>
        </>
    )
}

export default ProposalCheckout
