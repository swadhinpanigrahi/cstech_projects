const Mongoose = require("mongoose")

const submodelPermisionModel = new Mongoose.Schema(
    {
        userId: { type: String },
        dashboard: {
            dashboard_graph: { type: Boolean, default: true },
            order_list: { type: Boolean, default: true },
            register_list: { type: Boolean, default: true }
        },
        customers: {
            customers_viewlist: { type: Boolean, default: true },
            customers_exportfile: { type: Boolean, default: true },
            customers_action: {
                add: { type: Boolean, default: true },
                edit: { type: Boolean, default: true },
                active: { type: Boolean, default: true },
                payment: { type: Boolean, default: true },
                statement: { type: Boolean, default: true },
            }
        },
        shipments: {
            shipments_viewlist: { type: Boolean, default: true },
            shipments_exportfile: { type: Boolean, default: true },
            shipments_track: { type: Boolean, default: true }
        },
        codreports: {
            codreports_viewlist: { type: Boolean, default: true },
            codreports_exportfile: { type: Boolean, default: true },
            codreports_track: { type: Boolean, default: true }
        },
        outstanding: {
            outstanding_viewlist: { type: Boolean, default: true },
            outstanding_exportfile: { type: Boolean, default: true },
            outstanding_action: {
                opayment: { type: Boolean, default: true },
                ostatement: { type: Boolean, default: true },
            }
        },
        manage_profile: { type: Boolean, default: false },
        change_password: { type: Boolean, default: true },
    },
    { timestamps: true },
    { collection: "subadminpermission_tbls" }
);

module.exports = submodelPermisionModel;