const mongoose = require("mongoose");

const T_LinkKeywordSchema = mongoose.Schema(
    {
        vid: { type: Number },
        visiblekeyword: { type: String },
        deletedrow: { type: Boolean, default: null },
        f_show: { type: Boolean, default: null },
        aid: { type: String }
    },
    { collection: "T_LinkKeyword" }
)

module.exports = T_LinkKeyword = mongoose.model(
    "T_LinkKeyword",
    T_LinkKeywordSchema
)