import {
  Row,
  Col,
} from "react-bootstrap";

export const Requirement_Drop = [
  "Open", "Close", "PClose", "Sold", "Upgrade Sold",
  "QPack Sold", "DQuery Sold", "Pack Sold", "Exclude Sold"
]
export const Description_Drop = [
  "---select---", "Pricing and Procedure", "Costing for selected images", "Direct Order",
  "Image details sent for previous record", "Watermark query", "Free Research", "Contact us Form",
  "Link for Similar images", "Invoice resent", "Bank details", "Image usage Rights", "PO pending",
  "Change in user profile", "Upgrade Image", "Vendor form", "Address confirmation for payment/TDS",
  "Ecash query", "Quotation sent", "Images not available", "Renewal", "Exclude", "Fwd to upgrade",
  "Fwd quotation", "Fwd direct query", "Direct pack sold CS", "Others"
]

export const IB_FORM = ({ onInputChange }) => {
  return (
    <>
      <Col lg={6} className="FollowUps_Details_check">
        <Row className="rownew1">
          <div className="col-md-12 pr-50">
            <h3 style={{ color: "#0081ad", fontWeight: "bold", paddingLeft: "0px" }}>IB</h3>
          </div>
          <div className="col-md-6">
          </div>

          <div className="col-md-12 pr-50">
            <div className="form-group">
              <label className="control-label">Requirement Followups :</label>
              <div className="">
                <table className="followups_tabled" id="rbt_todaysdeal" border="0" style={{ width: "100%", marginTop: "7px" }}>
                  <tbody>
                    <tr>
                      {Requirement_Drop.slice(0, 5).map((info, inx) => {
                        return (
                          <td key={`${info}${inx}`}>
                            <input id="featuredtrue3"
                              type="radio" value={info}
                              tabindex="4" name="followUpType"
                              onChange={onInputChange} />
                            <label for="featuredtrue3" className="pd-l-5 labelin">
                              {info}
                            </label>
                          </td>
                        )
                      })}
                    </tr>
                    <tr>
                      {Requirement_Drop.slice(5, 9).map((info, inx) => {
                        return (
                          <td key={`${info}${inx}`}>
                            <input id="featuredtrue3"
                              type="radio" value={info}
                              tabindex="4" name="followUpType"
                              onChange={onInputChange} />
                            <label for="featuredtrue3" className="pd-l-5 labelin">
                              {info}
                            </label>
                          </td>
                        )
                      })}
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
            <div className="form-group">
              <label className="control-label">Description Type :</label>
              <div className="">
                <select className="form-control" id="followUpDescriptionType"
                  name="followUpDescriptionType" onChange={onInputChange}
                >
                  {Description_Drop.map((info, inx) => {
                    return (
                      <option value={info} key={`${info}${inx}`}>{info}</option>
                    )
                  })}
                </select>
              </div>
            </div>
            <div className="form-group">
              <label className="control-label">Order ID :</label>
              <div className="">
                <input className="form-control" type="number" name="orderid_IB"
                  onChange={onInputChange} style={{ background: "#f5f5f5" }} />
              </div>
            </div>
            <div className="form-group">
              <label className="control-label">Followups Date :</label>
              <div className="">
                <input className="form-control" type="date"
                  id="followupDate" name="followupDate"
                  onChange={onInputChange} placeholder="Select date" />
              </div>
            </div>
            <div className="form-group">
              <label className="control-label">Description :</label>
              <div className="">
                <textarea className="form-control" rows="4" id="followupDescription" name="followupDescription" onChange={onInputChange} placeholder="Enter description"></textarea>
              </div>
            </div>
          </div>
        </Row>
      </Col>
    </>
  )
}

export const STAR_FORM = ({ onInputChange }) => {
  return (
    <>
      <Col lg={6} className="FollowUps_Details_check">
        <Row className="rownew1">
          <div className="col-md-12 pr-50">
            <h3 style={{ color: "#0081ad", fontWeight: "bold", paddingLeft: "0px" }}>IB</h3>
          </div>
          <div className="col-md-6">
          </div>

          <div className="col-md-12 pr-50">
            <div className="form-group">
              <label className="control-label">Requirement Followups :</label>
              <div className="">
                <table className="followups_tabled" id="rbt_todaysdeal" border="0" style={{ width: "100%", marginTop: "7px" }}>
                  <tbody>
                    <tr>
                      {Requirement_Drop.slice(0, 5).map((info, inx) => {
                        return (
                          <td key={`${info}${inx}`}>
                            <input id="featuredtrue3"
                              type="radio" value={info}
                              tabindex="4" name="followUpType1"
                              onChange={onInputChange} />
                            <label for="featuredtrue3" className="pd-l-5 labelin">
                              {info}
                            </label>
                          </td>
                        )
                      })}
                    </tr>
                    <tr>
                      {Requirement_Drop.slice(5, 9).map((info, inx) => {
                        return (
                          <td key={`${info}${inx}`}>
                            <input id="featuredtrue3"
                              type="radio" value={info}
                              tabindex="4" name="followUpType1"
                              onChange={onInputChange} />
                            <label for="featuredtrue3" className="pd-l-5 labelin">
                              {info}
                            </label>
                          </td>
                        )
                      })}
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
            <div className="form-group">
              <label className="control-label">Description Type :</label>
              <div className="">
                <select className="form-control"
                  name="followUpDescriptionType1" onChange={onInputChange}
                >
                  {Description_Drop.map((info, inx) => {
                    return (
                      <option value={info} key={`${info}${inx}`}>{info}</option>
                    )
                  })}
                </select>
              </div>
            </div>
            <div className="form-group">
              <label className="control-label">Order ID :</label>
              <div className="">
                <input className="form-control" type="number" name="orderid_Star"
                  onChange={onInputChange} style={{ background: "#f5f5f5" }} />
              </div>
            </div>
            <div className="form-group">
              <label className="control-label">Followups Date :</label>
              <div className="">
                <input className="form-control" type="date"
                  id="followupDate" name="followupDate1"
                  onChange={onInputChange} placeholder="Select date" />
              </div>
            </div>
            <div className="form-group">
              <label className="control-label">Description :</label>
              <div className="">
                <textarea className="form-control" rows="4" id="followupDescription" name="followupDescription1"
                  onChange={onInputChange} placeholder="Enter description">

                </textarea>
              </div>
            </div>
          </div>
        </Row>
      </Col>
    </>
  )
}

export const PACKES_FORM = ({ onInputChange }) => {
  return (
    <>
      <Col lg={6} className="FollowUps_Details_check">
        <Row className="rownew1">
          <div className="col-md-12 pr-50">
            <h3 style={{ color: "#0081ad", fontWeight: "bold", paddingLeft: "0px" }}>IB</h3>
          </div>
          <div className="col-md-6">
          </div>

          <div className="col-md-12 pr-50">
            <div className="form-group">
              <label className="control-label">Requirement Followups :</label>
              <div className="">
                <table className="followups_tabled" id="rbt_todaysdeal" border="0" style={{ width: "100%", marginTop: "7px" }}>
                  <tbody>
                    <tr>
                      {Requirement_Drop.slice(0, 5).map((info, inx) => {
                        return (
                          <td key={`${info}${inx}`}>
                            <input id="featuredtrue3"
                              type="radio" value={info}
                              tabindex="4" name="followUpType2"
                              onChange={onInputChange} />
                            <label for="featuredtrue3" className="pd-l-5 labelin">
                              {info}
                            </label>
                          </td>
                        )
                      })}
                    </tr>
                    <tr>
                      {Requirement_Drop.slice(5, 9).map((info, inx) => {
                        return (
                          <td key={`${info}${inx}`}>
                            <input id="featuredtrue3"
                              type="radio" value={info}
                              tabindex="4" name="followUpType2"
                              onChange={onInputChange} />
                            <label for="featuredtrue3" className="pd-l-5 labelin">
                              {info}
                            </label>
                          </td>
                        )
                      })}
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
            <div className="form-group">
              <label className="control-label">Description Type :</label>
              <div className="">
                <select className="form-control" id="followUpDescriptionType"
                  name="followUpDescriptionType2" onChange={onInputChange}
                >
                  {Description_Drop.map((info, inx) => {
                    return (
                      <option value={info} key={`${info}${inx}`}>{info}</option>
                    )
                  })}
                </select>
              </div>
            </div>
            <div className="form-group">
              <label className="control-label">Order ID :</label>
              <div className="">
                <input className="form-control" type="number" name="orderid_Pack"
                  onChange={onInputChange} style={{ background: "#f5f5f5" }} />
              </div>
            </div>
            <div className="form-group">
              <label className="control-label">Followups Date :</label>
              <div className="">
                <input className="form-control" type="date"
                  id="followupDate" name="followupDate2"
                  onChange={onInputChange} placeholder="Select date" />
              </div>
            </div>
            <div className="form-group">
              <label className="control-label">Description :</label>
              <div className="">
                <textarea className="form-control" rows="4" id="followupDescription" name="followupDescription2" onChange={onInputChange} placeholder="Enter description"></textarea>
              </div>
            </div>
          </div>
        </Row>
      </Col>
    </>
  )
}

export const SPECIAL_FORM = ({ onInputChange }) => {
  return (
    <>
      <Col lg={6} className="FollowUps_Details_check">
        <Row className="rownew1">
          <div className="col-md-12 pr-50">
            <h3 style={{ color: "#0081ad", fontWeight: "bold", paddingLeft: "0px" }}>IB</h3>
          </div>
          <div className="col-md-6">
          </div>

          <div className="col-md-12 pr-50">
            <div className="form-group">
              <label className="control-label">Requirement Followups :</label>
              <div className="">
                <table className="followups_tabled" id="rbt_todaysdeal" border="0" style={{ width: "100%", marginTop: "7px" }}>
                  <tbody>
                    <tr>
                      {Requirement_Drop.slice(0, 5).map((info, inx) => {
                        return (
                          <td key={`${info}${inx}`}>
                            <input id="featuredtrue3"
                              type="radio" value={info}
                              tabindex="4" name="followUpType3"
                              onChange={onInputChange} />
                            <label for="featuredtrue3" className="pd-l-5 labelin">
                              {info}
                            </label>
                          </td>
                        )
                      })}
                    </tr>
                    <tr>
                      {Requirement_Drop.slice(5, 9).map((info, inx) => {
                        return (
                          <td key={`${info}${inx}`}>
                            <input id="featuredtrue3"
                              type="radio" value={info}
                              tabindex="4" name="followUpType3"
                              onChange={onInputChange} />
                            <label for="featuredtrue3" className="pd-l-5 labelin">
                              {info}
                            </label>
                          </td>
                        )
                      })}
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
            <div className="form-group">
              <label className="control-label">Description Type :</label>
              <div className="">
                <select className="form-control" id="followUpDescriptionType"
                  name="followUpDescriptionType3" onChange={onInputChange}
                >
                  {Description_Drop.map((info, inx) => {
                    return (
                      <option value={info} key={`${info}${inx}`}>{info}</option>
                    )
                  })}
                </select>
              </div>
            </div>
            <div className="form-group">
              <label className="control-label">Order ID :</label>
              <div className="">
                <input className="form-control" type="number" name="orderid_Special"
                  onChange={onInputChange} style={{ background: "#f5f5f5" }} />
              </div>
            </div>
            <div className="form-group">
              <label className="control-label">Followups Date :</label>
              <div className="">
                <input className="form-control" type="date"
                  id="followupDate" name="followupDate3"
                  onChange={onInputChange} placeholder="Select date" />
              </div>
            </div>
            <div className="form-group">
              <label className="control-label">Description :</label>
              <div className="">
                <textarea className="form-control" rows="4" id="followupDescription" name="followupDescription3" onChange={onInputChange} placeholder="Enter description"></textarea>
              </div>
            </div>
          </div>
        </Row>
      </Col>
    </>
  )
}

export const OTHER_FORM = ({ onInputChange }) => {
  return (
    <>
      <Col lg={6} className="FollowUps_Details_check">
        <Row className="rownew1">
          <div className="col-md-12 pr-50">
            <h3 style={{ color: "#0081ad", fontWeight: "bold", paddingLeft: "0px" }}>IB</h3>
          </div>
          <div className="col-md-6">
          </div>

          <div className="col-md-12 pr-50">
            <div className="form-group">
              <label className="control-label">Requirement Followups :</label>
              <div className="">
                <table className="followups_tabled" id="rbt_todaysdeal" border="0" style={{ width: "100%", marginTop: "7px" }}>
                  <tbody>
                    <tr>
                      {Requirement_Drop.slice(0, 5).map((info, inx) => {
                        return (
                          <td key={`${info}${inx}`}>
                            <input id="featuredtrue3"
                              type="radio" value={info}
                              tabindex="4" name="followUpType4"
                              onChange={onInputChange} />
                            <label for="featuredtrue3" className="pd-l-5 labelin">
                              {info}
                            </label>
                          </td>
                        )
                      })}
                    </tr>
                    <tr>
                      {Requirement_Drop.slice(5, 9).map((info, inx) => {
                        return (
                          <td key={`${info}${inx}`}>
                            <input id="featuredtrue3"
                              type="radio" value={info}
                              tabindex="4" name="followUpType4"
                              onChange={onInputChange} />
                            <label for="featuredtrue3" className="pd-l-5 labelin">
                              {info}
                            </label>
                          </td>
                        )
                      })}
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
            <div className="form-group">
              <label className="control-label">Description Type :</label>
              <div className="">
                <select className="form-control" id="followUpDescriptionType"
                  name="followUpDescriptionType4" onChange={onInputChange}
                >
                  {Description_Drop.map((info, inx) => {
                    return (
                      <option value={info} key={`${info}${inx}`}>{info}</option>
                    )
                  })}
                </select>
              </div>
            </div>
            <div className="form-group">
              <label className="control-label">Order ID :</label>
              <div className="">
                <input className="form-control" type="number" name="orderid_Other"
                  onChange={onInputChange} style={{ background: "#f5f5f5" }} />
              </div>
            </div>
            <div className="form-group">
              <label className="control-label">Followups Date :</label>
              <div className="">
                <input className="form-control" type="date"
                  id="followupDate" name="followupDate4"
                  onChange={onInputChange} placeholder="Select date" />
              </div>
            </div>
            <div className="form-group">
              <label className="control-label">Description :</label>
              <div className="">
                <textarea className="form-control" rows="4" id="followupDescription" name="followupDescription4" onChange={onInputChange} placeholder="Enter description"></textarea>
              </div>
            </div>
          </div>
        </Row>
      </Col>
    </>
  )
}