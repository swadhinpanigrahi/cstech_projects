import React from 'react';
import ImageManageList from "./ImageManageList"
import { Route } from "react-router-dom";

const ImageSection = () => {
    return (
        <>
            <Route path="/dashboard/image/get" component={ImageManageList} />
        </>
    )
}

export default ImageSection
