/**
 * UserSearch and UserSearchAll
*/

export const RegisterUserHeader = ["S. No.", "User Id",
    "Name", "Email", "Mobile No", "Company Name", "User", "Action"]

export const RegisterCompanyHeader = ["S. No.", "Company Name",
    "Group Name", "Email", "Mobile No", "Short Name", "Address", "State",
    "Special Comments", "Additional Information", "Gift Policy", "Comm.", "Action"]

export const OrderHeader = ["S. No.", "Client Name", "Email", "Mobile No.", "Total Order", "Unpaid Status",
    "Discount (%)", "Approval Mode", "Credit Period", "Pending Order", "Action"]

export const ProposalHeader = [
    "User ID", "User Name", "Heading", "Create Date", "No. of images", "Amount INR", "Discount INR",
    "Tax INR", "Total Amount INR", "Action"
]

export const FollowupsHeader = ["S. No.", "User Details", "Company Name", "User Type", "Requirement Type",  
"Status", "Date", "Type", "Discount Terms", "Action"]

export const FollowupsHeader1 = ["S. No.", "User Details", "Company Name", "User Type", "Mobile","Country", "Requirement Type",  
"Status", "Date", "Description Type", "Discount Terms", "Action"]