import React, { useState, useEffect } from 'react';
import { FollowupsHeader,FollowupsHeader1 } from '../../Components/Common/Tables/TableHeaders';
import { getDailySalesEntryLists, getFollowupsDetailsTableByID, postNextFollowup, getFollowupsDetailsById, getDailySalesEntryListByFilter } from '../../Utils/api';
import * as RB from 'react-bootstrap';
import PaginationComponent from "../../Components/Common/PaginationComponent";
import FollowupListModal from "../../Components/Models/FollowupModals/FollowupListModal";
import FollowupCreateMoadal from "../../Components/Models/FollowupModals/FollowupCreateMoadal";
import Moment from 'moment'
import { useLocation,Link } from "react-router-dom";
import { AiOutlineFileSearch } from "react-icons/ai";
import { IoExitOutline } from "react-icons/io5";
import {
    Col,
    Table,
} from "react-bootstrap";

const DailySalesEntryList = () => {
    const [Loading, setLoading] = useState(false);
    const [EntryLists, setEntryList] = useState([])
    const [f_sno, setId] = useState("");
    const [FollowupCreate, setFollowupCreate] = useState(false);
    const [followTable, setFollowTable] = useState([]);
    const [FollowupList, setFollowupList] = useState(false);
    const [gotoPage, setGoToPage] = useState("");
    let query = useQuery();
    const num = query.get("num") || 1;

    const [currentPage, setCurrentPage] = useState(1);
    const [itemPerPage, setItemPerPage] = useState(20);
    const [Count, setCount] = useState(0);
    let [searchData, setSearchData] = useState("");

    const [FormData, setFormData] = useState({
        f_sno,
        f_EmailID: "",
        f_CompanyName: "",
        f_creationdate: "",
        f_MobileNo: "",
        f_Firstname: "",
        f_AlternateEmail: "",
        f_RequirementType: "",
        orderid: "",
        f_status: "",
        f_followpby: "",
        f_State: "",
        f_IbOption: "",
        f_createdby: "",
    });

    function useQuery() {
        return new URLSearchParams(useLocation().search);
    }
    const FollowupCreateSubmit = async (f_sno) => {
        // alert(f_sno)
        setId(f_sno);
        const res = await getFollowupsDetailsById(f_sno);
        const { followupsData } = res;
        setFormData({
            f_sno,
            f_EmailID: followupsData.f_EmailID,
            f_CompanyName: followupsData.f_CompanyName,
            f_creationdate: followupsData.f_creationdate,
            f_MobileNo: followupsData.f_MobileNo,
            f_Firstname: followupsData.f_Firstname,
            f_AlternateEmail: followupsData.f_AlternateEmail,
            f_RequirementType: followupsData.f_RequirementType,
            orderid: followupsData.orderid,
            f_status: "",
            f_followpby: followupsData.f_followpby,
            f_State: followupsData.f_State,
            f_IbOption: followupsData.f_IbOption,
            f_createdby: followupsData.f_createdby,
        });
        setFollowupCreate(true);
    };
    const handleChange = (e) => {
        setFormData({ ...FormData, [e.target.name]: e.target.value });
    };
    const handleChange1 = async (e) => {
        setSearchData(e.target.value);
        setLoading(true);
        const res = await getDailySalesEntryLists(
            currentPage,
            itemPerPage,
            (searchData = e.target.value)
        );
        let { proposalCount, proposalData } = res;
        getDailySalesEntryLists(proposalData);
        proposalCount.length === 1
            ? setCount(proposalCount[0].totalCount)
            : setCount(0);
        setLoading(false);
    };

    const FollowupListOpen = async (f_sno) => {
        // alert(f_sno)
        const res = await getFollowupsDetailsTableByID(f_sno);
        console.log(res);
        const { followupsData } = res;
        setFollowTable(followupsData);
        setFollowupList(true);
    };
    const onSubmit = async (e) => {
        e.preventDefault();
        const res = await postNextFollowup(FormData);
        const { message, error } = res;
        if (!error && message === "added successfully") {
            setTimeout(() => {
                setFollowupCreate();
            }, 1000);
        } else {
            console.log(error);
        }
    };
    // async function getDailySalesEntryList() {
    //     setLoading(true);
    //     var data = await getDailySalesEntryLists(currentPage, itemPerPage, startDate, endDate, selectData, searchData)
    //     console.log(data);
    //     setEntryList(data.data)
    //     setLoading(false);
    // }
    const gotToPage = async () => {
        //console.log(gotoPage)
        setCurrentPage(gotoPage)
        setLoading(true);
        await GET_API();
        window.scroll(0, 0);
        setLoading(false);
    }
    const GET_API = async () => {
        const res = await getDailySalesEntryLists(currentPage, itemPerPage, searchData);
        let { proposalCount, proposalData } = res;
        setEntryList(proposalData);
        proposalCount.length === 1
            ? setCount(proposalCount[0].totalCount)
            : setCount(0);
        setLoading(false);
    };
    useEffect(() => {
        setLoading(true);
        GET_API();
    }, [currentPage, itemPerPage]);

    const listEntry = EntryLists.length !== 0 ? EntryLists.map((body, inx) => {
        return (
            <tr key={`ORDER_TBL_BODY${inx}`}>
                <td className="s_not1 text-center">{inx + 1}</td>
                <td className="company_emmailta">
                    {body.f_fullname}
                    {<br />}
                    {body.f_email}
                    {<br />}
                    {body.f_state}
                </td>
                <td className="company_emmailta">{body.f_CompanyName}</td>
                <td>{body.f_usertype}</td>
              
                <td>{body.f_MobileNo}</td>
                <td>India</td>
                <td>{body.f_RequirementType}</td>
                <td>{body.f_followups_status}</td>
                <td className="s_notd">
                    {Moment(body.f_creationdate).format("DD-MM-YYYY")}
                </td>
                <td>{body.f_Descriptiontype}</td>
                <td>{body.f_Discountterms}</td>
                <td className="s_not text-center td_comments">
                    <AiOutlineFileSearch title="Create New Followup"
                        onClick={() => FollowupCreateSubmit(body.f_sno)}
                    />
                    <IoExitOutline title="Followup History"
                        onClick={() => FollowupListOpen(body.f_sno)}
                    />
                </td>
            </tr>
        )
    }) : <tr><td class="no_records" colspan="12">No Records Found</td></tr>
    return (
        <div>

            <RB.Row className="rownew1">
                <RB.Col lg={12}>
                    <RB.Row className="rownew1" style={{ paddingTop: "25px" }}>
                        <div className="tableHeader tableHeader1 order_btntable">
                            <RB.Col md={12} xs={12} className="table_span">
                                <h3 className="page-title d-flex userv">
                                    <span>Search Results</span>
                                </h3>
                            </RB.Col>
                        </div>
                    </RB.Row>
                </RB.Col>

                <RB.Col lg={12}>
                    <div className="box_detail" style={{ borderRadius: "4px" }}>
                        <div className="page-header row">
                            <RB.Col md={12}>
                                <RB.Form className="manage_searchorder">
                                    <RB.Row className="mg_row0">
                                        <RB.Col lg={4} md={6}>
                                            <RB.Row className="mg_row0">
                                                <RB.Col lg={12} className="">
                                                    <RB.Form.Group>
                                                        <RB.Form.Control
                                                            onChange={handleChange1}
                                                            type="text"
                                                            placeholder="Search by Name/Email/Company"
                                                        />
                                                    </RB.Form.Group>
                                                </RB.Col>
                                            </RB.Row>
                                        </RB.Col>
                                        <RB.Col lg={5} md={6}></RB.Col>
                                        <RB.Col lg={3} md={6}>
                                            <RB.Row className="mg_row0">
                                                <RB.Col lg={12} className="">
                                                    <button type="button" class="btn_svg btn btn-primary btn-sm"> <Link to="/dashboard/createfollowups">ADD NEW RECORDS</Link> </button>
                                                </RB.Col>
                                            </RB.Row>
                                        </RB.Col>
                                    </RB.Row>
                                </RB.Form>
                            </RB.Col>
                        </div>
                    </div>
                </RB.Col>

                <RB.Col lg={12}>
                    <RB.Row className="rownew1">
                        <div className="tableHeader tableHeader1 search_new">
                            <RB.Col lg={6} md={6} className="table_span">
                                <h3 className="page-title d-flex userv">
                                    <span>Daily Sales Entry List</span>
                                </h3>
                            </RB.Col>
                        </div>
                    </RB.Row>
                    <div
                        className="box_detail table_boxdtl manage_order"
                        style={{ marginBottom: "0px" }}
                    >
                        <Table striped bordered hover variant="dark" responsive>
                            <thead>
                                <tr className="head_trmain">
                                    {FollowupsHeader1.map((head, inx) => {
                                        return <th key={`ORDER_TBL_HEAD${inx}`}>{head}</th>;
                                    })}
                                </tr>
                            </thead>
                            <tbody>

                                {Loading ?
                                    <tr><td class="loadingd" colspan="11">Loading....</td></tr> : listEntry}

                            </tbody>
                        </Table>
                    </div>
                    <FollowupListModal FollowupList={FollowupList} setFollowupList={setFollowupList} followTable={followTable} />


                    <FollowupCreateMoadal
                        FollowupCreate={FollowupCreate}
                        setFollowupCreate={setFollowupCreate}
                        setFormData={setFormData}
                        handleChange={handleChange}
                        onSubmit={onSubmit}
                        FormData={FormData}
                    />

                    <PaginationComponent
                        MOCK_DATA={Count}
                        currentPage={currentPage}
                        setCurrentPage={setCurrentPage}
                        itemPerPage={itemPerPage}
                        setItemPerPage={setItemPerPage}
                    />

                </RB.Col>
                {/* <RB.Col lg={12}>
                    <RB.Row className="rownew1">
                        <div className="tableHeader tableHeader1 search_new">
                            <RB.Col lg={5} md={5} className="table_span">

                            </RB.Col>
                            <RB.Col lg={2} md={2} className="table_span">
                                Go To Page :    <input type="number" className="form-control" value={gotoPage} onChange={(e) => setGoToPage(e.target.value)} /> <button type="submit" onClick={gotToPage}>Go</button>
                            </RB.Col>
                            <RB.Col lg={5} md={5} className="table_span">


                            </RB.Col>
                        </div>
                    </RB.Row>
                </RB.Col> */}

            </RB.Row>
        </div>
    )
}

export default DailySalesEntryList