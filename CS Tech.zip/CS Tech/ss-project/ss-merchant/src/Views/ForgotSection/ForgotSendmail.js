import React, { useState } from 'react'
import { Link } from 'react-router-dom';
import { Form } from "react-bootstrap";
import Header from "../../Components/Common/Header";
import { useTranslation } from "react-i18next";
import { inputFieldsValidetor } from "../../Utils/FormValidetor";
import Model from "../../Components/Common/Model";
import { forgotPasswordEmail } from "../../Utils/api"

const ForgotSendmail = () => {
    const { t } = useTranslation();
    const [isOpen, setIsOpen] = useState(false);
    const [ErrModel, setErrModel] = useState("");
    const [FormData, setFormData] = useState({});
    const [Errors, setErrors] = useState({
        errors: {},
        errMsg: "",
        errClr: "",
    });

    const handleChange = (e) => {
        let { name, value } = e.target;
        let data = { ...FormData };
        data[name] = value;
        setFormData(data);
        const updateError = { ...Errors };
        updateError.errors = inputFieldsValidetor(data);
        updateError.errMsg = "";
        updateError.errClr = "";
        setErrors({ ...updateError });
    };

    const onSubmit = async (e) => {
        e.preventDefault();
        if (FormData["email"]) {
            const res = await forgotPasswordEmail(FormData)
            let { error, status, message } = res;
            if (!error) {
                if (status === 200) {
                    setErrModel(message);
                    modelSet();
                } else {
                    const updatedError = { ...Errors };
                    updatedError.errMsg = message;
                    setErrors({ ...updatedError });
                }
            } else {
                const updatedError = { ...Errors };
                updatedError.errMsg = "Network Error!!";
                setErrors({ ...updatedError });
            }
        } else {
            const updatedError = { ...Errors };
            updatedError.errors = inputFieldsValidetor(FormData);
            updatedError.errMsg = "";
            updatedError.errClr = "border-danger";
            setErrors({ ...updatedError });
        }
    };

    const modelSet = () => {
        setIsOpen(true);
    };

    let { errors, errMsg, errClr } = Errors;

    return (
        <>
            <Header />
            <div id="page" className="theia-exception">
                <main className="mainl">
                    <div className="container-flud">
                        <div id="signin">
                            <div className="boxes">
                                <h4 className="title text-center">Forgot Password ?</h4>
                                <p className="fortext">{t("change.f_ufup")}</p>
                                <p className="fortext" style={{ paddingBottom: "25px" }}>
                                    {t("change.f_youcanchange")}
                                </p>
                                <Form.Text className="text-danger">{errMsg ? errMsg : ""}</Form.Text>
                                <form id="form">
                                    <div className="form-group">
                                        <input
                                            type="email"
                                            className="input"
                                            name="email"
                                            placeholder="Enter your Email ID"
                                            onChange={handleChange}
                                        />
                                        {errors["email"] && (
                                            <Form.Text className="text-danger">
                                                {errors["email"]}
                                            </Form.Text>
                                        )}
                                    </div>
                                    <div className="form-group" style={{ marginBottom: "15px" }}>
                                        <button className="btn-login" onClick={onSubmit}>
                                            SUBMIT
                                        </button>
                                        <div className="forgot">
                                            <Link to="/">Login here</Link>
                                        </div>
                                        <Model
                                            text={ErrModel}
                                            open={isOpen}
                                            onClose={() => setIsOpen(false)}
                                        />
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
        </>
    )
}

export default ForgotSendmail
