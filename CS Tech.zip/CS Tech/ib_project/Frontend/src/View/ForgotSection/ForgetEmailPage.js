import React, { useState } from "react";
import TopBar from "../../Components/NavSection/TopBar";
import { Link, useParams } from "react-router-dom";
import { Form, Button } from "react-bootstrap";
import { emailFormValidation } from "../../Utils/validation";
import { forgetEmailPasswordChange } from "../../Utils/api";
import Footer from "../../Components/NavSection/Footer"

const ForgetEmailPage = () => {
  const { token } = useParams();
  const [email, setEmail] = useState({
    password: "",
    confirmPassword: "",
  });
  const [Loading, setLoading] = useState("SUBMIT");
  const [Error, setError] = useState({
    errMsg: "",
    errClr: "",
  });
  const [errors, setErrors] = useState({});
  const handleChange = (e) => {
    setEmail({ ...email, [e.target.name]: e.target.value });
    const updateError = { ...Error };
    updateError.errCls = "";
    updateError.errMsg = "";
    setError({ ...updateError });
    const updateErrors = { ...errors };
    updateErrors.password = "";
    updateErrors.confirmPassword = "";
    setErrors({ ...updateErrors });
  };
  
  const changeLoading = () => {
    setLoading("Loading...");
    setTimeout(() => {
      setLoading("SUBMIT");
    }, 1000);
  };

  const onSubmit = async (e) => {
    e.preventDefault();
    if (email["password"] && email["confirmPassword"]) {
      const obj = {
        token,
        ...email,
      };
      const res = await forgetEmailPasswordChange(obj);
      const { error, message } = res;
      if (!error) {
        changeLoading();
        const updateError = { ...Error };
        updateError.errMsg = message;
        setError({ ...updateError });
      } else {
        changeLoading();
        const updateError = { ...Error };
        updateError.errMsg = "Network Error";
        setError({ ...updateError });
      }
    } else {
      const updateError = { ...Error };
      updateError.errCls = "border-danger";
      setError({ ...updateError });
      setErrors(emailFormValidation(email));
    }
  };

  let { errMsg, errCls } = Error;
  return (
    <div>
      <TopBar />
      <main>
        <div id="forget">
          <div className="forgetdetails">
            <h4 className="forgetHeader">Re-set Password</h4>
            <p className="text-danger">
              {Loading === "Loading..." ? "" : errMsg ? errMsg : ""}
            </p>
            <Form onSubmit={onSubmit}>
              <Form.Group controlId="FormControlIdEmail">
                <Form.Control
                  type="password"
                  name="password"
                  placeholder="Enter New Password"
                  className={
                    Loading === "Loading..." ? "" : errCls ? errCls : ""
                  }
                  onChange={handleChange}
                />
                {errors.password && (
                  <p className="text-danger">
                    {Loading === "Loading..." ? "" : errors.password}
                  </p>
                )}
              </Form.Group>
              <Form.Group controlId="FormControlIdEmail">
                <Form.Control
                  type="password"
                  name="confirmPassword"
                  placeholder="Re-Enter Your Password"
                  className={
                    Loading === "Loading..." ? "" : errCls ? errCls : ""
                  }
                  onChange={handleChange}
                />
                {errors.confirmPassword && (
                  <p className="text-danger">
                    {Loading === "Loading..." ? "" : errors.confirmPassword}
                  </p>
                )}
              </Form.Group>
              <Button variant="primary" className="subBtn" block type="submit">
                {Loading}
              </Button>
            </Form>
            <p className="loginBack">
              <Link to="/">Back To Login</Link>
            </p>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default ForgetEmailPage;
