import React, { useState, useEffect } from 'react';
import { ButtonToolbar, Button, ButtonGroup, Table } from "react-bootstrap"
import { useParams, Link } from 'react-router-dom';
import { AiOutlineFileSearch } from "react-icons/ai";
import { OrderHeader } from "../../Components/Common/Tables/TableHeaders";
import { orderFilter } from "../../Utils/api";


const ViewAllOrders = ({ OrderData, spanOrder, search }) => {
    const { mode } = useParams();

    const [MapedData, setMapedData] = useState([]);

    useEffect(() => {
        const apicall = async () => {
            const res = await orderFilter({ search })
            console.log(res, OrderData)
        }
        apicall()
    }, [])

    return (
        <>
            <ButtonToolbar>
                {spanOrder.map((data, inx) => {
                    let { name, count, path } = data;
                    return (
                        <ButtonGroup className="mr-2" key={"orderspan" + inx}>
                            <Button
                                as={Link}
                                to={`/dashboard/vieworder/${path}`}
                                size="sm"
                            >{`${name} - ${count}`}
                            </Button>

                        </ButtonGroup>
                    );
                })}
            </ButtonToolbar>
            <h1>Lets do {mode}</h1>
            <div className="box_detail table_boxdtl">
                <Table striped bordered hover variant="dark" responsive>
                    <thead>
                        <tr className="head_trmain">
                            {OrderHeader.map((head, inx) => {
                                return <th key={`ORDER_TBL_HEAD${inx}`}>{head}</th>;
                            })}
                        </tr>
                    </thead>
                    <tbody>
                        {MapedData.map((body, inx) => {
                            return (
                                <tr key={`ORDERALL_TBL_BODY${inx}`}>
                                    <td className="s_not1 text-center">{inx + 1}</td>
                                    <td>{body.f_clientname}</td>
                                    <td className="company_emmailta">{body.f_email}</td>
                                    <td>{body.f_mobileno}</td>
                                    {/* <td>{data.f_totalamtwithGST}</td> */}
                                    <td>{body.f_order_total}</td>
                                    <td>{body.f_order_Unpaid}</td>
                                    <td>{body.f_order_Current_Discount_Per}</td>
                                    <td>{body.f_approval_mode}</td>
                                    <td>{body.f_credit_period}</td>
                                    <td>{body.f_order_Pending}</td>
                                    <td className="s_not td_comments text-center">
                                        <Link to={`/dashboard/btndata/${body.f_email}`}>
                                            <AiOutlineFileSearch title="Order Details" />
                                        </Link>
                                    </td>
                                </tr>
                            );
                        })}
                    </tbody>
                </Table>
            </div>
        </>
    )
}

export default ViewAllOrders
