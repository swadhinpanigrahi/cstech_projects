// import { generateError } from "./errorContants";
const { generateError } = require("./errorContants")

exports.APIError = class {
  status;
  message;
  error;
  success;
  errMsg;

  constructor(status, message, errMsg) {
    // super();
    this.error = true;
    this.success = false;
    this.status = status;
    this.message = message;
    this.errMsg = errMsg;
  }
}

exports.logError = ({ path, dataValue, error, dataKey }) =>
  `Error in endpoint ${path} with ${dataKey} = ${dataValue} error=> ${generateError(
    error
  )}`;
