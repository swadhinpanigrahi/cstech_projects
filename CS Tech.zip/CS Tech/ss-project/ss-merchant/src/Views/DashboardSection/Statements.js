import React, { useState, useEffect } from "react";
import { getPaymentStalment, paymentFilteredData } from '../../Utils/api';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { useTranslation } from "react-i18next";


const Statements = () => {
    const { t } = useTranslation();
    const [Loading, setLoading] = useState(false)
    const [StatelmentData, setSetelmentData] = useState({
        satelmentArray: [],
        credit: 0,
        debit: 0,
        netPayble: 0,
        netRecevible: 0
    });
    let [startDate, setStartDate] = useState(0);
    let [endDate, setEndDate] = useState(0);

    const onsubmit = async () => {
        const res = await paymentFilteredData({ startDate, endDate })
        let { error, paymentDetails } = res
        console.log(res)
        if (!error) {
            const updateState = { ...StatelmentData }
            updateState.satelmentArray = [...paymentDetails];
            setSetelmentData({ ...updateState })
        }
    }

    let { satelmentArray, credit, debit, netPayble, netRecevible } = StatelmentData

    const listData = satelmentArray.length !== 0 ?
        satelmentArray.map((data, inx) => {
            let {
                createdAt,
                seller_entry_name,
                comment,
                payment_type,
            } = data;
            return (
                <tr key={"table" + inx}>
                    <td className="arabic_left">
                        {createdAt.slice(0, 10)}
                    </td>
                    <td className="arabic_left">{`${seller_entry_name}  [${data.userId}]`}</td>
                    <td className="arabic_left">{comment}</td>
                    <td className="text-right arabic_right">
                        {payment_type === "Credit" ? data.payed_amount : 0}
                    </td>
                    <td className="text-right arabic_right">
                        {payment_type === "Debit" ? data.payed_amount : 0}
                    </td>
                </tr>
            );
        }) : <tr ><td className="no_records" colSpan="8">NO RECORDS FOUND</td></tr>

    useEffect(() => {
        setLoading(true)
        const apiCall = async () => {
            const res = await getPaymentStalment();
            let { records, sumCredit, sumDebit, netPayble, netReceiveble } = res
            const updateState = { ...StatelmentData }
            updateState.satelmentArray = records;
            updateState.credit = sumCredit;
            updateState.debit = sumDebit;
            updateState.netPayble = netPayble;
            updateState.netRecevible = netReceiveble;
            setSetelmentData({ ...updateState })
            setLoading(false)
        }
        apiCall()
    }, []);

    return (
        <>
            <div className="container-fluid">
                <div className="col-12">
                    <div
                        className="page-header row no-gutters pym-4"
                        style={{ paddingBottom: ".5rem!important" }}
                    >
                        <div className="col-md-6">
                            <h3 className="page-title">{t("change.statement_report")}</h3>
                        </div>
                        <div className="col-md-6 text-right backb">
                        </div>
                        <hr />
                    </div>
                </div>

                <div className="col-md-12">
                    <div
                        className="box_detail"
                        style={{ padding: "15px 0px 0px 0px", marginBottom: "20px" }}
                    >
                        <div className="col-12" style={{ padding: "0px" }}>
                            <div className="head-title1 row no-gutters">
                                <div className="col-md-12">
                                    <h3 className="page-title subtitile">
                                        {t("change.account_statement")}
                                    </h3>
                                </div>
                                <hr style={{ marginBottom: "0px" }} />
                            </div>
                        </div>
                        <div className="row" style={{ padding: "20px 30px" }}>
                            <div className="col-lg-3 col-md-3 col-12">
                                <div className="form-group mgb-0">
                                    <label className="pwdc">
                                        {t("change.f_date")} <span className="text-danger">*</span>
                                    </label>
                                    <div
                                        className="input-container d-flex form-control"
                                        id="date_end"
                                    >
                                        <DatePicker
                                            placeholderText="Start Date"
                                            selected={startDate}
                                            onChange={(date) => setStartDate(date)}
                                        />
                                    </div>
                                </div>
                            </div>
                            <div className="col-lg-3 col-md-3 col-12">
                                <div className="form-group mgb-0">
                                    <label className="pwdc">
                                        {t("change.t_date")} <span className="text-danger">*</span>
                                    </label>
                                    <div
                                        className="input-container d-flex form-control"
                                        id="date_end"
                                    >
                                        <DatePicker
                                            placeholderText="End Date"
                                            selected={endDate}
                                            onChange={(date) => setEndDate(date)}
                                        />
                                    </div>
                                </div>
                            </div>
                            <div className="col-lg-1 col-md-3 col-12 pay_mer1">
                                <label
                                    className="pwdc newt_c"
                                    style={{ color: "transparent" }}
                                >
                                    Shipment
                                </label>
                                <button className="subpay" onClick={onsubmit}>
                                    {t("change.submit")}
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="col-12">
                    <div
                        className="box_detail tableboxdc"
                        style={{
                            paddingTop: "0px",
                            paddingBottom: "0px",
                            marginBottom: "0px",
                        }}
                    >
                        <table
                            className="table table-bordered table-responsive"
                            id="table-to-xls"
                        >
                            <thead className="thead-dark">
                                <tr>
                                    <th className="nhead arabic_left">{t("change.date")}</th>
                                    <th className="nhead arabic_left">{t("change.merchant")}</th>
                                    <th className="deshead arabic_left">{t("change.description")}</th>
                                    <th className="ohead text-right arabic_right">{t("change.credit")}</th>
                                    <th className="ohead text-right arabic_right">{t("change.debit")}</th>
                                </tr>
                            </thead>
                            <tbody>
                                {Loading ? <tr><td className="no_records" colSpan="8">{t("change.LOADING")}</td></tr> : [listData]}
                            </tbody>
                            <tbody className={satelmentArray.length !== 0 ? null : "display"}>
                                <tr>
                                    <td className="border_nonet"></td>
                                    <td className="border_nonet"></td>
                                    <td className="border_nonet text-right strongt arabic_right">
                                        {t("change.s_total")}
                                    </td>
                                    <td className="border_nonet text-right strongt arabic_right">
                                        {credit}
                                    </td>
                                    <td className="border_nonet text-right strongt arabic_right">
                                        {debit}
                                    </td>
                                </tr>
                                <tr>
                                    <td className="border_nonet"></td>
                                    <td className="border_nonet"></td>
                                    <td className="border_nonet text-right strongt arabic_right">
                                        {t("change.n_payble")}
                                    </td>
                                    <td className="border_nonet text-right strongt arabic_right">0.00</td>
                                    <td className="border_nonet text-right strongt arabic_right">
                                        {netPayble}
                                    </td>
                                </tr>
                                <tr>
                                    <td className="border_nonet"></td>
                                    <td className="border_nonet"></td>
                                    <td className="border_nonet text-right strongt arabic_right">
                                        {t("change.n_receivable")}
                                    </td>
                                    <td className="border_nonet text-right strongt arabic_right">
                                        {netRecevible}
                                    </td>
                                    <td className="border_nonet text-right strongt arabic_right">0.00</td>
                                </tr>
                                <tr>
                                    <td className="border_nonet"></td>
                                    <td className="border_nonet"></td>
                                    <td className="border_nonet text-right strongt arabic_right">
                                        {t("change.totalAmount")}
                                    </td>
                                    <td className="border_nonet text-right strongt arabic_right">
                                        {credit + netRecevible}
                                    </td>
                                    <td className="border_nonet text-right strongt arabic_right">
                                        {debit + netPayble}
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </>
    );
};

export default Statements;
