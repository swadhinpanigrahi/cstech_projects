const mongoose = require("mongoose");

const t_pricingdetail_Schema = mongoose.Schema(
    {
        f_id: { type: Number },
        f_refid: { type: String },
        f_refname: { type: String },
        f_typeid: { type: String },
        f_typename: { type: String },
        f_dimenation: { type: String },
        f_dpi: { type: String },
        f_outputsize: { type: String },
        f_price: { type: String },
        f_time: { type: String },
        f_showprice: { type: String },
        f_showdiscount: { type: String },
    },
    { collection: "T_pricingdetail_IB_MongoDB" }
)

module.exports = t_pricingdetail = mongoose.model(
    "T_pricingdetail_IB_MongoDB",
    t_pricingdetail_Schema
);