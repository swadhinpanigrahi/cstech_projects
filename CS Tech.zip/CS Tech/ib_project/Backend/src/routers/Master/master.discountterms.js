const Discountterms = require("express").Router();
const {
    addDiscountTerm, getDiscounttermsList, getDiscounttermsDetail, editDiscounttermsDetail, deleteDiscounttermsDetail
} = require("../../controllers/Master/master.discountterms.controller");

Discountterms.route("/adddiscountterms").post(addDiscountTerm);
Discountterms.route("/getdiscounttermslist").get(getDiscounttermsList);
Discountterms.route("/getdiscounttermsdetail/:_id").get(getDiscounttermsDetail);
Discountterms.route("/editdiscounttermsdetail").post(editDiscounttermsDetail);
Discountterms.route("/deletediscounttermsdetail/:_id").get(deleteDiscounttermsDetail);

module.exports = Discountterms;