import React, { useEffect, useState, useRef, useCallback } from "react";
import Cookie from "js-cookie";
import { Link } from "react-router-dom";
import { getOutstandingDetailsList } from "../../../Utils/api";
import { Col, Row } from "react-bootstrap";
import PageHeaders from "../../../Components/Common/PageHeaders";
import ReactExport from "react-data-export";

const Customer = () => {
  const [CustomerDetails, setCustomerDetails] = useState([]);
  const [MapedData, setMapedData] = useState([]);
  const [Loading, setLoading] = useState(false);
  const [Search, setSearch] = useState("");
  const [pagination, setPagination] = useState(0);
  const [OutstandingAuth, setOutstandingAuth] = useState({
    outstanding_viewlist: "",
    outstanding_exportfile: "",
    opayment: "",
    ostatement: "",
  });
  const [Short, setShort] = useState("ascending");

  let { outstanding_viewlist, outstanding_exportfile, opayment, ostatement } =
    OutstandingAuth;

  const handleChange = async (e) => {
    setSearch(e.target.value);
    const array = CustomerDetails.filter((val) => {
      if (Search === "") {
        return val;
      } else if (
        val.name.toLowerCase().includes(e.target.value.toLowerCase())
      ) {
        return val;
      } else if (
        val.email.toLowerCase().includes(e.target.value.toLowerCase())
      ) {
        return val;
      }
    });
    setMapedData(array);
  };

  //EXCEL
  const ExcelFile = ReactExport.ExcelFile;
  const ExcelSheet = ReactExport.ExcelFile.ExcelSheet;
  const DataSet = [
    {
      columns: [
        { title: "NAME" },
        { title: "EMAIL ID" },
        { title: "PHONE NO." },
        { title: "COMPANY NAME" },
        { title: "CREATION DATE" },
        { title: "ADDRESS" },
        { title: "PINCODE" },
        { title: "CITY" },
        { title: "STATE" },
        { title: "COUNTRY" },
        { title: "BENEFICIARY NAME" },
        { title: "BANK NAME" },
        { title: "ACCOUNT NUMBER" },
        { title: "IFSE CODE" },
        { title: "ACTIVE" },
      ],
      data: MapedData.map((data) => [
        { value: data.name },
        { value: data.email },
        { value: data.phone },
        { value: data.companyName },
        { value: data.createdAt.slice(0, 10) },
        { value: data.address },
        { value: data.pincode },
        { value: data.city },
        { value: data.state },
        { value: data.country },
        { value: data.beneficiary_name },
        { value: data.bank_name },
        { value: data.account_number },
        { value: data.ifsc_code },
        { value: data.activate },
      ]),
    },
  ];
  //EXCEL

  let listData =
    MapedData.length > 0 ? (
      MapedData.map((info, inx) => (
        <tr key={"customer-table" + inx}>
          {" "}
          {/*ref={lastBookElement}*/}
          <td>{inx + 1}</td>
          <td>{info.name}</td>
          <td>{info.email}</td>
          <td>{info.phone}</td>
          <td>{info.companyName}</td>
          <td>{info.createdAt.slice(0, 10)}</td>
          <td className="text-center">
            <Link
              to={`/dashboard/customer/paymrnt/${info._id}`}
              target="_blank"
            >
              <i
                className={
                  opayment === "true"
                    ? "fa fa-credit-card iconfa"
                    : "testingggg"
                }
              ></i>
            </Link>
            <Link
              to={`/dashboard/customer/statement/${info._id}`}
              target="_blank"
            >
              <i
                className={
                  ostatement === "true"
                    ? "fa fa-dollar-sign iconfa newi_c"
                    : "testingggg"
                }
              ></i>
            </Link>
          </td>
        </tr>
      ))
    ) : (
      <tr>
        <td className="no_records" colSpan="9">
          NO RECORDS FOUND
        </td>
      </tr>
    );

  const shortFun = (type) => {
    if (type === "name") {
      if (Short === "ascending") {
        const shaloArray = [...MapedData];
        const shortedArray = shaloArray.sort((a, b) => {
          if (a.name.toLowerCase() > b.name.toLowerCase()) return 1;
          if (a.name.toLowerCase() < b.name.toLowerCase()) return -1;
          return 0;
        });
        setMapedData(shortedArray);
        setShort("descending");
      } else {
        const shaloArray = [...MapedData];
        const shortedArray = shaloArray.sort((a, b) => {
          if (a.name.toLowerCase() > b.name.toLowerCase()) return -1;
          if (a.name.toLowerCase() < b.name.toLowerCase()) return 1;
          return 0;
        });
        setMapedData(shortedArray);
        setShort("ascending");
      }
    }

    if (type === "email") {
      if (Short === "ascending") {
        const shaloArray = [...MapedData];
        const shortedArray = shaloArray.sort((a, b) => {
          if (a.email.toLowerCase() > b.email.toLowerCase()) return 1;
          if (a.email.toLowerCase() < b.email.toLowerCase()) return -1;
          return 0;
        });
        setMapedData(shortedArray);
        setShort("descending");
      } else {
        const shaloArray = [...MapedData];
        const shortedArray = shaloArray.sort((a, b) => {
          if (a.email.toLowerCase() > b.email.toLowerCase()) return -1;
          if (a.email.toLowerCase() < b.email.toLowerCase()) return 1;
          return 0;
        });
        setMapedData(shortedArray);
        setShort("ascending");
      }
    }

    if (type === "phone") {
      if (Short === "ascending") {
        const shaloArray = [...MapedData];
        const shortedArray = shaloArray.sort((a, b) => {
          if (a.phone > b.phone) return 1;
          if (a.phone < b.phone) return -1;
          return 0;
        });
        setMapedData(shortedArray);
        setShort("descending");
      } else {
        const shaloArray = [...MapedData];
        const shortedArray = shaloArray.sort((a, b) => {
          if (a.phone > b.phone) return -1;
          if (a.phone < b.phone) return 1;
          return 0;
        });
        setMapedData(shortedArray);
        setShort("ascending");
      }
    }

    if (type === "c_name") {
      if (Short === "ascending") {
        const shaloArray = [...MapedData];
        const shortedArray = shaloArray.sort((a, b) => {
          if (a.companyName.toLowerCase() > b.companyName.toLowerCase()) return 1;
          if (a.companyName.toLowerCase() < b.companyName.toLowerCase()) return -1;
          return 0;
        });
        setMapedData(shortedArray);
        setShort("descending");
      } else {
        const shaloArray = [...MapedData];
        const shortedArray = shaloArray.sort((a, b) => {
          if (a.companyName.toLowerCase() > b.companyName.toLowerCase()) return -1;
          if (a.companyName.toLowerCase() < b.companyName.toLowerCase()) return 1;
          return 0;
        });
        setMapedData(shortedArray);
        setShort("ascending");
      }
    }

    if (type === "c_date") {
      if (Short === "ascending") {
        const shaloArray = [...MapedData];
        const shortedArray = shaloArray.sort((a, b) => {
          if (a.createdAt > b.createdAt) return 1;
          if (a.createdAt < b.createdAt) return -1;
          return 0;
        });
        setMapedData(shortedArray);
        setShort("descending");
      } else {
        const shaloArray = [...MapedData];
        const shortedArray = shaloArray.sort((a, b) => {
          if (a.createdAt > b.createdAt) return -1;
          if (a.createdAt < b.createdAt) return 1;
          return 0;
        });
        setMapedData(shortedArray);
        setShort("ascending");
      }
    }
  };

  const countBar = () => {
    return (
      <Col md={12} className="show_count text-center">
        {listData.length !== undefined ? (
          <p>{`showing ${pagination} - ${listData.length} of ${listData.length} items in listing`}</p>
        ) : (
          <p>{`showing ${pagination} - 0 of 0 items in listing`}</p>
        )}
      </Col>
    );
  };

  useEffect(() => {
    setLoading(true);
    const fun = async () => {
      const outstanding_viewlist = await Cookie.get("outstanding_viewlist");
      const outstanding_exportfile = await Cookie.get("outstanding_exportfile");
      const opayment = await Cookie.get("opayment");
      const ostatement = await Cookie.get("ostatement");

      const updatedState = { ...OutstandingAuth };
      updatedState.outstanding_viewlist = outstanding_viewlist;
      updatedState.outstanding_exportfile = outstanding_exportfile;
      updatedState.opayment = opayment;
      updatedState.ostatement = ostatement;
      setOutstandingAuth({ ...updatedState });

    };
    fun();
    const apiCall = async () => {
      const res = await getOutstandingDetailsList(pagination, Search);
      let { dataArr } = res;
      setCustomerDetails(dataArr);
      setMapedData(dataArr);
      setPagination(1);
      setLoading(false);
    };
    apiCall();
  }, []);

  return (
    <>
      <Col md={12}>
        <PageHeaders title="Outstanding Reports" />
        <Col cmd={12}>
          <div
            className="box_detail"
            style={{ padding: "15px 0px 10px 0px", marginBottom: "20px" }}
          >
            <Col lg={12} style={{ padding: "0px" }}>
              <div className="page-header row no-gutters">
                <Col md={12} style={{ color: "blue !important" }}>
                  <h3 className="page-title subtitile">FILTER BY SEARCH</h3>
                </Col>
                <hr />
              </div>
            </Col>
            <Row style={{ padding: "20px 30px" }}>
              <Col lg={4} md={8}>
                <div className="form-group row mb-0">
                  <Col lg={12}>
                    <input
                      type="text"
                      placeholder="Serach by Name, Email and Phone"
                      onChange={handleChange}
                      className="form-control"
                    />
                  </Col>
                </div>
              </Col>
            </Row>
          </div>
        </Col>
        <Col md={12} className="text-right">
          <span className="count_customer">
            Total Records: {listData.length}
          </span>
          <ExcelFile
            fillename="sheet"
            element={
              MapedData.length !== 0 ? (
                <button
                  className={
                    outstanding_exportfile === "true"
                      ? "export_btn addbce customer_export"
                      : "display"
                  }
                >
                  EXPORT
                </button>
              ) : (
                <button
                  className={
                    outstanding_exportfile === "true"
                      ? "export_btn addbce1 customer_export"
                      : "display"
                  }
                  disabled
                >
                  EXPORT
                </button>
              )
            }
          >
            <ExcelSheet dataSet={DataSet} name="shipment reports" />
          </ExcelFile>
        </Col>
        <Col md={12}>
          <hr />
          <div
            className="box_detail tableboxdc"
            style={{
              paddingTop: "0px",
              paddingBottom: "0px",
              marginBottom: "0px",
            }}
          >
            <table
              className="table table-bordered table-responsive"
              id="table-to-xls"
            >
              <thead className="thead-dark">
                <tr>
                  <th>S NO.</th>
                  <th className="sorting" onClick={() => shortFun("name")}>NAME</th>
                  <th className="sorting" onClick={() => shortFun("email")}>EMAIL</th>
                  <th className="sorting" onClick={() => shortFun("phone")}>PHONE NO.</th>
                  <th className="sorting" onClick={() => shortFun("c_name")}>COMPANY NAME</th>
                  <th className="sorting" onClick={() => shortFun("c_date")}>CREATION DATE</th>
                  <th className="text-center">ACTION</th>
                </tr>
              </thead>
              <tbody
                className={outstanding_viewlist === "true" ? "" : "testingggg"}
              >
                {Loading ? (
                  <tr>
                    <td className="no_records" colSpan="8">
                      Loading....
                    </td>
                  </tr>
                ) : (
                  [listData]
                )}
              </tbody>
            </table>
          </div>
        </Col>
        {countBar()}
      </Col>
    </>
  );
};

export default Customer;
