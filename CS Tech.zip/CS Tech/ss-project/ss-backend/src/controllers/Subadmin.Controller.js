const logger = require("../utilities/logger")
const { Auth, Merchant, Token, Subpermision } = require("../models/model.index");
const { APIError } = require("../utilities/APIError");
const {
    generateError,
    ERROR_STATUS_CODE,
    INTERNAL_SERVER_ERROR,
    EMAIL_NOT_EXISTS,
    WRONG_PASSWORD,
    PERMISSION_DENIED,
    USER_ALREADY_EXISTS,
    UNEXPECTED_ERROR,
    PASSWORD_NOT_MATCH
} = require("../utilities/errorContants");

exports.getSubAdminList = async (req, res, next) => {
    try {
        const subAdminList = await Auth.find({ userRole: "sub-admin" }).sort({ createdAt: -1 })
        res.json({ subAdminList })
    } catch (error) {
        logger.error(
            `Error while registering user with details ${JSON.stringify(
                req.body
            )} and error ${generateError(error)}`
        );
        return next(
            new APIError(
                ERROR_STATUS_CODE.INTERNAL_SERVER_ERROR_CODE,
                INTERNAL_SERVER_ERROR,
                error.message
            )
        );
    }
}

exports.deleteSubAdmin = async (req, res, next) => {
    const { _id } = req.params
    try {
        const SubUserData = await Auth.findOne({ _id });
        if (SubUserData) {
            await Auth.deleteOne({ _id: SubUserData._id });
            await Subpermision.deleteOne({ userId: SubUserData._id })
        }
        res.json({ message: "successfuly deleted" })
    } catch (error) {
        logger.error(
            `Error while registering user with details ${JSON.stringify(
                req.body
            )} and error ${generateError(error)}`
        );
        return next(
            new APIError(
                ERROR_STATUS_CODE.INTERNAL_SERVER_ERROR_CODE,
                INTERNAL_SERVER_ERROR,
                error.message
            )
        );
    }
}

exports.getSubAdminDetails = async (req, res, next) => {
    const { _id } = req.params
    try {
        const useData = await Auth.findOne({ _id })
        const accessData = await Subpermision.findOne({ userId: useData._id });
        res.json({ useData, accessData })
    } catch (error) {
        logger.error(
            `Error while registering user with details ${JSON.stringify(
                req.body
            )} and error ${generateError(error)}`
        );
        return next(
            new APIError(
                ERROR_STATUS_CODE.INTERNAL_SERVER_ERROR_CODE,
                INTERNAL_SERVER_ERROR,
                error.message
            )
        );
    }
}

exports.editSubUser = async (req, res, next) => {
    const { _id } = req.params;
    const data = req.body;
    const { firstName, lastName, emailId, mobileNo, companyName, password } = data
    try {
        const userData = await Auth.findOne({ _id });
        await Auth.updateOne({ _id: userData._id }, {
            $set: {
                firstName,
                lastName,
                emailId,
                mobileNo,
                companyName,
                password
            }
        });
        res.json({ message: "successfully updated!!" })

    } catch (error) {
        logger.error(
            `Error while registering user with details ${JSON.stringify(
                req.body
            )} and error ${generateError(error)}`
        );
        return next(
            new APIError(
                ERROR_STATUS_CODE.INTERNAL_SERVER_ERROR_CODE,
                INTERNAL_SERVER_ERROR,
                error.message
            )
        );
    }
}

exports.activeSubUser = async (req, res, next) => {
    const { _id } = req.params
    try {
        const subAdminData = await Auth.findOne({ _id });
        if (subAdminData && subAdminData.activate === "active") {
            await Auth.updateOne(
                { _id: subAdminData._id },
                {
                    $set: {
                        activate: "deactive",
                    },
                }
            );
            res.json({ status: 200, message: `account deactivated successfully` });
        } else {
            await Auth.updateOne(
                { _id: subAdminData._id },
                {
                    $set: {
                        activate: "active",
                    },
                }
            );
            res.json({ status: 200, message: `account activated successfully` });
        }

    } catch (error) {
        logger.error(
            `Error while registering user with details ${JSON.stringify(
                req.body
            )} and error ${generateError(error)}`
        );
        return next(
            new APIError(
                ERROR_STATUS_CODE.INTERNAL_SERVER_ERROR_CODE,
                INTERNAL_SERVER_ERROR,
                error.message
            )
        );
    }
}

exports.getSubCustomerDataBySearch = async (req, res, next) => {
    const { search } = req.query;
    const pipeline = [
        {
            $match: {
                $or: [
                    { firstName: { $regex: search, $options: 'im' } },
                    { emailId: { $regex: search, $options: 'im' } },
                    { mobileNo: { $regex: search, $options: 'im' } }
                ]
            }
        },
        {
            $sort: { createdAt: -1 }
        }
    ]
    try {
        const useData = await Auth.aggregate(pipeline);
        const searchData = useData.filter(data => data.userRole !== "admin")
        res.json({ searchData });
    } catch (error) {
        logger.error(
            `Error while registering user with details ${JSON.stringify(
                req.body
            )} and error ${generateError(error)}`
        );
        return next(
            new APIError(
                ERROR_STATUS_CODE.INTERNAL_SERVER_ERROR_CODE,
                INTERNAL_SERVER_ERROR,
                error.message
            )
        );
    }
}

exports.editSubUserPermissions = async (req, res, next) => {
    const data = req.body;
    let {
        _id, active, add, change_password, codreports_exportfile, codreports_track, codreports_viewlist, customers_exportfile,
        dashboard_graph, edit, manage_profile, opayment, order_list, ostatement, outstanding_exportfile, outstanding_viewlist,
        payment, register_list, shipments_exportfile, shipments_track, shipments_viewlist, statement, customers_viewlist
    } = data
    try {
        const subUserPermissionData = await Subpermision.findOne({ userId: _id })
        const updateData = await Subpermision.updateOne({ _id: subUserPermissionData._id }, {
            $set: {
                change_password,

                "codreports.codreports_exportfile": codreports_exportfile,
                "codreports.codreports_track": codreports_track,
                "codreports.codreports_viewlist": codreports_viewlist,

                "customers.customers_action.add": add,
                "customers.customers_action.edit": edit,
                "customers.customers_action.active": active,
                "customers.customers_action.payment": payment,
                "customers.customers_action.statement": statement,
                "customers.customers_viewlist": customers_viewlist,
                "customers.customers_exportfile": customers_exportfile,

                "dashboard.dashboard_graph": dashboard_graph,
                "dashboard.order_list": order_list,
                "dashboard.register_list": register_list,

                manage_profile,

                "outstanding.outstanding_action.opayment": opayment,
                "outstanding.outstanding_action.ostatement": ostatement,
                "outstanding.outstanding_exportfile": outstanding_exportfile,
                "outstanding.outstanding_viewlist": outstanding_viewlist,

                "shipments.shipments_viewlist": shipments_viewlist,
                "shipments.shipments_exportfile": shipments_exportfile,
                "shipments.shipments_track": shipments_track
            }
        })

        if (updateData) {
            res.json({ message: "permission assigned successfully!!" })
        }
    } catch (error) {
        logger.error(
            `Error while registering user with details ${JSON.stringify(
                req.body
            )} and error ${generateError(error)}`
        );
        return next(
            new APIError(
                ERROR_STATUS_CODE.INTERNAL_SERVER_ERROR_CODE,
                INTERNAL_SERVER_ERROR,
                error.message
            )
        );
    }
}