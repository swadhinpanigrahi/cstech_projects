import React, { useState, useEffect } from "react";
const ProposalList = () => {


    return (
        <div>
            <h1>ProposalList List Page</h1>
        </div>
    )

}

export default ProposalList;
