import React from "react";
import * as RB from "react-bootstrap";
import invoiceimg from "../../Images/imagec.png";

const ProposalInvoiceModel = ({
  show2,
  handleClose2,
  proposalInvoiceDetails,
}) => {
  return (
    <div>
      <RB.Modal show={show2} onHide={handleClose2} id="orders_modal">
        <RB.Modal.Header closeButton>
          <RB.Modal.Title>Quotation</RB.Modal.Title>
        </RB.Modal.Header>
        <RB.Modal.Body
          className="invoice_modalbody"
          style={{ paddingBottom: "20px" }}
        >
          <RB.Row>
            <RB.Col lg={6}>
              <span className="logo-invoice">
                <img
                  src="http://ibcdn.imagesbazaar.com/Html2015/images/logo_imagesBazaar.png"
                  alt="img_img1"
                />
              </span>
            </RB.Col>
            <RB.Col lg={6} className="text-right">
              <a href="javascript:print()" className="print_invoice">
                <i className="fa fa-print"></i>
              </a>
            </RB.Col>
          </RB.Row>
          <div className="main_orders">
            <RB.Row
              className="headinv"
              id="invoicem"
              style={{ borderBottom: "0px" }}
            >
              <RB.Col lg={12} className="pd_0">
                <RB.Table responsive>
                  <tbody>
                    <tr className="border_btm">
                      <td className="td_first td_qtfirst tr_quot">
                        <p class="mg-b-0">
                          <strong>Quotation No.:</strong> 34567778
                        </p>
                      </td>
                      <td className="td_second td_qtsecond tr_quot">
                        <p class="mg-b-0">
                          <strong>Date:</strong> 2021-03-05T14:38:00.000Z
                        </p>
                      </td>
                    </tr>
                    <tr className="border_btm">
                      <td className="td_first td_qtfirst tr_quot">
                        <p class="mg-b-0">
                          <strong>Kind Attn:</strong> Atti
                        </p>
                      </td>
                      <td className="td_second td_qtsecond"></td>
                    </tr>
                  </tbody>
                </RB.Table>
              </RB.Col>
            </RB.Row>
            <RB.Row
              className="headinv"
              id="invoicem"
              style={{ borderBottom: "0px" }}
            >
              <RB.Col lg={12} className="pd_0">
                <RB.Table responsive>
                  <thead>
                    <tr className="tr_quot">
                      <th className="td_first text-center">Image</th>
                      <th className="td_first text-center">Item ID</th>
                      <th className="td_first text-center">Image Type</th>
                      <th className="td_first text-center">Dimension (Px)</th>
                      <th className="td_first text-center">Rights</th>
                      <th className="text-right">Amount (Rs.)</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="border_btm">
                      <td className="td_first">
                        <img src={invoiceimg} alt="invoiceimg" />
                      </td>
                      <td className="td_first">
                        <p class="mg-b-0">SM748545</p>
                      </td>
                      <td className="td_first">
                        <p class="mg-b-0">SMALL</p>
                      </td>
                      <td className="td_first">
                        <p class="mg-b-0">1500X2250 at 300dpi</p>
                      </td>
                      <td className="td_first">
                        <p class="mg-b-0">Non-Exclusive</p>
                      </td>
                      <td className="td_second">
                        <p class="mg-b-0">2200</p>
                      </td>
                    </tr>
                    <tr className="border_btm">
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td className="text-right td_first">
                        <p className="mg-b-0 resblock">
                          <strong>Total</strong>
                        </p>
                      </td>
                      <td className="text-right">
                        <p class="mg-b-0">2200</p>
                      </td>
                    </tr>
                    <tr className="border_btm">
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td className="text-right td_first">
                        <p className="mg-b-0 resblock">
                          <strong>Discount</strong>
                        </p>
                      </td>
                      <td className="text-right">
                        <p class="mg-b-0">0</p>
                      </td>
                    </tr>
                    <tr className="border_btm">
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td className="text-right td_first">
                        <p className="mg-b-0 resblock">
                          <strong>IGST Value @18% (INR)</strong>
                        </p>
                      </td>
                      <td className="text-right">
                        <p class="mg-b-0">25960</p>
                      </td>
                    </tr>
                    <tr className="border_btm">
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td className="text-right td_first">
                        <p className="mg-b-0 resblock">
                          <strong>Net Payable Amount</strong>
                        </p>
                      </td>
                      <td className="text-right">
                        <p class="mg-b-0">25960</p>
                      </td>
                    </tr>
                  </tbody>
                </RB.Table>
                <RB.Table responsive>
                  <tbody>
                    <tr>
                      <td className="invoice_tdl">
                        <p className="mg-b-0">
                          PAN No. : <strong>AADCM6333L</strong>
                        </p>
                        <p className="mg-b-0">
                          GSTIN No. : <strong>GST8906538765234</strong>
                        </p>
                        <p className="mg-b-0">
                          HSN/SAC No. : <strong>998439</strong>
                        </p>
                        <p className="quot_imgtext">
                          Imagesbazaar is fully owned subsidiary of Mash Audio
                          Visuals Pvt. Ltd. Usage of images subject to Mash
                          Rights Agreement mentioned on{" "}
                          <a href="www.imagesbazaar.com/licensing">
                            www.imagesbazaar.com/licensing
                          </a>
                        </p>
                        <p className="quot_imgtext">
                          This is a computer generated Quotation and does not
                          require any authorised signatory.
                        </p>
                        <p className="quot_imgtext">
                          Kindly send Cheque/Demand Draft in favour of MASH
                          AUDIO VISUALS PVT. LTD. Payable at NEW DELHI to the
                          address given below :
                        </p>
                        <p className="quot_imgtext">
                          <strong>Mash Audio Visuals Private Limited</strong>
                        </p>
                        <p>
                          <strong>505, Aggarwal Prestige Mall,</strong>
                        </p>
                        <p>
                          <strong>Plot No.2, Road No.44,</strong>
                        </p>
                        <p>
                          <strong>Pitam Pura, New Delhi-110034</strong>
                        </p>
                        <p>
                          <a
                            href="www.imagesbazaar.com/licensing"
                            className="img_head"
                          >
                            www.imagesbazaar.com/licensing
                          </a>
                        </p>
                      </td>
                    </tr>
                  </tbody>
                </RB.Table>
              </RB.Col>
            </RB.Row>
          </div>
        </RB.Modal.Body>
      </RB.Modal>
    </div>
  );
};

export default ProposalInvoiceModel;
