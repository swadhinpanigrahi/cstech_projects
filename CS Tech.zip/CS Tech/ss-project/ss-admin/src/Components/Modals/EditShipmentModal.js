import React, { useState, useEffect } from 'react';
import { Modal, Button, Form, FormText } from "react-bootstrap";
import {
    updateShipmentDetail, GET_LOGS, getShipmentDropdownList
} from "../../Utils/api";

import swal from 'sweetalert';

const EditShipmentModal = (
    {
        EditShipment, setEditShipment, TrakingData, onButtonSearch,
        apiCall, pagination, Search, IsFilter,
    }
) => {
    const [FormData, setFormData] = useState({});
    const [Errors, setErrors] = useState("");
    const [LogList, setLogList] = useState([]);
    const [SearchHeader, setSearchHeader] = useState({
        provider: [],
        status: [],
    });

    const handleChange = (e) => {
        let { name, value } = e.target;
        const data = { ...FormData };
        data[name] = value;
        if (data.tracking_number === "") {
            setErrors("please enter valid traking number")
        } else {
            setErrors("")
        }
        setFormData(data);
    }

    const closeModal = () => {
        setEditShipment(false);
        setErrors("")
    }

    const EditShipmentFun = async () => {
        swal({
            title: "Are you sure you want to update ?",
            // text: "Once updated, you will not be able to recover this shipment details!",
            icon: "warning",
            buttons: true,
            dangerMode: true,
        })
            .then((willDelete) => {
                if (willDelete) {
                    const res = updateShipmentDetail(FormData).then((data) => {
                        if (data) {
                            { IsFilter ? onButtonSearch() : apiCall(pagination, Search) }
                        }
                    })
                    swal("Your Traking shipment has been Updated Successfully!", {
                        icon: "success",
                    });
                    setErrors("");
                } else {
                    swal("Your shipment details is safe!");
                }
            });
    }

    useEffect(() => {
        setFormData(TrakingData);
        const apiCall1 = async () => {
            const res = await getShipmentDropdownList();
            let { provider, status } = res;
            const updateState = { ...SearchHeader };
            updateState.provider = [...provider];
            updateState.status = [...status];
            setSearchHeader({ ...updateState });
        };
        apiCall1();

    }, [TrakingData])

    useEffect(() => {
        const getLogApi = async () => {
            const res = await GET_LOGS(FormData.order_number);
            let { data } = res;
            setLogList(data)
        }
        getLogApi();
    }, [LogList])

    let { provider } = SearchHeader;

    return (
        <Modal className="sedit_modal"
            show={EditShipment}
            onHide={closeModal}
            backdrop="static"
            keyboard={false}
        >
            <Modal.Header closeButton>
                <Modal.Title>Update Traking</Modal.Title>
            </Modal.Header>
            <Modal.Body>
                <p><strong>Order Number :</strong> {FormData.order_number}</p>

                <Form>

                    <Form.Group className="mb-0" controlId="formBasicEmail">
                        <Form.Label>Traking Number</Form.Label>
                        <Form.Control
                            type="email"
                            name="tracking_number"
                            placeholder="Enter Traking Number"
                            value={FormData.tracking_number}
                            onChange={handleChange}
                            className={Errors === "" ? "" : "border-danger"}
                        />
                    </Form.Group>

                    <Form.Group className="mb-0" controlId="formBasicEmail">
                        <label className="pwdc">Shiping Provider</label>
                        <select
                            className="form-control"
                            id="assocom"
                            name="shipping_method"
                            onChange={handleChange}
                            style={{ padding: "4px 10px", color: "#000" }}
                            value={FormData.shipping_method}
                        >
                            {provider.map((data, inx) => {
                                return (
                                    <option key={"SHIP-PPProvider" + inx}>{data}</option>
                                );
                            })}
                        </select>
                    </Form.Group>

                    {Errors === "" ? "" : <FormText className="text-danger">{Errors}</FormText>}
                    <Button variant="secondary" onClick={Errors === "" ? EditShipmentFun : null}
                        style={{ float: "right" }} className="mb-3 mt-3">
                        UPDATE
                    </Button>
                </Form>
                {LogList.length > 0 ?
                    <table className="modal_editt">
                        <thead className="thead-dark">
                            {/* <th>SL NO.</th> */}
                            <th>Order Number</th>
                            <th>Old Traking No.</th>
                            <th>New Traking No.</th>
                            <th>Old Ship Provider</th>
                            <th>New Ship Provider</th>
                            <th>Date</th>
                        </thead>
                        <tbody>
                            {LogList.map((info, inx) => {
                                return (
                                    <tr key={`LOG_DETAILS_${inx}`}>
                                        {/* <td>{inx + 1}</td> */}
                                        <td className="border_righttd">{info.order_number}</td>
                                        <td className="border_righttd">{info.old_tracking_number}</td>
                                        <td className="border_righttd">{info.tracking_number}</td>
                                        <td className="border_righttd">{info.old_shipping_method}</td>
                                        <td className="border_righttd">{info.shipping_method}</td>
                                        <td>{info.createdAt.slice(0, 10)}</td>
                                    </tr>
                                )
                            })}
                        </tbody>
                    </table> : ""}
            </Modal.Body>
        </Modal>
    )
}

export default EditShipmentModal
