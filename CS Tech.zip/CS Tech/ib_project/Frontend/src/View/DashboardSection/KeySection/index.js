import React from 'react';

import { Route } from "react-router-dom";

import VisibleKey from "./VisibleKey";
import AllKeys from './AllKeys';

const KeySectrion = () => {
    return (
        <>
            <Route path="/dashboard/keyword/visiblekeys/get" component={VisibleKey} />
            <Route path="/dashboard/keyword/allkeys/get" component={AllKeys} />
        </>
    )
}

export default KeySectrion
