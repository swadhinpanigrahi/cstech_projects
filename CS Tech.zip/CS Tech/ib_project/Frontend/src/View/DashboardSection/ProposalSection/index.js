import React from 'react';
import ProposalList from "./ProposalList";
import ProposalListnew from './ProposalListnew';
import ProposalCreate from './ProposalCreate';
import ProposalCheckout from './ProposalCheckout';
import ProposalPrint from './ProposalPrint';
import OrderCheckout from './OrderCheckout';
import { Route } from "react-router-dom"

export const ProposalSection = () => {
    return (
        <div>
            <Route path="/dashboard/proposal/get" component={ProposalList} />
            <Route path="/dashboard/proposal/listn" component={ProposalListnew} />
            <Route path="/dashboard/proposal/create" component={ProposalCreate} />
            <Route path="/dashboard/proposal/checkout" component={ProposalCheckout} />
            <Route path="/dashboard/proposal/print" component={ProposalPrint} />
            <Route path="/dashboard/proposal/ordercheckout/:CS_username" component={OrderCheckout} />
        </div>
    )
}

export default ProposalSection