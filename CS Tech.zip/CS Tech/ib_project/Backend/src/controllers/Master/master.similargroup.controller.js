const { M_SIMILARGROUP } = require("../../model");

exports.AddSimilarGroup = async (req, res) => {
    const {
        f_groupname, S_groupid
    } = req.body;
    try {
        const existingData = await M_SIMILARGROUP.findOne({ f_groupname });
        if (existingData) {
            res.json({ status: 400, message: "already exist" })
        }
        if (!existingData) {
            const Data = await new M_SIMILARGROUP({
                f_groupname, S_groupid
            }).save();
            if (Data) {
                res.json({ status: 200, message: "added successfully" })
            }
        }
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

exports.getSimilarGroupList = async (req, res) => {
    const { currentPage, itemPerPage, searchData } = req.query;
    const num = parseInt(itemPerPage)
    const start = parseInt(currentPage);
    let pipeline;
    let countline;
    try {
        if (!searchData || searchData === "") {
            pipeline = [
                { $sort: { _id: -1 } },
                { $skip: (start - 1) * num },
                { $limit: num },
            ]
            countline = [
                { $count: "totalcount" }
            ]
        } else {
            pipeline = [
                { $match: { f_groupname: { $regex: searchData, $options: "im" } } },
                { $sort: { _id: -1 } },
                { $skip: (start - 1) * num },
                { $limit: num },
            ]
            countline = [
                { $match: { f_groupname: { $regex: searchData, $options: "im" } } },
                { $count: "totalcount" }
            ]
        }
        const data = await M_SIMILARGROUP.aggregate(pipeline)
        const totalrecord = await M_SIMILARGROUP.aggregate(countline)
        res.json({ status: 200, data, totalrecord })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

exports.getSimilarGroup = async (req, res) => {
    const { _id } = req.params;
    try {
        const data = await M_SIMILARGROUP.findOne({ _id });
        res.json({ status: 200, data })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

exports.updateSimilarGroup = async (req, res) => {
    const {
        _id, f_groupname, S_groupid
    } = req.body
    try {
        const data = await M_SIMILARGROUP.findByIdAndUpdate({ _id }, {
            $set: {
                f_groupname, S_groupid
            }
        });
        res.json({ status: 200, message: "updated successfully" })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

exports.removeSimilarGroup = async (req, res) => {
    const { _id } = req.params;
    try {
        const data = await M_SIMILARGROUP.findByIdAndRemove({ _id });
        res.json({ status: 200, message: "removed successfully" })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}