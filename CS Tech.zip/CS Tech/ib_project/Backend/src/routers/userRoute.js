const userRoute = require("express").Router();
const {
  userLogin,
  forgetPasswordEmail,
  varify,
  changePassword,
  getAdminInfo,
  changePasswordFromEmail,
  onSearchBarCustomerDetails,
  onSearchBarOrderDetails,
  onSearchBarProposalDetails,
  onSearchBarFollowupDetails,
  cardCount,
  onButtonClickData,
  getOrderbyOrderId,
  getUserDeatilsByUsername,
  updateUserActionEdit,
  getCountryList,
  getStateByID,
  SubMitFollowUpRecord,
  getCompanyMaster,
  fetchCompanyDataByKeyPress,
  customerProfile,
  editCustomerProfile,
  getOrderInvoiceOrderId,
  fetchEmailDataByKeyPress,
  getDailySalesEntryLists,
  getFollowupsDetailsTableByIDs,
  getFollowupsDetailsByIds,
  getDailySalesEntryListByFilter,
  getmasterstatecustom
} = require("../controllers/userRouteController");

userRoute.post("/adminlogin", userLogin);
userRoute.get("/verifytoken", varify);
userRoute.post("/forgetpassword", forgetPasswordEmail);
userRoute.post("/changepasswordfrommail", changePasswordFromEmail);
userRoute.post("/changepassword", changePassword);
userRoute.post("/getAdminInfo", getAdminInfo);
userRoute.get("/cardcount", cardCount);
userRoute.post("/onSearchBarCustomerDetails", onSearchBarCustomerDetails);
userRoute.post("/onSearchBarOrderDetails", onSearchBarOrderDetails);
userRoute.post("/onSearchBarProposalDetails", onSearchBarProposalDetails);
userRoute.post("/onSearchBarFollowupsDetails", onSearchBarFollowupDetails);
userRoute.post("/buttonsearch/:btn_search", onButtonClickData);
//latest-temp;-
// userRoute.route("/getcustomerprofile/:f_userid").get(customerProfile);
// userRoute.route("/editcustomerprofile/:f_userid").post(editCustomerProfile);

// userRoutes.js  bottom
//order details
userRoute.get("/getOrderbyOrderId/:orderId", getOrderbyOrderId);
userRoute.get("/getinvoicedetails/:orderId", getOrderInvoiceOrderId);
userRoute.get("/getUserDeatilsByUsername/:uname", getUserDeatilsByUsername);
userRoute.post('/updateUserActionEdit', updateUserActionEdit)

userRoute.route("/getcustomerprofile/:f_userid").get(customerProfile);
userRoute.route("/editcustomerprofile/:f_userid").post(editCustomerProfile);

//follow up create ATTI

userRoute.get("/getCountryList", getCountryList);

userRoute.get("/getStateByID/:CountryID", getStateByID);
userRoute.post("/SubMitFollowUpRecord", SubMitFollowUpRecord)

userRoute.get('/getCompanyMaster', getCompanyMaster)
userRoute.post('/fetchCompanyDataByKeyPress', fetchCompanyDataByKeyPress)

userRoute.post('/fetchEmailDataByKeyPress', fetchEmailDataByKeyPress)
userRoute.get('/getDailySalesEntryLists', getDailySalesEntryLists)
userRoute.post('/getFollowupsDetailsTableByIDs', getFollowupsDetailsTableByIDs)
userRoute.post('/getFollowupsDetailsByIds', getFollowupsDetailsByIds)

userRoute.post('/getDailySalesEntryListByFilter', getDailySalesEntryListByFilter)

userRoute.get('/getmasterstatecustom', getmasterstatecustom);

module.exports = userRoute;
