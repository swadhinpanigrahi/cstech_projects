const mongoose = require("mongoose");

const t_Images_Schema = mongoose.Schema(
    {
        f_sno: { type: Number },
        F_imgid: { type: String },
        F_rank: { type: Number },
        F_group: { type: Number },
        deletedrow: { type: Boolean },
        suspendrow: { type: Boolean },
        f_pricing: { type: Number },
        nonexclusive: { type: Boolean },
        f_rank5: { type: Number },
        suspendate: { type: Date },
        f_agencyname: { type: String },
        f_Editorialid: { type: Boolean },
        f_exclusiveonly: { type: Boolean },
        f_view: { type: String },
        f_Available: { type: String },
        f_imgType: { type: String },
        f_createdate: { type: Date },
        f_imgstatus: { type: Number },
        f_rank1: { type: String },
    },
    { collection: "T_images_IB_MongoDB" }
)

module.exports = t_Images = mongoose.model(
    "T_images_IB_MongoDB",
    t_Images_Schema
);
