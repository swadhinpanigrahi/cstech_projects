const mongoose = require("mongoose");

const MasterModalVedioSchema = mongoose.Schema(
    {
        id: { type: String },
        f_still_folder: { type: String },
        f_video_floder: { type: String },
        f_map: { type: Number },
    },
    { collection: "t_modelvideo" }
);

module.exports = M_MODALVEDIO = mongoose.model(
    "t_modelvideo",
    MasterModalVedioSchema
);