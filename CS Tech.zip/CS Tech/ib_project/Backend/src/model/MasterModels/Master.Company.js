const mongoose = require("mongoose");

const MasterCompanySchema = mongoose.Schema(
    {
        f_sno: { type: String },
        f_companyname: { type: String },
        f_companygroup: { type: String },
        f_similarcompanyname: { type: String },
        f_discount: { type: String },
        f_city: { type: String },
        f_Assign: { type: String },
        f_email: { type: String }

    },
    { collection: "t_Company_master" }
);

module.exports = M_COMPANY = mongoose.model(
    "t_Company_master",
    MasterCompanySchema
);