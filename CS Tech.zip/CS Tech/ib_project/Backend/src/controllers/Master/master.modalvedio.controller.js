const { M_MODALVEDIO } = require("../../model");

exports.addVedioModel = async (req, res) => {
    const { f_still_folder, f_video_floder, f_map } = req.body;
    try {
        const existingData = await M_MODALVEDIO.findOne({ f_still_folder });
        if (existingData) {
            res.json({ status: 400, message: "star size already exist" })
        }
        if (!existingData) {
            const Data = await new M_MODALVEDIO({ f_still_folder, f_video_floder, f_map }).save();
            if (Data) {
                res.json({ status: 200, message: "star size added successfully" })
            }
        }
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

exports.getVedioModelList = async (req, res) => {
    const { currentPage, itemPerPage, searchData } = req.query;
    const num = parseInt(itemPerPage)
    const start = parseInt(currentPage);
    let pipeline;
    let countline;
    try {
        if (!searchData || searchData === "") {
            pipeline = [
                { $skip: (start - 1) * num },
                { $limit: num },
                { $sort: { _id: -1 } }
            ]
            countline = [
                { $count: "totalcount" }
            ]
        } else {
            pipeline = [
                { $match: { f_still_folder: { $regex: searchData, $options: "im" } } },
                { $skip: (start - 1) * num },
                { $limit: num },
                { $sort: { _id: -1 } }
            ]
            countline = [
                { $match: { f_still_folder: { $regex: searchData, $options: "im" } } },
                { $count: "totalcount" }
            ]
        }
        const data = await M_MODALVEDIO.aggregate(pipeline)
        const totalrecord = await M_MODALVEDIO.aggregate(countline)
        res.json({ status: 200, data, totalrecord })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

exports.activedeactiveVedioModel = async (req, res) => {
    const { _id, f_map } = req.params;
    try {
        const data = await M_MODALVEDIO.findOne({ _id });
        if (f_map == 1 && data) {
            await M_MODALVEDIO.findByIdAndUpdate({ _id }, { $set: { f_map: 0 } })
            res.json({ status: 200, message: "successfully deactiveted!" })
        }
        if (f_map == 0 && data) {
            await M_MODALVEDIO.findByIdAndUpdate({ _id }, { $set: { f_map: 1 } })
            res.json({ status: 200, message: "successfully activated" })
        }
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

exports.removeVedioModel = async (req, res) => {
    const { _id } = req.params;
    try {
        const removeData = await M_MODALVEDIO.findByIdAndRemove({ _id });
        if (removeData) {
            res.json({ status: 200, message: "successfully deleted!" })
        }
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}