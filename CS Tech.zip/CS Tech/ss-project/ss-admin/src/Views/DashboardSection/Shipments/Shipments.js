import React, { useState, useEffect, useRef, useCallback } from "react";
import Cookie from "js-cookie";
import {
  getShipmentDetailsList,
  getShipmentDropdownList,
  shipmentButtonFilter,
  getShipmentDetailsForView,
  shipmentButtonFilterCount,
  getShipmentDetailsListForExport,
  shipmentCODButtonFilterExport,
  removeShipmentDetail
} from "../../../Utils/api";
import { Col, Row } from "react-bootstrap";
import { Link } from "react-router-dom";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import ReactExport from "react-data-export";

import swal from 'sweetalert';

import ShipmentView from "./ShipmentView";

import EditShipmentModal from "../../../Components/Modals/EditShipmentModal";

const Shipments = () => {
  const [ShipmentData, setShipmentData] = useState([]);
  const [Loading, setLoading] = useState(false);
  const [Search, setSearch] = useState("");
  let [pagination, setPagination] = useState(0);
  const [totalPage, setTotalPage] = useState(0);
  const [SearchHeader, setSearchHeader] = useState({
    provider: [],
    status: [],
  });
  const [ShipmentAuth, setShipmentAuth] = useState({
    shipments_viewlist: "",
    shipments_exportfile: "",
    shipments_track: "",
  });

  const [Short, setShort] = useState("ascending");
  const [Name, setName] = useState("");

  const [ExportData, setExportData] = useState([]);
  const [IsExportCall, setIsExportCall] = useState(true);
  const [ButtonForm, setButtonForm] = useState({});
  let [startDate, setStartDate] = useState(0);
  let [endDate, setEndDate] = useState(0);
  //VIEW MODEL
  const [TrakingData, setTrakingData] = useState({
    totalData: {},
    from_data: {},
    to_data: {},
  });
  const [show, setShow] = useState(false);

  const [EditShipment, setEditShipment] = useState(false);
  const [IsFilter, setIsFilter] = useState(false)

  const handleClose = () => setShow(false);
  const handleShow = async (tracking_number) => {
    const res = await getShipmentDetailsForView(tracking_number);
    let { status, trakingData, error } = res;
    if (!error && status === 200) {
      const updateState = { ...TrakingData };
      updateState.totalData = trakingData;
      updateState.from_data = trakingData.from_address;
      updateState.to_data = trakingData.to_address;
      setTrakingData({ ...updateState });
    } else {
      window.alert("Network Error");
    }
    setShow(true);
  };
  //VIEW MODEL

  let { shipments_viewlist, shipments_exportfile, shipments_track } =
    ShipmentAuth;

  startDate = startDate === null ? setStartDate(0) : startDate;
  endDate = endDate === null ? setEndDate(0) : endDate;

  const handleChange = async (e) => {
    setSearch(e.target.value);
    setPagination(0);
    const res = await getShipmentDetailsList((pagination = 0), e.target.value);
    let { trakingDetailsList, count } = res;
    const shaloArray = [...trakingDetailsList];
    setShipmentData(shaloArray);
    setTotalPage(count);
  };

  const buttonHandleChange = async (e, date) => {
    let { name, value, type } = e.target;
    if (type === "select-one") {
      let data = { ...ButtonForm };
      data[name] = value;
      setButtonForm({ ...data });
    } else {
      const updateState = { ...ButtonForm };
      ButtonForm.startDate = date;
      setButtonForm({ ...updateState });
    }
  };

  const onButtonSearch = async () => {
    setPagination(0);
    setIsFilter(true)
    const res = await shipmentButtonFilter({
      ...ButtonForm,
      startDate,
      endDate,
      pagination: 0,
    });
    let { error, filteredData } = res;
    if (!error) {
      console.log(filteredData)
      setShipmentData(filteredData);
    }
    const res1 = await shipmentButtonFilterCount({
      ...ButtonForm,
      startDate,
      endDate,
      pagination,
    });
    let { count } = res1;
    setTotalPage(count);

    const ExportFilterData = await shipmentCODButtonFilterExport({
      ...ButtonForm,
      startDate,
      endDate,
      pagination,
    });
    let { shipExportList } = ExportFilterData;
    setExportData(shipExportList);
  };

  const TotalPage = Math.ceil(totalPage / 20);
  const observer = useRef();
  const lastBookElement = useCallback(
    (node) => {
      if (observer.current) observer.current.disconnect();
      observer.current = new IntersectionObserver(async (entries) => {
        if (ShipmentData.length > 19) {
          if (entries[0].isIntersecting && pagination <= TotalPage) {
            let { shipping_method, fulfillment_status } = ButtonForm;
            if (
              startDate === 0 &&
              endDate === 0 &&
              !shipping_method &&
              !fulfillment_status
            ) {
              setPagination((prevPageNumber) => prevPageNumber + 1);
              const res = await getShipmentDetailsList(pagination, Search);
              let { trakingDetailsList } = res;
              let mergeArray = [...ShipmentData, ...trakingDetailsList];
              if (Name !== "" && Name !== "name") {
                if (Short === "ascending") {
                  const shortedArray = mergeArray.sort((a, b) => {
                    if (a[Name] > b[Name]) return -1;
                    if (a[Name] < b[Name]) return 1;
                    return 0;
                  });
                  setShipmentData(shortedArray);
                } else {
                  const shortedArray = mergeArray.sort((a, b) => {
                    if (a[Name] > b[Name]) return 1;
                    if (a[Name] < b[Name]) return -1;
                    return 0;
                  });
                  setShipmentData(shortedArray);
                }
              } else if (Name === "name") {
                if (Short === "ascending") {
                  const shortedArray = mergeArray.sort((a, b) => {
                    if (a.from_address[Name].toLowerCase() > b.from_address[Name].toLowerCase()) return -1;
                    if (a.from_address[Name].toLowerCase() < b.from_address[Name].toLowerCase()) return 1;
                    return 0;
                  });
                  setShipmentData(shortedArray);
                } else {
                  const shortedArray = mergeArray.sort((a, b) => {
                    if (a.from_address[Name].toLowerCase() > b.from_address[Name].toLowerCase()) return 1;
                    if (a.from_address[Name].toLowerCase() < b.from_address[Name].toLowerCase()) return -1;
                    return 0;
                  });
                  setShipmentData(shortedArray);
                }
              } else {
                setShipmentData(mergeArray);
              }
            } else {
              setPagination((prevPageNumber) => prevPageNumber + 1);
              const res = await shipmentButtonFilter({
                ...ButtonForm,
                startDate,
                endDate,
                pagination,
              });
              let { error, filteredData } = res;
              if (!error) {
                let mergeArray = [...ShipmentData, ...filteredData];
                if (Name !== "" && Name !== "name") {
                  if (Short === "ascending") {
                    const shortedArray = mergeArray.sort((a, b) => {
                      if (a[Name] > b[Name]) return -1;
                      if (a[Name] < b[Name]) return 1;
                      return 0;
                    });
                    setShipmentData(shortedArray);
                  } else {
                    const shortedArray = mergeArray.sort((a, b) => {
                      if (a[Name] > b[Name]) return 1;
                      if (a[Name] < b[Name]) return -1;
                      return 0;
                    });
                    setShipmentData(shortedArray);
                  }
                } else if (Name === "name") {
                  if (Short === "ascending") {
                    const shortedArray = mergeArray.sort((a, b) => {
                      if (a.from_address[Name].toLowerCase() > b.from_address[Name].toLowerCase()) return -1;
                      if (a.from_address[Name].toLowerCase() < b.from_address[Name].toLowerCase()) return 1;
                      return 0;
                    });
                    setShipmentData(shortedArray);
                  } else {
                    const shortedArray = mergeArray.sort((a, b) => {
                      if (a.from_address[Name].toLowerCase() > b.from_address[Name].toLowerCase()) return 1;
                      if (a.from_address[Name].toLowerCase() < b.from_address[Name].toLowerCase()) return -1;
                      return 0;
                    });
                    setShipmentData(shortedArray);
                  }
                } else {
                  setShipmentData(mergeArray);
                }
              }
            }
          }
        }
      });
      if (node) observer.current.observe(node);
    },
    [ShipmentData]
  );

  //EXPORT
  const ExcelFile = ReactExport.ExcelFile;
  const ExcelSheet = ReactExport.ExcelFile.ExcelSheet;
  const DataSet = [
    {
      columns: [
        { title: "ORDER ID" },
        { title: "PARTNER ORDERID" },
        { title: "SHIPING PROVIDER" },
        { title: "TYPE" },
        { title: "ORDER NUMBER" },
        { title: "AMOUNT (SAR)" },
        { title: "SHOP NAME" },
        { title: "SHIPING NAME" },
        { title: "ACCOUNT ID" },
        { title: "TRACKING NUMBER" },
        { title: "CREATION DATE" },
        { title: "DELIVERY DATE" },
        { title: "RETURNED DATE" },
        { title: "STATUS" },

        { title: "FROM NAME" },
        { title: "FROM COMPANY NAME" },
        { title: "FROM ADDRESS" },
        { title: "FROM EMAIL" },
        { title: "FROM CITY" },
        { title: "FROM STATE" },
        { title: "FROM ZIP" },
        { title: "FROM COUNTRY" },
        { title: "FROM PHONE" },

        { title: "TO NAME" },
        // { title: "TO COMPANY NAME" },
        // { title: "TO ADDRESS" },
        // { title: "TO EMAIL" },
        // { title: "TO CITY" },
        // { title: "TO STATE" },
        // { title: "TO ZIP" },
        // { title: "TO COUNTRY" },
        // { title: "TO PHONE" },
      ],
      data: ExportData.map((data) => [
        { value: data.order_id },
        { value: data.partner_order_id },
        { value: data.shipping_method },
        { value: "COD" },
        { value: data.order_number },
        { value: data.order_amount },
        { value: data.shop_name },
        { value: data.shipping_name },
        { value: data.account_id },
        { value: data.tracking_number },
        { value: data.createdAt.slice(0, 10) },
        { value: data.t_delivery_date === null ? "" : data.t_delivery_date.slice(0, 10) },
        { value: data.t_return_date === null ? "" : data.t_return_date.slice(0, 10) },
        { value: data.fulfillment_status },

        { value: data.from_address.name },
        { value: data.from_address.company_name },
        { value: data.from_address.address_1 },
        { value: data.from_address.email },
        { value: data.from_address.city },
        { value: data.from_address.state },
        { value: data.from_address.zip },
        { value: data.from_address.country },
        { value: data.from_address.phone },

        { value: data.to_address.name },
        // { value: data.to_address.company_name },
        // { value: data.to_address.address_1 },
        // { value: data.to_address.email },
        // { value: data.to_address.city },
        // { value: data.to_address.state },
        // { value: data.to_address.zip },
        // { value: data.to_address.country },
        // { value: data.to_address.phone },
      ]),
    },
  ];
  //EXPORT

  const countBar = () => {
    return (
      <Col md={12} className="show_count text-center">
        <p>{`showing ${pagination - 1} - ${ShipmentData.length
          } of ${totalPage} items in listing`}</p>
      </Col>
    );
  };

  const sortFun = (type) => {
    if (type === "order_number") {
      if (Short === "ascending") {
        setName("order_number");
        const shaloArray = [...ShipmentData];
        const shortedArray = shaloArray.sort((a, b) => {
          if (a.order_number > b.order_number) return 1;
          if (a.order_number < b.order_number) return -1;
          return 0;
        });
        setShipmentData(shortedArray);
        setShort("descending");
      } else {
        setName("order_number");
        const shaloArray = [...ShipmentData];
        const shortedArray = shaloArray.sort((a, b) => {
          if (a.order_number > b.order_number) return -1;
          if (a.order_number < b.order_number) return 1;
          return 0;
        });
        setShipmentData(shortedArray);
        setShort("ascending");
      }
    }

    if (type === "shipping_method") {
      if (Short === "ascending") {
        setName("shipping_method");
        const shaloArray = [...ShipmentData];
        const shortedArray = shaloArray.sort((a, b) => {
          if (a.shipping_method.toLowerCase() > b.shipping_method.toLowerCase())
            return 1;
          if (a.shipping_method.toLowerCase() < b.shipping_method.toLowerCase())
            return -1;
          return 0;
        });
        setShipmentData(shortedArray);
        setShort("descending");
      } else {
        setName("shipping_method");
        const shaloArray = [...ShipmentData];
        const shortedArray = shaloArray.sort((a, b) => {
          if (a.shipping_method.toLowerCase() > b.shipping_method.toLowerCase())
            return -1;
          if (a.shipping_method.toLowerCase() < b.shipping_method.toLowerCase())
            return 1;
          return 0;
        });
        setShipmentData(shortedArray);
        setShort("ascending");
      }
    }

    if (type === "tracking_number") {
      if (Short === "ascending") {
        setName("tracking_number");
        const shaloArray = [...ShipmentData];
        const shortedArray = shaloArray.sort((a, b) => {
          if (a.tracking_number > b.tracking_number) return 1;
          if (a.tracking_number < b.tracking_number) return -1;
          return 0;
        });
        setShipmentData(shortedArray);
        setShort("descending");
      } else {
        setName("tracking_number");
        const shaloArray = [...ShipmentData];
        const shortedArray = shaloArray.sort((a, b) => {
          if (a.tracking_number > b.tracking_number) return -1;
          if (a.tracking_number < b.tracking_number) return 1;
          return 0;
        });
        setShipmentData(shortedArray);
        setShort("ascending");
      }
    }

    if (type === "t_delivery_date") {
      if (Short === "ascending") {
        setName("t_delivery_date");
        const shaloArray = [...ShipmentData];
        const shortedArray = shaloArray.sort((a, b) => {
          if (a.t_delivery_date > b.t_delivery_date) return 1;
          if (a.t_delivery_date < b.t_delivery_date) return -1;
          return 0;
        });
        setShipmentData(shortedArray);
        setShort("descending");
      } else {
        setName("t_delivery_date");
        const shaloArray = [...ShipmentData];
        const shortedArray = shaloArray.sort((a, b) => {
          if (a.t_delivery_date > b.t_delivery_date) return -1;
          if (a.t_delivery_date < b.t_delivery_date) return 1;
          return 0;
        });
        setShipmentData(shortedArray);
        setShort("ascending");
      }
    }

    if (type === "createdAt") {
      if (Short === "ascending") {
        setName("createdAt");
        const shaloArray = [...ShipmentData];
        const shortedArray = shaloArray.sort((a, b) => {
          if (a.createdAt > b.createdAt) return 1;
          if (a.createdAt < b.createdAt) return -1;
          return 0;
        });
        setShipmentData(shortedArray);
        setShort("descending");
      } else {
        setName("createdAt");
        const shaloArray = [...ShipmentData];
        const shortedArray = shaloArray.sort((a, b) => {
          if (a.createdAt > b.createdAt) return -1;
          if (a.createdAt < b.createdAt) return 1;
          return 0;
        });
        setShipmentData(shortedArray);
        setShort("ascending");
      }
    }

    if (type === "name") {
      if (Short === "ascending") {
        setName("name");
        const shaloArray = [...ShipmentData];
        const shortedArray = shaloArray.sort((a, b) => {
          if (
            a.from_address.name.toLowerCase() >
            b.from_address.name.toLowerCase()
          )
            return 1;
          if (
            a.from_address.name.toLowerCase() <
            b.from_address.name.toLowerCase()
          )
            return -1;
          return 0;
        });
        setShipmentData(shortedArray);
        setShort("descending");
      } else {
        setName("name");
        const shaloArray = [...ShipmentData];
        const shortedArray = shaloArray.sort((a, b) => {
          if (
            a.from_address.name.toLowerCase() >
            b.from_address.name.toLowerCase()
          )
            return -1;
          if (
            a.from_address.name.toLowerCase() <
            b.from_address.name.toLowerCase()
          )
            return 1;
          return 0;
        });
        setShipmentData(shortedArray);
        setShort("ascending");
      }
    }
  };

  const updateFun = async (tracking_number) => {
    const res = await getShipmentDetailsForView(tracking_number);
    let { status, trakingData, error } = res;
    if (!error && status === 200) {
      const updateState = { ...TrakingData };
      updateState.totalData = trakingData;
      setTrakingData({ ...updateState });
    } else {
      window.alert("Network Error");
    }
    setEditShipment(true)
  }

  const deleteFun = async (_id) => {
    swal({
      title: "Are you sure you want to Delete?",
      // text: "Once deleted, you will not be able to recover this shipment file!",
      icon: "warning",
      buttons: true,
      dangerMode: true,
    })
      .then((willDelete) => {
        if (willDelete) {
          const res = removeShipmentDetail(_id).then((data) => {
            if (data) {
              { IsFilter ? onButtonSearch() : apiCall(pagination, Search) }
            }
          })
          swal("Your shipment record has been deleted!", {
            icon: "success",
          });
        } else {
          swal("Your shipment file is safe!");
        }
      });
  }


  const listData =
    ShipmentData.length !== 0 ? (
      ShipmentData.map((data, inx) => (
        <tr key={"SHIPMENTDATA" + inx} ref={lastBookElement}>
          <td>{data.order_number}</td>
          <td>{data.shipping_method}</td>
          <td>{data.order_amount}</td>
          <td>
            <span onClick={() => updateFun(data.tracking_number)} style={{ marginRight: "5px" }} className="tracking_no1">
              {data.tracking_number}
            </span>
          </td>
          <td>{data.from_address.name}</td>
          <td>{data.createdAt.slice(0, 10)}</td>
          <td>{data.t_delivery_date === null ? "" : data.t_delivery_date.slice(0, 10)}</td>
          <td>{data.t_return_date === null ? "" : data.t_return_date.slice(0, 10)}</td>
          <td
            onClick={() => handleShow(data.tracking_number)}
            className="text-center view_mod"
          >
            VIEW
          </td>
          <td>{data.fulfillment_status}</td>
          <td className="text-center">
            <Link
              to={`/dashboard/shipments/track/${data.tracking_number}`}
              target="_blank"
            >
              <i
                data-toggle="tooltip"
                data-placement="bottom"
                title="Search"
                className={
                  shipments_track === "true"
                    ? "fa fa-search iconfa"
                    : "testingggg"
                }
              ></i>
            </Link>
          </td>
          <td className="text-center">
            <span onClick={() => deleteFun(data._id)}>
              <i
                data-toggle="tooltip"
                data-placement="bottom"
                title="Delete"
                className="fa fa-trash-alt iconfa text-danger"
              ></i></span>
          </td>
        </tr>
      ))
    ) : (
      <tr>
        <td className="no_records" colSpan="11">
          NO RECORDS FOUND
        </td>
      </tr>
    );

  const apiCall = async () => {
    setIsFilter(false)
    const res = await getShipmentDetailsList(pagination, Search);
    let { error, status, trakingDetailsList, shipDataForExports, count } =
      res;
    console.log(trakingDetailsList)
    if (!error && status === 200) {
      setShipmentData([...trakingDetailsList]);
      setTotalPage(count);
      setPagination(1);
      setLoading(false);
    } else {
      window.alert("network error!!");
    }
  };

  useEffect(() => {
    setLoading(true);

    apiCall();
    const apiCall1 = async () => {
      const res = await getShipmentDropdownList();
      let { provider, status } = res;
      const updateState = { ...SearchHeader };
      updateState.provider = [...provider];
      updateState.status = [...status];
      setSearchHeader({ ...updateState });
    };
    apiCall1();
  }, []);

  useEffect(() => {
    const fun = async () => {
      const shipments_viewlist = await Cookie.get("shipments_viewlist");
      const shipments_exportfile = await Cookie.get("shipments_exportfile");
      const shipments_track = await Cookie.get("shipments_track");

      const updateState = { ...ShipmentAuth };
      updateState.shipments_viewlist = shipments_viewlist;
      updateState.shipments_exportfile = shipments_exportfile;
      updateState.shipments_track = shipments_track;
      setShipmentAuth({ ...updateState });
    };
    if (IsExportCall) {
      const exportFun = async () => {
        const res = await getShipmentDetailsListForExport();
        let { shipmenyDetails } = res;
        console.log(shipmenyDetails);
        setExportData(shipmenyDetails);
        setIsExportCall(false);
        exportFun();
      };
    }

    fun();
    // exportFun();
  }, []);

  let { provider, status } = SearchHeader;

  return (
    <>
      <Col md={12}>
        <Col>
          <div className="page-header row no-gutters pym-4">
            <div className="col-md-12">
              <h3 className="page-title">Shipment Reports</h3>
            </div>
            <hr></hr>
          </div>
        </Col>
        <Col md={12}>
          <div
            className="box_detail"
            style={{ padding: "15px 0px 10px 0px", marginBottom: "20px" }}
          >
            <Col style={{ padding: "0px" }}>
              <div className="page-header row no-gutters">
                <div className="col-md-12">
                  <h3 className="page-title subtitile">FILTER OPTION</h3>
                </div>
                <hr style={{ marginBottom: "0px" }} />
              </div>
            </Col>
            <Row style={{ padding: "20px 30px" }}>
              <Col lg={10} md={12}>
                <Row>
                  <Col lg={2} md={4} className="form-group shipf">
                    <label className="pwdc">Shipment Providers</label>
                    <select
                      className="form-control"
                      id="assocom"
                      name="shipping_method"
                      style={{ padding: "4px 10px", color: "#000" }}
                      onChange={buttonHandleChange}
                    >
                      {provider.map((data, inx) => {
                        return (
                          <option key={"SHIP-PROVIDER" + inx}>{data}</option>
                        );
                      })}
                    </select>
                  </Col>
                  <Col lg={2} md={4} className="form-group shipf">
                    <label className="pwdc">Shipment Status</label>
                    <select
                      className="form-control"
                      id="assocom"
                      name="fulfillment_status"
                      onChange={buttonHandleChange}
                      style={{ padding: "4px 10px", color: "#000" }}
                    >
                      {status.map((data, inx) => {
                        return (
                          <option key={"SHIP-STATUS" + inx}>{data}</option>
                        );
                      })}
                    </select>
                  </Col>
                  <Col lg={2} md={4} className="form-group shipf">
                    <label className="pwdc">Start Date</label>
                    <div
                      className="input-container form-control"
                      id="date_start"
                    >
                      <DatePicker
                        placeholderText="Start Date"
                        selected={startDate}
                        onChange={(date) => setStartDate(date)}
                      />
                    </div>
                  </Col>
                  <Col lg={2} md={4} className="form-group shipf">
                    <label className="pwdc">End Date</label>
                    <div className="input-container form-control" id="date_end">
                      <DatePicker
                        placeholderText="End Date"
                        selected={endDate}
                        onChange={(date) => setEndDate(date)}
                      />
                    </div>
                  </Col>
                  <Col lg={1} md={2} className="form-group shipf">
                    <label
                      className="pwdc news_c"
                      style={{ color: "transparent" }}
                    >
                      Shipment
                    </label>
                    <button
                      className="searchs ship_srh"
                      onClick={onButtonSearch}
                    >
                      SEARCH
                    </button>
                  </Col>
                </Row>
              </Col>
              <Col lg={2} md={4} className="form-group shipf shipfn">
                <label className="pwdc">Name / AWB Number</label>
                <input
                  type="text"
                  onChange={handleChange}
                  placeholder="Search by Name/AWB"
                  className="form-control"
                />
              </Col>
            </Row>
          </div>
        </Col>
        <Col md={12} className="text-right">
          <span className="count_customer">Total Records: {totalPage}</span>
          <ExcelFile
            fillename="sheet"
            element={
              ShipmentData.length !== 0 ? (
                <button
                  className={
                    shipments_exportfile === "true"
                      ? "export_btn addbce customer_export"
                      : "display"
                  }
                >
                  EXPORT
                </button>
              ) : (
                <button
                  className={
                    shipments_exportfile === "true"
                      ? "export_btn addbce1 customer_export"
                      : "display"
                  }
                  disabled
                >
                  EXPORT
                </button>
              )
            }
          >
            <ExcelSheet dataSet={DataSet} name="shipment reports" />
          </ExcelFile>
          {/* <span className="count_customer">{totalPage}</span> */}
        </Col>
        <Col md={12}>
          <hr />
          <div
            className="box_detail tableboxdc"
            style={{
              paddingTop: "0px",
              paddingBottom: "0px",
              marginBottom: "0px",
            }}
          >
            <table
              className="table table-bordered table-responsive"
              id="table-to-xls"
            >
              <thead className="thead-dark">
                <tr>
                  <th
                    className="sorting"
                    onClick={() => sortFun("order_number")}
                  >
                    ORDER NUMBER
                  </th>
                  <th
                    className="sorting"
                    onClick={() => sortFun("shipping_method")}
                  >
                    SHIPING PROVIDER
                  </th>
                  <th>AMOUNT (SAR)</th>
                  <th
                    className="sorting"
                    onClick={() => sortFun("tracking_number")}
                  >
                    TRACKING NUMBER
                  </th>
                  <th className="sorting" onClick={() => sortFun("name")}>
                    NAME
                  </th>
                  <th className="sorting" onClick={() => sortFun("createdAt")}>
                    CREATION DATE
                  </th>
                  <th className="sorting" onClick={() => sortFun("t_delivery_date")}>
                    DELIVERY DATE
                  </th>
                  <th className="sorting" onClick={() => sortFun("t_delivery_date")}>
                    RETURNED DATE
                  </th>
                  <th className="text-center">VIEW</th>
                  <th>STATUS</th>
                  <th className="text-center">TRACK</th>
                  <th className="text-center">ACTION</th>
                </tr>
              </thead>
              <tbody
                className={shipments_viewlist === "true" ? "" : "testingggg"}
              >
                {Loading ? (
                  <tr>
                    <td className="no_records" colSpan="11">
                      Loading....
                    </td>
                  </tr>
                ) : (
                  [listData]
                )}
              </tbody>
            </table>
          </div>
        </Col>
        {countBar()}
      </Col>

      <EditShipmentModal
        EditShipment={EditShipment}
        setEditShipment={setEditShipment}
        TrakingData={TrakingData.totalData}
        apiCall={apiCall}
        pagination={pagination}
        Search={Search}
        IsFilter={IsFilter}
        onButtonSearch={onButtonSearch}
      />

      <ShipmentView
        show={show}
        handleClose={handleClose}
        TrakingData={TrakingData}
      />
    </>
  );
};

export default Shipments;
