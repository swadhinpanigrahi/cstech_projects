const mongoose = require("mongoose");

const t_hdfchistory = mongoose.Schema(
  {
    f_orderid: { type: String },
    f_orderAmt: { type: Number },
    f_userid: { type: String },
    f_crdate: { type: Date },
    f_ordersatus: { type: String },
    f_errormsg: { type: String },
    f_payamount: { type: String },
    f_paymentId: { type: String },
    f_ip: { type: String },
    f_trackid: { type: String },
    f_paymod: { type: String }
  },
  { collection: "t_hdfchistory_IB_MongoDB" }
);

module.exports = HdfcHistorySchema = mongoose.model(
  "t_hdfchistory_IB_MongoDB",
  t_hdfchistory
);
