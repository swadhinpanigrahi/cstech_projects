const nodeMailer = require("nodemailer");
const { SMTP_HOST, SMTP_EMAIL, SMTP_PASSWORD } = require(`../../config/config`);

const sendEmail = (data, callback) => {
  const { mailTo, subject, html } = data;

  var transport = nodeMailer.createTransport({
    host: SMTP_HOST,
    port: 587,
    service: "gmail.com",
    ssl: false,
    networkcredential: false,
    auth: {
      user: SMTP_EMAIL,
      pass: SMTP_PASSWORD,
    },
  });

  var mailOption = {
    from: SMTP_EMAIL,
    to: mailTo,
    subject: subject,
    html: html,
  };

  transport.sendMail(mailOption, function (error, info) {
    if (error) {
      callback(error, true);
    } else {
      callback(info, false);
    }
  });
};

module.exports = {
  sendEmail,
};
