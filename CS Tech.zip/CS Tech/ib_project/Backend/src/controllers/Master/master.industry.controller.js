const { M_INDUSTRY } = require("../../model");


exports.addIndustry = async (req, res) => {
    const { f_category, f_subcategory } = req.body;
    try {
        const savedData = await new M_INDUSTRY(
            { f_sno: "", f_groupid: null, f_category, f_subcategory }
        ).save();
        res.json({ status: 200, savedData })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

exports.getIndustryList = async (req, res) => {
    const { currentPage, itemPerPage, searchData } = req.query;
    const num = parseInt(itemPerPage)
    const start = parseInt(currentPage);
    let pipeline;
    let countline;
    try {
        if (!searchData || searchData === "") {
            pipeline = [
                { $sort: { _id: -1 } },
                { $skip: (start - 1) * num },
                { $limit: num }
            ]
            countline = [
                { $count: "totalcount" }
            ]
        } else {
            pipeline = [
                { $match: { f_category: { $regex: searchData, $options: "im" } } },
                { $sort: { _id: -1 } },
                { $skip: (start - 1) * num },
                { $limit: num }
            ]
            countline = [
                { $match: { f_category: { $regex: searchData, $options: "im" } } },
                { $count: "totalcount" }
            ]
        }
        const data = await M_INDUSTRY.aggregate(pipeline)
        const totalrecord = await M_INDUSTRY.aggregate(countline)
        res.json({ status: 200, data, totalrecord })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

exports.getIndustryDetail = async (req, res) => {
    const { _id } = req.params;
    try {
        const industryData = await M_INDUSTRY.findOne({ _id });
        res.json({ status: 200, industryData })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

exports.updateIndustryDetail = async (req, res) => {
    const { _id, f_category, f_subcategory } = req.body
    try {
        const industryData = await M_INDUSTRY.findByIdAndUpdate({ _id }, { $set: { f_category, f_subcategory } });
        res.json({ status: 200, message: "industry updated successfully" })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

exports.removeIndustryDetail = async (req, res) => {
    const { _id } = req.params;
    try {
        const industryData = await M_INDUSTRY.findByIdAndRemove({ _id });
        res.json({ status: 200, message: "industry removed successfully" })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}