import React, { useState, useEffect } from "react";
import { useParams, useHistory, useLocation, Link } from "react-router-dom";
import { IoIosArrowBack } from "react-icons/io";
import * as RB from "react-bootstrap";
import { customerProfile, updateUserActionEdit } from "../../Utils/api";
import Modal from "../../Components/Common/Modal";

function useQuery() {
  return new URLSearchParams(useLocation().search);
}

const UserActionEdit = () => {
  const history = useHistory();
  let query = useQuery();
  const num = query.get("num") || 1;

  const { f_userid, path } = useParams();
  const [userInfoEdit, setUserInfoEdit] = useState({});

  const [isOpen, setIsOpen] = useState(false);
  const [ModelMsg, setModelMsg] = useState("");

  const handleChange = (e) => {
    let { name, value, type, checked } = e.target;
    if (type !== "checkbox") {
      const Data = { ...userInfoEdit };
      Data[name] = value;
      setUserInfoEdit(Data);
    }
    if (type === "checkbox") {
      const Data = { ...userInfoEdit };
      Data[name] = checked;
      setUserInfoEdit(Data);
    }
  };

  const onSubmit = async (e) => {
    e.preventDefault();
    const res = await updateUserActionEdit({ ...userInfoEdit }, f_userid);
    console.log(res);
    let { error, message } = res;
    if (!error) {
      if (message === "user updated successfully!!") {
        setModelMsg(message);
        modelSet();
        setTimeout(() => {
          history.push(`/dashboard/customer/get?num=${num}`);
        }, 2000);
      } else {
        setModelMsg(message);
        modelSet();
      }
    } else {
      window.alert("network error!");
    }
  };

  const modelSet = () => {
    setIsOpen(true);
  };

  useEffect(() => {
    const apiCall = async () => {
      const res = await customerProfile(f_userid);
      let { t_LUS, t_TUR } = res;
      setUserInfoEdit({ ...t_TUR, ...t_LUS });
    };
    apiCall();
  }, [f_userid]);

  return (
    <>
      <main className="main_afterlogin">

        <RB.Row className="rownew1" style={{ paddingTop: "30px" }}>
          <div className="col-md-12">
            <div className="float-right">
              <div>
                <RB.Button
                  as={Link}
                  to={
                    path === "form_usesearch_edit"
                      ? `/dashboard/useraction/${f_userid}/from_usersearch`
                      : num
                        ? `/dashboard/customer/get?num=${num}`
                        : `/dashboard/useraction/${f_userid}/from_customerlist`
                  }
                  className="btn btn-primary btn-sm"
                >
                  <IoIosArrowBack />
                  BACK
                </RB.Button>
              </div>
            </div>
          </div>


          <div className="col-md-12" style={{ paddingTop: "7px" }}>
            <div
              className="box_detail"
              style={{
                paddingLeft: "0px",
                paddingRight: "0px",
                borderRadius: "4px",
                paddingTop: "0px",
              }}
            >
              <div className="page-header row no-gutters inside_header">
                <div className="col-md-12">
                  <h3
                    className="page-title"
                    style={{
                      color: "#000",
                      marginBottom: "0px",
                      paddingBottom: "0px",
                      fontSize: "1.5rem",
                    }}
                  >
                    Basic Information
                  </h3>
                </div>
              </div>
              <hr className="m-t-25 m-b-25" />
              <form method="post">
                <div className="form-body useraction_editform">
                  <div className="row">
                    <div className="col-md-6 pr-50">
                      <div className="form-group">
                        <label className="control-label">User ID :</label>
                        <div className="">
                          <input
                            className="form-control"
                            type="text"
                            name="CS_username"
                            disabled
                            placeholder="Enter email id"
                            value={userInfoEdit.CS_username}
                            onChange={handleChange}
                          />
                        </div>
                      </div>
                    </div>

                    <div className="col-md-6 pl-50">
                      <div className="form-group">
                        <label className="control-label">
                          Company Name :
                        </label>
                        <div className="">
                          <input
                            className="form-control"
                            type="text"
                            disabled
                            placeholder="Enter company name"
                            name="CS_companynames"
                            value={userInfoEdit.CS_companynames}
                            onChange={handleChange}
                          />
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="row">
                    <div className="col-md-6 pr-50">
                      <div className="form-group">
                        <label className="control-label">First Name :</label>
                        <div className="">
                          <input
                            className="form-control"
                            type="text"
                            placeholder="Enter first name"
                            name="CS_firstname"
                            value={userInfoEdit.CS_firstname}
                            onChange={handleChange}
                          />
                        </div>
                      </div>
                    </div>

                    <div className="col-md-6 pl-50">
                      <div className="form-group">
                        <label className="control-label">Last Name :</label>
                        <div className="">
                          <input
                            className="form-control"
                            type="text"
                            placeholder="Enter last name"
                            name="CS_lastname"
                            value={userInfoEdit.CS_lastname}
                            onChange={handleChange}
                          />
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="row">
                    <div className="col-md-6 pr-50">
                      <div className="form-group">
                        <label className="control-label">
                          Job Description :
                        </label>
                        <div className="">
                          <input
                            className="form-control"
                            type="text"
                            placeholder="Enter Job Description"
                            name="CS_jobdesc"
                            value={userInfoEdit.CS_jobdesc}
                            onChange={handleChange}
                          />
                        </div>
                      </div>
                    </div>

                    <div className="col-md-6 pl-50">
                      <div className="form-group">
                        <label className="control-label">
                          Business Type :
                        </label>
                        <div className="">
                          <input
                            className="form-control"
                            type="text"
                            disabled
                            placeholder="Enter Business Type"
                            name="CS_businesstype"
                            value={userInfoEdit.CS_businesstype}
                            onChange={handleChange}
                          />
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="row">
                    <div className="col-md-6 pr-50">
                      <div className="form-group">
                        <label className="control-label">Country :</label>
                        <div className="">
                          <input
                            className="form-control"
                            type="text"
                            placeholder="Enter country name"
                            name="CS_country"
                            value={userInfoEdit.CS_country}
                            onChange={handleChange}
                          />
                        </div>
                      </div>
                      <div className="form-group">
                        <label className="control-label">State :</label>
                        <div className="">
                          <input
                            className="form-control"
                            type="text"
                            placeholder="Enter State"
                            name="CS_state"
                            value={userInfoEdit.CS_state}
                            onChange={handleChange}
                          />
                        </div>
                      </div>
                    </div>

                    <div className="col-md-6 pl-50">
                      <div className="form-group">
                        <label className="control-label">Address :</label>
                        <div className="">
                          <textarea style={{ minHeight: "120px" }}
                            className="form-control"
                            type="text"
                            placeholder="Enter Address"
                            name="CS_address"
                            value={userInfoEdit.CS_address}
                            onChange={handleChange}
                          >
                            {userInfoEdit.CS_address}
                          </textarea>
                          {/* <inpu /> */}
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="row">
                    <div className="col-md-6 pr-50">
                      <div className="form-group">
                        <label className="control-label">
                          Zip / Pin Code :
                        </label>
                        <div className="">
                          <input
                            className="form-control"
                            type="number"
                            placeholder="Enter Zip/Pincode"
                            name="CS_pin"
                            value={userInfoEdit.CS_pin}
                            onChange={handleChange}
                          />
                        </div>
                      </div>
                    </div>
                    <div className="col-md-6 pl-50">
                      <div className="form-group">
                        <label className="control-label">Phone :</label>
                        <div className="">
                          <input
                            className="form-control"
                            type="number"
                            placeholder="Enter Phone"
                            name="CS_phone"
                            value={userInfoEdit.CS_phone}
                            onChange={handleChange}
                          />
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="row">
                    <div className="col-md-6 pr-50">
                      <div className="form-group">
                        <label className="control-label">Mobile :</label>
                        <div className="">
                          <input
                            className="form-control"
                            type="number"
                            placeholder="Enter Mobile"
                            name="CS_mobile"
                            value={userInfoEdit.CS_mobile}
                            onChange={handleChange}
                          />
                        </div>
                      </div>
                    </div>

                    <div className="col-md-6 pl-50">

                    </div>
                  </div>
                </div>
              </form>
            </div>
          </div>

          <div className="col-md-12">
            <div
              className="box_detail"
              style={{
                paddingLeft: "0px",
                paddingRight: "0px",
                borderRadius: "4px",
                paddingTop: "0px",
              }}
            >
              <div className="page-header row no-gutters inside_header">
                <div className="col-md-12">
                  <h3
                    className="page-title"
                    style={{
                      color: "#000",
                      marginBottom: "0px",
                      paddingBottom: "0px",
                      fontSize: "1.5rem",
                    }}
                  >
                    Business Details
                  </h3>
                </div>
              </div>
              <hr className="m-t-25 m-b-25" />
              <form method="post">
                <div className="form-body useraction_editform">
                  <div className="row">
                    <div className="col-md-6 pr-50">
                      <div className="form-group">
                        <label className="control-label">
                          Rename LightBox :
                        </label>
                        <div className="">
                          <input
                            className="form-control"
                            type="text"
                            placeholder="Enter Rename LightBox "
                            name="CS_lightboxname"
                            value={userInfoEdit.CS_lightboxname}
                            onChange={handleChange}
                          />
                        </div>
                      </div>
                    </div>

                    <div className="col-md-6 pl-50">
                      <div className="form-group">
                        <label className="control-label">Comments : </label>
                        <div className="">
                          <input
                            className="form-control"
                            type="text"
                            placeholder="Enter comments"
                            name="CS_comment"
                            value={userInfoEdit.CS_comment}
                            onChange={handleChange}
                          />
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="row">
                    <div className="col-md-6 pr-50">
                      <div className="form-group">
                        <label className="control-label">
                          User Discount (%) :
                        </label>
                        <div className="">
                          <input
                            className="form-control"
                            type="text"
                            placeholder="Enter  discount"
                            name="cs_discount"
                            value={userInfoEdit.cs_discount}
                            onChange={handleChange}
                          />
                        </div>
                      </div>
                    </div>

                    <div className="col-md-6 pl-50">
                      <div className="form-group">
                        <label className="control-label">Ecash :</label>
                        <div className="">
                          <input
                            className="form-control"
                            type="text"
                            placeholder="Enter ecash"
                            name="cs_ecashamt"
                            value={userInfoEdit.cs_ecashamt}
                            onChange={handleChange}
                          />
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="row">
                    <div className="col-md-6 pr-50">
                      <div className="form-group">
                        <label className="control-label">
                          Subscription CC Mail :
                        </label>
                        <div className="">
                          <textarea
                            className="form-control"
                            type="text"
                            placeholder="Enter subscription mail"
                            name="cs_subscriptionccmail"
                            value={userInfoEdit.cs_subscriptionccmail}
                            onChange={handleChange}
                          >
                            {userInfoEdit.cs_subscriptionccmail}
                          </textarea>
                          <small class="text-danger form-text">You can enter multiple email id with comma (,)</small>
                        </div>
                      </div>
                    </div>

                    <div className="col-md-6 pl-50">
                      <div className="form-group">
                        <label className="control-label">
                          Subscription Plan Connected to :
                        </label>
                        <div className="">
                          <textarea
                            className="form-control"
                            type="text"
                            placeholder="  subscription plan to"
                            name="f_Subscriptionconnectedto"
                            value={userInfoEdit.f_Subscriptionconnectedto}
                            onChange={handleChange}
                          >
                            {userInfoEdit.f_Subscriptionconnectedto}
                          </textarea>
                          <small class="text-danger form-text">You can enter multiple email id with comma (,)</small>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="row">
                    <div className="col-md-6 pr-50">
                      <div className="form-group">
                        <label className="control-label">
                          Additional Company Name :
                        </label>
                        <div className="">
                          <input
                            className="form-control"
                            type="text"
                            placeholder="Enter additinal company name"
                            name="f_addcmpname"
                            value={userInfoEdit.f_addcmpname}
                            onChange={handleChange}
                          />
                        </div>
                      </div>
                    </div>

                    <div className="col-md-6 pl-50">
                      <div className="form-group">
                        <label className="control-label">CC Mail :</label>
                        <div className="">
                          <input
                            className="form-control"
                            type="text"
                            placeholder="Enter CC mail"
                            name="cs_ccmail"
                            value={userInfoEdit.cs_ccmail}
                            onChange={handleChange}
                          />
                             <small class="text-danger form-text">You can enter multiple email id with comma (,)</small>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="row">
                    <div className="col-md-6 pr-50">
                      <div className="form-group">
                        <label className="control-label">Pan Card No. :</label>
                        <div className="">
                          <input
                            className="form-control"
                            type="text"
                            placeholder="Enter pan number"
                            name="f_pan"
                            value={userInfoEdit.f_pan}
                            onChange={handleChange}
                          />
                        </div>
                      </div>
                    </div>

                    <div className="col-md-6 pl-50">
                      <div className="form-group">
                        <label className="control-label">GSTIN No. :</label>
                        <div className="">
                          <input
                            className="form-control"
                            type="text"
                            placeholder="Enter gstin number"
                            name="f_GSTIN"
                            maxLength="16"
                            value={userInfoEdit.f_GSTIN}
                            onChange={handleChange}
                          />
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="row">
                    <div className="col-md-6 pr-50">
                      <div className="form-group">
                        <label className="control-label">
                          Action For High-Res Download :
                        </label>
                        <div className="">
                          <div id="act" className="checkbox">
                            <label style={{ marginTop: "10px" }}>
                              {" "}
                              <input
                                type="checkbox"
                                name="act_highres"
                                checked={userInfoEdit.act_highres}
                                onChange={handleChange}
                              />{" "}
                              Active - Checked{" "}
                            </label>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="col-md-6 pl-50">
                      <div className="form-group">
                        <label className="control-label">IP Address :</label>
                        <div className="">
                          <input
                            className="form-control"
                            type="text"
                            placeholder="Enter IP address"
                            name="CS_IPAddress"
                            value={userInfoEdit.CS_IPAddress}
                            onChange={handleChange}
                          />
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="row">
                    <div className="col-md-6 pr-50">
                      <div className="form-group">
                        <label className="control-label">
                          Limit of Images(Perday) :
                        </label>
                        <div className="">
                          <input
                            className="form-control"
                            type="text"
                            placeholder="Enter limit of images"
                            name="limit_img"
                            value={userInfoEdit.limit_img}
                            onChange={handleChange}
                          />
                        </div>
                      </div>
                    </div>

                    <div className="col-md-6 pl-50">
                      <div className="form-group">
                        <label className="control-label">
                          Identify The User :{" "}
                        </label>
                        <div className="">
                          <select
                            className="form-control"
                            id="assocom"
                            name="f_Identify_User"
                            onChange={handleChange}
                            value={userInfoEdit.f_Identify_User}
                          >

<option value="Buyer">Buyer</option>
                            <option value="Confirmed">Confirmed</option>
                            <option value="International">International</option>
                            <option value="Photographer">Photographer</option>
                            <option value="Student">Student</option>
                            <option value="Unconfirmed">Unconfirmed</option>
                            <option value="Photographer By Us">Photographer By Us</option>
                            <option value="Student By Us">Student By Us</option>
                            <option value="Model">Model</option>
                            {/* <option value="Unconfirmed">Unconfirmed</option> */}
                            <option value="Other">Other</option>
                          </select>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </form>
            </div>
          </div>

          <div className="col-md-12">
            <div
              className="box_detail"
              style={{
                paddingLeft: "0px",
                paddingRight: "0px",
                borderRadius: "4px",
                paddingTop: "0px",
              }}
            >
              <div className="page-header row no-gutters inside_header">
                <div className="col-md-12">
                  <h3
                    className="page-title"
                    style={{
                      color: "#000",
                      marginBottom: "0px",
                      paddingBottom: "0px",
                      fontSize: "1.5rem",
                    }}
                  >
                    User Setting
                  </h3>
                </div>
              </div>
              <hr className="m-t-25 m-b-25" />
              <form method="post">
                <div className="form-body useraction_editform">
                  <div className="row">
                    <div className="col-md-6 pr-50">
                      <div className="form-group">
                        <label className="control-label">
                          E-Cash Status :
                        </label>
                        <div className="">
                          <div id="act" className="checkbox">
                            <label style={{ marginTop: "05px" }}>
                              <input
                                type="checkbox"
                                name="f_EcashSetUp"
                                onChange={handleChange}
                                checked={userInfoEdit.f_EcashSetUp}
                              />{" "}
                              Check to give E-cash to the User
                            </label>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="col-md-6 pl-50">
                      <div className="form-group">
                        <label className="control-label">User Status :</label>
                        <div className="">
                          <div id="act" className="checkbox">
                            <label style={{ marginTop: "05px" }}>
                              <input
                                type="checkbox"
                                name="CS_active"
                                onChange={handleChange}
                                checked={userInfoEdit.CS_active}
                              />{" "}
                              Active
                            </label>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="row">
                    <div className="col-md-6 pr-50">
                      <div className="form-group">
                        <label className="control-label">
                          Performa User :
                        </label>
                        <div className="">
                          <div id="act" className="checkbox">
                            <label style={{ marginTop: "05px" }}>
                              <input
                                type="checkbox"
                                name="cs_performaUser"
                                onChange={handleChange}
                                checked={userInfoEdit.cs_performaUser}
                              />{" "}
                              Checked :Active and UnChecked :DeActive
                            </label>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="col-md-6 pl-50">
                      <div className="form-group">
                        <label className="control-label">
                          Proposal Rights :
                        </label>
                        <div className="">
                          <div id="act" className="checkbox">
                            <label style={{ marginTop: "05px" }}>
                              <input
                                type="checkbox"
                                name="cs_proposal"
                                onChange={handleChange}
                                checked={userInfoEdit.cs_proposal}
                              />{" "}
                              Proposal - Active
                            </label>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="row">
                    <div className="col-md-6 pr-50">
                      <div className="form-group">
                        <label className="control-label">Commission :</label>
                        <div className="">
                          <div id="act" className="checkbox">
                            <label style={{ marginTop: "05px" }}>
                              <input
                                type="checkbox"
                                name="cs_Commission"
                                onChange={handleChange}
                                checked={userInfoEdit.cs_Commission}
                              />{" "}
                              Active - Checked
                            </label>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="col-md-6 pl-50">
                      <div className="form-group">
                        <label className="control-label">
                          Subscription Plan Discount :
                        </label>
                        <div className="">
                          <div id="act" className="checkbox">
                            <label style={{ marginTop: "05px" }}>
                              <input
                                type="checkbox"
                                name="cs_SubscriptionDiscount"
                                onChange={handleChange}
                                checked={userInfoEdit.cs_SubscriptionDiscount}
                              />{" "}
                              Active - Checked
                            </label>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="row">
                    <div className="col-md-6 pr-50">
                      <div className="form-group">
                        <label className="control-label">Exclude :</label>
                        <div className="">
                          <div id="act" className="checkbox">
                            <label style={{ marginTop: "05px" }}>
                              <input
                                type="checkbox"
                                name="f_exclude"
                                onChange={handleChange}
                                checked={userInfoEdit.f_exclude}
                              />{" "}
                              Active -Checked
                            </label>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="col-md-6 pl-50">
                      <div className="form-group">
                        <label className="control-label">ISD No :</label>
                        <div className="">
                          <div id="act" className="checkbox">
                            <label style={{ marginTop: "05px" }}>
                              <input
                                type="checkbox"
                                name="f_ISDNo"
                                onChange={handleChange}
                                checked={userInfoEdit.f_ISDNo}
                              />{" "}
                              Active - Checked
                            </label>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="row">
                    <div className="col-md-6 pr-50">
                      <div className="form-group last_checkboxform">
                        <label className="control-label">
                          Action For IVS Download :
                        </label>
                        <div className="">
                          <div id="act" className="checkbox">
                            <label style={{ marginTop: "05px" }}>
                              <input
                                type="checkbox"
                                name="ivs_download"
                                onChange={handleChange}
                                checked={userInfoEdit.ivs_download}
                              />{" "}
                              Active - Checked
                            </label>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="col-md-6 pl-50">
                      <div className="form-group"></div>
                    </div>
                  </div>

                  <div className="row">
                    <div className="col-md-12">
                      <div className="form-group btn-submitform">
                        <RB.Button size="sm" variant="primary" onClick={onSubmit}>
                          SUBMIT
                        </RB.Button>

                      </div>
                    </div>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </RB.Row>

      </main>
      <Modal text={ModelMsg} open={isOpen} onClose={() => setIsOpen(false)} />
    </>
  );
};

export default UserActionEdit;
