import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import { getOrderDeatils } from "../../Utils/api";

const Orderdetails = () => {
  const { orderId } = useParams();
  const [OrderDetails, setInvoice] = useState([]);
  const [orderInfo, setOrder] = useState([]);
  const [finalAmout, setFinalAmount] = useState([]);
  const [totalAmout, setTotalAmount] = useState([]);
  const [gst, setGst] = useState([]);
  const [discount, setDiscount] = useState([]);
  const [netPayble, setNetPayble] = useState([]);


  useEffect(() => {
    //   alert(orderId)
    const apiCall = async () => {
      const res = await getOrderDeatils(orderId);
      const Order_Details = res.userData.Order_Details;
      const OrderData = res.userData.OrderInfo;
      console.log(res);
      // alert(res.totalAmount)
      setInvoice(Order_Details);
      setOrder(OrderData);
      setFinalAmount(res.userData.finalAmount);
      setTotalAmount(res.userData.totalAmount);
      setGst(res.userData.gst);
      setDiscount(res.userData.discount);
      setNetPayble(res.userData.netPayble);
    };
    apiCall();
  }, [orderId]);

  return (
    <div id="page">
      <div className="container">
        <div className="row no-gutters head_intop">
          <div className="row new_headinv">
            <div className="col-lg-4 col-md-4 col-12">
              <span className="logo-invoice">
                <img
                  src="http://ibcdn.imagesbazaar.com/Html2015/images/logo_imagesBazaar.png"
                  alt="img_img1"
                />
              </span>
            </div>
            <div className="col-lg-4 col-md-4 col-9">
              <h3 className="tax_invoice">Order Details</h3>
            </div>
            <div className="col-lg-4 col-md-4 col-3 text-right">
              <a href="demo" className="print_invoice">
                <i className="fa fa-print"></i>
              </a>
            </div>
          </div>
        </div>
        <main>
          <div className="row headinv" id="invoicem">
            <div className="col-lg-6 col-md-12" id="head1">
              <p>
                <strong>Mash Audio Visuals Private Limited</strong>
              </p>
              <p>505, Aggarwal Prestige Mall, Plot No. 2,</p>
              <p>Road No. 44, Pitam Pura, New Delhi - 110034</p>
              <p>Phone: (+91) 11 66545466 | (+91) 11 66545465</p>
              <p className="p_txt">
                <strong>CIN: </strong> U92111DL2003PTC122096
              </p>
              <p className="p_txt">
                <strong>GSTIN:</strong> 07AADCM6333L1ZA
              </p>
              <p className="p_txt">
                <strong>PAN: </strong>AADCM6333L
              </p>
            </div>
            <div className="col-lg-6 col-md-12" id="head2">
              <table className="table table-bordered">
                <tbody>
                  <tr style={{ borderBottom: "1px solid #707070" }}>
                    <td style={{ borderRight: "1px solid #707070" }}>
                      <p className="mg-b-0">
                        <strong>Date:</strong> {orderInfo.T_orderdate}
                      </p>
                    </td>
                    {orderInfo.T_status === "C" ? (
                      <td>
                        {/* <p className="mg-b-0"><strong>Invoice No.:</strong> 117156</p> */}
                      </td>
                    ) : (
                      ""
                    )}
                    {/* <td>
                                            <p className="mg-b-0"><strong>Invoice No.:</strong> 117156</p>
                                        </td> */}
                  </tr>
                  <tr style={{ borderBottom: "1px solid #707070" }}>
                    <td style={{ borderRight: "1px solid #707070" }}>
                      <p className="mg-b-0">
                        <strong>Order Confirmation No.:</strong>{" "}
                        {orderInfo.T_orderid}
                      </p>
                    </td>
                    {orderInfo.T_status === "C" ? (
                      <td>
                        <p className="mg-b-0">
                          <strong>HSN/SAC:</strong> {orderInfo.T_orderid}
                        </p>
                      </td>
                    ) : (
                      ""
                    )}
                  </tr>
                  <tr style={{ borderBottom: "1px solid #707070" }}>
                    {/* <td style={{ borderRight: "1px solid #707070" }}>
                                            <p className="mg-b-0"><strong>Mode of Payment:</strong> Mobikwik</p>
                                        </td> */}
                    {orderInfo.T_status === "C" ? (
                      <p className="mg-b-0">
                        <strong>Mode of Payment:</strong> {orderInfo.T_paymode}
                      </p>
                    ) : (
                      ""
                    )}
                    <td>
                      <p className="mg-b-0">
                        <strong>State Code:</strong> 07/DL
                      </p>
                    </td>
                  </tr>
                  <tr style={{ borderBottom: "1px solid #707070" }}>
                    <td style={{ borderRight: "1px solid #707070" }}>
                      <p className="mg-b-0">
                        <strong>Payment Status:</strong>{" "}
                        {orderInfo.t_paymentstatus}
                      </p>
                    </td>
                    <td>
                      <p className="mg-b-0">
                        <strong>State:</strong> Delhi
                      </p>
                    </td>
                  </tr>
                </tbody>
              </table>
              <table
                className="table table-bordered"
                style={{ borderBottom: "0px" }}
              >
                <tbody>
                  <tr>
                    <td>
                      {/* <p><strong>Reverse Charges Applicability:</strong> Not Applicable</p> */}
                      <p>
                        <strong>Place of Supply:</strong> Maharashtra
                      </p>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          <div className="row headinv" style={{ borderBottom: "0px" }}>
            <div className="col-lg-6 col-md-6" id="head3">
              <p>
                <strong>Party’s Name:</strong>
              </p>
              <p>TP Global Creations Private Limited</p>
              <p>1103, Lodha Supremus, Saki Vihar Road, Powal, Mumbai,</p>
              <p>Maharashtra - 400072, India</p>
              <p>
                <strong>State:</strong> Maharashtra{" "}
                <span style={{ paddingLeft: "10px" }}>
                  <strong>State Code:</strong> 27/Mh
                </span>
              </p>
              <p>
                <strong>GSTIN:</strong>27AAGCT8019H1Z4
              </p>
            </div>
            <div className="col-lg-6 col-md-6" id="head4">
              <p>
                <strong>Client Name:</strong> {orderInfo.t_client}
              </p>
              <p>
                <strong>Order By:</strong> {orderInfo.t_orderedby}
              </p>
            </div>
          </div>

          <div className="row headinv" style={{ borderBottom: "0px" }}>
            {/* {orderInfo.f_orderType=== "NPlan" ?"":""} */}
            {orderInfo.f_orderType === "NPlan" ? (
              <table className="table table-bordered">
                <thead>
                  <th
                    className="text-center"
                    style={{ borderRight: "1px solid #707070" }}
                  >
                    <p className="mg-b-0">
                      <strong>Image</strong>
                    </p>
                  </th>
                  <th
                    className="text-center"
                    style={{ borderRight: "1px solid #707070" }}
                  >
                    <p className="mg-b-0">
                      <strong>Item ID</strong>
                    </p>
                  </th>
                  <th
                    className="text-center"
                    style={{ borderRight: "1px solid #707070" }}
                  >
                    <p className="mg-b-0">
                      <strong>Type</strong>
                    </p>
                  </th>
                  <th
                    className="text-center"
                    style={{ borderRight: "1px solid #707070" }}
                  >
                    <p className="mg-b-0">
                      <strong>Dimension (Px)</strong>
                    </p>
                  </th>
                  <th
                    className="text-center"
                    style={{ borderRight: "1px solid #707070" }}
                  >
                    <p className="mg-b-0">
                      <strong>Rights</strong>
                    </p>
                  </th>
                  <th className="text-right">
                    <p className="mg-b-0">
                      <strong>Value</strong>
                    </p>
                  </th>
                </thead>
                <tbody>
                  {OrderDetails.map((data, inx) => (
                    <tr style={{ borderBottom: "1px solid #707070" }} >
                      <td
                        className="text-center"
                        style={{ borderRight: "1px solid #707070" }}
                      >
                        <img src="images/imagec.png" alt="img_img2" />
                      </td>
                      <td
                        className="text-center"
                        style={{ borderRight: "1px solid #707070" }}
                      >
                        <p className="mg-b-0">{data.t_imageid}</p>
                      </td>
                      <td
                        className="text-center"
                        style={{ borderRight: "1px solid #707070" }}
                      >
                        <p className="mg-b-0">{data.CS_ImgType_up}</p>
                      </td>
                      <td
                        className="text-center"
                        style={{ borderRight: "1px solid #707070" }}
                      >
                        <p className="mg-b-0">{data.f_mydimension}</p>
                      </td>
                      <td
                        className="text-center"
                        style={{ borderRight: "1px solid #707070" }}
                      >
                        <p className="mg-b-0">Non-Exclusive</p>
                      </td>
                      <td className="text-right">
                        <p className="mg-b-0">{data.t_price}</p>
                      </td>
                    </tr>
                  ))}
                  <tr style={{ borderBottom: "1px solid #707070" }}>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td
                      className="text-right"
                      style={{ borderRight: "1px solid #707070" }}
                    >
                      <p className="mg-b-0 resblock">
                        <strong>Total Value (INR)</strong>
                      </p>
                    </td>
                    <td className="text-right">
                      <p className="mg-b-0">{totalAmout}.00</p>
                    </td>
                  </tr>
                  <tr style={{ borderBottom: "1px solid #707070" }}>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td
                      className="text-right"
                      style={{ borderRight: "1px solid #707070" }}
                    >
                      <p className="mg-b-0 resblock">
                        <strong>Discount (INR)</strong>
                      </p>
                    </td>
                    <td className="text-right">
                      <p className="mg-b-0">{discount}.00</p>
                    </td>
                  </tr>
                  <tr style={{ borderBottom: "1px solid #707070" }}>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td
                      className="text-right"
                      style={{ borderRight: "1px solid #707070" }}
                    >
                      <p className="mg-b-0 resblock">
                        <strong>IGST Value @18% (INR)</strong>
                      </p>
                    </td>
                    <td className="text-right">
                      <p className="mg-b-0">{gst}.00</p>
                    </td>
                  </tr>
                </tbody>
              </table>
            ) : (
              <table className="table table-bordered">
                <thead>
                  <th
                    className="text-center"
                    style={{ borderRight: "1px solid #707070" }}
                  >
                    <p className="mg-b-0">
                      <strong>Image</strong>
                    </p>
                  </th>
                  <th
                    className="text-center"
                    style={{ borderRight: "1px solid #707070" }}
                  >
                    <p className="mg-b-0">
                      <strong>Plan Name</strong>
                    </p>
                  </th>
                  <th
                    className="text-center"
                    style={{ borderRight: "1px solid #707070" }}
                  >
                    <p className="mg-b-0">
                      <strong>No. of I/V</strong>
                    </p>
                  </th>
                  <th
                    className="text-center"
                    style={{ borderRight: "1px solid #707070" }}
                  >
                    <p className="mg-b-0">
                      <strong>Validity of Packages</strong>
                    </p>
                  </th>
                  <th
                    className="text-center"
                    style={{ borderRight: "1px solid #707070" }}
                  >
                    <p className="mg-b-0">
                      <strong>Rights</strong>
                    </p>
                  </th>
                  <th className="text-right">
                    <p className="mg-b-0">
                      <strong>Value</strong>
                    </p>
                  </th>
                </thead>
                <tbody>
                  {OrderDetails.map((data, inx) => (
                    <tr style={{ borderBottom: "1px solid #707070" }}>
                      {data.t_quality === "Large Size" ? (
                        <td
                          className="text-center"
                          style={{ borderRight: "1px solid #707070" }}
                        >
                          <img
                            src="https://www.imagesbazaar.com/images/icons/CheckoutLARGE.png"
                            alt="img_img2"
                          />
                        </td>
                      ) : (
                        ""
                      )}
                      {data.t_quality === "Extra-Small" ? (
                        <td
                          className="text-center"
                          style={{ borderRight: "1px solid #707070" }}
                        >
                          <img
                            src="https://www.imagesbazaar.com/images/icons/CheckoutSMALL.png"
                            alt="img_img3"
                          />
                        </td>
                      ) : (
                        ""
                      )}

                      {data.t_quality === "Medium-Size" ? (
                        <td
                          className="text-center"
                          style={{ borderRight: "1px solid #707070" }}
                        >
                          <img
                            src="https://www.imagesbazaar.com/images/icons/CheckoutMEDIUM.png"
                            alt="img_img4"
                          />
                        </td>
                      ) : (
                        ""
                      )}
                      {data.t_quality === "Web-Size" ? (
                        <td
                          className="text-center"
                          style={{ borderRight: "1px solid #707070" }}
                        >
                          <img
                            src="https://www.imagesbazaar.com/images/icons/CheckoutSMALL.png"
                            alt="img_img5"
                          />
                        </td>
                      ) : (
                        ""
                      )}
                      {data.t_quality === "XL-Size" ? (
                        <td
                          className="text-center"
                          style={{ borderRight: "1px solid #707070" }}
                        >
                          <img
                            src="https://www.imagesbazaar.com/images/icons/CheckoutXL.png"
                            alt="img_img6"
                          />
                        </td>
                      ) : (
                        +""
                      )}
                      {data.t_quality === "XXL-Size" ? (
                        <td
                          className="text-center"
                          style={{ borderRight: "1px solid #707070" }}
                        >
                          <img
                            src="https://www.imagesbazaar.com/images/icons/CheckoutXXL.png"
                            alt="img_img7"
                          />
                        </td>
                      ) : (
                        ""
                      )}

                      <td
                        className="text-center"
                        style={{ borderRight: "1px solid #707070" }}
                      >
                        <p className="mg-b-0">{data.t_imageid}</p>
                      </td>
                      <td
                        className="text-center"
                        style={{ borderRight: "1px solid #707070" }}
                      >
                        <p className="mg-b-0">{data.CS_ImgType_up}</p>
                      </td>
                      <td
                        className="text-center"
                        style={{ borderRight: "1px solid #707070" }}
                      >
                        <p className="mg-b-0">{data.CS_ImgType_up}days</p>
                      </td>
                      <td
                        className="text-center"
                        style={{ borderRight: "1px solid #707070" }}
                      >
                        <p className="mg-b-0">Non-Exclusive</p>
                      </td>
                      <td className="text-right">
                        <p className="mg-b-0">{data.t_price}</p>
                      </td>
                    </tr>
                  ))}
                  <tr style={{ borderBottom: "1px solid #707070" }}>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td
                      className="text-right"
                      style={{ borderRight: "1px solid #707070" }}
                    >
                      <p className="mg-b-0 resblock">
                        <strong>Total Value (INR)</strong>
                      </p>
                    </td>
                    <td className="text-right">
                      <p className="mg-b-0">{totalAmout}.00</p>
                    </td>
                  </tr>
                  <tr style={{ borderBottom: "1px solid #707070" }}>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td
                      className="text-right"
                      style={{ borderRight: "1px solid #707070" }}
                    >
                      <p className="mg-b-0 resblock">
                        <strong>Discount (INR)</strong>
                      </p>
                    </td>
                    <td className="text-right">
                      <p className="mg-b-0">{discount}.00</p>
                    </td>
                  </tr>
                  <tr style={{ borderBottom: "1px solid #707070" }}>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td
                      className="text-right"
                      style={{ borderRight: "1px solid #707070" }}
                    >
                      <p className="mg-b-0 resblock">
                        <strong>IGST Value @18% (INR)</strong>
                      </p>
                    </td>
                    <td className="text-right">
                      <p className="mg-b-0">{gst}.00</p>
                    </td>
                  </tr>
                </tbody>
              </table>
            )}

            <table className="table table-bordered">
              <tbody>
                <tr
                  style={{
                    background: "#eeeeee",
                    borderBottom: "1px solid #707070",
                  }}
                >
                  <td
                    className="text-right"
                    style={{ width: "88%", paddingRight: "10px" }}
                  >
                    <p className="mg-b-0">
                      <strong>
                        Total Amount Before GST (SGST / UGST / CGST / IGST)
                      </strong>
                    </p>
                  </td>
                  <td className="text-right">
                    <p className="mg-b-0">{finalAmout - gst}.00</p>
                  </td>
                </tr>
                <tr style={{ background: "#eeeeee" }}>
                  <td
                    className="text-right"
                    style={{ width: "88%", paddingRight: "10px" }}
                  >
                    <p className="mg-b-0">
                      <strong>
                        Total Amount Payable Inclusive of GST (SGST / UGST /
                        CGST / IGST)
                      </strong>
                    </p>
                  </td>
                  <td className="text-right">
                    <p className="mg-b-0">{netPayble}.00</p>
                  </td>
                </tr>
              </tbody>
            </table>
            <table className="table table-bordered">
              <tbody>
                <tr style={{ borderBottom: "1px solid #707070" }}>
                  <td>
                    <p className="mg-b-0">
                      ImagesBazaar is a unit of Mash Audio Visuals Pvt. Ltd.
                      Usage of content subject to Mash Rights Agreement
                      mentioned on{" "}
                      <a href="demo">www.Imagesbazaar.com/licensing.aspx</a>
                    </p>
                  </td>
                </tr>
              </tbody>
            </table>
            <table
              className="table table-bordered"
              style={{ borderBottom: "0px" }}
            >
              <tbody>
                <tr>
                  <td
                    style={{ width: "72%", borderRight: "1px solid #707070" }}
                  >
                    <p className="mg-b-0">
                      If you have any problem with your order, please call us at{" "}
                      <a href="demo">+91-9911366666</a> or{" "}
                      <a href="demo">+91-1166545466</a> or send us a message at
                      <a href="mailto:orders@imagesbazaar.com">
                        orders@imagesbazaar.com
                      </a>
                    </p>
                  </td>
                  <td style={{ width: "28%" }}>
                    <p className="">For Mesh Audio Visuals Pvt. Ltd.</p>
                    <p
                      className="mg-b-0 text-center"
                      style={{ marginTop: "100px" }}
                    >
                      Authorised Signatory
                    </p>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </main>
        <div className="col-md-12" style={{ marginBottom: "20px" }}>
          <div className="text-center">
            <h6 style={{ fontWeight: "bold", color: "#000" }}>
              WE THINK YOU FOR YOUR BUSINESS. WE VALUE YOUR PATRONAGE
            </h6>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Orderdetails;
