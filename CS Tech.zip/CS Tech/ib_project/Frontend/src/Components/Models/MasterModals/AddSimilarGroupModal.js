import React, { useState } from 'react';
import * as RB from "react-bootstrap";
import { Row } from "react-bootstrap";

import { ADD_SMILARGROUP } from "../../../Utils/api"

const AddSimilarGroupModal = (
    { show_addsimilargroup, setShow, apiCall, setModelMsg, modelSet }
) => {
    const [FormData, setFormData] = useState({});
    const [ErrorMsg, setErrorMsg] = useState("");

    const handleChange = (e) => {
        let { name, value } = e.target;
        const data = { ...FormData }
        data[name] = value
        setFormData(data)
    }

    const closeModal = () => {
        setFormData({});
        setErrorMsg("")
        setShow(false)
    }

    const AddSimilarGroupDetail = async () => {
        let { f_groupname, S_groupid } = FormData;
        if (!f_groupname || !S_groupid) {
            setErrorMsg("please fill requirment text-values")
        } else {
            const res = await ADD_SMILARGROUP(FormData);
            let { status, message } = res
            if (status === 200) {
                apiCall();
                setFormData({});
                setErrorMsg("")
                setShow(false);
                setModelMsg(message);
                modelSet()
            } else {
                setErrorMsg(message)
            }
        }

    }
    return (
        <div>
            <RB.Modal show={show_addsimilargroup} onHide={closeModal} className="ordermanage_modal">
                <RB.Modal.Header closeButton>
                    <RB.Modal.Title>Add Similar Group</RB.Modal.Title>
                </RB.Modal.Header>
                <RB.Modal.Body>
                    <RB.Row>
                        <RB.Col lg={12} md={12}>
                            <RB.Row>
                                {ErrorMsg !== "" ? ErrorMsg : ""}
                                <RB.Col lg={12} md={12}>
                                    <RB.Form>
                                        <RB.Form.Group as={Row} controlId="Country_id">
                                            <RB.Col lg={4} md={4}>
                                                <RB.Form.Label>Group Name :</RB.Form.Label>
                                            </RB.Col>
                                            <RB.Col lg={7} md={8}>
                                                <RB.Form.Control
                                                    type="text"
                                                    name="f_groupname"
                                                    onChange={handleChange}
                                                />
                                            </RB.Col>
                                        </RB.Form.Group>
                                        <RB.Form.Group as={Row} controlId="Country_id">
                                            <RB.Col lg={4} md={4}>
                                                <RB.Form.Label>Similar Group ID :</RB.Form.Label>
                                            </RB.Col>
                                            <RB.Col lg={7} md={8}>
                                                <RB.Form.Control
                                                    type="text"
                                                    name="S_groupid"
                                                    onChange={handleChange}
                                                />
                                            </RB.Col>
                                        </RB.Form.Group>
                                        <RB.Row>
                                            <RB.Col lg={4} md={4}></RB.Col>
                                            <RB.Col lg={6} md={7}>
                                                <RB.Button
                                                    size="sm" variant="primary"
                                                    onClick={AddSimilarGroupDetail}
                                                >
                                                    ADD
                                                </RB.Button>
                                            </RB.Col>
                                        </RB.Row>
                                    </RB.Form>
                                </RB.Col>
                            </RB.Row>
                        </RB.Col>
                    </RB.Row>
                </RB.Modal.Body>
            </RB.Modal>
        </div>
    )
}

export default AddSimilarGroupModal
