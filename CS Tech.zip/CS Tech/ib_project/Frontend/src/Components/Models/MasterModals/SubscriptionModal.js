import React, { useState } from 'react';
import * as RB from "react-bootstrap";
import { Row } from "react-bootstrap";
import { SubscriptionModalForm } from "../../../Components/Forms/FormElements";
import { ADD_SUBPLANDDETAIL } from "../../../Utils/api"

const DropArrayS = [
    { name: "Web Resolution" },
    { name: "High Resolution" },
    { name: "Super Resolution" },
    { name: "XXL Resolution" },
];

const SubscriptionModal = (
    { show_subscriptiomvideo, setShow, setModelMsg, modelSet, apiCall }
) => {
    const [FormData, setFormData] = useState({});
    const [ErrorMsg, setErrorMsg] = useState("");

    const closeModal = () => {
        setFormData({});
        setErrorMsg("")
        setShow(false);
    }

    const handleChange = (e) => {
        let { name, value } = e.target;
        const data = { ...FormData };
        data[name] = value;
        setFormData(data)
    }

    const addSubScriptionPlan = async () => {
        let { f_planname, f_maxallowed, f_periodindays, f_amount, f_totimg, f_imageType, f_save, f_desc } = FormData;
        if (!f_planname) {
            setErrorMsg("please fill plane name")
        } else if (!f_maxallowed) {
            setErrorMsg("please fill max allowed")
        } else if (!f_periodindays) {
            setErrorMsg("please fill period day")
        } else if (!f_amount) {
            setErrorMsg("please fill amount")
        } else if (!f_totimg) {
            setErrorMsg("please fill total image")
        } else if (!f_imageType) {
            setErrorMsg("please fill image type")
        } else if (!f_save) {
            setErrorMsg("please fill save")
        } else if (!f_desc) {
            setErrorMsg("please fill description")
        } else {
            const res = await ADD_SUBPLANDDETAIL(FormData);
            let { status, message } = res;
            if (status === 200) {
                apiCall();
                setModelMsg(message);
                modelSet();
                closeModal();
            } else {
                setErrorMsg(message)
            }
        }
    }
    return (
        <div>
            <RB.Modal show={show_subscriptiomvideo} onHide={closeModal} className="ordermanage_modal">
                <RB.Modal.Header closeButton>
                    <RB.Modal.Title>Add Subscription Plan</RB.Modal.Title>
                </RB.Modal.Header>
                <RB.Modal.Body>
                    <RB.Row>
                        <RB.Col lg={12} md={12}>
                            <RB.Row>
                                {ErrorMsg !== "" ? ErrorMsg : ""}
                                <RB.Col lg={12} md={12}>
                                    <RB.Form>
                                        {SubscriptionModalForm.map((data, inx) => {
                                            let { label, type, name, format, controlId, forms } = data;
                                            return (
                                                <>
                                                    {forms === "false" ?
                                                        <RB.Form.Group as={Row} controlId={controlId} key={controlId + inx}>
                                                            <RB.Col lg={5} md={5}>
                                                                <RB.Form.Label>{label} :</RB.Form.Label>
                                                            </RB.Col>
                                                            <RB.Col lg={6} md={6}>
                                                                <RB.Form.Control type={type} name={name} as={format} onChange={handleChange} />
                                                            </RB.Col>
                                                        </RB.Form.Group>
                                                        :
                                                        <RB.Form.Group as={Row} controlId={controlId} key={controlId + inx}>
                                                            <RB.Col lg={5} md={5}>
                                                                <RB.Form.Label>{label} :</RB.Form.Label>
                                                            </RB.Col>
                                                            <RB.Col lg={6} md={6}>
                                                                <RB.Form.Control name={name} as={format} onChange={handleChange}>
                                                                    <option>Select</option>
                                                                    {DropArrayS.map((data, inx) => {
                                                                        let { name } = data;
                                                                        return (
                                                                            <option value={name} key={`OPTION_SUB_${inx}`}>{name}</option>
                                                                        )
                                                                    })}
                                                                </RB.Form.Control>
                                                            </RB.Col>
                                                        </RB.Form.Group>
                                                    }
                                                </>

                                            );

                                        })}
                                        <RB.Row>
                                            <RB.Col lg={5} md={5}></RB.Col>
                                            <RB.Col lg={6} md={6}>
                                                <RB.Button
                                                    size="sm" variant="primary"
                                                    onClick={addSubScriptionPlan}
                                                >
                                                    SUBMIT
                                                </RB.Button>
                                            </RB.Col>
                                        </RB.Row>
                                    </RB.Form>
                                </RB.Col>
                            </RB.Row>
                        </RB.Col>
                    </RB.Row>
                </RB.Modal.Body>
            </RB.Modal>
        </div>
    )
}

export default SubscriptionModal