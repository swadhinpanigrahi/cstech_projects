const { T_visiblekeyword_MongoDB, T_LinkKeyword, T_allkeyword_MongoDB } = require("../../model");


exports.getVisibleKeyDetails = async (req, res) => {
    const { currentPage, itemPerPage } = req.query;
    const num = parseInt(itemPerPage)
    const start = parseInt(currentPage);
    let pipeline;
    let countline;
    try {
        pipeline = [
            { $sort: { _id: -1 } },
            { $skip: (start - 1) * num },
            { $limit: 3 }
        ]
        countline = [
            { $count: "totalcount" }
        ]
        const data = await T_visiblekeyword_MongoDB.aggregate(pipeline)
        const totalrecord = await T_visiblekeyword_MongoDB.aggregate(countline)
        res.json({ status: 200, data, totalrecord })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

exports.getAidValues = async (req, res) => {
    console.log(req.body)
    let { aid } = req.body;
    try {
        res.json({ status: 200, aid })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}