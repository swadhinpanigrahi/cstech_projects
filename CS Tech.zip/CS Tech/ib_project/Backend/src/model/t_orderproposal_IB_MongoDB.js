const mongoose = require("mongoose");

const t_orderproposal_IB_MongoDB_Schema = mongoose.Schema(
  {
    T_orderid: { type: String },
    T_username: { type: String },
    T_status: { type: String, default: "P" },
    f_heading: { type: String },
    f_amt: { type: Number },
    f_discount: { type: Number },
    f_amtpay: { type: Number },
    f_sertax: { type: Number },
    f_finalamt: { type: Number },
    f_ip: { type: String, default: "" },
    f_totimg: { type: Number },
    f_proposaluser: { type: String },
    f_Creditperiod: { type: String },
    t_followup_status: { type: Number, default: 0 },
    f_client: { type: String },
    f_ProposalType: { type: String, default: "NoPlan" },
    f_planid: { type: String, default: "" },
    f_state: { type: String },
    f_GSTNNo: { type: String },
    T_orderdate: { type: Date, default: Date.now() },
  },
  { collection: "t_orderproposal_IB_MongoDB" }
);

module.exports = t_orderproposal_IB_MongoDB = mongoose.model(
  "t_orderproposal_IB_MongoDB",
  t_orderproposal_IB_MongoDB_Schema
);