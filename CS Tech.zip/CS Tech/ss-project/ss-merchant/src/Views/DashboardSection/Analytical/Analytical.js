import React from 'react';
import PageHeaders from "../../../Components/Common/PageHeaders"
import Graph from "./Graph"
import { useTranslation } from "react-i18next";

const Analytical = () => {
    const { t } = useTranslation();
    return (
        <>
            <div className="col-md-12">
                <PageHeaders title={t("change.Analytical")} />
                <div className="col-md-12">
                    <Graph />
                </div>
            </div>
        </>
    )
}

export default Analytical
