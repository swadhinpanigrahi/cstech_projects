const mongoose = require("mongoose");

const MasterImageSizeSchema = mongoose.Schema(
    {
        f_sno: { type: Number },
        f_sizename: { type: String },
    },
    { collection: "t_sizes" }
);

module.exports = M_IMAGESIZE = mongoose.model(
    "t_sizes",
    MasterImageSizeSchema
);