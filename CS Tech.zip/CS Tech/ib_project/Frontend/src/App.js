import { HashRouter as Router, Switch, Route } from "react-router-dom";
import { ProvideAuth, PrivateRoute } from "./Utils/auth";
import DashSection from "./View/DashboardSection";
import Login from "./View/LoginSection/Login";
import Logout from "./View/LogoutSection/Logout";
import ForgotPage from "./View/ForgotSection/ForgotPage";
import ForgetEmailPage from "./View/ForgotSection/ForgetEmailPage";
// import Footer from "./Components/NavSection/Footer";
import UtilComponent from "./View/UtilComponent";
import ProposalAdditionalView from "./View/DashboardSection/ProposalSection/ProposalAdditionalView";

export default function App() {
  return (
    <ProvideAuth>
      <Router>
        <Switch>
          <Route exact path="/" children={<Login />} />
          <PrivateRoute path="/dashboard" children={<DashSection />} />
          <Route path="/logout" component={Logout} />
          <Route path="/forgotpage" component={ForgotPage} />
          <Route path="/auth/varifypage/:token" component={ForgetEmailPage} />
        </Switch>
        <Route path="/orderprint/:orderid" component={UtilComponent} />
        <Route path="/proposaldetails/:T_orderid" component={ProposalAdditionalView} />
      </Router>

    </ProvideAuth>
  );
}
