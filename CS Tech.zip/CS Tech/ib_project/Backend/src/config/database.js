const mongoose = require("mongoose");
//ImagesbazaarDB_MongoDB
mongoose
  .connect(
    // `mongodb+srv://image:image@imagebazaar.vfx0m.mongodb.net/myFirstDatabase?retryWrites=true&w=majority`,
    `mongodb://localhost:27017/ImagesbazaarDB_MongoDBv2`,
    {
      useCreateIndex: true,
      useFindAndModify: false,
      useNewUrlParser: true,
      useUnifiedTopology: true,
    }
  )
  .then(() => {
    console.log(`database connected successfully`);
  })
  .catch((err) => {
    console.log(`error : ${err}`);
  });
mongoose.connection
  .once("open", () => {
    console.log("connection made with myFirstDatabase");
  })
  .on("error", (error) => {
    console.log("error :" + error);
  });

module.exports = mongoose;
