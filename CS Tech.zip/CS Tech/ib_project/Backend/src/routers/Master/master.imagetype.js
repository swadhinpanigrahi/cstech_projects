const Imagetype = require("express").Router();
const {
    addImageTypeDetail, getImageTypeList, getImageTypeDetail, editImageTypeDetail, deleteImageTypeDetail
} = require("../../controllers/Master/master.imagetype.controller");

Imagetype.route("/addimagetypedetail").post(addImageTypeDetail)
Imagetype.route("/getimagetypeList").get(getImageTypeList)
Imagetype.route("/getimagetypedetail/:_id").get(getImageTypeDetail)
Imagetype.route("/editimagetypedetail").post(editImageTypeDetail)
Imagetype.route("/deletetmagetypedetail/:_id").get(deleteImageTypeDetail)

module.exports = Imagetype;