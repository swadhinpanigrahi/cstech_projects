const Agencies = require("express").Router();
const {
    getAgenciesList,
} = require("../../controllers/Master/master.agencies.controller");

Agencies.route("/getagencieslist").get(getAgenciesList)

module.exports = Agencies;