import {
  FATCH_USER_REQUEST,
  FATCH_USER_REGISTER,
  FATCH_USER_ORDER,
  FATCH_USER_PROPOSAL,
  FATCH_USER_FOLLOWUP,
  FATCH_USER_FAILED,
} from "./actionType";

const initialState = {
  loading: false,
  userData: {},
  order: [],
  proposal: [],
  followup: [],
  error: "",
};

const userActionReducer = (state = initialState, action) => {
  switch (action.type) {
    case FATCH_USER_REQUEST:
      return {
        ...state,
        loading: true,
      };
    case FATCH_USER_REGISTER:
      return {
        ...state,
        loading: false,
        userData: action.payload,
        error: "",
      };
    case FATCH_USER_ORDER:
      return {
        ...state,
        loading: false,
        order: action.payload,
        error: "",
      };
    case FATCH_USER_PROPOSAL:
      return {
        ...state,
        loading: false,
        proposal: action.payload,
        error: "",
      };
    case FATCH_USER_FOLLOWUP:
      return {
        ...state,
        loading: false,
        followup: action.payload,
        error: "",
      };
    case FATCH_USER_FAILED:
      return {
        ...state,
        loading: false,
        userData: {},
        order: [],
        proposal: [],
        followup: [],
        error: action.payload,
      };
    default:
      return state;
  }
};

export default userActionReducer;
