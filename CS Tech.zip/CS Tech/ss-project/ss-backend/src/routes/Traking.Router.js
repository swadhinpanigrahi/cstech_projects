const express = require("express");
const { createValidator } = require("express-joi-validation");

//controllers
const {
  postShipmentAPI, getlogdetail, updateShipment, removeShipment,
  getSMSAshipments, getARAMEXshipments, getWAYXPRESSshipments, statusChangeForAramex, statusChangeForSmsa,
  statusChangeForWaypress, resetRuningStatus, statusChangeForAll,
  getArmaxDeliveryData, AramaxStatusUpdateToReturn, resetDeliveryStatus,
  assiningDate
} = require("../controllers/Traking.Controller");

const validator = createValidator({ passError: true });
const takingRoutes = express.Router();

takingRoutes.route("/insert_trakingdetails").post(postShipmentAPI);
takingRoutes.route("/getupdatelogs/:order_number").get(getlogdetail);
takingRoutes.route("/update_trakingdetails").post(updateShipment);
takingRoutes.route("/remove_trakingdetails/:_id").get(removeShipment);


takingRoutes.route("/getSMSAshipments").get(getSMSAshipments);
takingRoutes.route("/getARAMEXshipments").get(getARAMEXshipments);
takingRoutes.route("/getWAYXPRESSshipments").get(getWAYXPRESSshipments);

takingRoutes.route("/changestatusforcrownjob").post(statusChangeForAramex);
takingRoutes.route("/changestatusforsmsacrownjob").post(statusChangeForSmsa);
takingRoutes
  .route("/changestatusforwaypresscrownjob")
  .post(statusChangeForWaypress);

takingRoutes.route("/statuschangeforall").post(statusChangeForAll);

takingRoutes.route("/aramaxgetdeliveryshipmentsforreturn").get(getArmaxDeliveryData);
takingRoutes.route("/aramaxupdatedeliverystatustoreturned").post(AramaxStatusUpdateToReturn);

takingRoutes.route("/converting/pending/status").get(resetRuningStatus);
takingRoutes.route("/converting/delivered/status").get(resetDeliveryStatus);


takingRoutes.route("/additionalwors").get(assiningDate);

module.exports = takingRoutes;
