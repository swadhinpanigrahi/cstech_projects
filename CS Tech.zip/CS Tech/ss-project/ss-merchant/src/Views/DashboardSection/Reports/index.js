import React from 'react';
import { Route } from "react-router-dom"

import Reports from "./Reports"

const ReportsDash = () => {
    return (
        <div>
            <Route path="/dashboard/CODReports/get" component={Reports} />
        </div>
    )
}

export default ReportsDash
