const mongoose = require("mongoose");

const FollowupSchemaNewV2 = mongoose.Schema(
    {
        f_sno: { type: String },
        f_email: { type: String },
        f_AlternateEmail: { type: String },
        f_fullname: { type: String },
        f_CompanyName: { type: String },
        f_PhoneNumber: { type: String },
        f_MobileNo: { type: String },
        f_state: { type: String },
        f_country: { type: String },
        f_usertype: { type: String },
        f_RequirementType: { type: String },
        f_followups_status: { type: String },
        f_createdby: { type: String },
        f_creationdate: { type: Date },
        f_DescriptionType: { type: String },
        f_DiscountTerms: { type: String },
        f_CreditPeriod: { type: String },
        f_OrderId: { type: String },
        f_followUpType1: { type: String },
        f_followUpType2: { type: String },
        f_followUpDescriptionType: { type: String },
        f_followUpDescriptionType2: { type: String },
        f_followupDate: { type: String },
        f_followupDate2: { type: String },
        f_followupDescription: { type: String },
        f_followupDescription2: { type: String },
        f_followupOrderID: { type: String },
        f_followupOrderID2: { type: String },
        f_AdditionalInfo: []
    },
    { collection: "t_DailySalesEntry_sales_IB_MongoDB" }
);

module.exports = FollowupSchemaV2 = mongoose.model(
    "t_DailySalesEntry_sales_IB_MongoDB",
    FollowupSchemaNewV2
);
