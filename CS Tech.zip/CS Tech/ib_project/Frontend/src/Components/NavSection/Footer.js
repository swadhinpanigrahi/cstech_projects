import React from "react";

const Footer = () => {
  return (
    <footer className="footer">
      © Imagesbazaar.com. A division of Mash Audio Visuals Pvt. Ltd. All rights reserved.
    </footer>
  );
};

export default Footer;
