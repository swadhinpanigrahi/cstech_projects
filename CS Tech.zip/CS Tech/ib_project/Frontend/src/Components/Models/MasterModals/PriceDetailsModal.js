import React, { useState } from 'react';
import * as RB from "react-bootstrap";
import { Row } from "react-bootstrap";
import { ImageDetailsModal } from "../../../Components/Forms/FormElements";

import { ADD_PRICEDETAIL } from "../../../Utils/api"



const PriceDetailsModal = (
    { show_imagepricedtl, setShow, apiCall, setModelMsg, modelSet }
) => {

    const [FormData, setFormData] = useState({});
    const [ErrorMsg, setErrorMsg] = useState("");

    const closeModal = () => {
        setModelMsg("")
        setShow(false)
    }

    const handleChange = (e) => {
        let { name, value } = e.target;
        const data = { ...FormData }
        data[name] = value
        setFormData(data)
    }

    const addPriceDetail = async () => {
        let { f_typename, f_refname, f_dimenation, f_dpi, f_outputsize, f_price, f_time, f_showprice, f_showdiscount } = FormData;
        if (!f_typename || !f_refname || !f_dimenation || !f_dpi ||
            !f_outputsize || !f_price || !f_time || !f_showprice || !f_showdiscount) {
            setErrorMsg("please fill all requirment fields!")
        } else {
            const res = await ADD_PRICEDETAIL(FormData);
            let { status, message } = res
            if (status === 200) {
                apiCall();
                setShow(false);
                setModelMsg(message);
                modelSet()
            } else {
                setErrorMsg(message)
            }
        }
    }

    return (
        <div>
            <RB.Modal show={show_imagepricedtl} onHide={closeModal} className="ordermanage_modal">
                <RB.Modal.Header closeButton>
                    <RB.Modal.Title>Add Image Price</RB.Modal.Title>
                </RB.Modal.Header>
                <RB.Modal.Body>
                    <RB.Row>
                        <RB.Col lg={12} md={12}>
                            <RB.Row>
                                {ErrorMsg !== "" ? ErrorMsg : ""}
                                <RB.Col lg={12} md={12}>
                                    <RB.Form>
                                        {ImageDetailsModal.map((data, inx) => {
                                            let { label, type, name, format, controlId, forms, dropArrays } = data;
                                            return (
                                                <>
                                                    {forms === "true" ?
                                                        <RB.Form.Group as={Row} controlId={controlId} key={controlId + inx}>
                                                            <RB.Col lg={5} md={5}>
                                                                <RB.Form.Label>{label} :</RB.Form.Label>
                                                            </RB.Col>
                                                            <RB.Col lg={6} md={6}>
                                                                <RB.Form.Control
                                                                    onChange={handleChange}
                                                                    type={type}
                                                                    name={name}
                                                                    as={format}
                                                                />
                                                            </RB.Col>
                                                        </RB.Form.Group>
                                                        :
                                                        <RB.Form.Group as={Row} controlId={controlId} key={controlId + inx}>
                                                            <RB.Col lg={5} md={5}>
                                                                <RB.Form.Label>{label} :</RB.Form.Label>
                                                            </RB.Col>
                                                            <RB.Col lg={6} md={6}>
                                                                <RB.Form.Control name={name} as={format} onChange={handleChange}>
                                                                    <option>Select</option>
                                                                    {dropArrays.map((data, inx) => {
                                                                        let { name } = data;
                                                                        return (
                                                                            <option value={name} key={`EDIT_${inx}`}>{name}</option>
                                                                        )
                                                                    })}
                                                                </RB.Form.Control>
                                                            </RB.Col>
                                                        </RB.Form.Group>
                                                    }
                                                </>

                                            );

                                        })}
                                        <RB.Row>
                                            <RB.Col lg={5} md={5}></RB.Col>
                                            <RB.Col lg={6} md={6}>
                                                <RB.Button
                                                    size="sm" variant="primary"
                                                    onClick={addPriceDetail}
                                                >
                                                    SUBMIT
                                                </RB.Button>
                                            </RB.Col>
                                        </RB.Row>
                                    </RB.Form>
                                </RB.Col>
                            </RB.Row>
                        </RB.Col>
                    </RB.Row>
                </RB.Modal.Body>
            </RB.Modal>
        </div>
    )
}

export default PriceDetailsModal