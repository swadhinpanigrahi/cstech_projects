import React, { useState, useEffect } from 'react';
import * as RB from 'react-bootstrap';
import { MdAddCircleOutline } from 'react-icons/md';
import { RiDeleteBin6Line } from "react-icons/ri";
import { BiCommentEdit } from "react-icons/bi";

import AddImageSize from "../../../Components/Models/MasterModals/AddImageSize";
import EditImageSize from "../../../Components/Models/MasterModals/MasterEdit/EditImageSize";

import Modal from "../../../Components/Common/Modal";

import PaginationComponent from "../../../Components/Common/PaginationComponent";

import { GET_IMAGESIZELIST, GET_IMAGESIZEDETAIL, REMOVE_IMAGESIZEDETAIL } from "../../../Utils/api"

export const ImageSize = () => {
  const [currentPage, setCurrentPage] = useState(1);
  const [itemPerPage, setItemPerPage] = useState(20);
  let [searchData, setSearchData] = useState("");
  const [TotalCount, setTotalCount] = useState(0);

  const [show_addimagesize, setShow] = useState(false);
  const [show_editimagesize, setEdit] = useState(false);

  const [ImageSizeList, setImageSizeList] = useState([])
  const [userData, setUserData] = useState({})
  const [Loading, setLoading] = useState(false)

  const [isOpen, setIsOpen] = useState(false);
  const [ModelMsg, setModelMsg] = useState("");

  const addimagesizeShow = () => {
    setShow(true)
  };

  const editimagesizeShowFun = async (id) => {
    const res = await GET_IMAGESIZEDETAIL(id);
    let { data } = res;
    setUserData(data)
    setEdit(true)
  };

  const modelSet = async () => {
    setIsOpen(true);
  };

  const deleteImageSizeFun = async (id) => {
    const res = await REMOVE_IMAGESIZEDETAIL(id);
    let { message } = res;
    apiCall()
    setModelMsg(message);
    modelSet();
  }

  const SearchDataFun = async (e) => {
    setSearchData(e.target.value);
    const res = await GET_IMAGESIZELIST(currentPage, itemPerPage, searchData);
    let { data, totalrecord } = res;
    setImageSizeList(data);
    totalrecord.length === 1
      ? setTotalCount(totalrecord[0].totalcount)
      : setTotalCount(0);
  }


  const apiCall = async () => {
    setLoading(true)
    const res = await GET_IMAGESIZELIST(currentPage, itemPerPage, searchData);
    let { data, totalrecord } = res;
    setImageSizeList(data);
    setTotalCount(totalrecord[0].totalcount)
    setLoading(false)
  }

  useEffect(() => {
    apiCall()
  }, [currentPage, itemPerPage])

  return (
    <RB.Row className="rownew1">
      <RB.Col lg={12}>
        <RB.Row className="rownew1" style={{ paddingTop: "25px" }}>
          <div className="tableHeader tableHeader1 order_btntable">
            <RB.Col md={6} xs={12} className="table_span">
              <h3 className="page-title d-flex userv">
                <span>Image Size List</span>
              </h3>
            </RB.Col>
            <RB.Col md={6} xs={12} className="table_span total_recordtimg">
              <div className="float-right total_recordt responsive_floatbtn desktop-float">
                <span>Total Records: {TotalCount}</span>
                <RB.Button size="sm" variant="primary" className="btn_svg" onClick={addimagesizeShow}
                >
                  <MdAddCircleOutline style={{ marginRight: "3px" }} />
                  ADD IMAGE SIZE
                </RB.Button>
              </div>
            </RB.Col>
          </div>
        </RB.Row>
      </RB.Col>

      <RB.Col lg={12}>
        <div
          className="box_detail table_boxdtl manage_order"
          style={{}}
        >
          <RB.Table striped bordered hover variant="dark" responsive>
            <thead>
              <tr class="vtable">
                <th className="text-center">S. No.</th>
                <th className="">	Image Size Name</th>
                <th className="text-center action_align">Action</th>
              </tr>
            </thead>
            <tbody>
              {Loading ? <tr><td className="no_records" colSpan="11">Loading...</td></tr> : ImageSizeList.length > 0 ? ImageSizeList.map((info, inx) => {
                return (
                  <tr key={`ImageSize_${inx}`}>
                    <td className="s_notm text-center">{inx + 1}</td>
                    <td className="">{info.f_sizename}</td>
                    <td className="td_comments text-center">
                      <BiCommentEdit title="Edit Image Size"
                        onClick={() => editimagesizeShowFun(info._id)}
                      />
                      <RiDeleteBin6Line
                        title="Delete Image Size"
                        className="text-danger1"
                        onClick={() => deleteImageSizeFun(info._id)}
                      />
                    </td>
                  </tr>
                )
              }) : <tr><td className="no_records" colSpan="11">No Records Found</td></tr>}
            </tbody>
          </RB.Table>
        </div>
        <PaginationComponent
          MOCK_DATA={TotalCount}
          currentPage={currentPage}
          setCurrentPage={setCurrentPage}
          itemPerPage={itemPerPage}
          setItemPerPage={setItemPerPage}
        />
      </RB.Col>

      <AddImageSize
        show_addimagesize={show_addimagesize}
        setShow={setShow}
        apiCall={apiCall}
        setModelMsg={setModelMsg}
        modelSet={modelSet}
      />

      <EditImageSize
        show_editimagesize={show_editimagesize}
        setEdit={setEdit}
        userData={userData}
        apiCall={apiCall}
      />

      <Modal text={ModelMsg} open={isOpen} onClose={() => setIsOpen(false)} />

    </RB.Row>
  )
}

export default ImageSize