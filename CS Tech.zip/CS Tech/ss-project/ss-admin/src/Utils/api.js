import Axios from "axios";
import Cookie from "js-cookie";
import { saveCookies } from "../Utils/helpers";
// Axios.defaults.baseURL = "http://localhost:2222/api";
Axios.defaults.baseURL = "https://apiv2.storagestation.net/api";

Axios.interceptors.request.use(
  (config) => {
    const token = Cookie.get("AAToken");
    config.headers.authorization = `Bearer ${token}`;
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

export const logInApi = async (FormData) => {
  try {
    const apiCall = await Axios.post("/v1/auth/login", FormData);
    let { status, message, token, authData } = apiCall.data;
    if (status === 200) {
      await saveCookies(authData)
      await Cookie.set("AAToken", token, { expires: 3 });
      return { status };
    } else {
      return { message };
    }
  } catch (error) {
    return { error };
  }
};

export const verifyProfile = async () => {
  try {
    const apiCall = await Axios.get("/v1/auth/verifyprofile");
    let { id, name, email } = apiCall.data.authData;
    await Cookie.set("_id", id, { expires: 3 });
    return { name, email };
  } catch (error) {
    return { error };
  }
};

export const getAdminProfile = async () => {
  try {
    const apiCall = await Axios.get("/v1/auth/getauthprofile");
    let { status, userData } = apiCall.data
    if (status === 200) {
      return { userData }
    } else {
      return { message: "internal server error" }
    }
  } catch (error) {
    return { error };
  }
}

export const updateAdminProfile = async (FormData) => {
  try {
    const apiCall = await Axios.post("/v1/auth/updateauthprofile", FormData);
    let { status, updatedData } = apiCall.data;
    if (status === 200) {
      return { updatedData }
    }
  } catch (error) {
    return { error }
  }
}

export const authChangePassword = async (FormData) => {
  try {
    const _id = Cookie.get("_id")
    const apiCall = await Axios.post(`/v1/auth/changeauthpassword/${_id}`, FormData);
    let { status, message, updatePassword } = apiCall.data;
    if (status === 200) {
      return { message, updatePassword }
    } else {
      return { message }
    }
  } catch (error) {
    return { error }
  }
}

export const forgotPasswordEmail = async (FormData) => {
  try {
    const apiCall = await Axios.post(`/v1/auth/authForgotMail`, FormData);
    let { status, message } = apiCall.data;
    return { status, message }
  } catch (err) {
    return { err };
  }
}

export const forgotEmailPasswordChange = async (FormData) => {
  try {
    const apiCall = await Axios.post(`/v1/auth/authemailpasswordchange`, FormData);
    let { message } = apiCall.data
    // let { status, message } = apiCall.data;
    return { message }
  } catch (err) {
    return { err };
  }
}

//Analatical--section
export const getDataForGraph = async () => {
  try {
    const apiCall = await Axios.get("/v2/auth/getshipment15daysrecords");
    let { status, graph, totalOrder, totalCustomer } = apiCall.data;
    if (status === 200) {
      return { graph, totalOrder, totalCustomer };
    }
  } catch (error) {
    return { error };
  }
};
//Analatical--section

//start-----customer-section
export const getCustomerDetailsList = async (pagecount, searchbyname) => {
  try {
    const res = await Axios.get("/v2/auth/getcustomerlist", {
      params: { pagecount: pagecount, searchbyname: searchbyname },
    });
    const { merchantData, merchantCount, merchantDataForExport } = res.data;
    return { merchantData, merchantCount, merchantDataForExport };
  } catch (error) {
    return { error };
  }
};

export const createCustomer = async (FormData) => {
  try {
    const apiCall = await Axios.post(`/v2/auth/createcustomer`, FormData);
    let { status, newCustomer, message } = apiCall.data;
    return { status, newCustomer, message };
  } catch (error) {
    return { error };
  }
};

export const getCustomerDetails = async (_id) => {
  try {
    const apiCall = await Axios.get(`/v2/auth/getcustomer/${_id}`);
    let { status, customerData } = apiCall.data;
    return { status, customerData };
  } catch (error) {
    return { error };
  }
};

export const updateCustomerDetails = async (_id, FormData) => {
  try {
    const apiCall = await Axios.post(`/v2/auth/updatecustomer/${_id}`, FormData);
    let { status, message, updatedCustomer } = apiCall.data;
    return { status, message, updatedCustomer };
  } catch (error) {
    return { error };
  }
};
//end-----customer-section

//PAYMENT----
export const makePaymentToCustomer = async (FormData) => {
  try {
    const apiCall = await Axios.post(`/v2/auth/createpayment`, FormData);
    let { status, newData } = apiCall.data;
    return { status, newData };
  } catch (error) {
    return { error };
  }
}

export const getpaymentAmount = async (_id) => {
  try {
    const apiCall = await Axios.get(`/v2/auth/paymentamtandname/${_id}`);
    let { data } = apiCall.data;
    return { data };
  } catch (error) {
    return { error };
  }
}

export const getPaymentStalment = async (_id) => {
  try {
    const apiCall = await Axios.get(`/v2/auth/getpaymentsatelments/${_id}`);
    let { records, sumCredit, sumDebit, netPayble, netReceiveble } = apiCall.data;
    return { records, sumCredit, sumDebit, netPayble, netReceiveble };
  } catch (error) {
    return { error };
  }
}

export const paymentFilteredData = async (data, _id) => {
  try {
    const apiCall = await Axios.post(`/v2/auth/getpaymentdetailsbydatefilter/${_id}`, data);
    let { paymentDetails, sumCredit, sumDebit, netPayble, netReceiveble } = apiCall.data;
    return { paymentDetails, sumCredit, sumDebit, netPayble, netReceiveble };
  } catch (error) {
    return { error };
  }
}

export const paymentFilteredDataV2 = async (data, _id) => {
  try {
    const apiCall = await Axios.post(`/v2/auth/getpaymentdetailsbydatefilterV2/${_id}`, data);
    console.log(apiCall)
    let { paymentDetails, sumCredit, sumDebit, netPayble, netReceiveble } = apiCall.data;
    return { paymentDetails, sumCredit, sumDebit, netPayble, netReceiveble };
  } catch (error) {
    return { error };
  }
}
//PAYMENT----

//start----shipment-section
export const getShipmentDropdownList = async () => {
  try {
    const apiCall = await Axios.get("/v2/auth/shipdropdata");
    let { provider, status, company } = apiCall.data;
    return { provider, status, company };
  } catch (error) {
    return { error };
  }
};

export const GET_LOGS = async (order_number) => {
  try {
    const apiCall = await Axios.get(`/v4/post_shipment/getupdatelogs/${order_number}`);
    let { data } = apiCall.data;
    return { data };
  } catch (error) {
    return { error };
  }
};

export const updateShipmentDetail = async (FormData) => {
  try {
    const apiCall = await Axios.post("/v4/post_shipment/update_trakingdetails", FormData);
    let { status, message } = apiCall.data;
    return { status, message };
  } catch (error) {
    return { error };
  }
};

export const removeShipmentDetail = async (_id) => {
  try {
    const apiCall = await Axios.get(`/v4/post_shipment/remove_trakingdetails/${_id}`);
    console.log(apiCall)
    let { status, message } = apiCall.data;
    return { status, message };
  } catch (error) {
    return { error };
  }
};

export const getShipmentDetailsList = async (pagecount, searchbyname) => {
  try {
    const apiCall = await Axios.get("/v2/auth/trakingdetails", {
      params: { pagecount: pagecount, searchbyname: searchbyname },
    });
    let { status, trakingDetailsList, count } = apiCall.data;
    return { status, trakingDetailsList, count };
  } catch (error) {
    return { error };
  }
};

export const getShipmentDetailsForView = async (tracking_number) => {
  try {
    const apiCall = await Axios.get(`/v2/auth/trakingdetailsview/${tracking_number}`);
    let { status, trakingData } = apiCall.data;
    return { status, trakingData };
  } catch (error) {
    return { error };
  }
};

export const shipmentButtonFilter = async (ButtonData) => {
  try {
    const apiCall = await Axios.post(`/v2/auth/trakingdetailsearchbybutton`, ButtonData);
    console.log(apiCall)
    let { filteredData } = apiCall.data;
    return { filteredData };
  } catch (error) {
    return { error };
  }
}

export const shipmentCODButtonFilter = async (ButtonData) => {
  try {
    const apiCall = await Axios.post(`/v2/auth/trakingCODdetailsearchbybutton`, ButtonData);
    let { filteredData, merchantCount } = apiCall.data;
    return { filteredData, merchantCount };
  } catch (error) {
    return { error };
  }
}

export const shipmentCODButtonFilterV2 = async (ButtonData) => {
  try {
    const apiCall = await Axios.post(`/v2/auth/trakingCODV2detailsearchbybutton`, ButtonData);
    console.log(apiCall.data)
    let { filteredData, merchantCount } = apiCall.data;
    return { filteredData, merchantCount };
  } catch (error) {
    return { error };
  }
}

export const getShipmentDetailsListForExport = async () => {
  try {
    const apiCall = await Axios.get("/v2/auth/allexportslist");
    let { status, shipmenyDetails } = apiCall.data;
    return { status, shipmenyDetails };
  } catch (error) {
    return { error };
  }
};

export const shipmentCODButtonFilterExport = async (ButtonData) => {
  try {
    const apiCall = await Axios.post(`/v2/auth/shipmentbuttonsearch`, ButtonData);
    let { shipExportList } = apiCall.data;
    return { shipExportList };
  } catch (error) {
    return { error };
  }
}

export const shipmentCODReportsButtonFilterExport = async (ButtonData) => {
  try {
    const apiCall = await Axios.post(`/v2/auth/shipmentCODbuttonsearch`, ButtonData);
    let { shipmentExport } = apiCall.data;
    return { shipmentExport };
  } catch (error) {
    return { error };
  }
}

export const shipmentCODV2ReportsButtonFilterExport = async (ButtonData) => {
  try {
    const apiCall = await Axios.post(`/v2/auth/shipmentCODV2buttonsearch`, ButtonData);
    console.log("freshlyaddeed", apiCall)
    let { filteredData } = apiCall.data;
    return { filteredData };
  } catch (error) {
    return { error };
  }
}
//End----shipment-section

//Start----outstanding
export const getOutstandingDetailsList = async () => {
  try {
    const apiCall = await Axios.get("/v2/auth/getoutstandingreports")
    const { dataArr } = apiCall.data;
    return { dataArr };
  } catch (error) {
    return { error };
  }
};

export const getOutstandingDetailsListV2 = async () => {
  try {
    const apiCall = await Axios.get("/v2/auth/getoutstandingreportsv2");
    console.log(apiCall)
    const { customerArray } = apiCall.data;
    return { customerArray };
  } catch (error) {
    return { error };
  }
};

export const getOutstandingDetailsListNew = async (FormData) => { //change
  try {
    const apiCall = await Axios.post("/v2/auth/getoutstandingreportsnew", FormData);
    const { customerArray } = apiCall.data;
    return { customerArray };
  } catch (error) {
    return { error };
  }
};
//End----outstanding

//TRACKING----SECTION
export const trakin_details = async (tracking_number, provider) => {
  try {
    const res = await Axios.get("https://app.sky-sa.net/api/track-shipment", {
      params: { tracking_number: tracking_number, provider: provider },
    });
    const { statuses } = res.data.data;
    return { statuses };
  } catch (error) {
    return { error };
  }
};
//TRACKING----SECTION

export const dataCount = async () => {
  try {
    const apiCall = await Axios.get(`/v2/auth/datacount`);
    let { merchantCount, shipmentCount } = apiCall.data;
    return { merchantCount, shipmentCount };
  } catch (error) {
    return { error };
  }
}

export const accountDeactivation = async (_id) => {
  try {
    const apiCall = await Axios.get(`/v2/auth/customerdeactivation/${_id}`);
    let { status, message } = apiCall.data;
    return { status, message };
  } catch (error) {
    return { error };
  }
}

/*change status to deliver*/
export const AllUpdateStatus = async (FormData) => {
  try {
    const apiCall = await Axios.post(`/v4/post_shipment/statuschangeforall`, FormData);
    let { message } = apiCall.data
    return { message };
  } catch (error) {
    return { error };
  }
}

export const getDataForChange = async () => {
  try {
    const apiCall = await Axios.get(`/v4/post_shipment/getshipmentsforcrownjob`);
    let { trakingDetails } = apiCall.data;
    return { trakingDetails };
  } catch (error) {
    return { error };
  }
}

export const getSMSAshipments = async () => {
  try {
    const apiCall = await Axios.get(`/v4/post_shipment/getSMSAshipments`);
    let { trakingDetails } = apiCall.data;
    return { trakingDetails };
  } catch (error) {
    return { error };
  }
}

export const getARAMEXshipments = async () => {
  try {
    const apiCall = await Axios.get(`/v4/post_shipment/getARAMEXshipments`);
    let { trakingDetails } = apiCall.data;
    return { trakingDetails };
  } catch (error) {
    return { error };
  }
}

export const getWAYXPRESSshipments = async () => {
  try {
    const apiCall = await Axios.get(`/v4/post_shipment/getWAYXPRESSshipments`);
    let { trakingDetails } = apiCall.data;
    return { trakingDetails };
  } catch (error) {
    return { error };
  }
}


export const changeStatusApi = async (FormData) => {
  try {
    const apiCall = await Axios.post(`/v4/post_shipment/changestatusforcrownjob`, FormData);
    let { message } = apiCall.data
    return { message };
  } catch (error) {
    return { error };
  }
}

export const SMSAchangeStatusApi = async (FormData) => {
  try {
    const apiCall = await Axios.post(`/v4/post_shipment/changestatusforsmsacrownjob`, FormData);
    let { message } = apiCall.data
    return { message };
  } catch (error) {
    return { error };
  }
}

export const WAYPRESSchangeStatusApi = async (FormData) => {
  try {
    const apiCall = await Axios.post(`/v4/post_shipment/changestatusforwaypresscrownjob`, FormData);
    let { message } = apiCall.data
    return { message };
  } catch (error) {
    return { error };
  }
}

export const getAramaxDeliveredShipments = async () => {
  try {
    const apiCall = await Axios.get(`/v4/post_shipment/aramaxgetdeliveryshipmentsforreturn`);
    let { status, shipmentData } = apiCall.data
    return { status, shipmentData };
  } catch (error) {
    return { error };
  }
}

export const AramaxUpdateStatusToReturn = async (FormData) => {
  try {
    const apiCall = await Axios.post(`/v4/post_shipment/aramaxupdatedeliverystatustoreturned`, FormData);
    let { message, code } = apiCall.data
    return { message, code };
  } catch (error) {
    return { error };
  }
}
/*change status to deliver*/

/*sub-admin section*/
export const Register_Subuser = async (FormData) => {
  try {
    const apiCall = await Axios.post(`/v1/auth/register`, FormData);
    let { permissionData, message } = apiCall.data;
    return { permissionData, message };
  } catch (error) {
    return { error };
  }
}

export const getSubUserList = async () => {
  try {
    const apiCall = await Axios.get(`/v5/subadmin/getsubadmin`);
    let { subAdminList } = apiCall.data;
    return { subAdminList };
  } catch (error) {
    return { error };
  }
}

export const deleteSubUser = async (_id) => {
  try {
    const apiCall = await Axios.get(`/v5/subadmin/deletesubuser/${_id}`);
    let { message } = apiCall.data;
    return { message };
  } catch (error) {
    return { error };
  }
}

export const getSubUserDetails = async (_id) => {
  try {
    const apiCall = await Axios.get(`/v5/subadmin/getsubadmindetails/${_id}`);
    let { useData, accessData } = apiCall.data;
    return { useData, accessData };
  } catch (error) {
    return { error };
  }
}

export const editSubUserDetails = async (_id, FormData) => {
  try {
    const apiCall = await Axios.post(`/v5/subadmin/editsubadmindetails/${_id}`, FormData);
    let { message } = apiCall.data;
    return { message };
  } catch (error) {
    return { error };
  }
}

export const ActiveDeactiveSubUser = async (_id) => {
  try {
    const apiCall = await Axios.get(`/v5/subadmin/active_deactive/${_id}`);
    let { status, message } = apiCall.data;
    return { status, message };
  } catch (error) {
    return { error };
  }
}

export const getSearchSubUserData = async (search) => {
  try {
    const apiCall = await Axios.get("/v5/subadmin/getsubuserdatabysearch", {
      params: { search: search },
    });
    let { searchData } = apiCall.data;
    return { searchData };
  } catch (error) {
    return { error };
  }
}

export const editSubUserPermissions = async (FormData) => {
  try {
    const apiCall = await Axios.post(`/v5/subadmin/editpermissionforsubuser`, FormData);
    let { message } = apiCall.data
    return { message };
  } catch (error) {
    return { error };
  }
}
/*sub-admin section*/

/*count*/
export const shipmentButtonFilterCount = async (ButtonData) => {
  try {
    const apiCall = await Axios.post(`/v6/count/getButtonShipmentCount`, ButtonData);
    let { count } = apiCall.data;
    return { count };
  } catch (error) {
    return { error };
  }
}
/*count*/

/*sorting*/
export const customerShorting = async (ShortData) => {
  try {
    const res = await Axios.post(`/v2/auth/sortingdata`, ShortData);
    console.log(res.data);
    let { customerData } = res.data;
    return { customerData }
  } catch (error) {
    return { error }
  }
}


export const logOutApi = async () => {
  try {
    Cookie.remove("AAToken");
    Cookie.remove("_id");

    Cookie.remove("graph");
    Cookie.remove("order_list");
    Cookie.remove("register_list");

    Cookie.remove("codreports_viewlist");
    Cookie.remove("codreports_exportfile");
    Cookie.remove("codreports_track");

    Cookie.remove("customers_viewlist");
    Cookie.remove("customers_exportfile");
    Cookie.remove("add");
    Cookie.remove("edit");
    Cookie.remove("active");
    Cookie.remove("payment");
    Cookie.remove("statement");

    Cookie.remove("shipments_viewlist");
    Cookie.remove("shipments_exportfile");
    Cookie.remove("shipments_track");

    Cookie.remove("outstanding_viewlist");
    Cookie.remove("outstanding_exportfile");
    Cookie.remove("opayment");
    Cookie.remove("ostatement");

    Cookie.remove("manage_profile");
    Cookie.remove("change_password");

    return { status: 200 };
  } catch (err) {
    return { err };
  }
};


export const getDataForGraphM = async (_id) => {
  try {
    const apiCall = await Axios.get(`/v3/merchant/get15dayshipmentsrecords/${_id}`);
    let { graph, creditAmount, debitAmount } = apiCall.data;
    return { graph, creditAmount, debitAmount }
  } catch (err) {
    return { err };
  }
}

