const Mongoose = require("mongoose")
const { DB_URL } = require("../config")

exports.dbConnect = () => {
  return Mongoose.connect(DB_URL, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
    useCreateIndex: true,
  });
};
