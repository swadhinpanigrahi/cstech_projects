import React, { useState, useEffect } from "react";
import logo from "../../Images/final_logon.png";
import Cookie from "js-cookie";
import { Link, useHistory } from "react-router-dom";
import user from "../../Images/user.png";
import { logOutApi, verifyProfile } from "../../Utils/api";
import { useAuth } from "../../Utils/auth";
import $ from "jquery";

const Profilebar = () => {
  const history = useHistory();
  const auth = useAuth();

  const [AuthName, setAuthName] = useState("");
  const [BarAuth, setBarAuth] = useState({
    manage_profile: "",
    change_password: ""
  });

  let { manage_profile, change_password } = BarAuth

  const logOut = async () => {
    await logOutApi();
    history.push("/logout");
    setTimeout(() => {
      auth.signout(() => history.push("/"));
    }, 3000);
  };

  const toggledrop = () => {
    if ($("#drop_menut").css("display") === "none") {
      $("#drop_menut").css("display", "block");
    } else {
      $("#drop_menut").css("display", "none");
    }
  };

  useEffect(() => {
    const verify = async () => {
      const res = await verifyProfile();
      let { error, name } = res;
      if (!error) {
        setAuthName(name);
      } else {
        await logOut();
      }
    };
    verify();
    const fun = async () => {
      const manage_profile = await Cookie.get("manage_profile");
      const change_password = await Cookie.get("change_password");

      const updatedState = { ...BarAuth }
      updatedState.manage_profile = manage_profile
      updatedState.change_password = change_password;
      setBarAuth({ ...updatedState })
      console.log("coming from bar", manage_profile, change_password)
    }
    fun()
  }, []);

  return (
    <div>
      <div className="container-flud headtop" style={{}}>
        <div className="row" style={{ margin: "0px" }}>
          <div className="col-lg-5 col-md-12 col-12 logom_headp">
            <div className="row">
              <div id="logo1" className="col-lg-4 col-md-3 col-12">
                <Link to="/dashboard/analytical">
                  <img
                    src={logo}
                    alt="Storage Station"
                    className="logo_sticky new_logod"
                  />
                </Link>
              </div>
              <div className="texth col-lg-7 col-md-7 col-12">
                <h6 className="after_loginhead">Shipment Tracking System</h6>
              </div>
            </div>
          </div>

          <div className="col-lg-7 col-md-12 col-12 righttop">
            <ul className="topul after_loginhead">
              <li>
                <span className="welth">
                  Welcome <Link to="#">Storage Station</Link>
                </span>
              </li>
              <li className="nav-item dropdown" onClick={toggledrop}>
                <Link className="nav-link dropdown-toggle text-nowrap d-flex align-items-center justify-content-center">
                  <span>
                    <img src={user} className="iconl" alt="profilebar_img" />
                    {/* {`${fstName} ${lastName}`} */}
                    {AuthName}
                  </span>
                </Link>
                <div
                  id="drop_menut"
                  className="dropdown-menu dropdown-menu-small"
                  style={{ zIndex: "999999999" }}
                >
                  <div>
                    <Link
                      className="dropdown-item"
                      id="logout"
                    // href="logout.aspx"
                    >

                      <i className="material-icons" style={{ color: "#000" }}>
                        person
                      </i>
                      <span
                        className="manage_toggle"
                        style={{
                          color: "#727b82",
                          position: "relative",
                          top: "-5px",
                        }}
                      >
                        <Link
                          to="/dashboard/editprofile"
                          style={{
                            color: "#000",
                            fontSize: "16px",
                            fontWeight: "600",
                            letterSpacing: ".5px",
                          }}
                        >
                          Manage Profile
                        </Link>
                      </span>
                    </Link>
                  </div>

                  {change_password === "true" ?
                    <div>
                      <div className="dropdown-divider"></div>
                      <a
                        className="dropdown-item employee nav-active"
                        href="change-password.html"
                      >
                        <i className="material-icons" style={{ color: "#000" }}>
                          vpn_key
                        </i>
                        <span
                          className="manage_toggle"
                          style={{
                            color: "#727b82",
                            position: "relative",
                            top: "-5px",
                          }}
                        >
                          <Link
                            to="/dashboard/changepassword"
                            style={{
                              color: "#000",
                              fontSize: "16px",
                              fontWeight: "600",
                              letterSpacing: ".5px",
                            }}
                          >
                            Change Password
                          </Link>
                        </span>
                      </a>
                    </div> : null}

                  {
                    manage_profile === "true" ?
                      <div>
                        <div className="dropdown-divider"></div>
                        <div>
                          <Link
                            className="dropdown-item text-danger"
                            id="logout"
                            to="/dashboard/subuser/get"
                          // href="logout.aspx"
                          >
                            <i className="material-icons">&#xE879;</i>
                            <span
                              className="manage_toggle"
                              style={{
                                color: "#000",
                                position: "relative",
                                top: "-5px",
                              }}
                            >
                              User list
                            </span>
                          </Link>
                        </div>
                      </div>
                      :
                      null
                  }


                  <div className="dropdown-divider"></div>
                  <Link
                    className="dropdown-item text-danger"
                    id="logout"
                  // href="logout.aspx"
                  >
                    <i className="material-icons text-danger">&#xE879;</i>
                    <span
                      className="manage_toggle"
                      style={{
                        color: "#dc3545",
                        position: "relative",
                        top: "-5px",
                      }}
                      onClick={logOut}
                    >
                      Logout
                    </span>
                  </Link>
                  <div className="dropdown-divider"></div>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profilebar;
