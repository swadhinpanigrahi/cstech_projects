var express = require('express');
var router = express.Router();

var { updateUserInfo, RemoveOrderMongoToSql, RejectOrderMongoToSql, confirmOrderMongoToSql, updateCustomerShortAndGroupNameMongoToSql, createNewOrderMongoToSql, FinalizeProposalMongoToSql, DeleteProposalMongoToSql,insertDataIntoCart,createNewFollowUpMongoToSql } = require('../controllers/apiforsql.controller')
router.post('/updateUserInfo', updateUserInfo)
router.post('/RemoveOrderMongoToSql', RemoveOrderMongoToSql)
router.post('/RejectOrderMongoToSql', RejectOrderMongoToSql)
router.post('/confirmOrderMongoToSql', confirmOrderMongoToSql)
router.post('/updateCustomerShortAndGroupNameMongoToSql', updateCustomerShortAndGroupNameMongoToSql)
router.post('/createNewOrderMongoToSql', createNewOrderMongoToSql)
router.post('/FinalizeProposalMongoToSql', FinalizeProposalMongoToSql)
router.post('/DeleteProposalMongoToSql', DeleteProposalMongoToSql)
router.post('/insertDataIntoCart',insertDataIntoCart)
router.post('/createNewFollowUpMongoToSql',createNewFollowUpMongoToSql)
module.exports = router;