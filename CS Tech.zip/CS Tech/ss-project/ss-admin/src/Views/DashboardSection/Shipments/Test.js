import React from 'react';
import { Modal, Button, Row, Col } from "react-bootstrap";
import ViewHelper from './Helpers/ViewHelper';
import FormAddress from "./Helpers/FormAddress";
import ToAddress from "./Helpers/ToAddress"

const Test = ({ show, handleClose, TrakingData }) => {
    console.log(TrakingData)
    return (
        <>
            <Modal show={show} onHide={handleClose} className="main_reportmodal">
                <Col md={12} className="modal_reports">
                    <div
                        className="box_detail mb-0 addc-detailh report_modaltest"
                        style={{ paddingTop: "15px" }}
                    >
                        <Col style={{ padding: "0px" }}>
                            <div className="page-header row no-gutters">
                                <Col md={6} xs={9}>
                                    <h3 className="page-title subtitile" style={{ paddingLeft: "20px", paddingRight: "20px" }}>SHIPMENT DETAILS</h3>
                                </Col>
                                <Col md={6} xs={3} className="text-right">
                                    <i variant="secondary" onClick={handleClose} className="fa fa-times close_modalreport"></i>
                                </Col>
                                <hr style={{ marginBottom: "30px" }} />
                            </div>
                        </Col>
                        <Row>
                            <ViewHelper info={TrakingData.totalData} />
                        </Row>
                    </div>
                </Col>

                <Row style={{ margin: "20px 0px 0px 0px" }}>
                    <Col lg={6} md={12} className="left_reportmodal">
                        <div
                            className="box_detail mb-0 addc-detailh min_hgtd report_modaltest"
                            style={{ paddingTop: "15px" }}
                        >
                            <div className="col-12" style={{ padding: "0px" }}>
                                <div className="page-header row no-gutters">
                                    <div className="col-md-6">
                                        <h3 className="page-title subtitile" style={{ paddingLeft: "20px", paddingRight: "20px" }}>FROM ADDRESS</h3>
                                    </div>
                                    <hr style={{ marginBottom: "30px" }} />
                                    <Col md={12}>
                                        <FormAddress info={TrakingData.from_data} />
                                    </Col>
                                </div>
                            </div>
                        </div>
                    </Col>
                    <Col lg={6} md={12} className="right_reportmodal">
                        <div
                            className="box_detail mb-0 addc-detailh min_hgtd to_add report_modaltest"
                            style={{ paddingTop: "15px" }}
                        >
                            <div className="col-12" style={{ padding: "0px" }}>
                                <div className="page-header row no-gutters">
                                    <div className="col-md-6">
                                        <h3 className="page-title subtitile" style={{ paddingLeft: "20px", paddingRight: "20px" }}>TO ADDRESS</h3>
                                    </div>
                                    <hr style={{ marginBottom: "30px" }} />
                                    <Col md={12}>
                                        <ToAddress info={TrakingData.to_data} />
                                    </Col>
                                </div>
                            </div>
                        </div>
                    </Col>
                </Row>
                {/* <Modal.Footer>
                    <Button variant="secondary" onClick={handleClose}>
                        Close
                    </Button>
                    <Button variant="primary" onClick={handleClose}>
                        Save Changes
                    </Button>
                </Modal.Footer> */}
            </Modal>
        </>
    )
}

export default Test
