import React from 'react';
import * as RB from "react-bootstrap";
import { Row } from "react-bootstrap";
import { RiDeleteBin6Line } from "react-icons/ri";
import { BiCommentEdit } from "react-icons/bi";
// import ReactQuill from 'react-quill'; // ES6

// import 'react-quill/dist/quill.snow.css'; // ES6

const DropArrayE = [
    {name: "1 Day"},
    {name: "5 Days"},
    {name: "7 Days"},
    {name: "15 Days"},
    {name: "30 Days"},
];

const ExpiryEmailModal = (
    { show_subscriptionedit, subscriptioeditClose }
) => {
    return (
        <div>
            <RB.Modal show={show_subscriptionedit} onHide={subscriptioeditClose} className="ordermanage_modal">
            <RB.Modal.Header closeButton>
                <RB.Modal.Title>Add Subscription Plan</RB.Modal.Title>
            </RB.Modal.Header>
            <RB.Modal.Body>
                <RB.Row>
                    <RB.Col lg={12} md={12}>
                        <RB.Row>
                            <RB.Col lg={12} md={12}>
                                <RB.Form>
                                <RB.Form.Group as={Row}>
                                            <RB.Col lg={3} md={3}>
                                                <RB.Form.Label>Expiry Days :</RB.Form.Label>
                                            </RB.Col>
                                            <RB.Col lg={6} md={6}>
                                                <RB.Form.Control  as="select">
                                                   <option>Select</option>
                                                   {DropArrayE.map((data, inx) => {
                                                       let {name} = data;
                                                       return (
                                                           <option value={name}>{name}</option>
                                                       )
                                                   })}
                                                </RB.Form.Control>
                                            </RB.Col>
                                        </RB.Form.Group>
                                        <RB.Form.Group as={Row}>
                                            <RB.Col lg={3} md={3}>
                                                <RB.Form.Label>Mail Subject :</RB.Form.Label>
                                            </RB.Col>
                                            <RB.Col lg={6} md={6}>
                                                <RB.Form.Control  type="text" />
                                            </RB.Col>
                                        </RB.Form.Group>
                                        <RB.Form.Group as={Row}>
                                            {/* <RB.Col lg={3} md={3}>
                                                <RB.Form.Label>Mail Subject :</RB.Form.Label>
                                            </RB.Col>
                                            <RB.Col lg={9} md={9}>
                                            <ReactQuill name="f_body" id="f_body" />
                                            </RB.Col> */}
                                        </RB.Form.Group>
                                    <RB.Row>
                                        <RB.Col lg={3} md={3}></RB.Col>
                                        <RB.Col lg={6} md={6}>
                                            <RB.Button
                                                size="sm" variant="primary"
                                            >
                                                ADD
                                            </RB.Button>
                                        </RB.Col>
                                    </RB.Row>
                                </RB.Form>
                            </RB.Col>
                        </RB.Row>
                        
                    </RB.Col>
                    <RB.Row className="" style={{margin: "15px 0px 0px 0px"}}>
              <RB.Col lg={12} className="pd_0 order_modal_table">
                <RB.Table responsive className="expirymail_main">
                  <thead className="thead-dark">
                    <tr>
                      <th className="td_first">ID</th>
                      <th className="td_first">Subject</th>
                      <th className="td_firs">Days</th>
                      <th className="td_first expiry_action">Plan Id</th>
                      <th className="text-cenrter expiry_action">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="expiry_mailm">
                        <td>127</td>
                        <td>Reminder for Subscription Package Expiring on Imagesbazaar</td>
                        <td>1</td>
                        <td>33</td>
                        <td className="td_comments text-center">
                          <BiCommentEdit title="Edit Plan" />
                          <RiDeleteBin6Line title="Delete Plan" className="text-danger1" />
                      </td>
                    </tr>
                    <tr className="expiry_mailm">
                        <td>127</td>
                        <td>Reminder for Subscription Package Expiring on Imagesbazaar</td>
                        <td>1</td>
                        <td>33</td>
                        <td className="td_comments text-center">
                          <BiCommentEdit title="Edit Plan" />
                          <RiDeleteBin6Line title="Delete Plan" className="text-danger1" />
                      </td>
                    </tr>
                  </tbody>
                </RB.Table>
              </RB.Col>
            </RB.Row>
                </RB.Row>
            </RB.Modal.Body>
        </RB.Modal>
        </div>
    )
}

export default ExpiryEmailModal