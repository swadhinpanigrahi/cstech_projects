import React, { useState, useEffect } from 'react';
import * as RB from "react-bootstrap";
import Moment from "moment";
import { useParams } from 'react-router-dom';
import { getOrderDeatils } from "../Utils/api"

const UtilComponent = () => {
    const { orderid } = useParams();
    const [OrderDataObj, setOrderDataObj] = useState({});
    const [OrderDataList, setOrderDataList] = useState([]);
    const [OrderUser, setOrderUser] = useState({});

    let [TotalAmount, setTotalAmount] = useState("");
    let [DiscountAmount, setDiscountAmount] = useState("");

    const OrderDetailsClick = async (orderId) => {
        const res = await getOrderDeatils(orderId);
        let { OrderDetail, OrderDetailsList, userDetails } = res;
        console.log(res)
        setOrderDataObj(OrderDetail);
        setOrderDataList(OrderDetailsList);
        setOrderUser(userDetails)
    };

    useEffect(() => {
        let Amount = 0;
        let Discount = 0;
        OrderDataList.forEach(element => {
            Amount += element.t_price
            Discount += element.t_disc_price
        });
        setTotalAmount(Amount);
        setDiscountAmount(Discount)
    }, [OrderDataList]);

    useEffect(() => {
        OrderDetailsClick(orderid)
    }, []);

    const Tax = (TotalAmount * 18) / 100;
    const PaybleAmount = TotalAmount - DiscountAmount
    return (
        <>
        <table border="0" width="900" align="center" cellspacing="0" style={{width: "900px"}}>
            <tbody>
                <tr>
                    <td align="right">
                        <table width="100%" cellspacing="0" border="0">
                            <tbody>
                                <tr>
                                    <td width="192" height="55" align="left" valign="top">
                                        <img className="logoinv_img"
                                         src="http://ibcdn.imagesbazaar.com/Html2015/images/logo_imagesBazaar.png"
                                          alt="img_img1" width="175" height="55" border="0" />
                                    </td>
                                    <td width="321" style={{height: "14px", fontSize: "22px"}} align="center" valign="bottom">
                                        <strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;TAX INVOICE &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;&nbsp;</strong>
  					                </td>
                                    <td width="150" align="center" style={{height: "55px", width: "220px"}}>
                                        <RB.Form id="checkforminvoive" className="float-right">
                                            <RB.Form.Group controlId="formBasicCheckbox">
                                                <RB.Form.Check type="checkbox" label="ORIGINAL FOR RECIPIENT" checked />
                                            </RB.Form.Group>
                                            <RB.Form.Group controlId="formBasicCheckbox2">
                                                <RB.Form.Check type="checkbox" label="DUPLICATE FOR SUPPLIER" />
                                            </RB.Form.Group>
                                        </RB.Form>
                                        <a href="javascript:print()" className="print_invoice">
                                            <i className="fa fa-print"></i>
                                        </a>
                                    </td>
                                </tr>
  				            </tbody>
  			            </table>
  		            </td>
  	            </tr>

                <tr>
                    <td align="center" width="100%">
                        <table width="900" style={{width: "900px", wordBreak: "break-word"}} border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#999999" style={{fontFamily: "Montserrat !important", fontSize: "9px" , fontWeight: "bold"}}>
                            <tbody>
                                <tr bgcolor="#ffffff" width="900" style={{width: "900px"}}>
                                    <td align="left" width="450" style={{width: "450px"}}>
                                        <table border="1" cellpadding="6" valign="top" height="265" width="450" style={{width: "450px", wordBreak: "break-word"}}>
                                            <tr>
                                                <td  valign="top">
                                                    <p><strong>Mash Audio Visuals Private Limited</strong></p>
                                                    <p>505, Aggarwal Prestige Mall, Plot No. 2,</p>
                                                    <p>Road No. 44, Pitam Pura, New Delhi - 110034</p>
                                                    <p>Phone: (+91) 11 66545466 | (+91) 11 66545465</p>
                                                    <p class="p_txt">
                                                        <strong>CIN: </strong> U92111DL2003PTC122096
                                                    </p>
                                                    <p class="p_txt">
                                                        <strong>GSTIN:</strong> 07AADCM6333L1ZA
                                                    </p>
                                                    <p class="p_txt">
                                                        <strong>PAN: </strong>AADCM6333L
                                                    </p>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                    <td align="left" width="450" style={{width: "450px"}}>
                                        <table border="1" cellpadding="6" valign="top" height="265" width="450" style={{width: "450px"}}>
                                            <tr>
                                                <td width="50%">
                                                    <p class="mg-b-0">
                                                        <strong>Date:</strong>{Moment(OrderDataObj.T_orderdate).format("DD-MM-YYYY")}
                                                    </p>
                                                    </td>
                                                    <td width="50%"></td>
                                            </tr>
                                            <tr>
                                                <td width="50%">
                                                    <p class="mg-b-0">
                                                        <strong>Order Confirmation No.:</strong> {OrderDataObj.T_orderid}
                                                    </p>
                                                </td>
                                                <td width="50%">
                                                    <p class="mg-b-0">
                                                        <strong>HSN/SAC:</strong> 998439
                                                    </p>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td width="50%">
                                                    <p class="mg-b-0">
                                                        <strong>Mode of Payment:</strong> {OrderDataObj.T_paymode}
                                                    </p>
                                                </td>
                                                <td width="50%">
                                                    <p class="mg-b-0">
                                                        <strong>State Code:</strong> {OrderUser.f_pin}
                                                    </p>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td width="50%">
                                                    <p class="mg-b-0">
                                                        <strong>Payment Status:</strong> {OrderDataObj.t_paymentstatus}
                                                    </p>
                                                </td>
                                                <td width="50%">
                                                    <p class="mg-b-0">
                                                        <strong>State:</strong> {OrderUser.f_state}
                                                    </p>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td width="50%">
                                                    <p class="mg-b-0">
                                                        <strong>Reverse Charges Applicability:</strong> Not Applicable
                                                    </p>
                                                </td>
                                                <td width="50%">
                                                    <p class="mg-b-0">
                                                        <strong>Place of Supply:</strong> {OrderDataObj.f_state}
                                                    </p>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>

                                <tr bgcolor="#ffffff" width="900" style={{width: "900px"}}>
                                    <td align="left" width="450" style={{width: "450px"}}>
                                        <table border="1" cellpadding="6" valign="top" height="200" width="450" style={{width: "450px", wordBreak: "break-word"}}>
                                            <tr>
                                                <td  valign="top">
                                                <p>
                                                        <strong>Party’s Name:</strong>
                                                    </p>
                                                    <p>{OrderUser.f_companyname}</p>
                                                    <p>{OrderUser.f_address}</p>
                                                    <p>{`${OrderUser.f_state} - ${OrderUser.f_pin}, ${OrderUser.f_country}`}</p>
                                                    <p>
                                                        <strong>State:</strong> {OrderUser.f_state}{" "}
                                                        <span style={{ paddingLeft: "10px" }}>
                                                          <strong>State Code:</strong> {OrderUser.f_pin}
                                                        </span>
                                                    </p>
                                                    <p>
                                                        <strong>GSTIN:</strong> {OrderDataObj.f_clientGSTIN_no}
                                                    </p>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                    <td align="left" width="450" style={{width: "450px"}}>
                                        <table border="1" cellpadding="6" valign="top" height="200" width="450" style={{width: "450px", wordBreak: "break-word"}}>
                                            <tr>
                                                <td width="50%" valign="top">
                                                    <p>
                                                        <strong>Client Name:</strong> {OrderDataObj.t_client}
                                                    </p>
                                                    <p>
                                                        <strong>Order By:</strong> {OrderDataObj.t_orderedby}
                                                    </p>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>

                                <tr>
                                    <td align="center" width="100%" colSpan="2">
                                        <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0" bordercolor="#999999" style={{fontFamily: "Montserrat !important", fontSize: "9px" , fontWeight: "bold"}}>
                                            <tbody>
                                                <tr>
                                                    <td align="center" colspan="4">
                                                        <table cellspacing="0" cellpadding="6" rules="all" border="1" id="GridView1" style={{fontWeight: "bold", fontFamily: "Montserrat", fontSize: "9px", width: "100%", borderCollapse: "collapse"}}>
                                                            <tbody>
                                                                <tr bgcolor="#333" style={{color: "#fff", backgroundColor: "#333", fontFamily: "Montserrat", fontSize: "12px", fontWeight: "bold"}}>
                                                                    <td align="center" style={{color: "#fff"}}>Image</td>
                					                                <td align="center" style={{color: "#fff"}}>Item ID</td>
                					                                <td align="center" style={{color: "#fff"}}>Type</td>
                					                                <td align="center" style={{color: "#fff"}}>Dimension (Px)</td>
                					                                <td align="right" style={{color: "#fff"}}>Value</td>
                				                                </tr>
                                                                {OrderDataList.map((data, inx) => (
                                                                    <tr key={"orderInvoice" + inx}>
                                                                        <td align="center">
                                                                            <img id="Img1" border="0" src={`https://ibcdn.imagesbazaar.com/img170/${data.f_rank}-${data.t_imageid}.jpg`} alt="invoiceimg" width="100px" height="100px" />
                					                                    </td>
                					                                    <td align="center"><p>{data.t_imageid}</p></td>
                                                                        <td align="center">
                                                                            <p>{data.t_quality}</p>
                                                                        </td>
                                                                        <td align="center"><p>{data.f_mydimension}</p></td>
                                                                        <td align="right"><p>{data.t_price}</p></td>
                				                                    </tr>
                                                                ))}
                                                            </tbody>
                		                                </table>
                	                                </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>

                                <tr>
                                    <td width="100%" colSpan="2">
                                        <table width="100%" border="1" align="center" cellpadding="4" cellspacing="0" bordercolor="#999999" style={{fontFamily: "Montserrat", fontSize: "9px"}}>
                                            <tbody>
                                                <tr style={{fontWeight: "bold"}}>
                                                    <td width="75%" align="right">
                                                        <p>
                                                            <strong>Total Value (INR)</strong>
                                                        </p>
                                                    </td>
                                                    <td align="right"><p>{TotalAmount}</p></td>
                                                </tr>
                                                <tr style={{fontWeight: "normal"}}>
                                                    <td align="right" width="81%">
                                                        <p>
                                                            <strong>GST Value @18% (INR)</strong>
                                                        </p>
                                                    </td>
                                                    <td align="right"><p>{Tax}</p></td>
                                                </tr>
                                                <tr style={{fontWeight: "normal"}}>
                                                    <td align="right" width="81%">
                                                        <p className="">
                                                            <strong>Discount</strong>
                                                        </p>
                                                    </td>
                                                    <td align="right"><p>{DiscountAmount}</p></td>
                                                </tr>
                                                <tr style={{fontWeight: "normal"}}>
                                                    <td align="right" width="81%">
                                                        <p className="">
                                                            <strong>Total Amount Before GST (SGST / UGST / CGST / IGST)</strong>
                                                        </p>
                                                    </td>
                                                    <td align="right"><p>{PaybleAmount}</p></td>
                                                </tr>
                                                <tr style={{fontWeight: "normal"}}>
                                                    <td align="right" width="81%">
                                                        <p className="">
                                                            <strong>Total Amount Payable Inclusive of GST (SGST / UGST / CGST / IGST)</strong>
                                                        </p>
                                                    </td>
                                                    <td align="right"><p>{PaybleAmount + Tax}</p></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>

                                <tr bgcolor="#ffffff" width="100%" style={{width: "900px"}}>
                                    <td colspan="2" align="left" width="100%" style={{width: "900px"}}>
                                        <table border="1" cellpadding="6" cellspacing="0">
                                            <tbody>
                                                <tr>
                                                    <td>
                                                        <p className="mg-b-0">
                                                        ImagesBazaar is a unit of Mash Audio Visuals Pvt. Ltd.
                                                        Usage of content subject to Mash Rights Agreement
                                                         mentioned on{" "}
                                                         <a href="#0">www.Imagesbazaar.com/licensing.aspx</a>
                                                         </p>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>

                                <tr bgcolor="#ffffff" width="100%" style={{width: "900px"}}>
                                    <td align="left" width="65%" style={{width: "585px"}}>
                                        <table border="1" cellpadding="6" valign="top" height="200" width="450" style={{width: "450px", wordBreak: "break-word"}}>
                                            <tr>
                                                <td  valign="top">
                                                  <p>
                                                    If you have any problem with your order, please call us at <a href="#0">+91-9911366666</a> or{" "}
                                                    <a href="#0">+91-1166545466</a> or send us a message at{" "}
                                                    <a href="mailto:orders@imagesbazaar.com">orders@imagesbazaar.com</a>
                                                  </p>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                    <td align="left" width="35%" style={{width: "315px"}}>
                                        <table border="1" cellpadding="6" valign="top" height="200" width="450" style={{width: "450px", wordBreak: "break-word"}}>
                                            <tr>
                                                <td width="50%" valign="top" align="center">
                                                    <p style={{minHeight: "160px"}}>For Mesh Audio Visuals Pvt. Ltd.</p>
                                                    <p>
                                                        Authorised Signatory
                                                    </p>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>

                            </tbody>
                        </table>
                    </td>
                </tr>

                <tr>
                    <td align="right">
                        <table width="100%" cellspacing="0" cellPadding="6" border="0">
                            <tbody>
                                <tr>
                                    <td valign="top" align="center">
                                        <h6 style={{ fontWeight: "bold", color: "#000"}}>
                                            WE THINK YOU FOR YOUR BUSINESS. WE VALUE YOUR PATRONAGE
                                        </h6>
                                    </td>
                                </tr>
  				            </tbody>
  			            </table>
  		            </td>
  	            </tr>

	        </tbody>
        </table>        
        </>
    )
}

export default UtilComponent
