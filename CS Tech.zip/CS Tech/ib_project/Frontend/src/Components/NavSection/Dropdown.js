import React, { useState } from "react";
import { Link } from "react-router-dom";
import "./Dropdown.css";

const MenuItems = [
  {
    nto: "/dashboard/master/get",
    title: "Video Model",
    cName: "dropdown-link"
  },
  {
    nto: "/dashboard/master/agencie",
    title: "TOP Agencies",
    cName: "dropdown-link"
  },
  {
    nto: "/dashboard/master/subscription",
    title: "Subscription Plan",
    cName: "dropdown-link"
  },
  {
    nto: "/dashboard/master/imagevediosubscriptionplan",
    title: "Image & Video Subscription plan",
    cName: "dropdown-link"
  },
  {
    nto: "/dashboard/master/imagetype",
    title: "Image Price Type",
    cName: "dropdown-link"
  },
  {
    nto: "/dashboard/master/imagesize",
    title: "Image Size",
    cName: "dropdown-link"
  },
  {
    nto: "/dashboard/master/imagedetails",
    title: "Image Price Details",
    cName: "dropdown-link"
  },
  {
    nto: "/dashboard/master/taxupdate",
    title: "Tax",
    cName: "dropdown-link"
  },
  {
    nto: "/dashboard/master/paymentrights",
    title: "Payments Getway Right",
    cName: "dropdown-link"
  },
  {
    nto: "/dashboard/master/changepricemodel",
    title: "Change Price Mode",
    cName: "dropdown-link"
  },
  {
    nto: "/dashboard/master/similargroup",
    title: "Similar Group",
    cName: "dropdown-link"
  },
  {
    nto: "/dashboard/master/suspendimages",
    title: "Suspend Images",
    cName: "dropdown-link"
  },
  {
    nto: "/dashboard/master/adminlist",
    title: "Admin User",
    cName: "dropdown-link"
  },
  {
    nto: "/dashboard/master/country",
    title: "Country",
    cName: "dropdown-link"
  },
  {
    nto: "/dashboard/master/state",
    title: "State",
    cName: "dropdown-link"
  },
  {
    nto: "/dashboard/master/city",
    title: "City",
    cName: "dropdown-link"
  },
  {
    nto: "/dashboard/master/company",
    title: "Company Master",
    cName: "dropdown-link"
  },
  {
    nto: "/dashboard/master/industry",
    title: "Industry",
    cName: "dropdown-link"
  },
  {
    nto: "/dashboard/master/starsize",
    title: "Star Size",
    cName: "dropdown-link"
  },
  {
    nto: "/dashboard/master/starperiod",
    title: "Star Period",
    cName: "dropdown-link"
  },
  {
    nto: "/dashboard/master/discountterm",
    title: "Discount Team",
    cName: "dropdown-link"
  },
  {
    nto: "/dashboard/master/creditperiod",
    title: "Credit Period",
    cName: "dropdown-link"
  }
]


const Dropdown = () => {

  const [click, setClick] = useState(false);

  const handleClick = () => setClick(!click)

  return (
    <>
      <ul onClick={handleClick} className={click ? "dropdown-menu clicked" : "dropdown-menu"}>
        {MenuItems.map((item, index) => {
          return (
            <li key={`MASTER_LIST_${index}`}>
              <Link className={item.cName} to={item.nto} onClick={() => setClick(false)}>
                {item.title}
              </Link>
            </li>
          )
        })}
      </ul>
    </>
  )
}

export default Dropdown