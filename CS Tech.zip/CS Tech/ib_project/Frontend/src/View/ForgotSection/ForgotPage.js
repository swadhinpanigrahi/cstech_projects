import React, { useState } from "react";
import TopBar from "../../Components/NavSection/TopBar";
import { Link } from "react-router-dom";
import { Form, Button } from "react-bootstrap";
import { forgetEmailSendApi } from "../../Utils/api";
import Footer from "../../Components/NavSection/Footer"

const ForgotPage = () => {
  const [email, setEmail] = useState("");
  const [Loading, setLoading] = useState("SUBMIT");
  const [Error, setError] = useState({
    errMsg: "",
    errClr: "",
  });
  const [errors, setErrors] = useState("");

  const changeLoading = () => {
    setLoading("Loading...");
    setTimeout(() => {
      setLoading("SUBMIT");
    }, 1000);
  };

  const onSubmit = async (e) => {
    e.preventDefault();
    if (email !== "") {
      const res = await forgetEmailSendApi({ email });
      let { status, error, message } = res;
      console.log(status);
      if (!error) {
        if (status === 200) {
          changeLoading();
          const updateError = { ...Error };
          updateError.errMsg = "Email Sent Successfully!!";
          updateError.errClr = "";
          setError({ ...updateError });
        } else {
          changeLoading();
          const updateError = { ...Error };
          updateError.errMsg = message;
          setError({ ...updateError });
        }
      } else {
        changeLoading();
        const updateError = { ...Error };
        updateError.errMsg = "Network Error";
        setError({ ...updateError });
      }
    } else {
      const updateError = { ...Error };
      updateError.errCls = "border-danger";
      setError({ ...updateError });
      setErrors("Email Id is Reqired! ");
    }
  };

  let { errMsg, errCls } = Error;

  return (
    <div>
      <TopBar />
      <main>
        <div id="forget">
          <div className="forgetdetails">
            <h4 className="forgetHeader">Forgot Password</h4>
            <Form.Text className="text-danger error_text">
                {Loading === "Loading..." ? "" : errMsg ? errMsg : ""}
              </Form.Text>
            <Form onSubmit={onSubmit}>
              <Form.Group controlId="FormControlIdEmail">
                <Form.Control
                  type="email"
                  name="email"
                  placeholder="Enter Your Email"
                  className={
                    Loading === "Loading..." ? "" : errCls ? errCls : ""
                  }
                  onChange={(e) => {
                    e.target.name = setEmail(e.target.value);
                    setErrors("");
                    const updateError = { ...Error };
                    updateError.errCls = "";
                    updateError.errMsg = "";
                    setError({ ...updateError });
                  }}
                />
                <p className="text-danger">
                  {Loading === "Loading..." ? "" : errors ? errors : ""}
                </p>
              </Form.Group>
              <Button variant="primary" className="subBtn" block type="submit">
                {Loading}
              </Button>
            </Form>
            <p className="loginBack">
              <Link to="/">Back To Login</Link>
            </p>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default ForgotPage;
