const mongoose = require("mongoose");

const t_invoice_IB_MongoDBShema = mongoose.Schema(
  {
    invoice_id: { type: String },
    orderid: { type: String },
    invoice_date: { type: Date },
    total_amt: { type: Number },
    discount: { type: Number },
    tax_amt: { type: Number },
    final_amt: { type: Number },
    f_username: { type: String },
    f_paymode: { type: String },
    f_client: { type: String },
    f_purchaseorderno: { type: String },
    t_paymentstatus: { type: String },
    f_orderdate: { type: Date },
    f_paymentdate: { type: Date },
    Name: { type: String },
    Companyname: { type: String },
    address:{ type: String },
    invoicereject: { type: Boolean },
    orderby: { type: String },
    t_followup_status: { type: Number },
    T_status: { type: String },
    f_county: { type: String },
    f_statecrm: { type: String },
    f_companyCrm: { type: String },
    t_commissionamount: { type: Number },
    t_commdiscount: { type: String },
    t_commShow: { type: String },
    f_comm_status: { type: String },
    f_comm_detail: { type: String },
    f_discountOnInvoice: { type: Number },
    f_clientGSTIN_no: { type: String },
    t_invoiceText: { type: String },
  },
  { collection: "t_invoice_IB_MongoDB" }
);

module.exports = t_invoice_IB_MongoDB = mongoose.model(
  "t_invoice_IB_MongoDB",
  t_invoice_IB_MongoDBShema
);
