import React from "react";
import { Navbar, Container } from "react-bootstrap";
import { Link } from "react-router-dom";
import { Row, Col, Form, FormControl, Button } from "react-bootstrap";
import brandlogo from "../../Images/brandlogo.png";

const TopBar = ({ isVisible, onSearch, errClr, Loading, handleSearch }) => {
  return (
    <>
      {isVisible ? (
        <div className="nav_header" expand="lg">
          <Container fluid className="top_headn">
            <Row className="header_top">
              <Col lg={7} md={5} xs={12}>
                <Navbar.Brand>
                  <Link to="/dashboard/home">
                    <img src={brandlogo} alt="branimage" />
                  </Link>
                </Navbar.Brand>
              </Col>
              <Col lg={5} md={7} xs={12}>
                <Form inline className="form_search topbar_searchf">
                  <FormControl
                    type="text"
                    // id="getSearchValue"
                    onChange={handleSearch}
                    placeholder="Enter search keywords......"
                    className={errClr ? errClr : "input_topsrh"}
                  />
                  <Button
                    type="submit"
                    variant="outline-success"
                    className="btn_submit"
                    style={{ color: "#fff" }}
                    onClick={onSearch}
                    disabled={Loading ? true : null}
                  >
                    <i className="fa fa-search"></i>
                  </Button>
                </Form>
              </Col>
            </Row>
          </Container>
        </div>
      ) : (
        <div className="nav_header" expand="lg">
          <Container fluid className="top_headn">
            <Navbar.Brand>
              <img src={brandlogo} alt="branimage" />
            </Navbar.Brand>
          </Container>
        </div>
      )}
    </>
  );
};

export default TopBar;
