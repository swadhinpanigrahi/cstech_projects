import React, { useState } from 'react';
import * as RB from "react-bootstrap";
import { Row } from "react-bootstrap";

import { ADD_IMAGESIZEDETAIL } from "../../../Utils/api";

const AddImageSize = (
    { show_addimagesize, setShow, apiCall, setModelMsg, modelSet }
) => {

    const [FormData, setFormData] = useState({});
    const [ErrorMsg, setErrorMsg] = useState("")

    const closeModel = () => {
        setFormData({});
        setErrorMsg("");
        setShow(false);
    }

    const handleChange = (e) => {
        let { name, value } = e.target;
        const data = { ...FormData };
        data[name] = value;
        setFormData(data)
    }

    const AddImageSizeFun = async () => {
        let { f_sizename } = FormData;
        if (!f_sizename) {
            setErrorMsg("please fill text-values")
        } else {
            const res = await ADD_IMAGESIZEDETAIL(FormData);
            let { status, message } = res
            if (status === 200) {
                apiCall();
                closeModel();
                setModelMsg(message);
                modelSet()
            } else {
                setErrorMsg(message);
            }
        }
    }

    return (
        <div>
            <RB.Modal show={show_addimagesize} onHide={closeModel} className="ordermanage_modal">
                <RB.Modal.Header closeButton>
                    <RB.Modal.Title>Add Image Size</RB.Modal.Title>
                </RB.Modal.Header>
                <RB.Modal.Body>
                    <RB.Row>
                        <RB.Col lg={12} md={12}>
                            <RB.Row>
                                <RB.Col lg={12} md={12}>
                                    {ErrorMsg !== "" ? ErrorMsg : ""}
                                    <RB.Form>
                                        <RB.Form.Group as={Row} controlId="image_pricet">
                                            <RB.Col lg={5} md={5}>
                                                <RB.Form.Label>Image Size Name :</RB.Form.Label>
                                            </RB.Col>
                                            <RB.Col lg={7} md={7}>
                                                <RB.Form.Control
                                                    type="text"
                                                    name="f_sizename"
                                                    onChange={handleChange}
                                                />
                                            </RB.Col>
                                        </RB.Form.Group>
                                        <RB.Row>
                                            <RB.Col lg={5} md={5}></RB.Col>
                                            <RB.Col lg={7} md={7}>
                                                <RB.Button
                                                    size="sm" variant="primary"
                                                    onClick={AddImageSizeFun}
                                                >
                                                    SUBMIT
                                                </RB.Button>
                                            </RB.Col>
                                        </RB.Row>
                                    </RB.Form>
                                </RB.Col>
                            </RB.Row>
                        </RB.Col>
                    </RB.Row>
                </RB.Modal.Body>
            </RB.Modal>
        </div>
    )
}

export default AddImageSize