import React, { useState, useEffect } from 'react';
import * as RB from 'react-bootstrap';
import { Row } from "react-bootstrap";
import { TaxUpdateForm } from "../../../Components/Forms/FormElements";

import { GET_TAXDETAIL, UPDATE_TAXDETAIL } from "../../../Utils/api";

import Modal from "../../../Components/Common/Modal";


export const TaxUpdate = () => {
  const [FormData, setFormData] = useState({});

  const [isOpen, setIsOpen] = useState(false);
  const [ModelMsg, setModelMsg] = useState("");

  const handleChange = (e) => {
    let { name, value } = e.target;
    const data = { ...FormData };
    data[name] = value;
    setFormData(data)
  }

  const modelSet = async () => {
    setIsOpen(true);
  };


  const taxUpdate = async () => {
    const res = await UPDATE_TAXDETAIL(FormData);
    let { message } = res;
    setModelMsg(message);
    modelSet()
  }

  const apiCall = async () => {
    const res = await GET_TAXDETAIL();
    let { data } = res;
    setFormData(data)
  }
  useEffect(() => {
    apiCall()
  }, [])

  return (
    <RB.Row className="rownew1">
      <RB.Col lg={12}>
        <RB.Row className="rownew1" style={{ paddingTop: "25px" }}>
          <div className="tableHeader tableHeader1 order_btntable">
            <RB.Col md={12} xs={12} className="table_span">
              <h3 className="page-title d-flex userv">
                <span>Tax Update</span>
              </h3>
            </RB.Col>
          </div>
        </RB.Row>
      </RB.Col>

      <div className="col-md-12" style={{ paddingTop: "7px" }}>
        <div
          className="box_detail"
          style={{
            paddingLeft: "0px",
            paddingRight: "0px",
            borderRadius: "4px",
            paddingTop: "25px",
          }}
        >

          <div className="form-body ">
            <RB.Form>
              {TaxUpdateForm.map((data, inx) => {
                let { label, format, type, name } = data;
                return (
                  <>
                    <RB.Form.Group as={Row}>
                      <RB.Col lg={2} md={2}>
                        <RB.Form.Label>{label} :</RB.Form.Label>
                      </RB.Col>
                      <RB.Col lg={2} md={3} className="show_inside">
                        <RB.Form.Control
                          onChange={handleChange}
                          type={type}
                          name={name}
                          value={FormData[name]}
                        />
                        <span className="formatn">
                          {format}
                        </span>
                      </RB.Col>
                    </RB.Form.Group>
                  </>
                );
              })}
              <RB.Row>
                <RB.Col lg={2} md={2}></RB.Col>
                <RB.Col lg={3} md={3}>
                  <RB.Button size="sm" variant="primary"
                    onClick={taxUpdate}>SUBMIT</RB.Button>
                </RB.Col>
              </RB.Row>
            </RB.Form>
          </div>
        </div>
      </div>

      <Modal text={ModelMsg} open={isOpen} onClose={() => setIsOpen(false)} />


    </RB.Row>
  )
}

export default TaxUpdate