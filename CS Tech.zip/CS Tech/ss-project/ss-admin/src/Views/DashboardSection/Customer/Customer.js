import React, { useEffect, useState, useRef, useCallback } from "react";
import Cookie from "js-cookie";
import { Link } from "react-router-dom";
import {
  getCustomerDetailsList, dataCount, accountDeactivation,
} from "../../../Utils/api";
import { Col, Row, Form } from "react-bootstrap";
import PageHeaders from "../../../Components/Common/PageHeaders";
import ReactExport from "react-data-export";
import EditCustomer from "./EditCustomer";
import Model from "../../../Components/Common/Model";

const Customer = () => {
  const [CustomerDetails, setCustomerDetails] = useState([]);
  const [Loading, setLoading] = useState(false);
  const [Search, setSearch] = useState("");
  let [pagination, setPagination] = useState(0);
  const [PageCount, setPageCount] = useState("");
  const [isOpen, setIsOpen] = useState(false);
  const [ModelMsg, setModelMsg] = useState("");
  const [CustomerAuth, setCustomerAuth] = useState({
    customers_exportfile: "",
    add: "",
    edit: "",
    active: "",
    payment: "",
    statement: "",
  });
  const [ExportData, setExportData] = useState([]);

  const [_id, set_id] = useState("");
  const [show, setShow] = useState(false);

  const [Short, setShort] = useState("ascending");
  const [Name, setName] = useState("");

  const handleClose = () => setShow(false);
  const handleShow = async (_id) => {
    setShow(true);
    set_id(_id);
  };

  let { customers_exportfile, add, edit, active, payment, statement } =
    CustomerAuth;

  const handleChange = async (e) => {
    setSearch(e.target.value);
    const res = await getCustomerDetailsList((pagination = 0), e.target.value);
    let { merchantData, merchantCount, merchantDataForExport } = res;
    const shaloArray = [...merchantData];
    setCustomerDetails(shaloArray);
    setExportData(merchantDataForExport);
    setPagination(1)
    setPageCount(merchantCount);
  };

  const userActiveAndDeactive = async (_id) => {
    const res = await accountDeactivation(_id);
    let { status, message } = res;
    if (status === 200) {
      setModelMsg(message);
      modelSet();
    }
  };

  const TotalPage = Math.ceil(PageCount / 20);
  const observer = useRef();
  const lastBookElement = useCallback(
    (node) => {
      if (observer.current) observer.current.disconnect();
      observer.current = new IntersectionObserver(async (entries) => {
        if (CustomerDetails.length > 19) {
          if (entries[0].isIntersecting && pagination <= TotalPage) {
            setPagination((prevPageNumber) => prevPageNumber + 1);
            const res = await getCustomerDetailsList(pagination, Search);
            let { merchantData } = res;
            let mergeArray = [...CustomerDetails, ...merchantData];
            if (Name !== "") {
              if (Short === "ascending") {
                const shortedArray = mergeArray.sort((a, b) => {
                  if (a[Name].toLowerCase() > b[Name].toLowerCase()) return -1;
                  if (a[Name].toLowerCase() < b[Name].toLowerCase()) return 1;
                  return 0;
                });
                setCustomerDetails(shortedArray);
              } else {
                const shortedArray = mergeArray.sort((a, b) => {
                  if (a[Name].toLowerCase() > b[Name].toLowerCase()) return 1;
                  if (a[Name].toLowerCase() < b[Name].toLowerCase()) return -1;
                  return 0;
                });
                setCustomerDetails(shortedArray);
              }
            }
            setCustomerDetails(mergeArray);
          }
        }
      });
      if (node) observer.current.observe(node);
    },
    [CustomerDetails]
  );

  //EXCEL
  const ExcelFile = ReactExport.ExcelFile;
  const ExcelSheet = ReactExport.ExcelFile.ExcelSheet;
  const DataSet = [
    {
      columns: [
        { title: "NAME" },
        { title: "EMAIL ID" },
        { title: "PHONE NO." },
        { title: "COMPANY NAME" },
        { title: "CREATION DATE" },
        { title: "ADDRESS" },
        { title: "PINCODE" },
        { title: "CITY" },
        { title: "STATE" },
        { title: "COUNTRY" },
        { title: "BENEFICIARY NAME" },
        { title: "BANK NAME" },
        { title: "ACCOUNT NUMBER" },
        { title: "IFSE CODE" },
        { title: "ACTIVE" },
      ],
      data: ExportData.map((data) => [
        { value: data.name },
        { value: data.email },
        { value: data.phone },
        { value: data.companyName },
        { value: data.createdAt.slice(0, 10) },
        { value: data.address },
        { value: data.pincode },
        { value: data.city },
        { value: data.state },
        { value: data.country },
        { value: data.beneficiary_name },
        { value: data.bank_name },
        { value: data.account_number },
        { value: data.ifsc_code },
        { value: data.activate },
      ]),
    },
  ];
  //EXCEL

  const countBar = () => {
    return (
      <Col md={12} className="show_count text-center">
        <p>{`showing ${pagination - 1} - ${CustomerDetails.length
          } of ${PageCount} items in listing`}</p>
      </Col>
    );
  };

  const modelSet = () => {
    setIsOpen(true);
  };

  const shortFun = (type) => {
    if (type === "name") {
      if (Short === "ascending") {
        setName("name");
        const shaloArray = [...CustomerDetails];
        const shortedArray = shaloArray.sort((a, b) => {
          if (a.name.toLowerCase() > b.name.toLowerCase()) return 1;
          if (a.name.toLowerCase() < b.name.toLowerCase()) return -1;
          return 0;
        });
        setCustomerDetails(shortedArray);
        setShort("descending");
      } else {
        setName("name");
        const shaloArray = [...CustomerDetails];
        const shortedArray = shaloArray.sort((a, b) => {
          if (a.name.toLowerCase() > b.name.toLowerCase()) return -1;
          if (a.name.toLowerCase() < b.name.toLowerCase()) return 1;
          return 0;
        });
        setCustomerDetails(shortedArray);
        setShort("ascending");
      }
    }

    if (type === "email") {
      if (Short === "ascending") {
        setName("email");
        const shaloArray = [...CustomerDetails];
        const shortedArray = shaloArray.sort((a, b) => {
          if (a.email.toLowerCase() > b.email.toLowerCase()) return 1;
          if (a.email.toLowerCase() < b.email.toLowerCase()) return -1;
          return 0;
        });
        setCustomerDetails(shortedArray);
        setShort("descending");
      } else {
        setName("email");
        const shaloArray = [...CustomerDetails];
        const shortedArray = shaloArray.sort((a, b) => {
          if (a.email.toLowerCase() > b.email.toLowerCase()) return -1;
          if (a.email.toLowerCase() < b.email.toLowerCase()) return 1;
          return 0;
        });
        setCustomerDetails(shortedArray);
        setShort("ascending");
      }
    }

    if (type === "phone") {
      if (Short === "ascending") {
        setName("phone");
        const shaloArray = [...CustomerDetails];
        const shortedArray = shaloArray.sort((a, b) => {
          if (a.phone > b.phone) return 1;
          if (a.phone < b.phone) return -1;
          return 0;
        });
        setCustomerDetails(shortedArray);
        setShort("descending");
      } else {
        setName("phone");
        const shaloArray = [...CustomerDetails];
        const shortedArray = shaloArray.sort((a, b) => {
          if (a.phone > b.phone) return -1;
          if (a.phone < b.phone) return 1;
          return 0;
        });
        setCustomerDetails(shortedArray);
        setShort("ascending");
      }
    }

    if (type === "companyName") {
      if (Short === "ascending") {
        setName("companyName");
        const shaloArray = [...CustomerDetails];
        const shortedArray = shaloArray.sort((a, b) => {
          if (a.companyName.toLowerCase() > b.companyName.toLowerCase())
            return 1;
          if (a.companyName.toLowerCase() < b.companyName.toLowerCase())
            return -1;
          return 0;
        });
        setCustomerDetails(shortedArray);
        setShort("descending");
      } else {
        setName("companyName");
        const shaloArray = [...CustomerDetails];
        const shortedArray = shaloArray.sort((a, b) => {
          if (a.companyName.toLowerCase() > b.companyName.toLowerCase())
            return -1;
          if (a.companyName.toLowerCase() < b.companyName.toLowerCase())
            return 1;
          return 0;
        });
        setCustomerDetails(shortedArray);
        setShort("ascending");
      }
    }

    if (type === "createdAt") {
      if (Short === "ascending") {
        setName("createdAt");
        const shaloArray = [...CustomerDetails];
        const shortedArray = shaloArray.sort((a, b) => {
          if (a.createdAt > b.createdAt) return 1;
          if (a.createdAt < b.createdAt) return -1;
          return 0;
        });
        setCustomerDetails(shortedArray);
        setShort("descending");
      } else {
        setName("createdAt");
        const shaloArray = [...CustomerDetails];
        const shortedArray = shaloArray.sort((a, b) => {
          if (a.createdAt > b.createdAt) return -1;
          if (a.createdAt < b.createdAt) return 1;
          return 0;
        });
        setCustomerDetails(shortedArray);
        setShort("ascending");
      }
    }
  };

  let listData =
    CustomerDetails.length > 0 ? (
      CustomerDetails.map((info, inx) => (
        <tr key={"customer-table" + inx} ref={lastBookElement}>
          <td>{inx + 1}</td>
          <td>{info.name}</td>
          <td>{info.email}</td>
          <td>{info.phone}</td>
          <td>{info.companyName}</td>
          <td>{info.createdAt.slice(0, 10)}</td>
          <td>{info.activate}</td>
          <td className="text-center">
            <i
              className={
                edit === "true" ? "fa fa-pencil-alt iconfa" : "testingggg"
              }
              onClick={() => handleShow(info._id)}
            ></i>
            <i
              className={active === "true" ? "fa fa-eye iconfa" : "testingggg"}
              onClick={() => userActiveAndDeactive(info._id)}
            ></i>
            <Link
              to={`/dashboard/customer/paymrnt/${info._id}`}
              target="_blank"
            >
              <i
                className={
                  payment === "true" ? "fa fa-credit-card iconfa" : "testingggg"
                }
              ></i>
            </Link>
            <Link
              to={`/dashboard/customer/statement/${info._id}`}
              target="_blank"
            >
              <i
                className={
                  statement === "true"
                    ? "fa fa-dollar-sign iconfa newi_c"
                    : "testingggg"
                }
              ></i>
            </Link>
          </td>
        </tr>
      ))
    ) : (
      <tr>
        <td className="no_records" colSpan="9">
          NO RECORDS FOUND
        </td>
      </tr>
    );

  useEffect(() => {
    setLoading(true);
    const count = async () => {
      const res = await dataCount();
      const { merchantCount } = res;
      setPageCount(merchantCount);
    };
    count();
    const apiCall = async () => {
      const res = await getCustomerDetailsList(pagination, Search);
      let { merchantData, merchantCount, merchantDataForExport } = res;
      setPageCount(merchantCount);
      setCustomerDetails(merchantData);
      setExportData(merchantDataForExport);
      setPagination(1);
      setLoading(false);
    };
    apiCall();
  }, []);

  useEffect(() => {
    const fun = async () => {
      const customers_exportfile = await Cookie.get("customers_exportfile");
      const add = await Cookie.get("add");
      const edit = await Cookie.get("edit");
      const active = await Cookie.get("active");
      const payment = await Cookie.get("payment");
      const statement = await Cookie.get("statement");

      const updateState = { ...CustomerAuth };
      updateState.customers_exportfile = customers_exportfile;
      updateState.add = add;
      updateState.edit = edit;
      updateState.active = active;
      updateState.payment = payment;
      updateState.statement = statement;
      setCustomerAuth({ ...updateState });
    };
    fun();
  }, []);

  return (
    <>
      <Col md={12}>
        <PageHeaders title="Customers" />
        <Col cmd={12}>
          <div
            className="box_detail"
            style={{ padding: "15px 0px 10px 0px", marginBottom: "20px" }}
          >
            <Col lg={12} style={{ padding: "0px" }}>
              <div className="page-header row no-gutters">
                <Col md={12} style={{ color: "blue !important" }}>
                  <h3 className="page-title subtitile">FILTER BY SEARCH</h3>
                </Col>
                <hr />
              </div>
            </Col>
            <Row style={{ padding: "20px 30px" }}>
              <Col lg={4} md={8}>
                <div className="form-group row mb-0">
                  <Col lg={12}>
                    <input
                      type="text"
                      placeholder="Serach by Name, Email and Phone"
                      onChange={handleChange}
                      className="form-control"
                    />
                  </Col>
                </div>
              </Col>
              <div className="col-lg-8 col-md-4 text-right addb">
                <button className={add === "true" ? "addc" : "testingggg"}>
                  <span>
                    <i className="fa fa-plus-circle"></i>
                    <span style={{ position: "relative", left: "5px" }}>
                      <Link to="/dashboard/customer/add">ADD CUSTOMER</Link>
                    </span>
                  </span>
                </button>
              </div>
            </Row>
          </div>
        </Col>
        <Col md={12} className="text-right">
          <span className="count_customer">Total Records: {PageCount}</span>
          <ExcelFile
            fillename="customer"
            element={
              CustomerDetails.length !== 0 ? (
                <button
                  className={
                    customers_exportfile === "true"
                      ? "export_btn addbce customer_export"
                      : "display"
                  }
                >
                  EXPORT
                </button>
              ) : (
                <button
                  className={
                    customers_exportfile === "true"
                      ? "export_btn addbce1 customer_export"
                      : "display"
                  }
                  disabled
                >
                  EXPORT
                </button>
              )
            }
          >
            <ExcelSheet dataSet={DataSet} name="shipment reports" />
          </ExcelFile>
          {/* {pagination} */}
        </Col>
        <Col md={12}>
          <hr />
          <div
            className="box_detail tableboxdc" //table_scroll
            style={{
              paddingTop: "0px",
              paddingBottom: "0px",
              marginBottom: "0px",
            }}
          >
            <table className="table table-bordered table-responsive">
              <thead className="thead-dark">
                <tr>
                  <th>S NO.</th>
                  <th className="sorting" onClick={() => shortFun("name")}>
                    NAME
                  </th>
                  <th className="sorting" onClick={() => shortFun("email")}>
                    EMAIL
                  </th>
                  <th className="sorting" onClick={() => shortFun("phone")}>
                    PHONE NO.
                  </th>
                  <th className="sorting" onClick={() => shortFun("companyName")}>
                    COMPANY NAME
                  </th>
                  <th className="sorting" onClick={() => shortFun("createdAt")}>
                    CREATION DATE
                  </th>
                  <th>ACTIVE</th>
                  <th className="text-center">ACTION</th>
                </tr>
              </thead>
              <tbody>
                {Loading ? (
                  <tr>
                    <td className="no_records" colSpan="8">
                      Loading....
                    </td>
                  </tr>
                ) : (
                  [listData]
                )}
              </tbody>
            </table>
          </div>
        </Col>
        <Model text={ModelMsg} open={isOpen} onClose={() => setIsOpen(false)} />
        {countBar()}
      </Col>
      <EditCustomer _id={_id} show={show} handleClose={handleClose} />
    </>
  );
};

export default Customer;
