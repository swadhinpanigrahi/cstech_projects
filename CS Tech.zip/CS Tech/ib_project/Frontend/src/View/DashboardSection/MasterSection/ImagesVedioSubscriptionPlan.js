import React, { useState, useEffect } from 'react';
import * as RB from 'react-bootstrap';
import { MdAddCircleOutline } from 'react-icons/md';
import { RiDeleteBin6Line } from "react-icons/ri";
import { BiCommentEdit } from "react-icons/bi";

import AddImageVedioSubscriptionPlan from "../../../Components/Models/MasterModals/AddImageVedioSubscriptionPlan";
import EditImageVedioSubscriptionPlan from "../../../Components/Models/MasterModals/MasterEdit/EditImageVedioSubscriptionPlan";

import Modal from "../../../Components/Common/Modal";

import PaginationComponent from "../../../Components/Common/PaginationComponent";

import {
    GET_IMAGEVEDIOLIST, REMOVE_IMAGEVEDIODETAIL, GET_IMAGEVEDIODETAIL
} from "../../../Utils/api"

const ImagesVedioSubscriptionPlan = () => {
    const [currentPage, setCurrentPage] = useState(1);
    const [itemPerPage, setItemPerPage] = useState(20);
    let [searchData, setSearchData] = useState("");
    const [TotalCount, setTotalCount] = useState(0);


    const [show_addimagevediosubscription, setShow] = useState(false);
    const [show_editimagevediosubscription, setEdit] = useState(false);

    const [ImageVideoList, setImageVideoList] = useState([])
    const [useData, setUserData] = useState({});
    const [Loading, setLoading] = useState(false)

    const [isOpen, setIsOpen] = useState(false);
    const [ModelMsg, setModelMsg] = useState("");

    const addimagevediosubscription = () => {
        setShow(true)
    }

    const editimagevediosubscription = async (id) => {
        const res = await GET_IMAGEVEDIODETAIL(id);
        let { data } = res;
        setUserData(data)
        setEdit(true)
    }

    const modelSet = async () => {
        setIsOpen(true);
    };

    const deleteIMGVDO_SUBFun = async (id) => {
        const res = await REMOVE_IMAGEVEDIODETAIL(id);
        let { message } = res;
        apiCall()
        setModelMsg(message);
        modelSet();
    }

    const SearchDataFun = async (e) => {
        setSearchData(e.target.value);
        const res = await GET_IMAGEVEDIOLIST(currentPage, itemPerPage, searchData);
        let { data, totalrecord } = res;
        setImageVideoList(data);
        totalrecord.length === 1
            ? setTotalCount(totalrecord[0].totalcount)
            : setTotalCount(0);
    }


    const apiCall = async () => {
        setLoading(true)
        const res = await GET_IMAGEVEDIOLIST(currentPage, itemPerPage, searchData);
        let { data, totalrecord } = res;
        setImageVideoList(data);
        setTotalCount(totalrecord[0].totalcount)
        setLoading(false)
    }

    useEffect(() => {
        apiCall()
    }, [currentPage, itemPerPage])
    return (
        <RB.Row className="rownew1">
            <RB.Col lg={12}>
                <RB.Row className="rownew1" style={{ paddingTop: "25px" }}>
                    <div className="tableHeader tableHeader1 order_btntable">
                        <RB.Col md={6} xs={12} className="table_span">
                            <h3 className="page-title d-flex userv">
                                <span>Search Results</span>
                            </h3>
                        </RB.Col>
                        <RB.Col md={6} xs={12} className="table_span">
                            <div className="float-right responsive_floatbtn">
                                <RB.Button size="sm" variant="primary" className="btn_svg"
                                    onClick={addimagevediosubscription}
                                >
                                    <MdAddCircleOutline style={{ marginRight: "3px" }} />
                                    ADD IMAGE / VEDIO SUBSCRIPTION
                                </RB.Button>
                            </div>
                        </RB.Col>
                    </div>
                </RB.Row>
            </RB.Col>

            <RB.Col lg={12}>
                <div className="box_detail" style={{ borderRadius: "4px" }}>
                    <div className="page-header row">
                        <RB.Col md={12}>
                            <RB.Form className="manage_searchorder">
                                <RB.Row className="mg_row0">
                                    <RB.Col lg={12} md={12} className="customer_leftsrh">
                                        <RB.Row className="mg_row0">
                                            <RB.Col lg={3} md={3} className="customer_sdate">
                                                <RB.Form.Group>
                                                    <RB.Form.Control
                                                        id="searchText"
                                                        type="text"
                                                        placeholder="Search by Text"
                                                        onChange={SearchDataFun}
                                                    />
                                                </RB.Form.Group>
                                            </RB.Col>
                                        </RB.Row>
                                    </RB.Col>

                                </RB.Row>
                            </RB.Form>
                        </RB.Col>
                    </div>
                </div>
            </RB.Col>

            <RB.Col lg={12}>
                <RB.Row className="rownew1">
                    <div className="tableHeader tableHeader1 search_new">
                        <RB.Col lg={6} md={6} className="table_span">
                            <h3 className="page-title d-flex userv">
                                <span>Image / Video List</span>
                            </h3>
                        </RB.Col>
                        <RB.Col lg={6} md={6} className="table_span total_recordt">
                            <span>Total Records: {TotalCount}</span>
                        </RB.Col>
                    </div>
                </RB.Row>
                <div
                    className="box_detail table_boxdtl manage_order"
                    style={{}}
                >
                    <RB.Table striped bordered hover variant="dark" responsive>
                        <thead>
                            <tr class="vtable">
                                <th className="text-center">S. No.</th>
                                <th className="">Plan Name</th>
                                <th className="">Plan Type</th>
                                <th className="">Max Allowed</th>
                                <th className="">Period in Days</th>
                                <th className="">Amount(INR)</th>
                                <th className="">Total No.Images</th>
                                <th className="">Savings</th>
                                <th className="text-center action_align">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            {Loading ? <tr><td className="no_records" colSpan="11">Loading...</td></tr> : ImageVideoList.length > 0 ? ImageVideoList.map((info, inx) => {
                                return (
                                    <tr key={`IMGVIDOSUB_${inx}`}>
                                        <td>{inx + 1}</td>
                                        <td>{info.f_planname}</td>
                                        <td>{info.f_imageType}</td>
                                        <td>{info.f_maxallowed}</td>
                                        <td>{info.f_periodindays}</td>
                                        <td>{info.f_amount}</td>
                                        <td>{info.f_totimg}</td>
                                        <td>{info.f_save}</td>
                                        <td className="td_comments text-center">
                                            <BiCommentEdit
                                                title="Edit Image Type"
                                                onClick={() => editimagevediosubscription(info._id)}
                                            />
                                            <RiDeleteBin6Line
                                                title="Delete Image Type"
                                                className="text-danger1"
                                                onClick={() => deleteIMGVDO_SUBFun(info._id)}
                                            />
                                        </td>
                                    </tr>
                                )
                            }) : <tr><td className="no_records" colSpan="11">No Records Found</td></tr>}

                        </tbody>
                    </RB.Table>
                </div>
                <PaginationComponent
                    MOCK_DATA={TotalCount}
                    currentPage={currentPage}
                    setCurrentPage={setCurrentPage}
                    itemPerPage={itemPerPage}
                    setItemPerPage={setItemPerPage}
                />
            </RB.Col>


            <AddImageVedioSubscriptionPlan
                show_addimagevediosubscription={show_addimagevediosubscription}
                setShow={setShow}
                apiCall={apiCall}
                setModelMsg={setModelMsg}
                modelSet={modelSet}
            />

            <EditImageVedioSubscriptionPlan
                show_editimagevediosubscription={show_editimagevediosubscription}
                setEdit={setEdit}
                useData={useData}
                apiCall={apiCall}
            />

            <Modal text={ModelMsg} open={isOpen} onClose={() => setIsOpen(false)} />

        </RB.Row>
    )
}

export default ImagesVedioSubscriptionPlan
