const followupRoute = require("express").Router();

const { getDropDownValues, getSearchFieldDetails } = require("../controllers/followupController");

followupRoute.get('/getcompanynames', getDropDownValues)
followupRoute.get('/getfollowupquerysearch/:f_companyname', getSearchFieldDetails)

module.exports = followupRoute;
