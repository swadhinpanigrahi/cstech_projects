const mongoose = require("mongoose");

const RegistrationSchema = mongoose.Schema(
  {
    f_userid: { type: String },
    f_fullname: { type: String, lowercase: true },
    f_email: { type: String, lowercase: true },
    f_mobileno: { type: String },
    f_companyname: { type: String },
    f_Shortname: { type: String, lowercase: true, default: null },
    f_groupname: { type: String, lowercase: true, default: null },
    f_registrationType: { type: String, lowercase: true },
    f_address: { type: String },
    f_Identify_User: { type: String },
    f_city: { type: String },
    f_state: { type: String },
    f_country: { type: String },
    f_giftpolicy: { type: String },
    f_commissionpolicy: { type: String },
    f_createdate: { type: Date },
    f_ipAddress: { type: String },
    f_businessType: { type: String },
    f_GSTIN: { type: String },
    CS_pin: { type: String },
    CS_address: { type: String },
    cs_discount: { type: Number },
    CS_phone: { type: Number },
    t_comment: { type: String },
    f_associativename: { type: String }
  },
  { collection: "t_registration_mongoDB" }
);

module.exports = registration = mongoose.model(
  "t_registration_mongoDB",
  RegistrationSchema
);
