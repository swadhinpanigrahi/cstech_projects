import Cookie from "js-cookie";

export const saveCookies = async (data) => {
    let { codreports, customers, dashboard, outstanding, shipments, manage_profile, change_password } = data;

    let { dashboard_graph, order_list, register_list } = dashboard;
    let { codreports_viewlist, codreports_exportfile, codreports_track } = codreports;
    let { customers_action, customers_viewlist, customers_exportfile } = customers;
    let { add, edit, active, payment, statement } = customers_action;
    let { shipments_viewlist, shipments_exportfile, shipments_track } = shipments;
    let { outstanding_action, outstanding_viewlist, outstanding_exportfile } = outstanding;
    let { opayment, ostatement } = outstanding_action;

    await Cookie.set("graph", dashboard_graph);
    await Cookie.set("order_list", order_list);
    await Cookie.set("register_list", register_list);

    await Cookie.set("codreports_viewlist", codreports_viewlist);
    await Cookie.set("codreports_exportfile", codreports_exportfile);
    await Cookie.set("codreports_track", codreports_track);

    await Cookie.set("customers_viewlist", customers_viewlist);
    await Cookie.set("customers_exportfile", customers_exportfile);
    await Cookie.set("add", add);
    await Cookie.set("edit", edit);
    await Cookie.set("active", active);
    await Cookie.set("payment", payment);
    await Cookie.set("statement", statement);

    await Cookie.set("shipments_viewlist", shipments_viewlist);
    await Cookie.set("shipments_exportfile", shipments_exportfile);
    await Cookie.set("shipments_track", shipments_track);

    await Cookie.set("outstanding_viewlist", outstanding_viewlist);
    await Cookie.set("outstanding_exportfile", outstanding_exportfile);
    await Cookie.set("opayment", opayment);
    await Cookie.set("ostatement", ostatement);

    await Cookie.set("manage_profile", manage_profile);
    await Cookie.set("change_password", change_password);
    
    console.log(
        codreports_viewlist, codreports_exportfile, codreports_track, customers_viewlist, customers_exportfile,
        add, edit, active, payment, statement, shipments_viewlist, shipments_exportfile, shipments_track, dashboard_graph, order_list, register_list,
        outstanding_viewlist, outstanding_exportfile, opayment, ostatement, manage_profile, change_password
    )
}