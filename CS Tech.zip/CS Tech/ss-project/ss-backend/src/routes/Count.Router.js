const express = require("express");

const countRouter = express.Router();

const {
    getTrakingDetailsByButtonSearchCount
} = require("../controllers/Count.Controller")

countRouter.route(`/getButtonShipmentCount`).post(getTrakingDetailsByButtonSearchCount);

module.exports = countRouter