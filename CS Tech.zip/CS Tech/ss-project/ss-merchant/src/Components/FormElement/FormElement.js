const FormData = {
    username: {
        name: "username",
        type: "text",
        placeholder: "Enter Your Username",
        controlId: "formBasicUsarname"
    },
    password: {
        label: "password",
        name: "password",
        type: "password",
        placeholder: "Enter Your Password",
        controlId: "formBasicPassword"
    },

    name: {
        label: "name",
        name: "name",
        type: "text",
        placeholder: "Enter Your Name",
        controlId: "formBasicName",
    },
    email: {
        label: "email",
        name: "email",
        type: "email",
        placeholder: "Enter Your Email",
        controlId: "formBasicEmail",
    },
    phone: {
        label: "phone",
        name: "phone",
        type: "text",
        placeholder: "Enter Your Phone",
        controlId: "formBasicPhone",
    },
    companyName: {
        label: "c_name",
        name: "companyName",
        type: "text",
        placeholder: "Enter Your Company Name",
        controlId: "formBasicCompanyName",
    },
    address: {
        label: "addr",
        name: "address",
        type: "email",
        placeholder: "Enter Your Address",
        controlId: "formBasicAddress",
    },
    pincode: {
        label: "zip",
        name: "pincode",
        type: "text",
        placeholder: "Enter Your Pincode",
        controlId: "formBasicPincode",
    },
    city: {
        label: "city",
        name: "city",
        type: "text",
        placeholder: "Enter Your City",
        controlId: "formBasicCity",
    },
    state: {
        label: "state",
        name: "state",
        type: "text",
        placeholder: "Enter Your State",
        controlId: "formBasicState",
    },
    country: {
        label: "country",
        name: "country",
        type: "text",
        placeholder: "Enter Your Country",
        controlId: "formBasicCountry",
    },
    beneficiary_name: {
        label: "bank_beneficiaryname",
        name: "beneficiary_name",
        type: "text",
        placeholder: "Enter Your Beneficiary Name",
        controlId: "formBasicBeneficiaryName",
    },
    bank_name: {
        label: "bank_bankname",
        name: "bank_name",
        type: "text",
        placeholder: "Enter Your Bank Name",
        controlId: "formBasicBankName",
    },
    account_number: {
        label: "bank_accnumber",
        name: "account_number",
        type: "number",
        placeholder: "Enter Your Account Number",
        controlId: "formBasicAccNum",
    },
    ifsc_code: {
        label: "bank_ifsccode",
        name: "ifsc_code",
        type: "text",
        placeholder: "Enter Your IFSC Code",
        controlId: "formBasicIFSCcode",
    },
    bank_branch: {
        label: "bank_branchname",
        name: "bank_branch",
        type: "text",
        placeholder: "Enter Your Bank Branch",
        controlId: "formBasicBankBranch",
    },

    oldpassword: {
        label: "current_password",
        name: "oldpassword",
        type: "password",
        placeholder: "Enter Your Current Password",
        className: "form-control",
        required: true,
        controlId: "formBasicOldpassword",
    },
    newpassword: {
        label: "new_password",
        name: "newpassword",
        type: "password",
        placeholder: "Enter Your New Password",
        className: "form-control",
        required: true,
        controlId: "formBasicNewPassword",
    },
    confirmpassword: {
        label: "conf_password",
        name: "confirmpassword",
        type: "password",
        placeholder: "Re-enter Your New Password",
        className: "form-control",
        required: true,
        controlId: "formBasicRE-enterNewPassword",
    },
}

export const loginForm = [FormData.username, FormData.password]

export const customerDetailsForm = [
    FormData.name, FormData.email,
    FormData.phone, FormData.password,
    FormData.companyName, FormData.address,
    FormData.pincode, FormData.city,
    FormData.state, FormData.country,
];

export const customerBankDetails = [
    FormData.beneficiary_name, FormData.bank_name,
    FormData.account_number, FormData.ifsc_code,
    FormData.bank_branch
]

export const changePasswordForm = [
    FormData.oldpassword,
    FormData.newpassword,
    FormData.confirmpassword,
];

export const EmailChangePasswordForm = [FormData.newpassword, FormData.confirmpassword]