const Starperiod = require("express").Router();
const {
    addStarPeriod, getStarPeriodList, getStarPeriodDetail, editStarPeriodDetail, deleteStarPeriodDetail
} = require("../../controllers/Master/master.starperiod.controller");

Starperiod.route("/addstarperiod").post(addStarPeriod)
Starperiod.route("/getstarperiodlist").get(getStarPeriodList)
Starperiod.route("/getstarperioddetail/:_id").get(getStarPeriodDetail)
Starperiod.route("/editstarperioddetail").post(editStarPeriodDetail)
Starperiod.route("/deletestarperioddetail/:_id").get(deleteStarPeriodDetail)

module.exports = Starperiod;