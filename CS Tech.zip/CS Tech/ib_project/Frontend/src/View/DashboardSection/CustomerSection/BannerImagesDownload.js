import React from 'react';
import { Row, Col, Form, Table } from 'react-bootstrap';
import { BannerImageAPI } from "../../../Utils/api";
import PaginationComponent from "../../../Components/Common/PaginationComponent";
import Moment from "moment";
// import DatePicker from "react-datepicker";
// import "react-datepicker/dist/react-datepicker.css";

const BannerImagesDownload = () => {
    const [Data, setData] = React.useState([]);
    const [Count, setCount] = React.useState(0);
    const [currentPage, setCurrentPage] = React.useState(1);
    const [itemPerPage, setItemPerPage] = React.useState(20);

    const [Loading, setLoading] = React.useState(false);

    const handleChange = async (e) => {
        const res = await BannerImageAPI(currentPage, itemPerPage, e.target.value);
        let { customerCount, customerData } = res;
        setData(customerData);
        customerCount.length === 1 ? setCount(customerCount[0].totalcount) : setCount(0);
        setLoading(false)
    }

    React.useEffect(() => {
        setLoading(true)
        const apiCall = async () => {
            const res = await BannerImageAPI(currentPage, itemPerPage);
            let { customerCount, customerData } = res;
            setData(customerData);
            customerCount.length === 1 ? setCount(customerCount[0].totalcount) : setCount(0);
            setLoading(false)
        }
        apiCall()
    }, [currentPage, itemPerPage]);

    return (
        <>
            <Row className="rownew1">
                <Col lg={12}>
                    <Row className="page_header1 rownew1">
                        <div className="tableHeader tableHeader1 search_new">
                            <Col md={12} className="table_span">
                                <h3 className="page-title d-flex userv">
                                    <span>Search Results</span>
                                </h3>
                            </Col>
                        </div>
                    </Row>
                </Col>
            </Row>

            <Col lg={12}>
                <div className="box_detail" style={{ borderRadius: "4px" }}>
                    <div className="page-header row">
                        <Col md={12}>
                            <Form className="manage_searchorder">
                                < Row className="mg_row0">
                                    < Col lg={6} md={6}>
                                        < Row className="mg_row0">
                                            {/* < Col lg={6} md={6}>
                                                <DatePicker className="startdate"
                                                    placeholderText="Start Date"
                                                    selected={startDate}
                                                    onChange={(date) => setStartDate(date)}
                                                    dateFormat="dd-MM-yyyy"
                                                />
                                            </ Col>
                                            < Col lg={6} md={6} className="customer_sdate order_sdate">
                                                <DatePicker className="enddate"
                                                    placeholderText="End Date"
                                                    selected={endDate}
                                                    onChange={(date) => setEndDate(date)}
                                                    dateFormat="dd-MM-yyyy"
                                                />
                                            </ Col> */}
                                        </ Row>
                                    </ Col>
                                    < Col lg={2} md={2} className="customer_sdate">
                                        {/* < Col lg={12} className="customer_sdate1">
                                            <Button size="sm" className="customer_srhbtn" variant="primary" >SEARCH</Button>
                                        </ Col> */}
                                    </ Col>
                                    < Col lg={4} md={4}>
                                        < Row className="mg_row0">
                                            < Col lg={4}></ Col>
                                            < Col lg={8} className="">
                                                <Form.Group>
                                                    <Form.Control
                                                        type="text"
                                                        placeholder="Search by Text/Order ID"
                                                        onChange={handleChange}
                                                    />
                                                </Form.Group>
                                            </ Col>
                                        </ Row>
                                    </ Col>
                                </Row>
                            </Form>
                        </Col>
                    </div>
                </div>
            </Col>

            <Col lg={12}>
                <Row className="rownew1">
                    <div className="tableHeader tableHeader1 search_new">
                        <Col lg={6} md={6} xs={7} className="table_span">
                            <h3 className="page-title d-flex userv">
                                <span>Banner Images Download List</span>
                            </h3>
                        </Col>
                        <Col lg={6} md={6} xs={5} className="table_span text-right">
                            Total Count : {Count}
                        </Col>
                    </div>
                </Row>

                <div
                    className="box_detail table_boxdtl manage_order"
                    style={{ marginBottom: "0px" }}
                >
                    <Table striped bordered hover variant="dark" responsive>
                        <thead>
                            <tr>
                                <th>Email</th>
                                <th>Ip</th>
                                <th>Date</th>

                            </tr>
                        </thead>
                        <tbody>
                            {Loading ? <>
                                <td className="no_records" colSpan="11">
                                    Loading...
                                </td>
                            </> : Data.length > 0 ? Data.map((info) => {
                                let { _id, Email, Ip, CreatedAt } = info
                                return (
                                    <tr key={_id}>
                                        <td>{Email}</td>
                                        <td>{Ip}</td>
                                        <td>{Moment(CreatedAt).format("DD-MM-YYYY")}</td>
                                    </tr>
                                )
                            }) : <>
                                <td className="no_records" colSpan="11">
                                    No Records Found
                                </td>
                            </>}
                        </tbody>
                    </Table>
                </div>
                <PaginationComponent
                    MOCK_DATA={Count}
                    currentPage={currentPage}
                    setCurrentPage={setCurrentPage}
                    itemPerPage={itemPerPage}
                    setItemPerPage={setItemPerPage}
                />
            </Col>

        </>
    )
}

export default BannerImagesDownload
