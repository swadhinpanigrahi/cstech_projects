const mongoose = require("mongoose");

const t_Highres_downSchema = mongoose.Schema(
    {
        f_sno: { type: String },
        Emailid: { type: String },
        ip: { type: String },
        download_date: { type: Date },
        Client_name: { type: String },
        Imageid: { type: String },
        groupid: { type: String },
    },
    { collection: "t_Highres_down" }
);

module.exports = t_Highres_down = mongoose.model(
    "t_Highres_down",
    t_Highres_downSchema
);