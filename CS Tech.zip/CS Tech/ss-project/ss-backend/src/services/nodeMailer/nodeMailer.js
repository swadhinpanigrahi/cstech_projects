const nodeMailer = require("nodemailer");
const { SMTP_HOST, SMTP_EMAIL, SMTP_PASSWORD } = require(`../../config`);

const sendEmail = (data, callback) => {
  const { mailTo, subject, html } = data;
  var transport = nodeMailer.createTransport({
    host: SMTP_HOST,
    port: 587,
    // service: "gmail.com",
    ssl: true,
    networkcredential: true,
    auth: {
      user: "SMTP_Injection",
      pass: SMTP_PASSWORD,
    },
  });

  var mailOption = {
    from: SMTP_EMAIL,
    to: mailTo,
    subject: subject,
    html: html,
  };

  transport.sendMail(mailOption, function (error, info) {
    if (error) {
      callback(error, true, "error");
    } else {
      callback(info, false);
    }
  });
};

module.exports = {
  sendEmail,
};
