const mongoose = require("mongoose");

const OrderSchema = mongoose.Schema(
  {
    f_sno: { type: Number },
    f_clientname: { type: String, default: null },
    f_email: { type: String, default: null },
    f_mobileno: { type: String, default: null },
    f_totalamtwithGST: { type: Number, default: 0 },
    f_order_total: { type: Number, default: 0 },
    f_order_Confirm: { type: Number, default: 0 },
    f_order_Pending: { type: Number, default: 0 },
    f_order_Rejected: { type: Number, default: 0 },
    f_order_Ecash: { type: Number, default: 0 },
    f_order_Payment: { type: Number, default: 0 },
    f_order_Discount: { type: Number, default: 0 },
    f_order_Unpaid: { type: Number, default: 0 },
    f_order_Current_Discount_Per: { type: Number, default: 0 },
    f_approval_mode: { type: String, default: "" },
    f_credit_period: { type: String, default: "" },
  },
  { collection: "t_order_mongoDB" }
);

module.exports = order = mongoose.model("t_order_mongoDB", OrderSchema);
