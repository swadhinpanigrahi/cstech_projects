const { M_IMAGESIZE, M_TAX, M_PAYMENTGATWAY } = require("../../model");

exports.addImageSizeDetail = async (req, res) => { //work
    const { f_sizename } = req.body
    try {
        const existingData = await M_IMAGESIZE.findOne({ f_sizename });
        if (existingData) {
            res.json({ status: 400, message: "already exist" })
        }
        if (!existingData) {
            const Data = await new M_IMAGESIZE({
                f_sizename
            }).save();
            if (Data) {
                res.json({ status: 200, message: "added successfully" })
            }
        }
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

exports.getImageSizeList = async (req, res) => {
    const { currentPage, itemPerPage, searchData } = req.query;
    const num = parseInt(itemPerPage)
    const start = parseInt(currentPage);
    let pipeline;
    let countline;
    try {
        if (!searchData || searchData === "") {
            pipeline = [
                { $sort: { _id: -1 } },
                { $skip: (start - 1) * num },
                { $limit: num }
            ]
            countline = [
                { $count: "totalcount" }
            ]
        } else {
            pipeline = [
                { $match: { f_sizename: { $regex: searchData, $options: "im" } } },
                { $sort: { _id: -1 } },
                { $skip: (start - 1) * num },
                { $limit: num }
            ]
            countline = [
                { $match: { f_sizename: { $regex: searchData, $options: "im" } } },
                { $count: "totalcount" }
            ]
        }
        const data = await M_IMAGESIZE.aggregate(pipeline)
        const totalrecord = await M_IMAGESIZE.aggregate(countline)
        res.json({ status: 200, data, totalrecord })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

exports.getImageSizeDetail = async (req, res) => {
    const { _id } = req.params;
    try {
        const data = await M_IMAGESIZE.findOne({ _id })
        res.json({ status: 200, data })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

exports.editImageSizeDetail = async (req, res) => {
    const { _id, f_sizename } = req.body;
    try {
        const data = await M_IMAGESIZE.findById({ _id });
        console.log(data, req.body)
        if (data) {
            await M_IMAGESIZE.findByIdAndUpdate({ _id }, { $set: { f_sizename } })
        }
        res.json({ status: 200, message: "Image size updated successfully" })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

exports.deleteImageSizeDetail = async (req, res) => {
    const { _id } = req.params;
    try {
        await M_IMAGESIZE.findByIdAndRemove({ _id })
        res.json({ status: 200, message: "Image size removed successfully!!" })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

//----TAX & RIGHTS_PAYMENT----//
exports.getTexDetail = async (req, res) => {
    try {
        const exist = await M_TAX.find({})
        const data = await M_TAX.findOne({ f_CMP_GSTIN: exist[0].f_CMP_GSTIN })
        res.json({ status: 200, data })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

exports.updateTexDetail = async (req, res) => {
    const { _id, f_totservicetax, f_servicetax, f_cess, f_usaprice } = req.body;
    console.log(req.body)
    try {
        await M_TAX.findByIdAndUpdate({ _id }, {
            $set: {
                f_totservicetax, f_servicetax, f_cess, f_usaprice
            }
        })
        res.json({ status: 200, message: "tax updated" })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

exports.getRightPayment = async (req, res) => {
    try {
        const data = await M_PAYMENTGATWAY.find({})
        res.json({ status: 200, data })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

exports.updateRightPayment = async (req, res) => {
    const {
        _id, f_hdfc, f_icici, f_ameriexp, f_cellpay, f_elecfund,
        f_paypall, f_ebs, f_payzippy, f_Mobikwik
    } = req.body;
    try {
        const data = await M_PAYMENTGATWAY.findByIdAndUpdate({ _id }, {
            $set: {
                f_hdfc, f_icici, f_ameriexp, f_cellpay, f_elecfund,
                f_paypall, f_ebs, f_payzippy, f_Mobikwik
            }
        })
        res.json({ status: 200, message: "payment details updated!" })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}