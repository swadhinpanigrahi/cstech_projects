import React from 'react';
import { Row, Col, Form, Table } from 'react-bootstrap';
import { SuperImageUserAPI, SuperImageUserDetailsAPI } from "../../../Utils/api";
import PaginationComponent from "../../../Components/Common/PaginationComponent";
import SuperImgTableModel from "../../../Components/Models/UserModals/SuperImgTableModel";
import Moment from "moment";


const SuperImageUser = () => {
    const [Data, setData] = React.useState([]);
    const [Count, setCount] = React.useState(0);
    const [currentPage, setCurrentPage] = React.useState(1);
    const [itemPerPage, setItemPerPage] = React.useState(20);

    const [Loading, setLoading] = React.useState(false);

    const [ShowModel, setShowModel] = React.useState(false);

    const [ViewData, setViewData] = React.useState({
        List: [],
        Count: 0,
        email: ""
    })

    const onView = async (f_email) => {
        const res = await SuperImageUserDetailsAPI(f_email);
        let { customerCount, customerData, email } = res;
        const data = { ...ViewData };
        data.List = customerData;
        data.Count = customerCount;
        data.email = email;
        setViewData(data)
        setShowModel(true)
    }

    const handleChange = async (e) => {
        const res = await SuperImageUserAPI(currentPage, itemPerPage, e.target.value);
        let { customerCount, customerData } = res;
        setData(customerData);
        customerCount.length === 1 ? setCount(customerCount[0].totalcount) : setCount(0);
        setLoading(false)
    }


    React.useEffect(() => {
        setLoading(true)
        const apiCall = async () => {
            const res = await SuperImageUserAPI(currentPage, itemPerPage);
            let { customerCount, customerData } = res;
            setData(customerData);
            customerCount.length === 1 ? setCount(customerCount[0].totalcount) : setCount(0);
            setLoading(false)
        }
        apiCall()
    }, [currentPage, itemPerPage])

    return (
        <>
            <Row className="rownew1">
                <Col lg={12}>
                    <Row className="page_header1 rownew1">
                        <div className="tableHeader tableHeader1 search_new">
                            <Col md={12} className="table_span">
                                <h3 className="page-title d-flex userv">
                                    <span>Search Results</span>
                                </h3>
                            </Col>
                        </div>
                    </Row>
                </Col>
            </Row>

            <Col lg={12}>
                <div className="box_detail" style={{ borderRadius: "4px" }}>
                    <div className="page-header row">
                        <Col md={12}>
                            <Form className="manage_searchorder">
                                < Row className="mg_row0">
                                    <Col lg={6} md={6}></Col>
                                    < Col lg={2} md={2} className="customer_sdate"></ Col>
                                    < Col lg={4} md={4}>
                                        < Row className="mg_row0">
                                            < Col lg={4}></ Col>
                                            < Col lg={8} className="">
                                                <Form.Group>
                                                    <Form.Control
                                                        type="text"
                                                        placeholder="Search by Text/Order ID"
                                                        onChange={handleChange}
                                                    />
                                                </Form.Group>
                                            </ Col>
                                        </ Row>
                                    </ Col>
                                </Row>
                            </Form>
                        </Col>
                    </div>
                </div>
            </Col>

            <Col lg={12}>
                <Row className="rownew1">
                    <div className="tableHeader tableHeader1 search_new">
                        <Col lg={6} md={6} xs={7} className="table_span">
                            <h3 className="page-title d-flex userv">
                                <span>Super Image User List</span>
                            </h3>
                        </Col>
                        <Col lg={6} md={6} xs={5} className="table_span text-right">
                            Total Count : {Count}
                        </Col>
                    </div>
                </Row>

                <div
                    className="box_detail table_boxdtl manage_order"
                    style={{ marginBottom: "0px" }}
                >
                    <Table striped bordered hover variant="dark" responsive>
                        <thead>
                            <tr>
                                <th>User Id</th>
                                <th>User Name</th>
                                <th>User Details</th>
                                <th>Date(First Image Download)</th>
                                <th>Total Download</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            {Loading ? <>
                                <td className="no_records" colSpan="11">
                                    Loading...
                                </td>
                            </> : Data.length > 0 ? Data.map((info) => {
                                let { _id, f_userid, f_email,
                                    activationdate, limit_img, f_status,
                                    ip_address
                                } = info
                                return (
                                    <tr key={_id}>
                                        <td>{f_userid}</td>
                                        <td>{f_email}</td>
                                        <td>
                                            limit img : {limit_img} <br />
                                            ip address : {ip_address}
                                        </td>
                                        <td>{Moment(activationdate).format("DD-MM-YYYY")}</td>
                                        <td>{limit_img}</td>
                                        <td>{f_status === 1 ? "ACTIVE" : "DEACTIVE"}</td>
                                        <td onClick={() => onView(f_email)}>view</td>
                                    </tr>
                                )
                            }) : <>
                                <td className="no_records" colSpan="11">
                                    No Records Found
                                </td>
                            </>}
                        </tbody>
                    </Table>
                </div>
                <PaginationComponent
                    MOCK_DATA={Count}
                    currentPage={currentPage}
                    setCurrentPage={setCurrentPage}
                    itemPerPage={itemPerPage}
                    setItemPerPage={setItemPerPage}
                />
            </Col>

            <SuperImgTableModel
                ShowModel={ShowModel}
                setShowModel={setShowModel}
                ViewData={ViewData}
            />
        </>
    )
}

export default SuperImageUser
