const SuspendImage = require("express").Router();
const { 
    getSuspendedImageList,
    suspendImage 
} = require("../../controllers/Master/master.suspendimages.controller")

SuspendImage.route(`/getsuspendedimages`).get(getSuspendedImageList);
SuspendImage.route(`/updatesuspendimages`).post(suspendImage);


module.exports = SuspendImage;