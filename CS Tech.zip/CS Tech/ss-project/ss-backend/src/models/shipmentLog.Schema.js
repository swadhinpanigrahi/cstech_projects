const Mongoose = require("mongoose");

const shipmentLogSchema = new Mongoose.Schema(
    {
        traking_id: { type: String },
        error: { type: Object }
    },
    { timestamps: true },
    { collection: "log_tbls" }
)

module.exports = shipmentLogSchema;
