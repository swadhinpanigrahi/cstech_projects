const mongoose = require("mongoose");

const MasterStarPeriodSchema = mongoose.Schema(
    {
        f_sno: { type: String },
        f_period: { type: String },
        f_cal: { type: Number },
    },
    { collection: "t_star_period" }
);

module.exports = M_STARPERIOD = mongoose.model(
    "t_star_period",
    MasterStarPeriodSchema
);