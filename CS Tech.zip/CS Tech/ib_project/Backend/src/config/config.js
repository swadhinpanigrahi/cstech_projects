const dotenv = require(`dotenv`);
dotenv.config();

module.exports = {
  PORT: process.env.PORT,
  JWT_TOKEN: process.env.JWT_TOKEN,
  SMTP_HOST: process.env.SMTP_HOST,
  SMTP_EMAIL: process.env.SMTP_EMAIL,
  SMTP_PASSWORD: process.env.SMTP_PASSWORD,
  SQL_URL: process.env.SQL_URL,
};

//smtp.gmail.com
//mails@cstech.in
//P@khi2107#
