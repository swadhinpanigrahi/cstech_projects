import React from "react";
import { Col } from "react-bootstrap";

const PageHeaders = ({ title }) => {
  return (
    <Col lg={12}>
      <div className="page-header row no-gutters pym-4">
        <Col md={12}>
          <h3 className="page-title">{title}</h3>
        </Col>
        <hr />
      </div>
    </Col>
  );
};

export default PageHeaders;
