const {
    invoiceSchema, t_invoice_IB_MongoDB,
    T_Orders_IB_MongoDB,
    t_LUS104576_IB_MongoDB, t_TUR0615518_IB_MongoDB
} = require("../model");

exports.getInvoiceDetail = async (req, res) => {
    const { f_orderid } = req.params
    try {
        const invoiceDetail = await t_invoice_IB_MongoDB.findOne(
            { orderid: f_orderid },
            { _id: 0, f_clientGSTIN_no: 1, invoice_date: 1, f_paymode: 1, Name: 1, Companyname: 1, f_client: 1, address: 1, orderby: 1, f_statecrm: 1, orderid: 1 }
        );
        const T_orderDetails = await T_Orders_IB_MongoDB.findOne(
            { T_orderid: invoiceDetail.orderid },
            { _id: 0, T_username: 1, f_discountType: 1, f_usertype: 1, f_CreaditPeriod: 1 }
        );

        const invoiceDetails = await invoiceSchema.find({ f_orderid });

        const LUS = await t_LUS104576_IB_MongoDB.findOne(
            { CS_username: T_orderDetails.T_username },
            { _id: 0, CS_email: 1, CS_mobile: 1, CS_userid: 1 }
        );

        const TUR = await t_TUR0615518_IB_MongoDB.findOne(
            { CS_userid: LUS.CS_userid },
            { _id: 0, CS_comment: 1, cs_discount: 1, CS_companynames: 1, group_cmpname: 1 }
        );

        res.json({ invoiceDetail, invoiceDetails, T_orderDetails, LUS, TUR });
    } catch (error) {
        res.json({ message: `Error in Controller`, error: error.message });
    }
};

exports.InvoiceUpdate = async (req, res) => {
    const { f_orderid } = req.params;
    const {
        Companyname, f_client, CS_comment, address, orderby, f_statecrm, f_clientGSTIN_no,
        find_info_mail, CS_companynames, group_cmpname, cs_discount,
        f_discountType, f_CreaditPeriod
    } = req.body;
    try {
        if (!find_info_mail) {
            const invoiceDetail = await t_invoice_IB_MongoDB.findOne({ orderid: f_orderid });
            await t_invoice_IB_MongoDB.updateOne(
                { _id: invoiceDetail._id },
                {
                    $set: {
                        Companyname, f_client, address, orderby, f_statecrm, f_clientGSTIN_no
                    }
                }
            )
        }

        if (find_info_mail) {
            console.log("m i calling", CS_comment, cs_discount, CS_companynames, group_cmpname)
            const invoiceDetail = await t_invoice_IB_MongoDB.findOne({ orderid: f_orderid });
            const T_orderDetails = await T_Orders_IB_MongoDB.findOne({ T_orderid: invoiceDetail.orderid });
            const LUS = await t_LUS104576_IB_MongoDB.findOne({ CS_username: T_orderDetails.T_username });
            const TUR = await t_TUR0615518_IB_MongoDB.findOne({ CS_userid: LUS.CS_userid });


            await t_invoice_IB_MongoDB.updateOne(
                { _id: invoiceDetail._id },
                {
                    $set: {
                        Companyname, f_client, address, orderby, f_statecrm, f_clientGSTIN_no
                    }
                }
            )

            await t_TUR0615518_IB_MongoDB.updateOne(
                { _id: TUR._id },
                {
                    $set: {
                        CS_comment, cs_discount, CS_companynames, group_cmpname
                    }
                }
            )

            await T_Orders_IB_MongoDB.updateOne(
                { _id: T_orderDetails._id },
                {
                    $set: {
                        f_discountType, f_CreaditPeriod
                    }
                }
            )
        }

        res.json({ status: 200, message: "invoice update successfully!" })

    } catch (error) {
        res.json({ message: `Error in Controller`, error: error.message });
    }
}

exports.InvoiceDropDown = async (req, res) => {
    const pipeline = [
        {
            $group: {
                _id: "$CS_companynames",
            },
        },
    ];
    try {
        const dropData = await t_TUR0615518_IB_MongoDB.aggregate(pipeline);
        res.json({ status: 200, dropData })
    } catch (error) {
        res.json({ message: `Error in Controller`, error: error.message });
    }
}

exports.getCompanyGroupName = async (req, res) => {
    let { CS_companynames } = req.body
    try {
        const GroupData = await t_TUR0615518_IB_MongoDB.findOne(
            { CS_companynames }, { CS_companynames: 1, group_cmpname: 1 }
        );
        res.json({ status: 200, GroupData })
    } catch (error) {
        res.json({ message: `Error in Controller`, error: error.message });
    }
}