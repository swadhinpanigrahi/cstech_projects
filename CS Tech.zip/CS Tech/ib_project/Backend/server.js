const express = require("express");
const mongoose = require("./src/config/database");
const CORS = require("cors");
const morgan = require("morgan");
var path = require('path');
const bodyParser = express.json();
// const bodyParser1 = require('body-parser')
const apiRouter = require("./src/routers");
const { PORT } = require("./src/config/config");
const fileUpload = require('express-fileupload');
function main() {
  const app = express();
  app.use(bodyParser);
  app.use(fileUpload());
  app.use(CORS());
  app.use(express.static(path.join(__dirname, 'public')));
  //   app.use(bodyParser1.json());
  // app.use(bodyParser1.urlencoded({
  // extended: false
  // }));
  app.use(morgan("dev"));
  mongoose;
  app.use("/api", apiRouter);
  app.listen(PORT, () => {
    console.log(`Running on PORT: ${PORT}`);
  });
}

main();
