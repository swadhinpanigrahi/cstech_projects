var express = require('express');
var router = express.Router();



var { updateUserDetailsSqlToMongo,removeUserSqlToMongo,RemoveOrderSqlToMongo,RejectOrderSqlToMongo,confirmOrderSqlToMongo,updateInvoiceSqlToMongo,updateCompanySqlToMongo,RemoveProposalSqlToMongo,CreateFollowUpSqlToMongo } = require('../controllers/apiformongo.controller')
router.post('/updateUserDetailsSqlToMongo/:f_userid', updateUserDetailsSqlToMongo)
router.post('/removeUserSqlToMongo',removeUserSqlToMongo)
router.post('/RemoveOrderSqlToMongo/:T_orderid',RemoveOrderSqlToMongo)
router.post('/RejectOrderSqlToMongo/:T_orderid',RejectOrderSqlToMongo)
router.post('/confirmOrderSqlToMongo',confirmOrderSqlToMongo)
router.post('/updateInvoiceSqlToMongo',updateInvoiceSqlToMongo)
router.post('/updateCompanySqlToMongo',updateCompanySqlToMongo)
router.post('/RemoveProposalSqlToMongo',RemoveProposalSqlToMongo)
router.post('/CreateFollowUpSqlToMongo',CreateFollowUpSqlToMongo)

module.exports = router;