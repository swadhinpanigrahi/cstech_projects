const mongoose = require("mongoose");

const T_Orders_IB_MongoDB_Schema = mongoose.Schema(
  {
    T_orderid: { type: String },
    T_username: { type: String },
    T_userid: { type: String },
    T_orderdate: { type: Date, default: Date.now() },
    T_paymode: { type: String },
    T_status: { type: String, default: "P" },
    T_condate: { type: Date, default: Date.now() },
    t_comment: { type: String, default: "" },
    t_client: { type: String },
    t_orderedby: { type: String },
    t_download: { type: String, default: "" },
    t_paymentstatus: { type: String, default: "Unpaid" },
    t_paymentdate: { type: Date, default: null },
    t_purchaseorder: { type: String, default: "" },
    t_followup_status: { type: Number, default: 0 },
    t_invoiceid: { type: String, default: null },
    f_nextfollowupsdate: { type: String, default: null },
    f_TodayFollowup: { type: String, default: null },
    f_remarks: { type: String, default: null },
    f_paidBy: { type: String, default: null },
    f_bouncedchequedesc: { type: String, default: "" },
    f_assignto: { type: String, default: "" },
    f_paidDate: { type: Date, default: null },
    f_companytag: { type: String, default: "" },
    f_usertype: { type: String, default: "" },
    f_Discountterms: { type: String, default: null },
    f_dis_per: { type: String, default: "" },
    f_CreaditPeriod: { type: String, default: "" },
    f_discountType: { type: String, default: "" },
    f_orderType: { type: String, default: "" },
    f_planid: { type: Number, default: 0 },
    f_maxallowed: { type: Number, default: 0 },
    f_days: { type: Number, default: 0 },
    f_subscriptionUpgradeAtive: { type: Number, default: 0 },
    f_invoiceUpgrade: { type: String, default: "0" },
    f_upgreadeAmount: { type: String, default: "0" },
    f_orderCompany: { type: String, default: null },
    f_orderCompanyTag: { type: String, default: null },
    f_partpay: { type: Number, default: 0 },
    f_PreOrderid: { type: String, default: "0" },
    f_clientGSTIN_no: { type: String },
    uploadedImg: { type: String, default: "" },
    f_invoiceID: { type: String, default: "" },
    f_orderAmt: { type: Number }
  },
  { collection: "T_Orders_IB_MongoDB" }
);

module.exports = T_Orders_IB_MongoDB = mongoose.model(
  "T_Orders_IB_MongoDB",
  T_Orders_IB_MongoDB_Schema
);
