const mongoose = require("mongoose");

const t_ordproposal_details_IB_MongoDB_Schema = mongoose.Schema(
	{
		t_sno: { type: Number },
		t_orderid: { type: String },
		t_imageid: { type: String },
		t_price: { type: Number },
		t_quality: { type: String },
		f_image_type: { type: String, default: "I" },
		CS_ImgType_up: { type: String, default: null },
		f_country: { type: String, default: null },
		f_state: { type: String },
		f_mydimension: { type: String },
		f_duration: { type: String, default: null },
		f_plantype: { type: String, default: null },
		f_industry: { type: String, default: null },
		f_rights: { type: String, default: "Exclusive" },
		f_groupid: { type: String, default: "" },
		f_rank: { type: Number }
	},
	{ collection: "t_ordproposal_details_IB_MongoDB" }
);

module.exports = t_ordproposal_details_IB_MongoDB = mongoose.model(
	"t_ordproposal_details_IB_MongoDB",
	t_ordproposal_details_IB_MongoDB_Schema
);