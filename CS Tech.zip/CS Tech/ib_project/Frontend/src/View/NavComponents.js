// profile section
import ChangePassword from "./DashboardSection/ChangePassword";
// input search
import Usersearch from "./DashboardSection/Usersearch";
import UsersearchViewAll from "./DashboardSection/UsersearchViewAll";
import UserButtonSearch from "./DashboardSection/UserButtonSearch";
//Actions
import UserAction from "./DashboardSection/UserAction";
import UserActionEdit from "./DashboardSection/UserActionEdit";
import ProposalView from "./DashboardSection/proposalAction/ProposalView";
import CompanyAction from "./DashboardSection/CompanyAction";
//Order Action
import Orderdetails from "./DashboardSection/Orderdetails";
import Invoicedetails from "./DashboardSection/Invoicedetails";
// dashboard section
import CreateFollowups from "./DashboardSection/CreateFollowups";
import Home from "./DashboardSection/HomeSection/Home";
import CustomerSection from "./DashboardSection/CustomerSection"
import OrderSection from "./DashboardSection/OrderSection"
import AdminProfile from "./DashboardSection/AdminProfile";
import ProposalList from "./DashboardSection/proposalAction/ProposalList";
import ProposalSection from "./DashboardSection/ProposalSection";

import DailySalesEntryList from "./DashboardSection/DailySalesEntryList";

import MasterSection from "./DashboardSection/MasterSection";

import ImageSection from "./DashboardSection/ImageSection";

import KeySectrion from "./DashboardSection/KeySection";

export const ROUTES = [
    {
        path: "/dashboard/home",
        Components: Home,
    },
    {
        path: "/dashboard/searchdata",
        Components: Usersearch,
    },
    {
        path: "/dashboard/changepassword",
        Components: ChangePassword,
    },
    {
        path: "/dashboard/viewalldata/:tbl_name",
        Components: UsersearchViewAll,
    },
    {
        path: "/dashboard/btndata/:T_username",
        Components: UserButtonSearch,
    },
    {
        path: "/dashboard/useraction/:f_userid/:path",
        Components: UserAction,
    },
    {
        path: "/dashboard/proposalview/:_id",
        Components: ProposalView,
    },
    {
        path: "/dashboard/groupdetails/:f_userid",
        Components: CompanyAction,
    },
    {
        path: "/dashboard/createfollowups",
        Components: CreateFollowups,
    },
    {
        path: "/dashboard/useractioneditprofile/:f_userid/:path",
        Components: UserActionEdit,
    },
    {
        path: "/dashboard/orderdetails/:orderId",
        Components: Orderdetails,
    },
    {
        path: "/dashboard/invoicedetails/:orderId",
        Components: Invoicedetails,
    },
    {
        path: "/dashboard/adminProfile/:userId",
        Components: AdminProfile,
    },
    {
        path: "/dashboard/proposal/proposallist",
        Components: ProposalList,
    },
    {
        path: "/dashboard/customer",
        Components: CustomerSection
    },
    {
        path: "/dashboard/order",
        Components: OrderSection
    },
    {
        path: "/dashboard/proposal",
        Components: ProposalSection
    },
    {
        path: "/dashboard/dailysalesentry",
        Components: DailySalesEntryList
    },
    {
        path: "/dashboard/master",
        Components: MasterSection
    },
    {
        path: "/dashboard/image",
        Components: ImageSection
    },
    {
        path: "/dashboard/keyword",
        Components: KeySectrion
    }
];