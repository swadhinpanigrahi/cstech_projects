import React from 'react';
import { Link } from "react-router-dom";
import logo from "../../Images/final_logon.png";

const Logout = () => {
    return (
        <>
            <div id="logouta">
                <div className="logo">
                    <img src={logo} className="new_logod" alt="Storage Station" />
                </div>
                <div className="boxes">
                    {/* <h4 className="title logout_title">{t("change.l_o_uhaveso")}</h4> */}
                    <h4 className="title">You have been signed out</h4>
                    {/* <h6 className="text-center">{t("change.l_o_asypy")}</h6> */}
                    <h6 className="text-center">
                        To access your panel you will need to login again.
                    </h6>
                    <h6 className="text-center" style={{ fontWeight: "bold" }}>
                        <Link to="/" style={{ color: "#f3a03f", letterSpacing: ".5px" }}>
                            {/* {t("change.l_o_trytolog")} */}
                            Try to log in again.
                        </Link>
                    </h6>
                </div>
                {/* <div className="copy">{t("change.c_footer")}</div> */}
                <div className="copy">copyright © 2021 www.storagestation.net, all rights reserved</div>
            </div>
        </>
    )
}

export default Logout
