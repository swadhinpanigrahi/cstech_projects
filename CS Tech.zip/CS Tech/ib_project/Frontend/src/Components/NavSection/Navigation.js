import React, { useState, useEffect } from "react";
import "./Navbar.css";
import Dropdown from "./Dropdown";
import OrderDropDown from "./Lists/OrderDropDown";
import ListDropDown from "./Lists/ListDropDown";
import KeyDropDown from "./Lists/KeyDropDown";
import CustomerDropDown from "./Lists/CustomerDropDown";

import { Nav, NavDropdown, Row, Col } from "react-bootstrap";
import { useHistory, Link } from "react-router-dom";
import { AiOutlineUser } from "react-icons/ai";
import { BiLockOpenAlt } from "react-icons/bi";
import { FiLogOut } from "react-icons/fi";
import { useAuth } from "../../Utils/auth";
import { logOutApi, verifyProfile } from "../../Utils/api";

const NavNavigation = () => {

  let history = useHistory();

  const [click, setClick] = React.useState(false);
  const [cdropdown, setcDropdown] = useState(false);
  const [dropdown, setDropdown] = useState(false);
  const [mdropdown, setmDropdown] = useState(false);
  const [ldropdown, setlDropdown] = useState(false);
  const [kdropdown, setkDropdown] = useState(false);

  const [name, setName] = useState("");
  const [userId, setUserId] = useState("");

  const handleClick = () => setClick(!click);
  const closeMobileMenu = () => setClick(false);

  const oncMouseEnter = () => {
    if (window.innerWidth < 960) {
      setcDropdown(false)
    } else {
      setcDropdown(true)
    }
  };

  const oncMouseLeave = () => {
    if (window.innerWidth < 960) {
      setcDropdown(false)
    } else {
      setcDropdown(false)
    }
  };

  const onMouseEnter = () => {
    if (window.innerWidth < 960) {
      setDropdown(false)
    } else {
      setDropdown(true)
    }
  };

  const onMouseLeave = () => {
    if (window.innerWidth < 960) {
      setDropdown(false)
    } else {
      setDropdown(false)
    }
  };

  const onmMouseEnter = () => {
    if (window.innerWidth < 960) {
      setmDropdown(false)
    } else {
      setmDropdown(true)
    }
  };

  const onmMouseLeave = () => {
    if (window.innerWidth < 960) {
      setmDropdown(false)
    } else {
      setmDropdown(false)
    }
  };

  const onlMouseEnter = () => {
    if (window.innerWidth < 960) {
      setlDropdown(false)
    } else {
      setlDropdown(true)
    }
  };

  const onlMouseLeave = () => {
    if (window.innerWidth < 960) {
      setlDropdown(false)
    } else {
      setlDropdown(false)
    }
  };

  const onkMouseEnter = () => {
    if (window.innerWidth < 960) {
      setkDropdown(false)
    } else {
      setkDropdown(true)
    }
  };

  const onkMouseLeave = () => {
    if (window.innerWidth < 960) {
      setkDropdown(false)
    } else {
      setkDropdown(false)
    }
  };

  let auth = useAuth();
  const logOut = async () => {
    await logOutApi();
    history.push("/logout");
    setTimeout(() => {
      auth.signout(() => history.push("/"));
    }, 3000);
  };

  const UserProfile = async () => {
    history.push("/dashboard/adminProfile/" + userId);
  };

  useEffect(() => {
    const isVarify = async () => {
      const res = await verifyProfile();
      let { message, tokenData } = res;
      if (message === "verifyed") {
        console.log(tokenData);
        setName(tokenData.username);
        setUserId(tokenData.id);
      }
    };
    isVarify();
  }, []);

  return (
    <>
      <nav className="navbar" onClick={(e) => e.stopPropagation()}>
        <div className="menu-icon" onClick={handleClick}>
          <i className={click ? "fa fa-times" : "fa fa-bars"}></i>
        </div>
        <ul className={click ? "nav-menu active" : "nav-menu"}>
          <li className="nav-item">
            <Link to="/dashboard/home" className="nav-link" onClick={closeMobileMenu}>
              HOME
            </Link>
          </li>
          <li className="nav-item"
            onMouseEnter={oncMouseEnter}
            onMouseLeave={oncMouseLeave}
          >
            <Link to="#" className="nav-link" onClick={closeMobileMenu}>
              CUSTOMER <i className="fa fa-caret-down"></i>
            </Link>
            {cdropdown && <CustomerDropDown />}
          </li>
          <li className="nav-item"
            onMouseEnter={onMouseEnter}
            onMouseLeave={onMouseLeave}
          >
            <Link to="#" className="nav-link" onClick={closeMobileMenu}>
              MASTER <i className="fa fa-caret-down"></i>
            </Link>
            {dropdown && <Dropdown />}
          </li>
          <li className="nav-item"
            onMouseEnter={onmMouseEnter}
            onMouseLeave={onmMouseLeave}
          >
            <Link to="#" className="nav-link" onClick={closeMobileMenu}>
              ORDERS <i className="fa fa-caret-down"></i>
            </Link>
            {mdropdown && <OrderDropDown />}
          </li>

          <li className="nav-item"
            onMouseEnter={onlMouseEnter}
            onMouseLeave={onlMouseLeave}
          >
            <Link to="#" className="nav-link" onClick={closeMobileMenu}>
              IMAGE <i className="fa fa-caret-down"></i>
            </Link>
            {ldropdown && <ListDropDown />}
          </li>

          <li className="nav-item"
            onMouseEnter={onkMouseEnter}
            onMouseLeave={onkMouseLeave}
          >
            <Link to="#" className="nav-link" onClick={closeMobileMenu}>
              KEYWORD <i className="fa fa-caret-down"></i>
            </Link>
            {kdropdown && <KeyDropDown />}
          </li>

        </ul>

        <NavDropdown title={name} id="basic-nav-dropdown" className="profile_navdropdown">
          <NavDropdown.Item onClick={UserProfile}>
            <AiOutlineUser className="profile_svg" />Profile
          </NavDropdown.Item>
          <NavDropdown.Divider />
          <NavDropdown.Item as={Link} to="/dashboard/changepassword">
            <BiLockOpenAlt className="profile_svg" />Change Password
          </NavDropdown.Item>
          <NavDropdown.Divider />
          <NavDropdown.Item onClick={logOut} className="text-danger">
            <FiLogOut className="text-danger profile_svg" />Log Out
          </NavDropdown.Item>
        </NavDropdown>
        {/* <div className="nav-icon" onClick={handleClick}>
          <i className={click ? "fa fa-times" : "fa fa-bars"}></i>
        </div> */}

      </nav>
    </>
  )
}

export default NavNavigation