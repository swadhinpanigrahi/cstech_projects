import React, { useState, useEffect } from "react";
import * as RB from "react-bootstrap";
import Moment from "moment";

const OrderDetailsModel = ({
  OrderDetailsIsOpen,
  CloseOrderDetails,
  OrderDataObj,
  OrderDataList,
  OrderUser
}) => {

  let [TotalAmount, setTotalAmount] = useState("");
  let [DiscountAmount, setDiscountAmount] = useState("");

  useEffect(() => {
    let Amount = 0;
    let Discount = 0;
    OrderDataList.forEach(element => {
      Amount += element.t_price
      Discount += element.t_disc_price
    });
    setTotalAmount(Amount);
    setDiscountAmount(Discount)
  }, [OrderDataList]);

  const Tax = (TotalAmount * 18) / 100;
  const PaybleAmount = TotalAmount - DiscountAmount
  return (
    <div>
      <RB.Modal
        show={OrderDetailsIsOpen}
        onHide={CloseOrderDetails}
        id="orders_modal"
      >
        <RB.Modal.Header closeButton>
          <RB.Modal.Title>Order Details</RB.Modal.Title>
        </RB.Modal.Header>
        <RB.Modal.Body className="invoice_modalbody">
          <RB.Row>
            <RB.Col lg={6}>
              <span className="logo-invoice">
                <img className="logoinv_img"
                  src="http://ibcdn.imagesbazaar.com/Html2015/images/logo_imagesBazaar.png"
                  alt="img_img1"
                />
              </span>
            </RB.Col>
            <RB.Col lg={6} className="text-right">
              {/* <a href="javascript:print()" className="print_invoice">
                <i className="fa fa-print"></i>
              </a> */}
            </RB.Col>
          </RB.Row>
          <div className="main_orders">
            <RB.Row className="headinv" id="invoicem">
              <RB.Col lg={6} className="right_bordertd_detail">
                <p>
                  <strong>Mash Audio Visuals Private Limited</strong>
                </p>
                <p>505, Aggarwal Prestige Mall, Plot No. 2,</p>
                <p>Road No. 44, Pitam Pura, New Delhi - 110034</p>
                <p>Phone: (+91) 11 66545466 | (+91) 11 66545465</p>
                <p class="p_txt">
                  <strong>CIN: </strong> U92111DL2003PTC122096
                </p>
                <p class="p_txt">
                  <strong>GSTIN:</strong> 07AADCM6333L1ZA
                </p>
                <p class="p_txt">
                  <strong>PAN: </strong>AADCM6333L
                </p>
              </RB.Col>
              <RB.Col lg={6} className="pd_0">
                <RB.Table responsive>
                  <tbody>
                    <tr className="border_btm">
                      <td className="td_first">
                        <p class="mg-b-0">
                          <strong>Date:</strong>
                          {Moment(OrderDataObj.T_orderdate).format("DD-MM-YYYY")}
                        </p>
                      </td>
                      <td className="td_second">
                        <p class="mg-b-0">
                          {/* <strong>Invoice No.:</strong> 117156 */}
                        </p>
                      </td>
                    </tr>
                    <tr className="border_btm">
                      <td className="td_first">
                        <p class="mg-b-0">
                          <strong>Order Confirmation No.:</strong> {OrderDataObj.T_orderid}
                        </p>
                      </td>
                      <td className="td_second">
                        <p class="mg-b-0">
                          <strong>HSN/SAC:</strong> 998439
                        </p>
                      </td>
                    </tr>
                    <tr className="border_btm">
                      <td className="td_first">
                        <p class="mg-b-0">
                          <strong>Mode of Payment:</strong> {OrderDataObj.T_paymode}
                        </p>
                      </td>
                      {/* <td className="td_second">
                        <p class="mg-b-0">
                          <strong>State Code:</strong> {OrderUser.f_pin}
                        </p>
                      </td> */}
                    </tr>
                    <tr className="border_btm">
                      <td className="td_first">
                        <p class="mg-b-0">
                          <strong>Payment Status:</strong> {OrderDataObj.t_paymentstatus}
                        </p>
                      </td>
                      <td className="td_second">
                        <p class="mg-b-0">
                          <strong>State:</strong> {OrderUser.f_state}
                        </p>
                      </td>
                    </tr>
                  </tbody>
                </RB.Table>
                <RB.Table responsive>
                  <tbody>
                    <tr>
                      <td className="text-left">
                        <p>
                          <strong>Reverse Charges Applicability:</strong> Not
                          Applicable
                        </p>
                        <p>
                          <strong>Place of Supply:</strong> {OrderDataObj.f_state}
                        </p>
                      </td>
                    </tr>
                  </tbody>
                </RB.Table>
              </RB.Col>
            </RB.Row>

            <RB.Row className="headinv" id="invoicem">
              <RB.Col lg={6} className="right_bordertd_detail">
                <p>
                  <strong>Party’s Name:</strong>
                </p>
                <p>{OrderUser.f_companyname}</p>
                <p>{OrderUser.f_address}</p>
                <p>{`${OrderUser.f_state} - ${OrderUser.f_pin}, ${OrderUser.f_country}`}</p>
                <p>
                  <strong>State:</strong> {OrderUser.f_state}{" "}
                  {/* <span style={{ paddingLeft: "10px" }}>
                    <strong>State Code:</strong> {OrderUser.f_pin}
                  </span> */}
                </p>
                <p className="p_txt">
                  <strong>GSTIN:</strong> {OrderDataObj.f_clientGSTIN_no}
                </p>
              </RB.Col>
              <RB.Col lg={6} className="pd_0">
                <RB.Table responsive>
                  <tbody>
                    <tr className="">
                      <td className="text-left">
                        <p>
                          <strong>Client Name:</strong> {OrderDataObj.t_client}
                        </p>
                        <p>
                          <strong>Order By:</strong> {OrderDataObj.t_orderedby}
                        </p>
                      </td>
                    </tr>
                  </tbody>
                </RB.Table>
              </RB.Col>
            </RB.Row>

            <RB.Row className="headinv">
              <RB.Col lg={12} className="pd_0 order_modal_table">
                <RB.Table responsive>
                  <thead className="thead-dark">
                    <tr>
                      <th className="td_first text-center">Image</th>
                      <th className="td_first text-center">{OrderDataObj.f_orderType === "Plan" ? "Plan Name" : "Item ID"}</th>
                      <th className="td_first text-center">
                        {OrderDataObj.f_orderType === "Plan" ? "No of Videos" : "Image Type"}
                      </th>
                      {OrderDataObj.f_orderType === "Plan" ? null : <th className="td_first text-center">Dimension (Px)</th>}
                      <th className="text-right">Value</th>
                    </tr>
                  </thead>
                  <tbody>
                    {OrderDataList.map((data, inx) => (
                      <tr className="border_btm" key={"orderInvoice" + inx}>
                        {OrderDataObj.f_orderType === "Plan" || OrderDataObj.f_orderType === "IV" ?
                          <td className="td_first text-center">
                            {data.t_quality === 'Large Size' ? <img src="https://old.imagesbazaar.com/imagesvideoimg/images/CheckoutLARGE.png" alt="invoiceimg" /> : ""}
                            {data.t_quality === 'Web-Size' ? <img src="https://old.imagesbazaar.com/imagesvideoimg/images/CheckoutSMALL.png" alt="invoiceimg" /> : ""}
                            {data.t_quality === 'Medium-Size' ? <img src="https://old.imagesbazaar.com/imagesvideoimg/images/CheckoutMEDIUM.png" alt="invoiceimg" /> : ""}
                            {data.t_quality === 'Small-Size' ? <img src="https://old.imagesbazaar.com/imagesvideoimg/images/CheckoutSMALL.png" alt="invoiceimg" /> : ""}
                            {data.t_quality === 'XL-Size' ? <img src="https://old.imagesbazaar.com/imagesvideoimg/images/CheckoutXL.png" alt="invoiceimg" /> : ""}
                            {data.t_quality === 'XXL-Size' ? <img src="https://old.imagesbazaar.com/imagesvideoimg/images/CheckoutXXL.png" alt="invoiceimg" /> : ""}
                          </td>
                          :
                          <td className="td_first text-center">
                            <img src={`https://ibcdn.imagesbazaar.com/img170/${data.f_rank}-${data.t_imageid}.jpg`} alt="invoiceimg" />
                          </td>
                        }

                        {OrderDataObj.f_orderType === "Plan" || OrderDataObj.f_orderType === "IV" ?
                          <td className="td_first text-center">
                            <p class="mg-b-0">{data.t_quality}</p>
                          </td>
                          :
                          <td className="td_first">
                            <p class="mg-b-0">{data.t_imageid}</p>
                          </td>
                        }

                        {OrderDataObj.f_orderType === "Plan" || OrderDataObj.f_orderType === "IV" ?
                          <td className="td_first text-center">
                            <p class="mg-b-0">{data.t_imageid}</p>
                          </td>
                          :
                          <td className="td_first text-center">
                            <p class="mg-b-0">{data.t_quality}</p>
                          </td>
                        }

                        {OrderDataObj.f_orderType === "Plan" || OrderDataObj.f_orderType === "IV" ?
                          null
                          :
                          <td className="td_first text-center">
                            <p class="mg-b-0">{data.f_mydimension}</p>
                          </td>
                        }

                        <td className="td_second">
                          <p class="mg-b-0">{data.t_price}</p>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </RB.Table>
              </RB.Col>
            </RB.Row>
            <RB.Row className="headinv">
              <RB.Col lg={12} className="pd_0 amount_orderdtl">
                <RB.Table responsive>
                  <tbody>
                    <tr className="border_btm">
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td className="text-right td_first">
                        <p className="mg-b-0 resblock">
                          <strong>Total Value (INR)</strong>
                        </p>
                      </td>
                      <td className="text-right">
                        <p class="mg-b-0">{TotalAmount}</p>
                      </td>
                    </tr>
                    <tr className="border_btm">
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td className="text-right td_first">
                        <p className="mg-b-0 resblock">
                          <strong>GST Value @18% (INR)</strong>
                        </p>
                      </td>
                      <td className="text-right">
                        <p class="mg-b-0">{Tax}</p>
                      </td>
                    </tr>
                    <tr className="border_btm">
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td className="text-right td_first">
                        <p className="mg-b-0 resblock">
                          <strong>Discount</strong>
                        </p>
                      </td>
                      <td className="text-right">
                        <p class="mg-b-0">{DiscountAmount}</p>
                      </td>
                    </tr>
                  </tbody>
                </RB.Table>
                <RB.Table responsive>
                  <tbody>

                    <tr>
                      <td className="text-right inv_rightdtl">
                        <p className="mg-b-0">
                          <strong>
                            Total Amount Before GST (SGST / UGST / CGST / IGST)
                          </strong>
                        </p>
                      </td>
                      <td className="text-right">
                        <p className="mg-b-0">{PaybleAmount}</p>
                      </td>
                    </tr>
                    <tr>
                      <td className="text-right inv_rightdtl">
                        <p className="mg-b-0">
                          <strong>
                            Total Amount Payable Inclusive of GST (SGST / UGST /
                            CGST / IGST)
                          </strong>
                        </p>
                      </td>
                      <td className="text-right">
                        <p className="mg-b-0">{PaybleAmount + Tax}</p>
                      </td>
                    </tr>
                  </tbody>
                </RB.Table>
                <RB.Table responsive>
                  <tbody>
                    <tr>
                      <td className="text-left">
                        <p className="mg-b-0">
                          ImagesBazaar is a unit of Mash Audio Visuals Pvt. Ltd.
                          Usage of content subject to Mash Rights Agreement
                          mentioned on{" "}
                          <a href="#0">www.Imagesbazaar.com/licensing.aspx</a>
                        </p>
                      </td>
                    </tr>
                  </tbody>
                </RB.Table>
                <RB.Table responsive>
                  <tbody>
                    <tr>
                      <td
                        style={{ width: "65%" }}
                        className="text-left td_first"
                      >
                        <p className="mg-b-0">
                          If you have any problem with your order, please call
                          us at <a href="#0">+91-9911366666</a> or{" "}
                          <a href="#0">+91-1166545466</a> or send us a message
                          at{" "}
                          <a href="mailto:orders@imagesbazaar.com">
                            orders@imagesbazaar.com
                          </a>
                        </p>
                      </td>
                      <td style={{ width: "35%" }}>
                        <p className="">For Mesh Audio Visuals Pvt. Ltd.</p>
                        <p className="mg-b-0 text-center signature">
                          Authorised Signatory
                        </p>
                      </td>
                    </tr>
                  </tbody>
                </RB.Table>
              </RB.Col>
            </RB.Row>
          </div>

          <div className="col-md-12" style={{ marginBottom: "20px" }}>
            <div className="text-center">
              <h6
                style={{ fontWeight: "bold", color: "#000", marginTop: "10px" }}
              >
                WE THINK YOU FOR YOUR BUSINESS. WE VALUE YOUR PATRONAGE
              </h6>
            </div>
          </div>
        </RB.Modal.Body>
      </RB.Modal >
    </div >
  );
};

export default OrderDetailsModel;
