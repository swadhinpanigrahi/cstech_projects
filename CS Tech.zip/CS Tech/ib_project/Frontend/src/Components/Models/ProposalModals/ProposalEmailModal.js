import React, { useState } from 'react';
import * as RB from "react-bootstrap";
import { sendProposalViewEmail } from "../../../Utils/api"

const ProposalEmailModal = ({ ProposalEmail, setProposalEmail, T_orderid }) => {

    const [FormData, setFormData] = useState({})

    const PROPOSAL_EMAIL_CLOSE = () => setProposalEmail(false);

    const handleChange = (e) => {
        let { name, value } = e.target;
        const data = { ...FormData };
        data[name] = value;
        setFormData(data);
    }

    const sendMail = async () => {
        const res = await sendProposalViewEmail({ ...FormData, T_orderid });
        const { message } = res;
        window.alert(message)
        console.log({ ...FormData, T_orderid })
    }

    return (
        <>
            <RB.Modal show={ProposalEmail} onHide={PROPOSAL_EMAIL_CLOSE} className="ordermanage_modal send_proposalmail">
                <RB.Modal.Header closeButton>
                    <RB.Modal.Title>Send Proposal Mail</RB.Modal.Title>
                </RB.Modal.Header>
                <RB.Modal.Body>
                    <RB.Row>
                        <RB.Col lg={12} md={12}>
                            <RB.Row>
                                <RB.Col lg={12} md={12}>
                                    <RB.Form>
                                        <RB.Form.Group as={RB.Row} controlId="formbasicemailo">
                                            <RB.Col lg={3} md={4}>
                                                <RB.Form.Label>Proposal ID :</RB.Form.Label>
                                            </RB.Col>
                                            <RB.Col lg={6} md={7}>
                                                <p>{T_orderid}</p>
                                            </RB.Col>
                                        </RB.Form.Group>
                                        <RB.Form.Group as={RB.Row} controlId="formbasicamount">
                                            <RB.Col lg={3} md={4}>
                                                <RB.Form.Label>Client Email :</RB.Form.Label>
                                            </RB.Col>
                                            <RB.Col lg={6} md={7}>
                                                <RB.Form.Control
                                                    name="email"
                                                    onChange={handleChange}
                                                    type="text"
                                                    placeholder="Enter Email" />
                                            </RB.Col>
                                        </RB.Form.Group>

                                        <RB.Row>
                                            <RB.Col lg={3} md={4}></RB.Col>
                                            <RB.Col lg={6} md={7}>
                                                <RB.Button size="sm" variant="primary"
                                                    onClick={sendMail}
                                                >
                                                    CONFIRM
                                                </RB.Button>
                                            </RB.Col>
                                        </RB.Row>
                                    </RB.Form>
                                </RB.Col>
                            </RB.Row>
                        </RB.Col>
                    </RB.Row>
                </RB.Modal.Body>
            </RB.Modal>
        </>
    )

}

export default ProposalEmailModal
