import React, { useState, useEffect } from 'react';
import * as RB from "react-bootstrap";
import { getProposalDetails, insertDataIntoCart } from "../../../Utils/api";
// import ProposalInsertCart from "../../Models/ProposalModals/ProposalInsertCart";
import Moment from 'moment';
import { useParams } from "react-router-dom";

const ProposalAdditionalView = () => {
    const { T_orderid } = useParams()

    const [ProposalState, setProposalState] = useState({
        ProposalData: {},
        ProposalArray: [],
        UserData: {}
    });
    const [InsertCart, setInsertCart] = useState(false);
    const [FormData, setFormData] = useState({
        orderid: T_orderid,
    })

    // const PROPOSAL_VIEW_CLOSE = () => setProposalView(false);
    const InsertCart_Close = () => setInsertCart(true);

    const handleChange = (e) => {
        const { name, value } = e.target;
        const data = { ...FormData };
        data[name] = value;
        setFormData(data)
    }

    const insertCart = async () => {
        const returnData = await insertDataIntoCart({ list: ProposalArray, email: FormData.email })
        console.log(returnData, FormData);
        setInsertCart(false);
    }

    useEffect(() => {
        const GET_API = async () => {
            const res = await getProposalDetails(T_orderid);
            console.log("getProposalDetails : ", res)
            let { status, proposalDetails, proposalDetail, userDetails } = res;
            if (status === 200) {
                const updatedState = { ...ProposalState };
                updatedState.ProposalData = proposalDetail;
                updatedState.ProposalArray = proposalDetails;
                updatedState.UserData = userDetails;
                setProposalState(updatedState);
            }
        }
        GET_API()
    }, [T_orderid]);

    let { ProposalData, ProposalArray, UserData } = ProposalState;

    let totalAmount = 0;
    let discount = 0;

    return (
        <>
            {/* <RB.Modal show={ProposalView} onHide={PROPOSAL_VIEW_CLOSE} id="proposal_modal"> */}
            {/* <RB.Modal.Header closeButton> */}
            <h1>Quotation</h1>
            {/* </RB.Modal.Header> */}
            {/* <RB.Modal.Body className=""> */}
            <RB.Row>
                <RB.Col lg={6} md={6}>
                    {/* <FiPrinter /> */}
                </RB.Col>
                <RB.Col lg={6} md={6}>
                    <div className="float-right">
                        <RB.Button block className="goBtnm btn btn-sm mx-auto mb-2" onClick={InsertCart_Close}>Insert Shopping Cart</RB.Button>
                    </div>
                </RB.Col>
            </RB.Row>
            <div className="main_orders">
                <RB.Row className="headinv" id="invoicem" style={{ borderBottom: "0px" }}>
                    <RB.Col lg={12} className="pd_0">
                        <RB.Table responsive>
                            <tbody>
                                <tr className="border_btm">
                                    <td className="td_first text-left">
                                        <p class="mg-b-0">
                                            <strong>Quotation No.:</strong> {ProposalData.T_orderid}
                                        </p>
                                    </td>
                                    <td className="td_second text-left">
                                        <p class="mg-b-0">
                                            <strong>Date:</strong>  {Moment(ProposalData.T_orderdate).format('DD-MM-YYYY')}
                                        </p>
                                    </td>
                                </tr>
                                <tr className="border_btm">
                                    <td className="td_first text-left">
                                        <p class="mg-b-0">
                                            <strong>Kind Attn:</strong> {UserData.f_email}
                                        </p>
                                    </td>
                                    <td className="td_second text-left">
                                        <p class="mg-b-0">
                                            <strong>Credit period:</strong> {ProposalData.f_Creditperiod}
                                        </p>
                                    </td>
                                </tr>
                                <tr className="border_btm">
                                    <td className="td_first text-left">
                                        <p class="mg-b-0">
                                            <strong>GSTIN No :</strong> {ProposalData.f_GSTNNo}
                                        </p>
                                    </td>
                                    <td className="td_second text-left">
                                        <p class="mg-b-0">
                                            <strong>Client Name.:</strong> {ProposalData.f_client}
                                        </p>
                                    </td>
                                </tr>
                            </tbody>
                        </RB.Table>
                    </RB.Col>
                </RB.Row>

                <RB.Row className="headinv" id="invoice1">
                    <RB.Col lg={12} className="pd_0">
                        <RB.Table striped bordered hover variant="dark" responsive style={{ border: "1px solid #dee2e6" }}>
                            <thead>
                                <tr class="proposal_th">
                                    <th className="td_first text-center">Image</th>
                                    <th className="td_first text-center">Item ID</th>
                                    <th className="td_first text-center">Type</th>
                                    <th className="td_first text-center">Dimension (Px)</th>
                                    <th className="td_first text-center">Rights</th>
                                    <th className="text-right">Value</th>
                                </tr>
                            </thead>
                            <tbody>
                                {ProposalArray.map((info, inx) => {

                                    totalAmount += info.t_price;
                                    discount = totalAmount * ProposalData.f_discount / 100;
                                    console.log(info)
                                    return (
                                        <tr key={`PROP_VIEW_MODEL${inx}`} className="border_btm">
                                            <td className="td_first text-center">
                                                <img src={`https://ibcdn.imagesbazaar.com/img170/${info.f_rank}-${info.t_imageid}.jpg`} alt={`invoiceimg${inx}`} />
                                            </td>
                                            <td className="td_first text-center">
                                                <p class="mg-b-0">{info.t_imageid}</p>
                                            </td>
                                            <td className="td_first text-center">
                                                <p class="mg-b-0">{info.t_quality}</p>
                                            </td>
                                            <td className="td_first text-center">
                                                <p class="mg-b-0">{info.f_mydimension}</p>
                                            </td>
                                            <td className="td_first text-center">
                                                <p class="mg-b-0">{info.f_rights}</p>
                                            </td>
                                            <td className="td_second text-right">
                                                <p class="mg-b-0">{info.t_price}</p>
                                            </td>
                                        </tr>
                                    )
                                })}
                                <tr className="border_btm">
                                    <td className="text-right td_first" colspan="5">
                                        <p className="mg-b-0 resblock">
                                            <strong>Total Value (INR)</strong>
                                        </p>
                                    </td>
                                    <td className="text-right">
                                        <p class="mg-b-0"><strong>{ProposalData.f_amt}</strong></p>
                                    </td>
                                </tr>
                                {ProposalData.f_discount !== 0 ? <tr tr className="border_btm">
                                    <td className="text-right td_first" colspan="5">
                                        <p className="mg-b-0 resblock">
                                            <strong>Discount (INR) </strong>
                                        </p>
                                    </td>
                                    <td className="text-right">
                                        <p class="mg-b-0"><strong>{ProposalData.f_discount}</strong></p>
                                    </td>
                                </tr> : ""}


                                <tr className="border_btm">
                                    <td className="text-right td_first" colspan="5">
                                        <p className="mg-b-0 resblock">
                                            <strong>IGST Value @ 18% (INR) </strong>
                                        </p>
                                    </td>
                                    <td className="text-right">
                                        <p class="mg-b-0"><strong>{ProposalData.f_sertax}</strong></p>
                                    </td>
                                </tr>
                                <tr className="border_btm">
                                    <td className="text-right td_first" colspan="5">
                                        <p className="mg-b-0 resblock">
                                            <strong>Net Payable Amount (INR) </strong>
                                        </p>
                                    </td>
                                    <td className="text-right">
                                        <p class="mg-b-0"><strong>{ProposalData.f_finalamt}</strong></p>
                                    </td>
                                </tr>
                            </tbody>
                        </RB.Table>
                    </RB.Col>
                </RB.Row>

                <RB.Row className="headinv" id="invoicem" style={{ borderBottom: "0px" }}>
                    <RB.Col lg={12} className="proposal_last">
                        <p><strong>PAN No.:</strong> AADCM6333L</p>
                        <p><strong>GSTIN No.:</strong> {UserData.f_GSTIN}</p>
                        <p><strong>HSN/SAC No.:</strong> 998439</p>
                        <br />
                        <p>Imagesbazaar is fully owned subsidiary of Mash Audio Visuals Pvt. Ltd. Usage of images subject to Mash  Rights Agreement mentioned on <a hre="www.imagesbazaar.com/licensing">www.imagesbazaar.com/licensing</a></p>
                        <br />
                        <p>This is a computer generated Quotation and does not require any authorised signatory.</p>
                        <br />
                        <p>Kindly send Cheque/Demand Draft in favour of MASH AUDIO VISUALS PVT. LTD. Payable at NEW DELHI to the address given below :</p>
                        <div className="mash_proposaladd">
                            <p>Mash Audio Visuals Pvt. Ltd.</p>
                            <p>505, Aggarwal Prestige Mall,</p>
                            <p>Plot No.2, Road No.44,,</p>
                            <p>Pitam Pura, New Delhi-110034</p>
                            <p><a href="www.imagesbazaar.com">www.imagesbazaar.com</a></p>
                        </div>
                    </RB.Col>
                </RB.Row>
            </div>
            {/* </RB.Modal.Body>
            </RB.Modal> */}


            {/* <ProposalInsertCart
                InsertCart={InsertCart}
                setInsertCart={setInsertCart}
                T_orderid={T_orderid}
                insertCart={insertCart}
                handleChange={handleChange}
            /> */}
        </>
    )
}

export default ProposalAdditionalView
