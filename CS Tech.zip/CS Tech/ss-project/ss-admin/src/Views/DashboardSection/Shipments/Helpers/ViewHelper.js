import React from 'react';
import { Col } from 'react-bootstrap';
import { Link } from 'react-router-dom'

const ViewHelper = ({ info }) => {
    const lableArray1 =
        [
            { label: "Shipping Method :", name: info.shipping_method }, { label: "Order ID :", name: info.order_id },
            { label: "Profile :", name: "Shipping Method" }, { label: "Fulfillment Status :", name: info.fulfillment_status },
            { label: "Order No. :", name: info.order_number }, { label: "Order Amount :", name: info.order_amount },
            { label: "Shop Name :", name: info.shop_name }, { label: "Account ID :", name: info.account_id },
            { label: "Partner Order ID :", name: info.partner_order_id },
            { label: "Shipping Name :", name: info.shipping_name }, { label: "Tracking No. :", name: info.tracking_number },
            { label: "Download :", name: info.label_url }
        ]
    return (
        <>
            {lableArray1.map((data, inx) => {
                let { label, name } = data
                if (label === "Tracking No. :") {
                    return (
                        <Col lg={6} key={"TOTALDATA" + inx} style={{ paddingLeft: "5px", paddingRight: "5px" }}>
                            <div className="form-group row mg-b-13">
                                <div className="col-lg-5 col-md-4">
                                    <h6 className="pwdc">{label}</h6>
                                </div>
                                <div className="col-lg-7 col-md-8">
                                    <h6 className="namep"><Link to={`/dashboard/shipments/track/${name}`} className="view_mod" target="_blank">{name}</Link></h6>
                                </div>
                            </div>
                        </Col>
                    )
                } else {
                    return (
                        <Col lg={6} key={"TOTALDATA" + inx} style={{ paddingLeft: "5px", paddingRight: "5px" }}>
                            <div className="form-group row mg-b-13">
                                <div className="col-lg-5 col-md-4">
                                    <h6 className="pwdc">{label}</h6>
                                </div>
                                <div className="col-lg-7 col-md-8">
                                    <h6 className="namep">{name}</h6>
                                </div>
                            </div>
                        </Col>
                    )
                }
            })}
        </>
    )
}

export default ViewHelper
