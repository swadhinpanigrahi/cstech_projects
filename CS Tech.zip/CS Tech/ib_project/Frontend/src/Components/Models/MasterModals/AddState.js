import React, { useState } from 'react';
import * as RB from "react-bootstrap";
import { Row } from "react-bootstrap";
import { CREATE_STATE } from "../../../Utils/api";

const AddState = (
    { show_addstate, setShow, CountryData, apiCall }
) => {
    const [FormData, setFormData] = useState({});
    const [ErrMsg, setErrMsg] = useState("")

    const handleChange = (e) => {
        let { name, value } = e.target;
        const data = { ...FormData };
        data[name] = value;
        setFormData(data)
    }
    const closeModal = () => {
        setFormData({});
        setErrMsg("")
        setShow(false);
    }
    const addStste = async () => {
        let { f_countryid, f_state } = FormData;
        const regex = /^[a-zA-Z]*$/;
        const value = regex.test(f_state);
        if (!f_countryid || !f_state || f_countryid === "--select--") {
            setErrMsg("please fill requirment text-values")
        } else if (!value) {
            setErrMsg("please fill valid text-values")
        } else {
            const res = await CREATE_STATE(FormData);
            let { status, saveData, message } = res;
            if (status === 200 && saveData) {
                apiCall();
                closeModal()
            } else {
                setErrMsg(message)
            }
        }

    }

    return (
        <div>
            <RB.Modal show={show_addstate} onHide={closeModal} className="ordermanage_modal">
                <RB.Modal.Header closeButton>
                    <RB.Modal.Title>Add New State</RB.Modal.Title>
                </RB.Modal.Header>
                <RB.Modal.Body>
                    <RB.Row>
                        <RB.Col lg={12} md={12}>
                            <RB.Row>
                                <RB.Col lg={12} md={12}>
                                    {ErrMsg === "" ? null : ErrMsg}
                                    <RB.Form>
                                        <RB.Form.Group as={Row} controlId="Country_id">
                                            <RB.Col lg={4} md={4}>
                                                <RB.Form.Label>Select Country :</RB.Form.Label>
                                            </RB.Col>
                                            <RB.Col lg={7} md={8}>
                                                <select className="select_customerd" name="f_countryid" onChange={handleChange}>
                                                    <option value={null}>--select--</option>
                                                    {CountryData.map((info, inx) => {
                                                        return (
                                                            <option value={info.f_countryid} key={`COUNTRY_DROPDOWN_${inx}`}>
                                                                {info.f_country}
                                                            </option>
                                                        )
                                                    })}
                                                </select>
                                            </RB.Col>
                                        </RB.Form.Group>
                                        <RB.Form.Group as={Row} controlId="Country_id">
                                            <RB.Col lg={4} md={4}>
                                                <RB.Form.Label>State Name :</RB.Form.Label>
                                            </RB.Col>
                                            <RB.Col lg={7} md={8}>
                                                <RB.Form.Control type="text" name="f_state" onChange={handleChange} />
                                            </RB.Col>
                                        </RB.Form.Group>
                                        <RB.Row>
                                            <RB.Col lg={4} md={4}></RB.Col>
                                            <RB.Col lg={6} md={7}>
                                                <RB.Button
                                                    size="sm" variant="primary"
                                                    onClick={addStste}
                                                >
                                                    SUBMIT
                                                </RB.Button>
                                            </RB.Col>
                                        </RB.Row>
                                    </RB.Form>
                                </RB.Col>
                            </RB.Row>
                        </RB.Col>
                    </RB.Row>
                </RB.Modal.Body>
            </RB.Modal>
        </div>
    )
}

export default AddState