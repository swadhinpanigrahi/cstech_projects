// import JWT from "jsonwebtoken";
const JWT = require("jsonwebtoken")
// import { APIError } from "../utilities/APIError";
const { APIError } = require("../utilities/APIError")
const {
  ERROR_STATUS_CODE,
  INVALID_TOKEN,
} = require("../utilities/errorContants");
const options = {
  expiresIn: "7 days",
};
const { JWT_TOKEN } = require("../config");

exports.generateJwtToken = async (req, res, next) => {
  try {
    let { authorization } = req.headers;
    let token = authorization.split(" ");
    token = JWT.verify(token[token.length - 1], JWT_TOKEN, options);
    if (!token)
      return next(
        new APIError(ERROR_STATUS_CODE.BAD_REQUEST_CODE, INVALID_TOKEN)
      );
    req.authData = token;
    next();
  } catch (error) {
    return next(
      new APIError(ERROR_STATUS_CODE.INTERNAL_SERVER_ERROR_CODE, INVALID_TOKEN)
    );
  }
};
