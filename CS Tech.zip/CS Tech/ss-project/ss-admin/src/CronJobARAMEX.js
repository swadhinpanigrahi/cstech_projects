import React, { useState, useEffect } from "react";
import {
  trakin_details,
  changeStatusApi,
  getARAMEXshipments,
} from "./Utils/api";

const CronJobARAMEX = () => {
  const [Loading, setLoading] = useState(true);

  const changeStatusFORaramex = async (element) => {
    await changeStatusApi(element);
  };

  const aramex = async () => {
    const res = await getARAMEXshipments();
    let { trakingDetails } = res;
    console.log(trakingDetails);
    trakingDetails.forEach(async (element, inx) => {
      let { tracking_number, shipping_method } = element;
      const trakData = await trakin_details(tracking_number, shipping_method);
      let { statuses, error } = trakData;
      if (!error && statuses) {
        console.log(inx, tracking_number, statuses);
        statuses.forEach(async (element) => {
          if (element !== undefined) {
            await changeStatusFORaramex(element);
          }
        });
      }
    });
    setLoading(false);
  };

  useEffect(() => {
    aramex();
  }, []);

  return (
    <div>
      <h2>Aramex Script is running.....</h2>
      <p>{Loading ? "Loading..." : "Done"}</p>
    </div>
  );
};

export default CronJobARAMEX;
