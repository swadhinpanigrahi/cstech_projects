exports.EMAIL_NOT_EXISTS = "Email or phone number does not exists";
exports.WRONG_PASSWORD = "current password is incorrect";
exports.WR_PASSEORD = "password is incorrect"
exports.INVALID_REFRESH_TOKEN = "INVALID REFRESH TOKEN";
exports.UNAUTHORIZED_REQUEST = "Access Denied, Please try with correct credentials";
exports.REFRESH_TOKEN_EXPIRED = "REFRESH TOKEN EXPIRED";
exports.INVALID_AUTH_TOKEN = "INVALID AUTH TOKEN";
exports.NOT_FOUND = "NOT FOUND";
exports.INVALID_HEADER_VALUE = "INVALID HEADERS VALUE";
exports.INVALID_TOKEN = "INVALID TOKEN";
exports.TOKEN_EXPIRED = "TOKEN EXPIRED";
exports.INVALID_ID = "INVALID ID";
exports.UNEXPECTED_ERROR = "UNEXPECTED ERROR";
exports.USER_ALREADY_EXISTS = "User already exists";
exports.INTERNAL_SERVER_ERROR = "Something went wrong, try again after sometime";
exports.LINK_EXPIRED = "Link expired,Please try again";
exports.USER_DOES_NOT_EXISTS = "User does not exists";
exports.PERMISSION_DENIED = "Access Denied";
exports.PASSWORD_NOT_MATCH = "new password and confirm password did not match";

exports.RESOURCE_ALREADY_EXITS = (resource) =>
  `${resource} already exists`;

exports.ERROR_STATUS_CODE = {
  BAD_REQUEST_CODE: 400,
  INTERNAL_SERVER_ERROR_CODE: 500,
  UNAUTHORIZED_REQUEST_CODE: 401,
  NOT_FOUND: 404,
  ALREADY_EXITS: 409,
};

exports.generateError = (error) => {
  if (error.message && error.stack) {
    error = { message: error.message, stack: error.stack };
  }
  if (typeof error === "object") {
    error = JSON.stringify(error);
  }
  return error;
};
