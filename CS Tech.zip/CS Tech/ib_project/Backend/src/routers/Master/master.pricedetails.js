const PriceDetails = require("express").Router();

const {
    AddPriceDetail, getPriceDetailList, getPriceDetail,
    updatePriceDetail, removePriceDetail
} = require("../../controllers/Master/master.pricedetail.controller");

PriceDetails.route("/addpricedetail").post(AddPriceDetail);
PriceDetails.route("/getpricedetaillist").get(getPriceDetailList);
PriceDetails.route("/getpricedetail/:_id").get(getPriceDetail);
PriceDetails.route("/updatepricedetail").post(updatePriceDetail);
PriceDetails.route("/removepricedetail/:_id").get(removePriceDetail);


module.exports = PriceDetails;