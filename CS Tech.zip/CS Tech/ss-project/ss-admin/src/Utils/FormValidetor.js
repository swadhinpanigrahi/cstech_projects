export const authLoginValidetor = (formValue) => {
  let errors = {};
  if (!formValue.username) {
    errors.username = "Username Is Required";
  } else if (!/\S+@\S+\.\S+/.test(formValue.username)) {
    errors.username = "Invalid Username";
  }

  if (!formValue.password) {
    errors.password = "Password Is Required";
  }
  return errors;
};
// address: "hhhhh"
// city: "hhhhhh"
// companyName: "hhhhhh"
// country: "hhhhhh"
// email: "hhhh"
// name: "jhhh"
// password: "hhhhh"
// phone: "hhhh"
// pincode: "hhhhhh"
// state: "hhhhhhh"

export const inputFieldsValidetor = (formValue) => {
  let errors = {};
  if (formValue.name === "") {
    errors.name = "Name Is Required";
  }

  if (formValue.emailId === "") {
    errors.emailId = "Username Is Required";
  } else if (!/\S+@\S+\.\S+/.test(formValue.emailId)) {
    errors.emailId = "Invalid Email";
  }

  if (formValue.email === "") {
    errors.email = "Username Is Required";
  } else if (!/\S+@\S+\.\S+/.test(formValue.email)) {
    errors.email = "Invalid Email";
  }

  if (formValue.phone === "") {
    errors.phone = "Mobile Number Is Required";
  }

  if (formValue.password === "") {
    errors.password = "Password Is Required";
  }

  if (formValue.companyName === "") {
    errors.companyName = "Company Name Is Required";
  }

  if (formValue.address === "") {
    errors.address = "Address Is Required";
  }

  if (formValue.pincode === "") {
    errors.pincode = "Pincode Is Required";
  }

  if (formValue.city === "") {
    errors.city = "City Is Required";
  }

  if (formValue.state === "") {
    errors.state = "State Is Required";
  }

  if (formValue.country === "") {
    errors.country = "Country Is Required";
  }

  return errors;
};

/*
account_number: "6766767"
balance: "675765765"
bank_branch: "fggfgfghf"
bank_name: "66767576"
beneficiary_name: "gfgfghfhg"
comment: "hgfhgfgh"
ifsc_code: "gfhfhgfg"
mode: "Cheque"
payed_amount: "767868"
payment_type: "Debit"
seller_entry_name: "uyytt"
transection_no: "gf"
_id: "60c8a1058a8e916d58bcfc83"
*/

export const paymentFieldsValidator = (formValue) => {
  let errors = {}
  if (!formValue.account_number) {
    errors.account_number = "Account Number is Required!";
  }

  if (!formValue.balance) {
    errors.balance = "Balance is Required!";
  }

  if (!formValue.bank_branch) {
    errors.bank_branch = "Bank Branch is Required!";
  }

  if (!formValue.bank_name) {
    errors.bank_name = "Bank Name is Required!";
  }

  if (!formValue.beneficiary_name) {
    errors.beneficiary_name = "Beneficiary Name is Required!";
  }

  if (!formValue.comment) {
    errors.comment = "Comment is Required!";
  }

  if (!formValue.ifsc_code) {
    errors.ifsc_code = "IFSE Code is Required!";
  }

  if (!formValue.mode) {
    errors.mode = "Mode is Required!";
  }

  if (!formValue.payed_amount) {
    errors.payed_amount = "Payed Type is Required!";
  }

  if (!formValue.payment_type) {
    errors.payment_type = "Payment Type is Required!";
  }

  if (!formValue.seller_entry_name) {
    errors.seller_entry_name = "Seller Entry Name is Required!";
  }

  if (!formValue.transection_no) {
    errors.transection_no = "Transection No is Required!";
  }

  return errors;
}

export const authChangePasswordValidetor = (formValue) => {
  let errors = {};
  if (!formValue.oldpassword) {
    errors.oldpassword = "Enter Your Old Password";
  }
  if (!formValue.newpassword) {
    errors.newpassword = "Enter Your New Password";
  }
  if (!formValue.confirmpassword) {
    errors.confirmpassword = "Re-Enter Your New Password";
  }
  return errors;
}

export const authProfiledValidetor = (formValue) => {
  let errors = {};

  if (formValue.firstName === "") {
    errors.firstName = "Enter Your First Name";
  }

  if (formValue.lastName === "") {
    errors.lastName = "Enter Your Last Name";
  }

  if (formValue.emailId === "") {
    errors.emailId = "Enter Your Email";
  }

  if (formValue.mobileNo === "") {
    errors.mobileNo = "Enter Your Mobile Number";
  }

  if (formValue.companyName === "") {
    errors.companyName = "Enter Your Company Name";
  }

  return errors;
}

export const trakingValidation = (formValue) => {
  let errors = {};
  if (formValue.tracking_number === "") {
    errors.tracking_number = "Enter Valid Traking Number";
  }
  return errors;
}
