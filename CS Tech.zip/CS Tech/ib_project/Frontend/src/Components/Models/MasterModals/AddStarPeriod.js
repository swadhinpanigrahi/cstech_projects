import React, { useState } from 'react';
import * as RB from "react-bootstrap";
import { Row } from "react-bootstrap";

import { ADD_STARPERIODDETAIL } from "../../../Utils/api"

const AddStarPeriod = (
    { show_addstarperiod, setShow, apiCall, modelSet, setModelMsg }
) => {
    const [FormData, setFormData] = useState({});
    const [ErrorMsg, setErrorMsg] = useState("")

    const handleChange = (e) => {
        let { name, value } = e.target;
        const data = { ...FormData }
        data[name] = value
        setFormData(data)
    }

    const closeModal = () => {
        setFormData({});
        setErrorMsg("")
        setShow(false)
    }

    const addStarPeriod = async () => {
        let { f_period, f_cal } = FormData;
        if (!f_period) {
            setErrorMsg("please fill period")
        } else if (!f_cal) {
            setErrorMsg("please fill cal")
        } else {
            const res = await ADD_STARPERIODDETAIL(FormData);
            let { status, message } = res;
            if (status === 200) {
                apiCall();
                closeModal();
                setModelMsg(message);
                modelSet()
            } else {
                setErrorMsg(message)
            }
        }
    }

    return (
        <div>
            <RB.Modal show={show_addstarperiod} onHide={closeModal} className="ordermanage_modal">
                <RB.Modal.Header closeButton>
                    <RB.Modal.Title>Add Star Period</RB.Modal.Title>
                </RB.Modal.Header>
                <RB.Modal.Body>
                    <RB.Row>
                        <RB.Col lg={12} md={12}>
                            <RB.Row>
                                {ErrorMsg !== "" ? ErrorMsg : ""}
                                <RB.Col lg={12} md={12}>
                                    <RB.Form>
                                        <RB.Form.Group as={Row} controlId="Country_id">
                                            <RB.Col lg={4} md={4}>
                                                <RB.Form.Label>Period :</RB.Form.Label>
                                            </RB.Col>
                                            <RB.Col lg={7} md={8}>
                                                <RB.Form.Control
                                                    type="text"
                                                    name="f_period"
                                                    onChange={handleChange}
                                                />
                                            </RB.Col>
                                        </RB.Form.Group>
                                        <RB.Form.Group as={Row} controlId="Country_id">
                                            <RB.Col lg={4} md={4}>
                                                <RB.Form.Label>Calculate Value :</RB.Form.Label>
                                            </RB.Col>
                                            <RB.Col lg={7} md={8}>
                                                <RB.Form.Control
                                                    type="number"
                                                    name="f_cal"
                                                    onChange={handleChange}
                                                />
                                            </RB.Col>
                                        </RB.Form.Group>
                                        <RB.Row>
                                            <RB.Col lg={4} md={4}></RB.Col>
                                            <RB.Col lg={6} md={7}>
                                                <RB.Button
                                                    size="sm" variant="primary"
                                                    onClick={addStarPeriod}
                                                >
                                                    ADD
                                                </RB.Button>
                                            </RB.Col>
                                        </RB.Row>
                                    </RB.Form>
                                </RB.Col>
                            </RB.Row>
                        </RB.Col>
                    </RB.Row>
                </RB.Modal.Body>
            </RB.Modal>
        </div>
    )
}

export default AddStarPeriod