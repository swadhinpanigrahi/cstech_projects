const { M_STARSIZE } = require("../../model");

exports.addStarSize = async (req, res) => {
    const { f_size, f_cal } = req.body;
    try {
        const existingData = await M_STARSIZE.findOne({ f_size });
        if (existingData) {
            res.json({ status: 400, message: "star size already exist" })
        }
        if (!existingData) {
            const Data = await new M_STARSIZE({ f_size, f_cal }).save();
            if (Data) {
                res.json({ status: 200, message: "star size added successfully" })
            }
        }
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

exports.getStarSizeList = async (req, res) => {
    const { currentPage, itemPerPage, searchData } = req.query;
    const num = parseInt(itemPerPage)
    const start = parseInt(currentPage);
    let pipeline;
    let countline;
    try {
        if (!searchData || searchData === "") {
            pipeline = [
                { $skip: (start - 1) * num },
                { $limit: num },
                { $sort: { _id: -1 } }
            ]
            countline = [
                { $count: "totalcount" }
            ]
        } else {
            pipeline = [
                { $match: { f_size: { $regex: searchData, $options: "im" } } },
                { $skip: (start - 1) * num },
                { $limit: num },
                { $sort: { _id: -1 } }
            ]
            countline = [
                { $match: { f_size: { $regex: searchData, $options: "im" } } },
                { $count: "totalcount" }
            ]
        }
        const data = await M_STARSIZE.aggregate(pipeline)
        const totalrecord = await M_STARSIZE.aggregate(countline)
        res.json({ status: 200, data, totalrecord })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

exports.getStarSizeDetail = async (req, res) => {
    const { _id } = req.params;
    try {
        const starDetails = await M_STARSIZE.findOne({ _id });
        res.json({ status: 200, starDetails })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

exports.editStarSizeDetails = async (req, res) => {
    const { _id, f_size, f_cal } = req.body;
    try {
        const updatedData = await M_STARSIZE.findByIdAndUpdate({ _id }, { $set: { f_size, f_cal } });
        res.json({ status: 200, message: "star size updated successfully!" })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

exports.deleteStarSizeDetails = async (req, res) => {
    const { _id } = req.params;
    try {
        const starDetails = await M_STARSIZE.findOneAndRemove({ _id });
        res.json({ status: 200, message: "star size deleted successfully!" })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}