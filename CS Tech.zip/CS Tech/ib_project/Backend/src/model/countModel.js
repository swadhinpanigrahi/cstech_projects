const mongoose = require("mongoose");

const counterSchema = mongoose.Schema(
    {
        _id: { type: String },
        sequence: { type: Number }
    },
    { collection: "Counter" }
)

module.exports = Counter = mongoose.model(
    "Counter",
    counterSchema
)