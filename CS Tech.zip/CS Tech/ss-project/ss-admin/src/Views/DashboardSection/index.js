import React from "react";
import AuthButton from "../LogoutSection/AuthButton";
import { Route } from "react-router-dom";

import Analytical from "./Analytical/Analytical";
import CustomerDash from "./Customer";
import ShipmentDash from "./Shipments";
import ReportsDash from "./Reports";
import OutstandingDash from "./Outstanding";

//profile
import ManageProfile from './ManageProfile';
import ChangePassword from "./ChangePassword";
import SubUser from "./Subuser";

import Footer from '../../Components/Headers/Footer';

const DashSection = () => {
  return (
    <>
      <AuthButton />
      <Route path="/dashboard/analytical" component={Analytical} />
      <Route path="/dashboard/customer" component={CustomerDash} />
      <Route path="/dashboard/shipments" component={ShipmentDash} />
      <Route path="/dashboard/CODReports" component={ReportsDash} />
      <Route path="/dashboard/outstandingreport" component={OutstandingDash} />
      <Route path="/dashboard/editprofile" component={ManageProfile} />
      <Route path="/dashboard/changepassword" component={ChangePassword} />
      <Route path="/dashboard/subuser" component={SubUser} />
      <Footer />
    </>
  );
};

export default DashSection;
