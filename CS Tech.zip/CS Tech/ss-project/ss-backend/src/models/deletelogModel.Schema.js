const Mongoose = require("mongoose");

const deleteShipDataSchema = new Mongoose.Schema(
    {
        removed_shipment: { type: Object }
    },
    { timestamps: true },
    { collection: "deletedlog_tbls" }
)

module.exports = deleteShipDataSchema;