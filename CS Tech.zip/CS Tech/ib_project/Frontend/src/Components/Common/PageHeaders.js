import React from "react";

const PageHeaders = ({ pageHeading }) => {
  return (
    <div className="page_header">
      <h3 className="page-title">{pageHeading}</h3>
    </div>
  );
};

export default PageHeaders;
