const { M_STARPERIOD } = require("../../model");

exports.addStarPeriod = async (req, res) => {
    const { f_period, f_cal } = req.body;
    try {
        const existingData = await M_STARPERIOD.findOne({ f_period });
        if (existingData) {
            res.json({ status: 400, message: "star period already exist" })
        }
        if (!existingData) {
            const Data = await new M_STARPERIOD({ f_period, f_cal }).save();
            if (Data) {
                res.json({ status: 200, message: "star period added successfully" })
            }
        }
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

exports.getStarPeriodList = async (req, res) => {
    const { currentPage, itemPerPage, searchData } = req.query;
    const num = parseInt(itemPerPage)
    const start = parseInt(currentPage);
    let pipeline;
    let countline;
    try {
        if (!searchData || searchData === "") {
            pipeline = [
                { $skip: (start - 1) * num },
                { $limit: num },
                { $sort: { _id: -1 } }
            ]
            countline = [
                { $count: "totalcount" }
            ]
        } else {
            pipeline = [
                { $match: { f_period: { $regex: searchData, $options: "im" } } },
                { $skip: (start - 1) * num },
                { $limit: num },
                { $sort: { _id: -1 } }
            ]
            countline = [
                { $match: { f_period: { $regex: searchData, $options: "im" } } },
                { $count: "totalcount" }
            ]
        }
        const data = await M_STARPERIOD.aggregate(pipeline)
        const totalrecord = await M_STARPERIOD.aggregate(countline)
        res.json({ status: 200, data, totalrecord })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

exports.getStarPeriodDetail = async (req, res) => {
    const { _id } = req.params;
    try {
        const starPeriodDetail = await M_STARPERIOD.findOne({ _id });
        res.json({ status: 200, starPeriodDetail })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

exports.editStarPeriodDetail = async (req, res) => {
    const { _id, f_period, f_cal } = req.body;
    try {
        const updatedData = await M_STARPERIOD.findByIdAndUpdate({ _id }, { $set: { f_period, f_cal } });
        res.json({ status: 200, message: "star period updated successfully!" })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

exports.deleteStarPeriodDetail = async (req, res) => {
    const { _id } = req.params;
    try {
        const deletedData = await M_STARPERIOD.findByIdAndRemove({ _id });
        res.json({ status: 200, message: "star period deleted successfully!" })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}