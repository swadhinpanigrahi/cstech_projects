// const BASE_URL = "https://ibadminreactapi.imagesbazaar.com/api";
// const BASE_URL = "http://localhost:5000/api";
// const BASE_URL = "http://ibadminreactapiv1.cstechns.com/api";
const BASE_URL = "http://ibadminreactapi.cstechns.com/api";
/**
 * 
  "http://localhost:5000/api" || 
  "http://ibadminreactapi.cstechns.com/api" || 
  "http://ibadminreactapi.imagesbazaar.com/api" ||
  "http://ibadminreactapiv1.cstechns.com/api"
 * 
*/

module.exports = {
  BASE_URL,
};
