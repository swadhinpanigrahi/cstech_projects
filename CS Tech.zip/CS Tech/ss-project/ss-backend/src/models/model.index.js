const Mongoose = require("mongoose");

const authSchema = require("./authModel.Schema");
const merchantModelSchema = require("./merchantModel.Schema");
const paymentModelSchema = require("./paymentModule.Schema");
const tokenModelSchema = require("./tokenModel.Schema");
const trackingModelSchema = require("./trackingModel.Schema");
const submodelPermisionModel = require("./submodelPermisionModel.Schema");
const shipmentLogSchema = require("./shipmentLog.Schema");
const modifyShipDataSchema = require("./modifyShipData.Schema");
const deleteShipDataSchema = require("./deletelogModel.Schema")

exports.Auth = Mongoose.model(`auth_tbls`, authSchema);
exports.Merchant = Mongoose.model(`customerdetails_tbls`, merchantModelSchema);
exports.Payment = Mongoose.model(`payment_tbls`, paymentModelSchema);
exports.Token = Mongoose.model(`tbl_forgetpass_jwt_tokens`, tokenModelSchema);
exports.TrackData = Mongoose.model(`trackingmodel_tbls`, trackingModelSchema);
exports.Subpermision = Mongoose.model(`subadminpermission_tbls`, submodelPermisionModel);
exports.Log = Mongoose.model(`log_tbls`, shipmentLogSchema);
exports.PreShipLog = Mongoose.model(`shipmentlog_tbls`, modifyShipDataSchema);
exports.DeleteShipLog = Mongoose.model(`deletedlog_tbls`, deleteShipDataSchema);
