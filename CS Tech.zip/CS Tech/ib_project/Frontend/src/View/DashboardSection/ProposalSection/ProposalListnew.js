import React from 'react'

export const ProposalListnew = () => {
    return (
        <div>
            <h1>List</h1>
        </div>
    )
}

export default ProposalListnew