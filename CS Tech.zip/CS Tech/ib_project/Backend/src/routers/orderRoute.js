const orderRoute = require("express").Router();

const {
  getOrderByEmailData, getOrderData, getPendingOrderData, getOrderDetail, SendPaymentMail, SendOrderCCMail,
  updateBounceChequeDesc, paidProcessUpdateStatus, rejectInvoice,
  deleteOrderDetail, FinalizeOrder,
  getOrderDetialsForConfirm, confirmOrderAndGenerateInvoice,
  fetchPaymentDetailsByOrderId, uploadPurchaseImage,
  fetchInvoiceDataByOrderId
} = require("../controllers/orderController");

orderRoute.route("/getorderbyemaildata/:T_username").get(getOrderByEmailData);
orderRoute.route("/getorderdata").get(getOrderData);
orderRoute.route("/getpendingorderdata").get(getPendingOrderData);
orderRoute.route("/getorderdetail/:T_orderid").get(getOrderDetail);
orderRoute.route("/updatebouncecheque").post(updateBounceChequeDesc);
orderRoute.route("/updatepaidproccessstatusupdate").post(paidProcessUpdateStatus);
orderRoute.route("/invoicechangingtoreject/:T_orderid").get(rejectInvoice);
orderRoute.route("/deleteorderdetail/:T_orderid").get(deleteOrderDetail);
orderRoute.route("/placeorderdetails").post(FinalizeOrder);
orderRoute.route("/sendpaymentmail").post(SendPaymentMail);
orderRoute.route("/sendorderccmail").post(SendOrderCCMail);

orderRoute.route("/getOrderDetialsForConfirm").post(getOrderDetialsForConfirm);
orderRoute.route("/confirmOrderAndGenerateInvoice").post(confirmOrderAndGenerateInvoice);
orderRoute.route("/fetchPaymentDetailsByOrderId/:orderId").get(fetchPaymentDetailsByOrderId);
orderRoute.route("/uploadPurchaseImage").post(uploadPurchaseImage);
orderRoute.route("/fetchInvoiceDataByOrderId").post(fetchInvoiceDataByOrderId);

module.exports = orderRoute;
