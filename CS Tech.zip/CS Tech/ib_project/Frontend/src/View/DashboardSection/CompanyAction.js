import React, { useState, useEffect } from "react";
import * as RB from "react-bootstrap";
import { useParams, Link } from "react-router-dom";
import { Form, Row } from "react-bootstrap";
import {
  companyAction, proposalDeleteAction, getFollowupsDetails, getFollowupsDetailsTable,
  postNextFollowup, proposalViewAction, getOrderDeatils, getOrderInvoice
} from "../../Utils/api";
import { AiOutlineFileSearch } from "react-icons/ai";
import { BiCommentDetail } from "react-icons/bi";
import { FiEdit } from "react-icons/fi";
import { IoExitOutline } from "react-icons/io5";
import { RiDeleteBin6Line } from "react-icons/ri";
import ProposalInvoiceModel from "../../Components/Models/ProposalInvoiceModel";
import { IoIosArrowBack } from "react-icons/io";
import OrderInvoiceModel from "../../Components/Models/OrderModals/OrderInvoiceModel";
import OrderDetailsModel from "../../Components/Models/OrderModals/OrderDetailsModel";
import Moment from 'moment'
const CompanyAction = () => {
  const { f_userid } = useParams();
  const [companyDetails, setCompanyDetails] = useState({});
  const [groupData, setGroupData] = useState({
    isView: false,
    data: [],
  });
  const [OrderData, setOrderData] = useState({
    isView: false,
    data: [],
  });
  const [filtredOrderData, setFiltredOrderData] = useState([]);

  const [ProposalData, setProposalData] = useState({
    isView: false,
    data: [],
  });
  const [FollowupData, setFollowupData] = useState({
    isView: false,
    data: [],
  });
  const [followFilterData, setFollowFilterData] = useState([]);

  const [followTable, setFollowTable] = useState([]);
  const [f_sno, setId] = useState("");
  const [FormData, setFormData] = useState({
    f_sno,
    f_EmailID: "",
    f_CompanyName: "",
    f_creationdate: "",
    f_MobileNo: "",
    f_Firstname: "",
    f_AlternateEmail: "",
    f_RequirementType: "",
    orderid: "",
    f_status: "",
    f_followpby: "",
    f_State: "",
    f_IbOption: "",
    f_createdby: "",
  });

  const [proposalInvoiceDetails, setProposalInvoiceDetails] = useState({
    table1: {},
    table2: {},
  });

  const [show, setShow] = useState(false);
  const [show1, setShow1] = useState(false);
  const [show2, setShow2] = useState(false);
  const handleClose2 = () => setShow2(false);

  /*top-button*/

  const [OrderDetailsIsOpen, setOrderDetailsIsOpen] = useState(false);
  const [OrderInvoiceIsOpen, setOrderInvoiceIsOpen] = useState(false);

  const [OrderDataObj, setOrderDataObj] = useState({});
  const [OrderDataList, setOrderDataList] = useState([]);

  const [OrderInvoiceObj, setOrderInvoiceObj] = useState({});
  const [OrderInvoiceList, setOrderInvoiceList] = useState([])

  const CloseOrderDetails = () => setOrderDetailsIsOpen(false);
  const OrderDetailsClick = async (orderId) => {
    const res = await getOrderDeatils(orderId);
    let { OrderDetail, OrderDetailsList } = res;
    setOrderDataObj(OrderDetail);
    setOrderDataList(OrderDetailsList);
    console.log(OrderDetail, OrderDetailsList);
    setOrderDetailsIsOpen(true);
  };

  const CloseOrderInvoice = () => setOrderInvoiceIsOpen(false);
  const OrderInvoiceClick = async (orderId) => {
    const res = await getOrderInvoice(orderId);
    console.log(orderId, res)
    let { OrderInvoice, OrderInvoiceList } = res;
    setOrderInvoiceObj(OrderInvoice);
    setOrderInvoiceList(OrderInvoiceList);
    console.log(OrderInvoice, OrderInvoiceList);
    setOrderInvoiceIsOpen(true);
  };

  const handleShow2 = async (_id) => {
    const res = await proposalViewAction(_id);
    let { proposalData, tblProposalData } = res;
    let updatedData = { ...proposalInvoiceDetails };
    updatedData.table1 = proposalData;
    updatedData.table2 = tblProposalData;
    setProposalInvoiceDetails({ ...updatedData });
    console.log(_id, proposalData, tblProposalData);
    setShow2(true);
  };

  const openFilter = (name) => {
    const shaloFollowUpData = [...FollowupData.data];
    if (name === "Open") {
      const FollowUpfilterData = shaloFollowUpData.filter(
        (data) => data.f_followups_status === "0"
      );
      setFollowFilterData([...FollowUpfilterData]);
    }
    if (name === "Close") {
      const FollowUpfilterData = shaloFollowUpData.filter(
        (data) => data.f_followups_status === "1"
      );
      setFollowFilterData([...FollowUpfilterData]);
    }
    if (name === "Sold") {
      const FollowUpfilterData = shaloFollowUpData.filter(
        (data) => data.f_followups_status === "3"
      );
      setFollowFilterData([...FollowUpfilterData]);
    }
  };

  const handleChange = (e) => {
    setFormData({ ...FormData, [e.target.name]: e.target.value });
  };

  const handleClose = () => setShow(false);
  const handleShow = async (f_sno) => {
    setId(f_sno);
    const res = await getFollowupsDetails(f_sno);
    const { followupsData } = res;
    setFormData({
      f_sno,
      f_EmailID: followupsData.f_EmailID,
      f_CompanyName: followupsData.f_CompanyName,
      f_creationdate: followupsData.f_creationdate,
      f_MobileNo: followupsData.f_MobileNo,
      f_Firstname: followupsData.f_Firstname,
      f_AlternateEmail: followupsData.f_AlternateEmail,
      f_RequirementType: followupsData.f_RequirementType,
      orderid: followupsData.orderid,
      f_status: "",
      f_followpby: followupsData.f_followpby,
      f_State: followupsData.f_State,
      f_IbOption: followupsData.f_IbOption,
      f_createdby: followupsData.f_createdby,
    });
    setShow(true);
  };

  const handleClose1 = () => setShow1(false);
  const handleShow1 = async (f_sno) => {
    const res = await getFollowupsDetailsTable(f_sno);
    const { followupsData } = res;
    setFollowTable(followupsData);
    setShow1(true);
  };

  const viewGroupData = () => {
    if (groupData.isView === false) {
      const updatedGroup = { ...groupData };
      updatedGroup.isView = true;
      setGroupData({ ...updatedGroup });
    } else {
      const updatedGroup = { ...groupData };
      updatedGroup.isView = false;
      setGroupData({ ...updatedGroup });
    }
  };

  const viewOrderData = () => {
    if (OrderData.isView === false) {
      const updatedOrder = { ...OrderData };
      updatedOrder.isView = true;
      setOrderData({ ...updatedOrder });
    } else {
      const updatedOrder = { ...OrderData };
      updatedOrder.isView = false;
      setOrderData({ ...updatedOrder });
    }
  };

  const viewProposalData = () => {
    if (ProposalData.isView === false) {
      const updatedProposal = { ...ProposalData };
      updatedProposal.isView = true;
      setProposalData({ ...updatedProposal });
    } else {
      const updatedProposal = { ...ProposalData };
      updatedProposal.isView = false;
      setProposalData({ ...updatedProposal });
    }
  };

  const viewFollowupData = () => {
    if (FollowupData.isView === false) {
      const updatedFollowups = { ...FollowupData };
      updatedFollowups.isView = true;
      setFollowupData({ ...updatedFollowups });
    } else {
      const updatedFollowups = { ...FollowupData };
      updatedFollowups.isView = false;
      setFollowupData({ ...updatedFollowups });
    }
  };

  const onSubmit = async (e) => {
    e.preventDefault();
    const res = await postNextFollowup(FormData);
    const { message, error } = res;
    if (!error && message === "added successfully") {
      setTimeout(() => {
        handleClose();
      }, 1000);
    } else {
      console.log(error);
    }
  };

  useEffect(() => {
    const apiCompanyAction = async () => {
      const res = await companyAction(f_userid);
      let {
        error,
        userData,
        groupData,
        T_orderData,
        proposal_data,
        followup_data,
      } = res;
      
      if (!error) {
        const updatedGroupData = { ...groupData };
        updatedGroupData.data = groupData;
        setGroupData({ ...updatedGroupData });

        const updatedOrderData = { ...OrderData };
        updatedOrderData.data = T_orderData;
        setOrderData({ ...updatedOrderData });

        const updatedProposalData = { ...ProposalData };
        updatedProposalData.data = proposal_data;
        setProposalData({ ...updatedProposalData });

        const updatedFollowUps = { ...FollowupData };
        updatedFollowUps.data = followup_data;
        setFollowupData({ ...updatedFollowUps });
        setFollowFilterData(followup_data);

        setFiltredOrderData(T_orderData);
        // setOrderSpan(orderArr);
        // setFollowupsSpan(followupsArr);
        setCompanyDetails(userData);
      }
    };
    apiCompanyAction();
  }, [f_userid]);

  const orderFilter = (name) => {
    const shaloArray = [...OrderData.data];
    if (name === "Total") {
      const filteredData = [...shaloArray];
      setFiltredOrderData(filteredData);
    }

    if (name === "Confirmed") {
      const filteredData = shaloArray.filter((data) => {
        return data.T_status === "C";
      });
      setFiltredOrderData(filteredData);
    }

    if (name === "Pending") {
      const filteredData = shaloArray.filter((data) => {
        return data.T_status === "P";
      });
      setFiltredOrderData(filteredData);
    }

    if (name === "Rejected") {
      const filteredData = shaloArray.filter((data) => {
        return data.T_status === "R";
      });
      setFiltredOrderData(filteredData);
    }
  };

  const onDelete = async (_id) => {
    const res = await proposalDeleteAction(_id);
    const { deleted } = res;
    if (deleted) {
      const shaloArray = [...ProposalData];
      const filterData = shaloArray.filter((data) => data.T_orderid !== _id);
      setProposalData(filterData);
    }
  };

  const userList = groupData.data.length !== 0 ? groupData.data.map((data, inx) => (<tr key={"custable1" + inx}>
    <td className="text-center">{inx + 1}</td>
    <td>{data.CS_userid}</td>
    <td>{`${data.CS_firstname} ${data.CS_lastname}`}</td>
    <td>{data.CS_mobile}</td>
    <td>{data.CS_companynames}</td>
    <td>{data.CS_businesstype}</td>
    <td>{data.sortcmp_name}</td>
    <td>{data.group_cmpname}</td>
    {/* <td>{data.cs_date}</td> */}
    <td>{data.CS_subscribe}</td>
    <td>{data.CS_state}</td>
    <td className="text-center td_comments">
      <Link to={`/dashboard/useraction/${data.CS_userid}/:form_company`}>
        <AiOutlineFileSearch title="User Details" />
      </Link>
      <Link
        to={`/dashboard/useractioneditprofile/${data.CS_userid}/form_company`}
      >
        <FiEdit title="Edit User" />
      </Link>
    </td>
  </tr>)) : <tr><td className="no_records" colSpan="11">No Records Found</td></tr>

  const userList1 = groupData.data.length !== 0 ? groupData.data.slice(0, 10).map((data, inx) => (<tr key={"custable1" + inx}>
    <td className="text-center">{inx + 1}</td>
    <td>{data.CS_userid}</td>
    <td>{`${data.CS_firstname} ${data.CS_lastname}`}</td>
    <td>{data.CS_mobile}</td>
    <td>{data.CS_companynames}</td>
    <td>{data.CS_businesstype}</td>
    <td>{data.sortcmp_name}</td>
    <td>{data.group_cmpname}</td>
    {/* <td>{data.cs_date}</td> */}
    <td>{data.CS_subscribe}</td>
    <td>{data.CS_state}</td>
    <td className="text-center td_comments">
      <Link to={`/dashboard/useraction/${data.CS_userid}/:form_company`}>
        <AiOutlineFileSearch title="User Details" />
      </Link>
      <Link
        to={`/dashboard/useractioneditprofile/${data.CS_userid}/form_company`}
      >
        <FiEdit title="Edit User" />
      </Link>
    </td>
  </tr>)) : <tr><td className="no_records" colSpan="11">No Records Found</td></tr>

  const orderList = filtredOrderData.length !== 0 ? filtredOrderData.map((data, inx) => (<tr key={"order1" + inx}>
    <td className="text-center">{inx + 1}</td>
    <td>{data.T_orderid}</td>
    <td>{data.t_client}</td>
    <td className="company_emmailta">{data.T_username}</td>
    <td>{data.f_partpay}</td>
    <td>
      {/* {data.T_orderdate.slice(0, 10)} */}
      {Moment(data.T_orderdate).format("DD-MM-YYYY")}
    </td>
    <td>{data.T_status}</td>
    <td>{data.t_paymentstatus}</td>
    <td>{data.f_orderAmt}</td>
    <td>{data.t_invoiceid}</td>
    <td className="text-center td_comments">
      <AiOutlineFileSearch title="Order Details"
        onClick={() => {
          OrderDetailsClick(data.T_orderid);
        }}
      />
      {data.T_status === "C" ? (
        <BiCommentDetail title="invoice Details"
          onClick={() => OrderInvoiceClick(data.T_orderid)}
        />
      ) : (
        ""
      )}
    </td>
  </tr>)) : <tr><td className="no_records" colSpan="11">No Records Found</td></tr>

  const orderList1 = filtredOrderData.length !== 0 ? filtredOrderData.slice(0, 10).map((data, inx) => (<tr key={"order1" + inx}>
    <td className="text-center">{inx + 1}</td>
    <td>{data.T_orderid}</td>
    <td>{data.t_client}</td>
    <td className="company_emmailta">{data.T_username}</td>
    <td>{data.f_partpay}</td>
    <td>
      {/* {data.T_orderdate.slice(0, 10)} */}
      {Moment(data.T_orderdate).format("DD-MM-YYYY")}
    </td>
    <td>{data.T_status}</td>
    <td>{data.t_paymentstatus}</td>
    <td>{data.f_orderAmt}</td>
    <td>{data.t_invoiceid}</td>
    <td className="text-center td_comments">
      <AiOutlineFileSearch title="Order Details"
        onClick={() => {
          OrderDetailsClick(data.T_orderid);
        }}
      />
      {data.T_status === "C" ? (
        <BiCommentDetail title="Invoice Details"
          onClick={() => OrderInvoiceClick(data.T_orderid)}
        />
      ) : (
        ""
      )}
    </td>
  </tr>)) : <tr><td className="no_records" colSpan="11">No Records Found</td></tr>

  const proposalList = ProposalData.data.length !== 0 ? ProposalData.data.map((data, inx) => (<tr key={"custable1" + inx}>
    <td className="text-center">{inx + 1}</td>
    <td>{data.f_proposaluser}</td>
    <td>{data.f_heading}</td>
    <td>
      {/* {data.T_orderdate.slice(0, 10)} */}
      {Moment(data.T_orderdate).format("DD-MM-YYYY")}
    </td>
    <td>{data.f_totimg}</td>
    <td>{data.f_amt}</td>
    <td>{data.f_discount}</td>
    <td>{data.f_amtpay}</td>
    {/* <td>{data.cs_date}</td> */}
    <td>View</td>
    <td>Open</td>
    <td>{data.T_orderid}</td>
    <td className="text-center td_comments">
      {/* <Link
    to={`/dashboard/proposalview/${data.T_orderid}`}
  > */}
      <AiOutlineFileSearch
        onClick={() => handleShow2(data.T_orderid)}
      />
      {/* </Link> */}
      <RiDeleteBin6Line
        onClick={() => onDelete(data.T_orderid)}
      />
    </td>
  </tr>)) : <tr><td className="no_records" colSpan="12">No Records Found</td></tr>

  const proposalList1 = ProposalData.data.length !== 0 ? ProposalData.data.map((data, inx) => (<tr key={"custable1" + inx}>
    <td className="text-center">{inx + 1}</td>
    <td>{data.f_proposaluser}</td>
    <td>{data.f_heading}</td>
    <td>
      {/* {data.T_orderdate.slice(0, 10)} */}
      {Moment(data.T_orderdate).format("DD-MM-YYYY")}
    </td>
    <td>{data.f_totimg}</td>
    <td>{data.f_amt}</td>
    <td>{data.f_discount}</td>
    <td>{data.f_amtpay}</td>
    {/* <td>{data.cs_date}</td> */}
    <td>View</td>
    <td>Open</td>
    <td>{data.T_orderid}</td>
    <td className="text-center td_comments">
      <AiOutlineFileSearch
        onClick={() => handleShow2(data.T_orderid)}
      />
      <RiDeleteBin6Line
        onClick={() => onDelete(data.T_orderid)}
      />
    </td>
  </tr>)) : <tr><td className="no_records" colSpan="12">No Records Found</td></tr>

  const followupList = followFilterData.length !== 0 ? followFilterData.map((data, inx) => (<tr key={"custable1" + inx}>
    <td className="text-center">{inx + 1}</td>
    <td>
      {data.f_Firstname} {data.f_lastName}
      <br /> {data.f_EmailID} <br /> {data.f_State}
    </td>
    <td>{data.f_CompanyName}</td>
    <td>{data.f_UserType}</td>
    <td>{data.f_createdby}</td>
    <td>Upload Images</td>
    <td>Open</td>
    <td>
      {/* {data.f_creationdate.slice(0, 10)} */}
      {Moment(data.f_creationdate).format("DD-MM-YYYY")}
    </td>
    <td>{data.f_RequirementType}</td>
    <td>{data.f_Discountterms}</td>
    <td className="text-center td_comments">
      <AiOutlineFileSearch
        onClick={() => {
          handleShow(data.f_sno);
        }}
      />
      <IoExitOutline
        onClick={() => {
          handleShow1(data.f_sno);
        }}
      />
    </td>
  </tr>)) : <tr><td className="no_records" colSpan="11">No Records Found</td></tr>

  const followupList1 = followFilterData.length !== 0 ? followFilterData.slice(0, 10).map((data, inx) => (<tr key={"custable1" + inx}>
    <td className="text-center">{inx + 1}</td>
    <td>
      {data.f_Firstname} {data.f_lastName}
      <br /> {data.f_EmailID} <br /> {data.f_State}
    </td>
    <td>{data.f_CompanyName}</td>
    <td>{data.f_UserType}</td>
    <td>{data.f_createdby}</td>
    <td>Upload Images</td>
    <td>Open</td>
    <td>
      {/* {data.f_creationdate.slice(0, 10)} */}
      {Moment(data.f_creationdate).format("DD-MM-YYYY")}
    </td>
    {/* <td>{data.cs_date}</td> */}
    <td>{data.f_RequirementType}</td>
    <td>{data.f_Discountterms}</td>
    <td className="text-center td_comments">
      <AiOutlineFileSearch
        onClick={() => {
          handleShow(data.f_sno);
        }}
      />
      <IoExitOutline
        onClick={() => {
          handleShow1(data.f_sno);
        }}
      />
    </td>
  </tr>)) : <tr><td className="no_records" colSpan="11">No Records Found</td></tr>

  return (
    <main className="main_afterlogin">
      <div className="col-md-12">
        <div
          className="page-header row no-gutters"
          style={{ paddingTop: "30px", margin: "0px" }}
        >
          <div className="col-8">
            <h3 className="page-title">
              {`${companyDetails.f_groupname} Group`}
            </h3>
          </div>
          <div className="col-4">
            <div className="float-right">
              {/* {Reg.f_registrationType === "Register" ? ( */}
              <div>
                <RB.ButtonGroup>
                  <RB.Button
                    size="sm"
                    className="btn_svg"
                    variant="primary"
                  >
                    <Link to="/dashboard/searchdata" ><IoIosArrowBack />
                      Back
                    </Link>
                  </RB.Button>
                </RB.ButtonGroup>

              </div>
              {/* ) : (
                <RB.Button disabled>Edit</RB.Button>
              )} */}

              {/* <p>{Reg.f_registrationType}</p> */}
            </div>
          </div>
        </div>
      </div>
      <RB.Row style={{ paddingTop: "10px" }} className="rownew1">
        <RB.Col md={12}>
          <div className="box_detail" style={{ borderRadius: "4px" }}>
            <RB.Row style={{ paddingLeft: "25px", paddingRight: "25px" }}>
              <RB.Col md={8}>
                <p className="loc">
                  <strong>{companyDetails.f_companyname}</strong>
                </p>
                <p className="add">{companyDetails.f_address}</p>
                <p className="add">
                  {companyDetails.f_state}, {companyDetails.f_state},{" "}
                  {companyDetails.f_country} - 201301
                </p>
                <p className="grpname">
                  <strong>Group Name :</strong>{" "}
                  <span style={{ color: "#0081ad", fontWeight: "600" }}>
                    {companyDetails.f_groupname}
                  </span>{" "}
                  <span className="lowc"> </span>
                </p>
              </RB.Col>
              <RB.Col md={4}>
                <div className="float-right">
                  {/* <button
                    className="btn btn-block btn-edit btn-sm"
                    type="submit"
                  >
                    Edit
                  </button> */}
                </div>
              </RB.Col>
            </RB.Row>
          </div>
        </RB.Col>

        <RB.Col md={12}>
          <div className="page-header row no-gutters" style={{ margin: "0px" }}>
            <div className="col-lg-8 col-md-12">
              <div className="tableHeader">
                <h3 className="page-title d-flex userv">
                  <span>User List</span>
                  {
                    userList.length > 10 ?
                      <RB.Button size="sm" variant="primary" onClick={viewGroupData} size="sm"
                      // disabled={userList.length > 10 ? false : true}
                      >
                        View All
                      </RB.Button> : null
                  }
                </h3>
              </div>
            </div>

            <div className="col-lg-4 col-md-12">
              <div
                className="demo-btn-group col-md-12 pd-r-0 float-right text-right pad-right"
                id="probtnt"
              ></div>
            </div>
          </div>
          <div className="box_detail table_boxdtl">
            <RB.Table striped bordered hover variant="dark" responsive>
              <thead>
                <tr>
                  <th className="s_not1 text-center">S. No.</th>
                  <th>User ID</th>
                  <th>Full Name</th>
                  <th>Mobile</th>
                  <th>Company Name</th>
                  <th>Business Company Type</th>
                  <th>Short Name</th>
                  <th>Group Name</th>
                  {/* <th>Date</th> */}
                  <th>Subscribe</th>
                  <th>State</th>
                  <th className="s_not text-center">Action</th>
                </tr>
              </thead>
              <tbody>
                {groupData.isView
                  ? [userList]
                  : [userList1]}
                { }
              </tbody>
            </RB.Table>
          </div>

          <div className="page-header row no-gutters" style={{ margin: "0px" }}>
            <div className="col-lg-8 col-md-12">
              <div className="tableHeader">
                <h3 className="page-title d-flex userv">
                  <span>Order List</span>
                  {
                    orderList.length > 10 ?
                      <RB.Button onClick={viewOrderData} size="sm"
                      // disabled={orderList.length > 10 ? false : true}
                      >
                        View All
                      </RB.Button> : null
                  }
                </h3>
              </div>
            </div>
            <div className="col-lg-4 col-md-12">
              <div
                className="demo-btn-group col-md-12 pd-r-0 float-right text-right pad-right"
                id="probtnt"
              >
                {/* {orderSpan.map((data, inx) => {
                  let { name, count } = data;
                  return (
                    <RB.ButtonGroup className="mr-2" key={"orderspanb" + inx}>
                      <RB.Button
                        size="sm"
                        onClick={() => {
                          orderFilter(name);
                        }}
                      >{`${name} - ${count}`}</RB.Button>
                    </RB.ButtonGroup>
                  );
                })} */}
              </div>
            </div>
          </div>

          <div
            className="box_detail table_boxdtl"
            style={{
              paddingTop: "0px",
              paddingBottom: "0px",
              borderRadius: "4px",
            }}
          >
            <RB.Table striped bordered hover variant="dark" responsive>
              <thead>
                <tr>
                  <th className="s_not1 text-center">S. No.</th>
                  <th className="s_notd">Order ID</th>
                  <th>Client Name</th>
                  <th>Email</th>
                  <th>Amount</th>
                  <th className="s_notd">Date</th>
                  <th>Order STatus</th>
                  <th>Payment Status</th>
                  <th>Order Amt</th>
                  <th>Invoice Id</th>
                  {/* <th>Date</th> */}
                  <th className="s_not text-center">Action</th>
                </tr>
              </thead>
              <tbody>
                {OrderData.isView
                  ? [orderList]
                  : [orderList1]}
                { }

              </tbody>
            </RB.Table>
          </div>

          <div className="page-header row no-gutters" style={{ margin: "0px" }}>
            <div className="col-lg-8 col-md-12">
              <div className="tableHeader">
                <h3 className="page-title d-flex userv">
                  <span>Proposal List</span>
                  {
                    proposalList.length > 10 ?
                      <RB.Button onClick={viewProposalData} size="sm"
                      // disabled={proposalList.length > 10 ? false : true}
                      >
                        View All
                      </RB.Button> : null
                  }
                </h3>
              </div>
            </div>
            <div className="col-lg-4 col-md-12">
              <div
                className="demo-btn-group col-md-12 pd-r-0 float-right text-right pad-right"
                id="probtnt"
              >
                {/* <button type="button" className="btn btn-dark btn-sm mr-2">
                  Active - 05
                </button>
                <button type="button" className="btn btn-dark btn-sm ">
                  Inactive - 03
                </button> */}
              </div>
            </div>
          </div>

          <div
            className="box_detail table_boxdtl"
            style={{
              paddingTop: "0px",
              paddingBottom: "0px",
              borderRadius: "4px",
            }}
          >
            <RB.Table striped bordered hover variant="dark" responsive>
              <thead>
                <tr>
                  <th className="s_not1 text-center">S. No.</th>
                  <th>User Name</th>
                  <th>Heading</th>
                  <th className="s_notd">Date</th>
                  <th>Image</th>
                  <th>Amount ₹</th>
                  <th>Discount ₹</th>
                  <th>Total Amt ₹</th>
                  {/* <th>Date</th> */}
                  <th>Proposal Updates</th>
                  <th>Status Update</th>
                  <th>Refrences ID</th>
                  <th className="s_not text-center">Action</th>
                </tr>
              </thead>
              <tbody>
                {ProposalData.isView
                  ? [proposalList]
                  : [proposalList1]}
                { }
              </tbody>
            </RB.Table>
          </div>

          <div className="page-header row no-gutters" style={{ margin: "0px" }}>
            <div className="col-lg-8 col-md-12">
              <div className="tableHeader">
                <h3 className="page-title d-flex userv">
                  <span>FollowUp List</span>
                  {
                    followupList.length > 10 ?
                      <RB.Button onClick={viewFollowupData} size="sm"
                      // disabled={followupList.length > 10 ? false : true}
                      >
                        View All
                      </RB.Button> : null
                  }
                </h3>
              </div>
            </div>
            <div className="col-lg-4 col-md-12">
              <div
                className="demo-btn-group col-md-12 pd-r-0 float-right text-right pad-right"
                id="probtnt"
              >
                {/* {followupSpan.map((data, inx) => {
                  let { name, count } = data;
                  return (
                    <RB.ButtonGroup className="mr-2" key={"orderspanb" + inx}>
                      <RB.Button
                        size="sm"
                        onClick={() => {
                          openFilter(name);
                        }}
                      >{`${name} - ${count}`}</RB.Button>
                    </RB.ButtonGroup>
                  );
                })} */}
              </div>
            </div>
          </div>

          <div
            className="box_detail table_boxdtl"
            style={{
              paddingTop: "0px",
              paddingBottom: "0px",
              borderRadius: "4px",
            }}
          >
            <RB.Table striped bordered hover variant="dark" responsive>
              <thead>
                <tr>
                  <th className="s_not1 text-center">S. No.</th>
                  <th>User Details</th>
                  <th>Company Name</th>
                  <th>User Type</th>
                  <th>Requirement Type</th>
                  <th>User</th>
                  <th>Status</th>
                  <th className="s_notd">Date</th>
                  {/* <th>Date</th> */}
                  <th>Type</th>
                  <th>Discount Terms</th>
                  <th className="s_not text-center">Action</th>
                </tr>
              </thead>
              <tbody>
                {FollowupData.isView
                  ? [followupList]
                  : [followupList1]}
                { }
              </tbody>
            </RB.Table>
          </div>
        </RB.Col>
      </RB.Row>

      <RB.Modal show={show} onHide={handleClose} size="lg">
        <RB.Modal.Header closeButton className="view_create">
          <RB.Modal.Title style={{ fontWeight: "bold", fontSize: "22px" }}>
            Daily Sales Entry Follow Ups - Create
          </RB.Modal.Title>
        </RB.Modal.Header>
        <RB.Modal.Body className="show-grid view_create">
          <RB.Form>
            <RB.Form.Group as={Row} controlId="formPlaintextEmail">
              <RB.Col sm="6" className="right_mar">
                <RB.Form.Label>Email</RB.Form.Label>
                <RB.Form.Control
                  plaintext
                  readOnly
                  defaultValue={FormData.f_EmailID}
                />
              </RB.Col>
              <RB.Col sm="6" className="left_mar">
                <RB.Form.Label>Requirement followups</RB.Form.Label>
                <RB.Form.Control
                  as="select"
                  onChange={(e) => {
                    const data = { ...FormData };
                    data.f_status = e.target.value;
                    setFormData({ ...data });
                  }}
                >
                  <option value="Open">Open</option>
                  <option value="Close">Close</option>
                  <option value="PClose">PClose</option>
                  <option value="Sold">Sold</option>
                  <option value="UpgradeSold">Upgrade Sold</option>
                  <option value="QPackSold">QPack Sold</option>
                  <option value="DQuerySold">DQuery Sold</option>
                  <option value="DPackSold">DPack Sold</option>
                  <option value="ExcludeSold">Exclude Sold</option>
                </RB.Form.Control>
              </RB.Col>
            </RB.Form.Group>

            <Form.Group as={Row} controlId="exampleForm.ControlTextarea1">
              <RB.Col sm="6" className="right_mar">
                <Form.Label>Description</Form.Label>
                <Form.Control
                  as="textarea"
                  className="textarea"
                  name="discription"
                  onChange={handleChange}
                />
              </RB.Col>
              <RB.Col sm="6" className="left_mar">
                <div style={{ marginBottom: "1rem" }}>
                  <Form.Label>Followups by</Form.Label>
                  <Form.Control
                    as="select"
                    onChange={(e) => {
                      const data = { ...FormData };
                      data.f_followpby = e.target.value;
                      setFormData({ ...data });
                    }}
                  >
                    <option value={`${FormData.f_followpby}`}>
                      {FormData.f_followpby}
                    </option>
                    <option value="Email">Email</option>
                    <option value="Call">Call</option>
                  </Form.Control>
                </div>
                <div>
                  <Form.Label>State</Form.Label>
                  <Form.Control
                    as="select"
                    onChange={(e) => {
                      const data = { ...FormData };
                      data.f_State = e.target.value;
                      setFormData({ ...data });
                    }}
                  >
                    <option value={`${FormData.f_State}`}>
                      {FormData.f_State}
                    </option>
                    <option value="Delhi">Delhi</option>
                    <option value="Goa">Goa</option>
                  </Form.Control>
                </div>
              </RB.Col>
            </Form.Group>

            <Form.Group as={Row} controlId="formPlaintextPassword">
              <RB.Col sm="6" className="right_mar">
                <Form.Label>How they came to know about IB</Form.Label>
                <Form.Control
                  as="select"
                  onChange={(e) => {
                    const data = { ...FormData };
                    data.f_IbOption = e.target.value;
                    setFormData({ ...data });
                  }}
                >
                  <option value={`${FormData.f_IbOption}`}>
                    {FormData.f_IbOption}
                  </option>
                  <option value="KnowBefore">Know before</option>
                  <option value="Google">Google</option>
                  <option value="Emailer">Emailer</option>
                  <option value="sales">Sales</option>
                </Form.Control>
              </RB.Col>
              <RB.Col sm="6" className="left_mar">
                <Form.Label>Company name</Form.Label>
                <Form.Control
                  type="text"
                  placeholder="Enter Company Name"
                  name="f_CompanyName"
                  value={FormData.f_CompanyName}
                  onChange={handleChange}
                />
              </RB.Col>
            </Form.Group>

            <Form.Group as={Row} controlId="formPlaintextEmail">
              <RB.Col sm="6" className="right_mar">
                <Form.Label>Followups Date</Form.Label>
                <Form.Control
                  type="text"
                  placeholder="Enter Date"
                  name="f_creationdate"
                  value={FormData.f_creationdate}
                  onChange={handleChange}
                />
              </RB.Col>
              <RB.Col sm="6" className="left_mar">
                <Form.Label>Contact NO.</Form.Label>
                <Form.Control
                  type="text"
                  placeholder="Enter Mobile Number"
                  name="f_MobileNo"
                  value={FormData.f_MobileNo}
                  onChange={handleChange}
                />
              </RB.Col>
            </Form.Group>

            <Form.Group as={Row} controlId="formPlaintextEmail">
              <RB.Col sm="6" className="right_mar">
                <Form.Label>Contact person</Form.Label>
                <Form.Control
                  type="text"
                  placeholder="Enter Contact Person"
                  name="f_Firstname"
                  value={FormData.f_Firstname}
                  onChange={handleChange}
                />
              </RB.Col>
              <RB.Col sm="6" className="left_mar">
                <Form.Label>Alternate Email</Form.Label>
                <Form.Control
                  type="email"
                  placeholder="Enter Alternative Email"
                  name="f_AlternateEmail"
                  value={FormData.f_AlternateEmail}
                  onChange={handleChange}
                />
              </RB.Col>
            </Form.Group>

            <Form.Group as={Row} controlId="formPlaintextEmail">
              <RB.Col sm="6" className="right_mar">
                <Form.Label>Requirement Type</Form.Label>
                <Form.Control
                  type="text"
                  placeholder="Enter Requirment Type"
                  name="f_RequirementType"
                  value={FormData.f_RequirementType}
                  onChange={handleChange}
                />
              </RB.Col>
              <RB.Col sm="6" className="left_mar">
                <Form.Label>Order Id</Form.Label>
                <Form.Control
                  type="text"
                  placeholder="Enter Order ID"
                  name="orderid"
                  value={FormData.orderid}
                  onChange={handleChange}
                />
              </RB.Col>
            </Form.Group>

            <Form.Group as={Row} controlId="formBasicCheckbox">
              <RB.Col sm="6" className="right_mar">
                <Form.Label>Important follow ups</Form.Label>
                <Form.Check type="checkbox" />
              </RB.Col>
              <RB.Col sm="6" className="left_mar">
                <Form.Label>Created by</Form.Label>
                <Form.Control
                  plaintext
                  readOnly
                  defaultValue={FormData.f_createdby}
                />
              </RB.Col>
            </Form.Group>
          </RB.Form>
        </RB.Modal.Body>
        <RB.Modal.Footer>
          <RB.Button variant="primary" onClick={onSubmit}>
            SUBMIT
          </RB.Button>
        </RB.Modal.Footer>
      </RB.Modal>

      <RB.Modal
        show={show1}
        onHide={handleClose1}
        size="lg"
        className="modal_con"
      >
        <RB.Modal.Header closeButton>
          <RB.Modal.Title style={{ fontWeight: "bold", fontSize: "22px" }}>
            Daily Sales Entry FollowUps - History
          </RB.Modal.Title>
        </RB.Modal.Header>
        <RB.Modal.Body className="show-grid">
          <RB.Table
            striped
            bordered
            hover
            variant="dark"
            responsive
            className="create_table history_table"
          >
            <thead>
              <tr>
                <th>Creation Date</th>
                <th>Followups Date</th>
                <th>Description</th>
                <th>Contact Person</th>
                <th>Contact No.</th>
                <th>Status</th>
                <th>Requirement Type</th>
                <th>Create By</th>
                <th>Follow up by</th>
                <th>Order Id</th>
              </tr>
            </thead>
            <tbody>
              {followTable.map((data, inx) => (
                <tr key={"follow_table_model" + inx}>

                  <td>

                    {Moment(data.f_date).format("DD-MM-YYYY")}
                  </td>
                  <td>
                    {/* {data.f_nextfollowupsdate.slice(0, 10)} */}
                    {Moment(data.f_nextfollowupsdate).format("DD-MM-YYYY")}
                  </td>
                  <td>{data.f_desc}</td>
                  <td>{data.f_contactperson}</td>
                  <td>{data.f_contactno}</td>
                  <td>{data.f_status}</td>
                  <td>{data.f_requrement}</td>
                  <td>{data.f_createby}</td>
                  <td>{data.f_followupsby}</td>
                  <td>{data.f_followupsby}</td>
                </tr>
              ))}
            </tbody>
          </RB.Table>
        </RB.Modal.Body>
      </RB.Modal>

      <ProposalInvoiceModel show2={show2} handleClose2={handleClose2} />

      <OrderDetailsModel
        OrderDetailsIsOpen={OrderDetailsIsOpen}
        CloseOrderDetails={CloseOrderDetails}
        OrderDataObj={OrderDataObj}
        OrderDataList={OrderDataList}
        OrderUser={OrderDataObj}
      />

      <OrderInvoiceModel
        OrderInvoiceIsOpen={OrderInvoiceIsOpen}
        CloseOrderInvoice={CloseOrderInvoice}
        OrderInvoiceObj={OrderInvoiceObj}
        OrderInvoiceList={OrderInvoiceList}
        OrderUser={OrderDataObj}
      />

    </main>
  );
};

export default CompanyAction;
