const logger = require("../utilities/logger")
const { APIError } = require("../utilities/APIError");
const {
    generateError,
    ERROR_STATUS_CODE,
    INTERNAL_SERVER_ERROR,
    EMAIL_NOT_EXISTS,
    WRONG_PASSWORD,
    PERMISSION_DENIED,
    PASSWORD_NOT_MATCH
} = require("../utilities/errorContants");
const { getDateArr } = require("../utilities/helper");
const { Merchant, Payment, TrackData } = require("../models/model.index")

exports.get15daysShipmentData = async (req, res, next) => {
    const { _id } = req.params
    const dateArr = getDateArr(16);
    let { [dateArr.length - 1]: ed_date } = dateArr;
    try {
        var pipeline = [
            {
                $match: {
                    userId: _id,
                    createdAt: {
                        $lte: new Date(),
                        $gte: ed_date,
                    },
                },
            },
            {
                $group: {
                    _id: {
                        $dateToString: {
                            format: "%Y-%m-%d",
                            date: "$createdAt",
                        },
                    },
                    count: {
                        $sum: 1,
                    },
                },
            },
            {
                $sort: {
                    _id: -1
                }
            }
        ];
        const getData = await Payment.find({ userId: _id });
        let creditAmount = 0;
        let debitAmount = 0;
        for (let i = 0; i < getData.length; i++) {
            if (getData[i].payment_type === "Credit") {
                creditAmount = creditAmount + getData[i].payed_amount;
            } else {
                debitAmount = debitAmount + getData[i].payed_amount;
            }
        }
        let query = TrackData.aggregate(pipeline);
        let graph = await query.exec();
        res.json({ status: 200, graph, creditAmount, debitAmount });
    } catch (error) {
        logger.error(
            `Error while registering user with details ${JSON.stringify(
                req.body
            )} and error ${generateError(error)}`
        );
        return next(
            new APIError(
                ERROR_STATUS_CODE.INTERNAL_SERVER_ERROR_CODE,
                INTERNAL_SERVER_ERROR,
                error.message
            )
        );
    }
}

//-----SHIPMENT(START)

exports.getShipmentDropSearch = async (req, res, next) => {
    const { _id } = req.params;
    try {
        const pipeline = [
            {
                $match: { userId: _id }
            },
            {
                $group: { _id: { provider: "$shipping_method" } },
            }
        ]
        const pipeline1 = [
            {
                $match: { userId: _id }
            },
            {
                $group: { _id: { status: "$fulfillment_status" } },
            }
        ]
        const data = await TrackData.aggregate(pipeline);
        const data1 = await TrackData.aggregate(pipeline1);
        let provider = ["All Provider"];
        let status = ["All Status"];
        data.forEach(element => {
            provider.push(element._id.provider)
        })
        data1.forEach(element => {
            status.push(element._id.status)
        })
        res.json({ provider, status })
    } catch (error) {
        logger.error(
            `Error while registering user with details ${JSON.stringify(
                req.body
            )} and error ${generateError(error)}`
        );
        return next(
            new APIError(
                ERROR_STATUS_CODE.INTERNAL_SERVER_ERROR_CODE,
                INTERNAL_SERVER_ERROR,
                error.message
            )
        );
    }
}

exports.getTrakingDetails = async (req, res, next) => {
    const { _id, pagecount, searchbyname } = req.query;
    let limit = 20
    try {
        if (!searchbyname) {
            const trakingDetailsList = await TrackData
                .find({ userId: _id }, { shipping_method: 1, order_id: 1, order_number: 1, order_amount: 1, tracking_number: 1, createdAt: 1, fulfillment_status: 1, from_address: 1 })
                .sort({ createdAt: -1 })
                .skip(limit * pagecount)
                .limit(20)
            const shipExportList = await TrackData.find({userId: _id}) 
            res.json({ status: 200, trakingDetailsList, shipExportList })
        }
        if (searchbyname !== "") {
            const pipeline = [
                {
                    $match: {
                        userId: _id,
                        $or: [
                            { "from_address.name": { $regex: searchbyname, $options: 'im' } },
                            { tracking_number: { $regex: searchbyname, $options: 'im' } },
                            { order_id: { $regex: searchbyname, $options: 'im' } },
                        ]
                    }
                },
                { $project: { order_number: 1,order_id: 1, shipping_method: 1, order_amount: 1, tracking_number: 1, createdAt: 1, fulfillment_status: 1, from_address: 1 } },
                {
                    $skip: limit * pagecount
                },
                {
                    $limit: 20
                },
                {
                    $sort: { createdAt: -1 }
                }
            ]
            const pipeline1 = [
                {
                    $match: {
                        userId: _id,
                        $or: [
                            { "from_address.name": { $regex: searchbyname, $options: 'im' } },
                            { tracking_number: { $regex: searchbyname, $options: 'im' } },
                            { order_id: { $regex: searchbyname, $options: 'im' } },
                        ]
                    }
                },
            ]
            const trakingDetailsList = await TrackData.aggregate(pipeline);
            const shipExportList = await TrackData.aggregate(pipeline1)
            res.json({ status: 200, trakingDetailsList, shipExportList })
        }

    } catch (error) {
        logger.error(
            `Error while registering user with details ${JSON.stringify(
                req.body
            )} and error ${generateError(error)}`
        );
        return next(
            new APIError(
                ERROR_STATUS_CODE.INTERNAL_SERVER_ERROR_CODE,
                INTERNAL_SERVER_ERROR,
                error.message
            )
        );
    }
}

exports.getTrakingDetailsView = async (req, res, next) => {
    try {
        const { tracking_number } = req.params
        const trakingData = await TrackData.findOne({ tracking_number })
        res.json({ status: 200, trakingData })
    } catch (error) {
        logger.error(
            `Error while registering user with details ${JSON.stringify(
                req.body
            )} and error ${generateError(error)}`
        );
        return next(
            new APIError(
                ERROR_STATUS_CODE.INTERNAL_SERVER_ERROR_CODE,
                INTERNAL_SERVER_ERROR,
                error.message
            )
        );
    }
}

//onButton Serch Shipment(NEED TO CHANGE)
exports.getTrakingDetailsByButtonSearch = async (req, res, next) => {
    const data = req.body;
    const { _id } = req.params;
    const limit = 20;
    let { shipping_method, fulfillment_status, startDate, endDate, pagination } = data;
    if (!shipping_method) shipping_method = "All Provider"
    if (!fulfillment_status) fulfillment_status = "All Status"
    console.log(shipping_method, fulfillment_status, startDate, endDate)
    var s_date = new Date(startDate);
    var e_date = new Date(endDate);
    s_date.setHours(1);
    e_date.setHours(23);
    let pipeline;
    let pipeline1;
    try {
        if (shipping_method === "All Provider" && fulfillment_status === "All Status" && startDate === 0 && endDate === 0) {
            pipeline = [{ $match: { userId: _id } }, { $skip: limit * pagination }, { $limit: 20 }, { $sort: { createdAt: -1 } }]
            pipeline1 = [{ $match: { userId: _id } }]
        }

        if (startDate == 0 && endDate == 0) {
            if (shipping_method != "All Provider" && fulfillment_status != "All Status") {
                pipeline = [{ $match: { userId: _id, shipping_method, fulfillment_status } }, { $skip: limit * pagination }, { $limit: 20 }, { $sort: { createdAt: -1 } }]
                pipeline1 = [{ $match: { userId: _id, shipping_method, fulfillment_status } }]
            }
            if (shipping_method != "All Provider" && fulfillment_status == "All Status") {
                pipeline = [{ $match: { userId: _id, shipping_method } }, { $skip: limit * pagination }, { $limit: 20 }, { $sort: { createdAt: -1 } }]
                pipeline1 = [{ $match: { userId: _id, shipping_method } }]
            }
            if (shipping_method == "All Provider" && fulfillment_status != "All Status") {
                pipeline = [{ $match: { userId: _id, fulfillment_status } }, { $skip: limit * pagination }, { $limit: 20 }, { $sort: { createdAt: -1 } }]
                pipeline1 = [{ $match: { userId: _id, fulfillment_status } }]
            }
        }

        if (startDate != 0 && endDate != 0) {
            if (shipping_method == "All Provider" && fulfillment_status == "All Status") {
                pipeline = [
                    {
                        $match: {
                            userId: _id,
                            createdAt: {
                                $gte: s_date,
                                $lte: e_date,
                            },
                        }
                    },
                    {
                        $skip: limit * pagination
                    },
                    {
                        $limit: 20
                    },
                    {
                        $sort: { createdAt: -1 }
                    }
                ];
                pipeline1 = [
                    {
                        $match: {
                            userId: _id,
                            createdAt: {
                                $gte: s_date,
                                $lte: e_date,
                            },
                        }
                    }
                ]
            }
            if (shipping_method != "All Provider" && fulfillment_status != "All Status") {
                pipeline = [
                    {
                        $match: {
                            userId: _id,
                            shipping_method,
                            fulfillment_status,
                            createdAt: {
                                $gte: s_date,
                                $lte: e_date,
                            },
                        }
                    },
                    {
                        $skip: limit * pagination
                    },
                    {
                        $limit: 20
                    },
                    {
                        $sort: { createdAt: -1 }
                    }
                ];

                pipeline1 = [
                    {
                        $match: {
                            userId: _id,
                            shipping_method,
                            fulfillment_status,
                            createdAt: {
                                $gte: s_date,
                                $lte: e_date,
                            },
                        }
                    }
                ]
            }
            if (shipping_method != "All Provider" && fulfillment_status == "All Status") {
                pipeline = [
                    {
                        $match: {
                            userId: _id,
                            shipping_method,
                            createdAt: {
                                $gte: s_date,
                                $lte: e_date,
                            },
                        }
                    },
                    {
                        $skip: limit * pagination
                    },
                    {
                        $limit: 20
                    },
                    {
                        $sort: { createdAt: -1 }
                    }
                ];

                pipeline1 = [
                    {
                        $match: {
                            userId: _id,
                            shipping_method,
                            createdAt: {
                                $gte: s_date,
                                $lte: e_date,
                            },
                        }
                    }
                ]
            }
            if (shipping_method == "All Provider" && fulfillment_status != "All Status") {
                pipeline = [
                    {
                        $match: {
                            userId: _id,
                            fulfillment_status,
                            createdAt: {
                                $gte: s_date,
                                $lte: e_date,
                            },
                        }
                    },
                    {
                        $skip: limit * pagination
                    },
                    {
                        $limit: 20
                    },
                    {
                        $sort: { createdAt: -1 }
                    }
                ];

                pipeline1 = [
                    {
                        $match: {
                            userId: _id,
                            fulfillment_status,
                            createdAt: {
                                $gte: s_date,
                                $lte: e_date,
                            },
                        }
                    }
                ]
            }

        }
        const filteredData = await TrackData.aggregate(pipeline);
        const shipExportList = await TrackData.aggregate(pipeline1)
        res.json({ filteredData, shipExportList })

    } catch (error) {
        logger.error(
            `Error while registering user with details ${JSON.stringify(
                req.body
            )} and error ${generateError(error)}`
        );
        return next(
            new APIError(
                ERROR_STATUS_CODE.INTERNAL_SERVER_ERROR_CODE,
                INTERNAL_SERVER_ERROR,
                error.message
            )
        );
    }
}
//onButton Serch CODReports(NEED TO CHANGE)
exports.CODbuttonSearch = async (req, res, next) => {
    const data = req.body
    const { _id } = req.params
    let { shipping_method, startDate, endDate, pagination } = data;
    var s_date = new Date(startDate);
    var e_date = new Date(endDate);
    let limit = 20
    s_date.setHours(1);
    e_date.setHours(23);
    let pipeline1;
    try {
        if (!shipping_method && startDate == 0 && endDate == 0) {
            const filteredData = await TrackData.find({ userId: _id }).skip(limit * pagination).limit(20).sort({ createdAt: -1 })
            pipeline1 = [{ $match: { userId: _id } }];
            let shipExportList = await TrackData.aggregate(pipeline1)
            res.json({ message: "1st", filteredData, shipExportList })
        } else if (shipping_method && startDate == 0 && endDate == 0) {
            const filteredData = await TrackData.find({ userId: _id, shipping_method }).skip(limit * pagination).limit(20).sort({ createdAt: -1 })
            pipeline1 = [{ $match: { userId: _id, shipping_method } }]
            let shipExportList = await TrackData.aggregate(pipeline1)
            if (filteredData <= 0) {
                let filteredData = await TrackData.find({ userId: _id, }).skip(limit * pagination).limit(20).sort({ createdAt: -1 })
                pipeline1 = [{ $match: { userId: _id } }]
                let shipExportList = await TrackData.aggregate(pipeline1)
                res.json({ filteredData, shipExportList })
            } else {
                res.json({ message: "2nd", filteredData, shipExportList })
            }
        } else if (!shipping_method || shipping_method === "All Providers" && startDate != 0 && endDate != 0) {
            console.log(shipping_method, startDate, endDate)
            var pipeline = [
                {
                    $match: {
                        userId: _id,
                        createdAt: {
                            $gte: s_date,
                            $lte: e_date,
                        },
                    },
                },
                {
                    $skip: limit * pagination
                },
                {
                    $limit: 20
                },
                {
                    $sort: { createdAt: -1 }
                }
            ];
            pipeline1 = [
                {
                    $match: {
                        userId: _id,
                        createdAt: {
                            $gte: s_date,
                            $lte: e_date,
                        },
                    },
                },
            ]
            let filteredData = await TrackData.aggregate(pipeline);
            let shipExportList = await TrackData.aggregate(pipeline1);
            res.json({ message: "3st", filteredData, shipExportList })
        } else {
            var pipeline = [
                {
                    $match: {
                        userId: _id,
                        shipping_method,
                        createdAt: {
                            $gte: s_date,
                            $lte: e_date,
                        },
                    },
                },
                {
                    $skip: limit * pagination
                },
                {
                    $limit: 20
                },
                {
                    $sort: { createdAt: -1 }
                }
            ];
            pipeline1 = [
                {
                    $match: {
                        userId: _id,
                        shipping_method,
                        createdAt: {
                            $gte: s_date,
                            $lte: e_date,
                        },
                    },
                },
            ]
            let filteredData = await TrackData.aggregate(pipeline);
            let shipExportList = await TrackData.aggregate(pipeline1);
            if (shipping_method === "All Providers") {
                let filteredData = await TrackData.find({ userId: _id }).skip(limit * pagination).limit(20).sort({ createdAt: -1 });
                pipeline1 = [{ $match: { userId: _id } }]
                let shipExportList = await TrackData.aggregate(pipeline1);
                res.json({ filteredData, shipExportList })
            } else {
                if (filteredData <= 0) {
                    var pipeline = [
                        {
                            $match: {
                                userId: _id,
                                createdAt: {
                                    $gte: s_date,
                                    $lte: e_date,
                                },
                            },
                        },
                        {
                            $skip: limit * pagination
                        },
                        {
                            $limit: 20
                        },
                        {
                            $sort: { createdAt: -1 }
                        }
                    ];

                    pipeline1 = [
                        {
                            $match: {
                                userId: _id,
                                createdAt: {
                                    $gte: s_date,
                                    $lte: e_date,
                                },
                            },
                        },
                    ]
                    let filteredData = await TrackData.aggregate(pipeline);
                    let shipExportList = await TrackData.aggregate(pipeline1);
                    res.json({ message: "4st", filteredData, shipExportList })
                } else {
                    res.json({ message: "4st", filteredData, shipExportList })
                }
            }
        }
    } catch (error) {
        logger.error(
            `Error while registering user with details ${JSON.stringify(
                req.body
            )} and error ${generateError(error)}`
        );
        return next(
            new APIError(
                ERROR_STATUS_CODE.INTERNAL_SERVER_ERROR_CODE,
                INTERNAL_SERVER_ERROR,
                error.message
            )
        );
    }
}

//-----SHIPMENT(END)

//-----PAYMENT(START)
exports.getPaymentSatelments = async (req, res, next) => {
    const { _id } = req.params
    try {
        const records = await Payment.find({ userId: _id }).sort({ createdAt: -1 })
        let sumCredit = 0;
        let sumDebit = 0;
        for (let i = 0; i < records.length; i++) {
            if (records[i].payment_type === "Credit") {
                sumCredit = sumCredit + records[i].payed_amount;
            } else {
                sumDebit = sumDebit + records[i].payed_amount;
            }
        }
        let netPayble = sumCredit > sumDebit ? sumCredit - sumDebit : 0;
        let netReceiveble =
            sumDebit > sumCredit ? Math.abs(sumDebit - sumCredit) : 0;
        res.json({ status: 200, records, sumCredit, sumDebit, netPayble, netReceiveble })
    } catch (error) {
        logger.error(
            `Error while registering user with details ${JSON.stringify(
                req.body
            )} and error ${generateError(error)}`
        );
        return next(
            new APIError(
                ERROR_STATUS_CODE.INTERNAL_SERVER_ERROR_CODE,
                INTERNAL_SERVER_ERROR,
                error.message
            )
        );
    }
}

exports.paymentDateFilter = async (req, res, next) => {
    const data = req.body;
    const { _id } = req.params
    const { startDate, endDate } = data
    let s_date = new Date(startDate);
    let e_date = new Date(endDate);
    s_date.setHours(1);
    e_date.setHours(23);
    let pipeline;
    if (startDate !== 0 || endDate !== 0) {
        pipeline = [
            {
                $match: {
                    userId: _id,
                    createdAt: {
                        $gte: s_date,
                        $lte: e_date,
                    },
                },
            },
            { $sort: { createdAt: -1 } }
        ]
    } else {
        pipeline = [
            {
                $match: {
                    userId: _id,
                },
            },
            { $sort: { createdAt: -1 } }
        ]
    }
    try {
        const paymentDetails = await Payment.aggregate(pipeline);
        res.json({ paymentDetails })
    } catch (error) {
        logger.error(
            `Error while registering user with details ${JSON.stringify(
                req.body
            )} and error ${generateError(error)}`
        );
        return next(
            new APIError(
                ERROR_STATUS_CODE.INTERNAL_SERVER_ERROR_CODE,
                INTERNAL_SERVER_ERROR,
                error.message
            )
        );
    }
}
//----PAYMENT(END)

//----COUNT
exports.totalCounts = async (req, res, next) => {
    const { _id } = req.params;
    try {
        const shipmentCount = await TrackData.aggregate([{ $match: { userId: _id } }, { $count: "total" }])
        res.json({ shipmentCount: shipmentCount[0].total })
    } catch (error) {
        logger.error(
            `Error while registering user with details ${JSON.stringify(
                req.body
            )} and error ${generateError(error)}`
        );
        return next(
            new APIError(
                ERROR_STATUS_CODE.INTERNAL_SERVER_ERROR_CODE,
                INTERNAL_SERVER_ERROR,
                error.message
            )
        );
    }
}