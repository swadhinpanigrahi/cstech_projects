const profileDataRoute = require("express").Router();
const {
  userProfile,
  testFun,
  companyAction,
  proposalView,
  proposalDelete,
  getFollowupsDetail,
  getFollowupsDetailsForTable,
  postFollowups,
} = require("../controllers/profileDataController");

profileDataRoute.route("/getProfile/:_id").get(userProfile);
profileDataRoute.route("/profileData/:f_userid").get(testFun);
profileDataRoute.route("/companygroupdata/:f_userid").get(companyAction);
profileDataRoute.route("/proposalactionview/:_id").get(proposalView);
profileDataRoute.route("/proposalactiondelete/:_id").get(proposalDelete);
profileDataRoute.route("/getFollowupsDetail/:f_sno").get(getFollowupsDetail);
profileDataRoute
  .route("/getFollowupsDetailTable/:f_sno")
  .get(getFollowupsDetailsForTable);
profileDataRoute.route("/saveingnextfollowups").post(postFollowups);

module.exports = profileDataRoute;
