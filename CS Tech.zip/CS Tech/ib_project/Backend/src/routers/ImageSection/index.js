const ImageRoute = require("express").Router();

const Image = require("./managelist.routes")


ImageRoute.use(`/image`, Image);

module.exports = ImageRoute