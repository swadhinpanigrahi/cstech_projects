const { M_COMPANY } = require("../../model");


exports.addCompany = async (req, res) => {
    const {
        f_city, f_companygroup, f_companyname, f_discount, f_email, f_similarcompanyname
        , f_Assign
    } = req.body;
    try {
        const data = await M_COMPANY.findOne({ f_companyname });
        if (data) {
            res.json({ status: 400, message: "already exists!" })
        } else {
            const id = await Counter.findOneAndUpdate({ _id: "f_sno" }, {
                $inc: { sequence: 1 }
            }, { useFindAndModify: false });
            const saveData = await new M_COMPANY({
                f_sno: id.sequence,
                f_city, f_companygroup, f_companyname, f_discount,
                f_email, f_similarcompanyname, f_Assign
            }).save()
            res.json({ status: 200, saveData })
        }
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

exports.getCompanyList = async (req, res) => {
    const { currentPage, itemPerPage, searchData } = req.query;
    const num = parseInt(itemPerPage)
    const start = parseInt(currentPage);
    let pipeline;
    let countline;
    try {
        if (!searchData || searchData === "") {
            pipeline = [
                { $sort: { _id: -1 } },
                { $skip: (start - 1) * num },
                { $limit: num }
            ]
            countline = [
                { $count: "totalcount" }
            ]
        } else {
            pipeline = [
                { $match: { f_companyname: { $regex: searchData, $options: "im" } } },
                { $sort: { _id: -1 } },
                { $skip: (start - 1) * num },
                { $limit: num }
            ]
            countline = [
                { $match: { f_companyname: { $regex: searchData, $options: "im" } } },
                { $count: "totalcount" }
            ]
        }
        const data = await M_COMPANY.aggregate(pipeline)
        const totalrecord = await M_COMPANY.aggregate(countline)
        res.json({ status: 200, data, totalrecord })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

exports.getCompanyDetail = async (req, res) => {
    const { _id } = req.params
    try {
        const companyData = await M_COMPANY.findById({ _id });
        res.json({ status: 200, companyData })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

exports.updateCompanyDetail = async (req, res) => {
    const {
        _id, f_companyname, f_similarcompanyname, f_companygroup, f_discount, f_city
    } = req.body
    try {
        const companyData = await M_COMPANY.findByIdAndUpdate({ _id }, {
            $set: {
                f_companyname, f_similarcompanyname, f_companygroup, f_discount, f_city
            }
        });
        res.json({ status: 200, message: "company updated successfully" })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

exports.removeCompanyDetail = async (req, res) => {
    const { _id } = req.params
    try {
        const companyData = await M_COMPANY.findByIdAndRemove({ _id });
        res.json({ status: 200, message: "company removed successfully" })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}