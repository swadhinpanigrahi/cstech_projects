const { t_Images } = require("../../model");

exports.getSuspendedImageList = async (req, res) => {
    const { currentPage, itemPerPage, F_imgid } = req.query;
    const num = parseInt(itemPerPage)
    const start = parseInt(currentPage);
    let pipeline;
    let countline;
    try {
        const existData = await t_Images.findOne({ F_imgid })
        pipeline = [
            { $match: { F_group: existData.F_group } },
            { $skip: (start - 1) * num },
            { $limit: num }
        ]
        countline = [
            { $count: "totalcount" }
        ]
        const data = await t_Images.aggregate(pipeline)
        const totalrecord = await t_Images.aggregate(countline)
        res.json({ status: 200, data, totalrecord })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

exports.suspendImage = async (req, res) => {
    const { images, suspendate } = req.body;
    try {
        images.forEach(async (element) => {
            const updateData = await t_Images.updateOne({ F_imgid: element }, {
                $set: {
                    suspendate: suspendate
                }
            })
        })
        res.json({ images, suspendate })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}