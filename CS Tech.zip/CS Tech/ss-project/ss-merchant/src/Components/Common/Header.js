import React from "react";
import logo from "../../Images/final_logon.png";
import { useTranslation } from "react-i18next";


const Header = () => {
    const lang = localStorage.getItem("lang") || "en";
    const { t, i18n } = useTranslation();
    const change = (option) => {
        localStorage.setItem("lang", option.target.value);
        let language = localStorage.getItem("lang") || "en";
        i18n.changeLanguage(language);
        window.location.reload();
    };
    return (
        <header className="header_in before_loghead" style={{ background: "#212529" }}>
            <div className="container-fluid">
                <div className="row">
                    <div className="col-lg-7 col-md-8 col-12">
                        <div className="row">
                            <div id="logo" className="col-lg-3 col-md-4 col-5 beforelogo">
                                <a href="index.html">
                                    <img src={logo} alt="" className="logo_sticky new_logod" />
                                </a>
                            </div>
                            <div className="texth col-lg-6 col-md-5 col-7">
                                <h6>{t("change.Mheader")}</h6>
                                {/* <h6>Merchant Panel</h6> */}
                            </div>
                        </div>
                    </div>
                    <div className="col-lg-5 col-md-4 col-12">
                        <select
                            className="custom-select float-right change_language"
                            onChange={change}
                            value={lang}
                        >
                            <option value="en">English</option>
                            <option value="arab">Arabic</option>
                        </select>
                    </div>
                </div>
            </div>
            <div className="layer"></div>
        </header>
    );
};

export default Header;