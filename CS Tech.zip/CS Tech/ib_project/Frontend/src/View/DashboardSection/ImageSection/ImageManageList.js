import React, { useState, useEffect } from 'react';
import * as RB from 'react-bootstrap';
import { Row, Form, Col, Button } from "react-bootstrap"
import { MdAddCircleOutline } from 'react-icons/md';
import { RiDeleteBin6Line } from "react-icons/ri";
import { BiCommentEdit } from "react-icons/bi";
import { GET_IMGLIST, GET_IMG, REMOVE_IMG } from "../../../Utils/api";

import EditImage from "../../../Components/Models/ImageModals/EditImage";

import PaginationComponent from "../../../Components/Common/PaginationComponent";

import Modal from "../../../Components/Common/Modal";

import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";

const ImageManageList = () => {
    const [currentPage, setCurrentPage] = useState(1);
    const [itemPerPage, setItemPerPage] = useState(20);
    let [searchData, setSearchData] = useState("");
    const [Loading, setLoading] = useState(false)

    const [TotalCount, setTotalCount] = useState(0);

    const [isOpen, setIsOpen] = useState(false);
    const [ModelMsg, setModelMsg] = useState("");

    const [ImageListData, setImageListData] = useState([]);
    const [ImageDetail, setImageDetail] = useState({});
    const [selectedEmails, setSelectedEmails] = useState([]);
    const [showEditModal, setShowEditModal] = useState(false);
    const [OpenConvert, setOpenConvert] = useState(false)

    const [SuspendModalOpen, setSuspendModalOpen] = useState(false);

    const SearchDataFun = async (e) => {
        setSearchData(e.target.value);
        const res = await GET_IMGLIST(currentPage, itemPerPage, (searchData = e.target.value));
        let { data, totalrecord } = res;
        setImageListData(data);
        totalrecord.length === 1
            ? setTotalCount(totalrecord[0].totalcount)
            : setTotalCount(0);
    }

    const modelSet = async () => {
        setIsOpen(true);

    };

    const openModal = () => {
        if (selectedEmails.length > 0) {
            setOpenConvert(true)
        } else {
            window.alert("please select atleast one imageID!")
        }
    }

    const editImageDetails = async (_id) => {
        const res = await GET_IMG(_id);
        const { data } = res;
        setImageDetail(data);
        setTimeout(() => {
            setShowEditModal(true)
        }, 800);
    }

    const deleteImageDetails = async (_id) => {
        const res = await REMOVE_IMG(_id);
        let { message } = res;
        setModelMsg(message);
        apiCall();
        modelSet();
    }

    const OpenSuspendedModal = async (F_imgid) => {
        var d = new Date();
        var year = d.getFullYear();
        var month = d.getMonth();
        var day = d.getDate();
        var c = new Date(year + 10, month, day);
        console.log(c);
        console.log(F_imgid, c)
        setModelMsg("this image is suspended successfully!!");
        modelSet();
    }

    const apiCall = async () => {
        setLoading(true);
        const res = await GET_IMGLIST(currentPage, itemPerPage, searchData);
        if (res) {
            let { data, totalrecord } = res;
            setImageListData(data);
            setTotalCount(totalrecord[0].totalcount)
            setLoading(false)
        }
    }

    useEffect(() => {
        apiCall()
    }, [currentPage, itemPerPage])

    return (
        <>
            <RB.Row className="rownew1">
                <RB.Col lg={12}>
                    <RB.Row className="rownew1" style={{ paddingTop: "25px" }}>
                        <div className="tableHeader tableHeader1 order_btntable">
                            <RB.Col md={6} xs={12} className="table_span">
                                <h3 className="page-title d-flex userv">
                                    <span>Search Results</span>
                                </h3>
                            </RB.Col>
                            <RB.Col md={6} xs={12} className="table_span">
                                <div className="float-right responsive_floatbtn">
                                    <RB.Button size="sm" variant="primary" className="btn_svg"
                                        onClick={openModal}
                                    >
                                        <MdAddCircleOutline style={{ marginRight: "3px" }} />
                                        CONVERT PROCESS
                                    </RB.Button>
                                </div>
                            </RB.Col>
                        </div>
                    </RB.Row>
                </RB.Col>

                <RB.Col lg={12}>
                    <div className="box_detail" style={{ borderRadius: "4px" }}>
                        <div className="page-header row">
                            <RB.Col md={12}>
                                <RB.Form className="manage_searchorder">
                                    <RB.Row className="mg_row0">
                                        <RB.Col lg={12} md={12} className="customer_leftsrh">
                                            <RB.Row className="mg_row0">
                                                <RB.Col lg={3} md={3} className="customer_sdate">
                                                    <RB.Form.Group>
                                                        <RB.Form.Control
                                                            id="searchText"
                                                            type="text"
                                                            placeholder="Search by Text"
                                                            onChange={SearchDataFun}
                                                        />
                                                    </RB.Form.Group>
                                                </RB.Col>
                                            </RB.Row>
                                        </RB.Col>

                                    </RB.Row>
                                </RB.Form>
                            </RB.Col>
                        </div>
                    </div>
                </RB.Col>

                <RB.Col lg={12}>
                    <RB.Row className="rownew1">
                        <div className="tableHeader tableHeader1 search_new">
                            <RB.Col lg={6} md={6} className="table_span">
                                <h3 className="page-title d-flex userv">
                                    <span>Image List</span>
                                </h3>
                            </RB.Col>
                            <RB.Col lg={6} md={6} className="table_span total_recordt">
                                <span>Total Records: {TotalCount}</span>
                            </RB.Col>
                        </div>
                    </RB.Row>
                    <div
                        className="box_detail table_boxdtl manage_order"
                        style={{}}
                    >
                        <RB.Table striped bordered hover variant="dark" responsive>
                            <thead>
                                <tr class="vtable">
                                    <th className="text-center">Image</th>
                                    <th className="text-center">ImageId</th>
                                    <th className="" >Price Type</th>
                                    <th className="" >Image Type</th>
                                    <th className="" >Image Rank</th>
                                    <th className="" >Image Group</th>
                                    <th className="" >Suspend</th>
                                    <th className="text-center action_align">Action</th>
                                    <th><input type="checkbox" /></th>
                                </tr>
                            </thead>
                            <tbody>
                                {Loading ? <tr><td className="no_records" colSpan="11">Loading...</td></tr> : ImageListData.length > 0 ?
                                    <TableData
                                        {...{
                                            info: ImageListData,
                                            selectedEmails,
                                            setSelectedEmails,
                                            deleteImageDetails,
                                            editImageDetails,
                                            OpenSuspendedModal

                                        }} /> : <tr><td className="no_records" colSpan="11">No Records Found</td></tr>}
                            </tbody>
                        </RB.Table>
                    </div>

                    <PaginationComponent
                        MOCK_DATA={TotalCount}
                        currentPage={currentPage}
                        setCurrentPage={setCurrentPage}
                        itemPerPage={itemPerPage}
                        setItemPerPage={setItemPerPage}
                    />

                    <EditImage
                        showEditModal={showEditModal}
                        setShowEditModal={setShowEditModal}
                        ImageDetail={ImageDetail}
                        apiCall={apiCall}
                    />

                    <SuspendModal
                        SuspendModalOpen={SuspendModalOpen}
                        setSuspendModalOpen={setSuspendModalOpen}
                        selectedEmails={selectedEmails}
                    />

                    <ConvertProccessModal
                        OpenConvert={OpenConvert}
                        setOpenConvert={setOpenConvert}
                        selectedEmails={selectedEmails}
                    />

                    <Modal text={ModelMsg} open={isOpen} onClose={() => setIsOpen(false)} />

                </RB.Col>
            </RB.Row>
        </>
    )
}


export default ImageManageList;

const TableData = ({
    info,
    deleteImageDetails,
    selectedEmails: selectedEmail,
    setSelectedEmails,
    editImageDetails,
    OpenSuspendedModal
}) => {
    const handleCheck = (e, f_email) => {
        let { checked } = e.target;
        let selectedEmailVal = [...selectedEmail];
        if (checked) {
            selectedEmailVal.push(f_email);
        } else {
            let delIndex = selectedEmailVal.indexOf(f_email);
            selectedEmailVal.splice(delIndex, 1);
        }
        setSelectedEmails(selectedEmailVal);
    };
    return info.length !== 0 ? (
        info.map((data, inx) => {
            let { _id, F_rank, F_imgid, f_agencyname, f_imgType, F_group } = data;
            return (
                <tr key={`IMAGE_LIST_${inx}`}>
                    <td className="s_notm text-center">
                        <img className="img_dtlimg" src={`https://ibcdn.imagesbazaar.com/img170/${F_rank}-${F_imgid}.jpg`} alt="dyc_im2" />
                    </td>
                    <td className="">{F_imgid}</td>
                    <td className="">{f_agencyname}</td>
                    <td className="">{f_imgType}</td>
                    <td className="">{F_rank}</td>
                    <td className="">{F_group}</td>
                    <td className="" onClick={() => OpenSuspendedModal(F_imgid)}>suspend</td>
                    <td className="td_comments text-center">
                        <BiCommentEdit title="Edit Country" onClick={() => editImageDetails(_id)} />
                        <RiDeleteBin6Line title="Delete Country" className="text-danger1" onClick={() => deleteImageDetails(_id)} />
                    </td>
                    <td>
                        <RB.Form.Group className="mb-3" controlId="formBasicCheckbox">
                            <RB.Form.Check
                                type="checkbox"
                                name={data.F_imgid}
                                checked={selectedEmail.includes(data.F_imgid) || false}
                                onChange={(e) => {
                                    handleCheck(e, data.F_imgid);
                                }}
                            />
                        </RB.Form.Group>
                    </td>
                </tr>
            );
        })
    ) : (
        <tr>
            <td class="no_records" colspan="11">
                No Records Found
            </td>
        </tr>
    );
};


const SuspendModal = ({ SuspendModalOpen, setSuspendModalOpen, selectedEmails }) => {

    const [suspendate, setsuspendate] = useState(new Date())

    const closeModal = () => {
        setSuspendModalOpen(false)
    }

    const Suspend = async () => {

    }

    return (
        <>
            <RB.Modal show={SuspendModalOpen} onHide={closeModal}>
                <RB.Modal.Header closeButton>
                    <RB.Modal.Title>Modal heading</RB.Modal.Title>
                </RB.Modal.Header>
                <RB.Modal.Body>
                    {selectedEmails.map((list, inx) => {
                        return (
                            <li key={`SUSPENDNAMELST_${inx}`}>{list}</li>
                        )
                    })}
                    <DatePicker selected={suspendate} onChange={(date) => setsuspendate(date)} />
                </RB.Modal.Body>
                <RB.Modal.Footer>
                    <RB.Button variant="secondary" onClick={Suspend}>
                        Close
                    </RB.Button>
                    <RB.Button variant="primary" onClick={closeModal}>
                        Save Changes
                    </RB.Button>
                </RB.Modal.Footer>
            </RB.Modal>
        </>
    )
}



const ConvertProccessModal = ({ OpenConvert, setOpenConvert, selectedEmails }) => {

    const [FormData, setFormData] = useState({
        ImageDetails: selectedEmails,
        f_imgType: "I"
    })

    const closeModal = () => {
        setOpenConvert(false)
    }

    const handleChange = (e) => {
        const data = { ...FormData };
        data.f_imgType = e.target.value;
        setFormData(data)
    }

    const submit = async () => {
        console.log(FormData)
    }

    useEffect(() => {
        setFormData({ ...FormData, ImageDetails: selectedEmails })
    }, [selectedEmails])

    return (
        <>
            <RB.Modal show={OpenConvert} onHide={closeModal}>
                <RB.Modal.Header closeButton>
                    <RB.Modal.Title>Modal heading</RB.Modal.Title>
                </RB.Modal.Header>
                <RB.Modal.Body>
                    <Row>
                        <Form.Label column="sm" lg={2}>
                            Image ID
                        </Form.Label>
                        <Col>
                            {selectedEmails.map((d, i) => <p key={`${d}-${i}`}>{d}</p>)}
                        </Col>
                    </Row>
                    <Row>
                        <Form.Label column="sm" lg={2}>
                            Image Type
                        </Form.Label>
                        <Col>
                            <Form.Control
                                size="sm" as="select"
                                value={FormData.f_imgType}
                                onChange={handleChange}
                            >
                                <option value="I">I</option>
                                <option value="S">S</option>
                            </Form.Control>
                        </Col>
                    </Row>
                </RB.Modal.Body>
                <RB.Modal.Footer>
                    <RB.Button variant="secondary" onClick={closeModal}>
                        Close
                    </RB.Button>
                    <RB.Button variant="primary" onClick={submit}>
                        Save Changes
                    </RB.Button>
                </RB.Modal.Footer>
            </RB.Modal>
        </>
    )
}
