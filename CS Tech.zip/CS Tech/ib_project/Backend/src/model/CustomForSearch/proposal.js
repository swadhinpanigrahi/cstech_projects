const mongoose = require("mongoose");

const ProposalSchema = mongoose.Schema(
  {
    f_proposal_RefrencesID: { type: String },
    f_proposal_email: { type: String },
    f_proposalheading: { type: String },
    f_mobileno: { type: String },
    f_proposal_client: { type: String },
    f_Noofimages: { type: String },
    f_proposal_amount: { type: Number },
    f_proposal_discount: { type: String },
    f_taxamount: { type: Number },
    f_proposal_totalamount: { type: Number },
    f_status: { type: String },
    f_proposalType: { type: String },
    f_createdate: { type: Date },
  },
  { collection: "t_proposal_mongoDB" }
);

module.exports = proposal = mongoose.model(
  "t_proposal_mongoDB",
  ProposalSchema
);
