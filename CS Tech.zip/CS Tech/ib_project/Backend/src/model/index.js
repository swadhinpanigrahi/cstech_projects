const AdminLogin = require("./AdminLogin");
const registration = require("./CustomForSearch/registration");
const order = require("./CustomForSearch/order");
const followup = require("./CustomForSearch/followups");
const proposal = require("./CustomForSearch/proposal");
const forgetPassTkn = require("./forgetPassTkn");
const T_Orders_IB_MongoDB = require("./T_Orders_IB_MongoDB");
const t_LUS104576_IB_MongoDB = require("./t_LUS104576_IB_MongoDB");
const t_orderproposal_IB_MongoDB = require("./t_orderproposal_IB_MongoDB");
const t_ordproposal_details_IB_MongoDB = require("./t_ordproposal_details_IB_MongoDB");
// const t_DailySalesEntry_sales_IB_MongoDB = require("./t_DailySalesEntry_sales_IB_MongoDB");
const t_DailySalesEntryfollowups_sales_IB_MongoDB = require("./t_DailySalesEntryfollowups_sales_IB_MongoDB");
const t_TUR0615518_IB_MongoDB = require("./t_TUR0615518_IB_MongoDB");
// const orderSchema = require("./orderSchema");
const invoiceSchema = require("./invoiceSchema");
const orderDetailSchema = require("./orderDetailSchema");
const CountrySchema = require("./countrySchema");
const StateSchema = require("./stateSchema");
const CompanyMasterSchema = require("./companyMasterSchema");
const RegistrationSchema = require("./CustomForSearch/registration");
const HdfcHistorySchema = require("./hdfcHistorySchema");
const PurchaseImageSchema = require("./uploadPurchaseImageSchema");
const t_invoice_IB_MongoDB = require("./t_invoice_IB_MongoDB");
const T_images_full_viewing_Search = require("./T_images_full_viewing_Search");
const t_Images = require("./t_Images");
const t_pricingdetail = require("./t_pricingdetail");
const T_ShopingCart = require("./T_ShopingCart");
const Counter = require("./countModel")
const FollowupSchemaV2 = require('./followupMongoSchema');

const M_COUNTRY = require("./MasterModels/Master.Country");
const M_STATE = require("./MasterModels/Master.State");
const M_CITY = require("./MasterModels/Master.City");
const M_COMPANY = require("./MasterModels/Master.Company");
const M_INDUSTRY = require("./MasterModels/Master.Industry");
const M_STARSIZE = require("./MasterModels/Master.StarSize");
const M_STARPERIOD = require("./MasterModels/Master.StarPeriod");
const M_DISCOUNTTERMS = require("./MasterModels/Master.Discountterms");
const M_CREDITPERIOD = require("./MasterModels/Master.Creditperiod");
const M_MODALVEDIO = require("./MasterModels/Master.Modelvideo");
const M_SUBSCRIPTION = require("./MasterModels/Master.SubscriptionPlan");
const M_AGENCIES = require("./MasterModels/Master.TOP200Agencies");
const M_IMAGEVIDEO = require("./MasterModels/Master.ImageVideoSubscription");
const M_IMAGETYPE = require("./MasterModels/Master.ImageType");
const M_IMAGESIZE = require("./MasterModels/Master.ImageSize");

const M_PRICEDETAIL = require("./MasterModels/Master.PriceDetail");
const M_SIMILARGROUP = require("./MasterModels/Master.SimilarGroup");
const M_TAX = require("./MasterModels/Master.Tax");
const M_PAYMENTGATWAY = require("./MasterModels/Master.RightsPayment");

const T_visiblekeyword_MongoDB = require("./T_visiblekeyword_MongoDB");
const T_allkeyword_MongoDB = require("./T_allkeyword_MongoDB");

const t_BannerImgInfo = require("./t_BannerImgInfo")
const t_feedback = require("./t_feedback")
const t_imagesviedosubscription_download = require("./t_imagesviedosubscription_download");
const t_HighresUserList = require("./t_HighresUserList");
const t_Highres_down = require("./t_Highres_down");


module.exports = {
  AdminLogin,
  registration,
  order,
  followup,
  proposal,
  forgetPassTkn,
  T_Orders_IB_MongoDB,
  t_LUS104576_IB_MongoDB,
  t_orderproposal_IB_MongoDB,
  // t_DailySalesEntry_sales_IB_MongoDB,
  t_DailySalesEntryfollowups_sales_IB_MongoDB,
  t_TUR0615518_IB_MongoDB,
  invoiceSchema,
  orderDetailSchema,
  CountrySchema,
  StateSchema,
  CompanyMasterSchema,
  RegistrationSchema,
  HdfcHistorySchema,
  PurchaseImageSchema,
  t_ordproposal_details_IB_MongoDB,
  t_invoice_IB_MongoDB,
  T_images_full_viewing_Search,
  t_Images,
  t_pricingdetail,
  T_ShopingCart,
  Counter,
  FollowupSchemaV2,

  M_COUNTRY,
  M_STATE,
  M_CITY,
  M_COMPANY,
  M_INDUSTRY,
  M_STARSIZE,
  M_STARPERIOD,
  M_DISCOUNTTERMS,
  M_CREDITPERIOD,
  M_MODALVEDIO,
  M_SUBSCRIPTION,
  M_AGENCIES,

  M_IMAGEVIDEO,
  M_IMAGETYPE,
  M_IMAGESIZE,

  M_PRICEDETAIL,
  M_SIMILARGROUP,
  M_TAX,
  M_PAYMENTGATWAY,

  T_visiblekeyword_MongoDB,
  T_allkeyword_MongoDB,

  t_BannerImgInfo,
  t_feedback,
  t_imagesviedosubscription_download,
  t_HighresUserList,
  t_Highres_down
};
