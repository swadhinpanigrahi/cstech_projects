const mongoose = require("mongoose");

const MasterSimilarGroupSchema = mongoose.Schema(
    {
        f_sno: { type: Number },
        groupid: { type: String },
        S_groupid: { type: String },
        f_groupname: { type: String },
    },
    { collection: "t_similargp" }
);

module.exports = M_SIMILARGROUP = mongoose.model(
    "t_similargp",
    MasterSimilarGroupSchema
);