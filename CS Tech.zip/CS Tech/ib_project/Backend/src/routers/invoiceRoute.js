const invoiceRoute = require("express").Router();
const {
    getInvoiceDetail, InvoiceUpdate, InvoiceDropDown, getCompanyGroupName
} = require("../controllers/invoiceController")

invoiceRoute.route("/getinvoicedetail/:f_orderid").get(getInvoiceDetail);
invoiceRoute.route("/invoiceupdate/:f_orderid").post(InvoiceUpdate);
invoiceRoute.route("/invoicedropdata").get(InvoiceDropDown);
invoiceRoute.route("/getCompanyGroupName").post(getCompanyGroupName); 

module.exports = invoiceRoute;