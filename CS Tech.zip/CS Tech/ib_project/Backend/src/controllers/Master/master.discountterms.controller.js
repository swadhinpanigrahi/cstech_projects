const { M_DISCOUNTTERMS } = require("../../model");

exports.addDiscountTerm = async (req, res) => {
    const { f_discountterm, f_description } = req.body;
    try {
        const existingData = await M_DISCOUNTTERMS.findOne({ f_discountterm });
        if (existingData) {
            res.json({ status: 400, message: "discount term already exist" })
        }
        if (!existingData) {
            const Data = await new M_DISCOUNTTERMS({ f_discountterm, f_description }).save();
            if (Data) {
                res.json({ status: 200, message: "discount term added successfully" })
            }
        }
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

exports.getDiscounttermsList = async (req, res) => {
    const { currentPage, itemPerPage, searchData } = req.query;
    const num = parseInt(itemPerPage)
    const start = parseInt(currentPage);
    let pipeline;
    let countline;
    try {
        if (!searchData || searchData === "") {
            pipeline = [
                { $skip: (start - 1) * num },
                { $limit: num },
                { $sort: { _id: -1 } }
            ]
            countline = [
                { $count: "totalcount" }
            ]
        } else {
            pipeline = [
                { $match: { f_discountterm: { $regex: searchData, $options: "im" } } },
                { $skip: (start - 1) * num },
                { $limit: num },
                { $sort: { _id: -1 } }
            ]
            countline = [
                { $match: { f_discountterm: { $regex: searchData, $options: "im" } } },
                { $count: "totalcount" }
            ]
        }
        const data = await M_DISCOUNTTERMS.aggregate(pipeline)
        const totalrecord = await M_DISCOUNTTERMS.aggregate(countline)
        res.json({ status: 200, data, totalrecord })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

exports.getDiscounttermsDetail = async (req, res) => {
    const { _id } = req.params;
    try {
        const discData = await M_DISCOUNTTERMS.findOne({ _id });
        res.json({ status: 200, discData })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

exports.editDiscounttermsDetail = async (req, res) => {
    const { _id, f_discountterm, f_description } = req.body;
    try {
        const updateData = await M_DISCOUNTTERMS.findByIdAndUpdate({ _id }, { $set: { f_discountterm, f_description } });
        res.json({ status: 200, message: "discount term updated successfully!" })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

exports.deleteDiscounttermsDetail = async (req, res) => {
    const { _id } = req.params;
    try {
        const deletedData = await M_DISCOUNTTERMS.findByIdAndRemove({ _id });
        res.json({ status: 200, message: "discount term deleted successfully!" })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}