import React from "react";
import TopBar from "../../Components/NavSection/TopBar";
import {Link} from "react-router-dom";
import Footer from "../../Components/NavSection/Footer"

const Logout = () => {
  return (
    <>
      <TopBar />
      <main>
       <div id="logout">
         <aside>
         <h4 className="text-center loginc">
         You have been signed out
         </h4>
         <p className="text-center">To access your panel you will need to login again.</p>
         <p className="tryl text-center">
           <Link to="/">Try to login again.</Link>
         </p>
         </aside>
       </div>
      </main>
      <Footer />
    </>
  );
};

export default Logout;
