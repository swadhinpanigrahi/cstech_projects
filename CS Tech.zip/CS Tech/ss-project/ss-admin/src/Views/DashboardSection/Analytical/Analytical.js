import React from "react";
import PageHeaders from "../../../Components/Common/PageHeaders";
import Graph from "./Graph"

const Analytical = () => {
  return (
    <>
      <main className="">
        <div className="col-md-12">
          <PageHeaders title="Analytical" />
          <div className="col-md-12">
            <Graph />
          </div>
        </div>
      </main>
    </>
  );
};

export default Analytical;