const joi = require("joi")

exports.registerValidator = joi.object({
  firstName: joi.string().required(),
  lastName: joi.string().required(),
  emailId: joi.string().email().required(),
  mobileNo: joi.string().required(),
  userRole: joi.string().required(),
  companyName: joi.string().required(),
  password: joi.string().required(),
});

exports.authLoginValidator = joi.object({
  username: joi.string().email().required(),
  password: joi.string().required(),
});

exports.updateValidator = joi.object({
  _id: joi.required(),
  firstName: joi.string().required(),
  lastName: joi.string().required(),
  emailId: joi.string().email().required(),
  mobileNo: joi.string().required(),
  companyName: joi.string().required(),
});

exports.changePasswordValidator = joi.object({
  oldpassword: joi.string().required(),
  newpassword: joi.string().required(),
  confirmpassword: joi.string().required(),
});