const AllKeywords = require("express").Router();

const {
    getAllkeyDetails
} = require("../../controllers/KeywordsController/allkeywords.controller");

AllKeywords.use(`/getallkeydetails`, getAllkeyDetails)


module.exports = AllKeywords;