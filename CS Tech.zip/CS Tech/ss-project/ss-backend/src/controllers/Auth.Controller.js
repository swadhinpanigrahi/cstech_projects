const logger = require("../utilities/logger")
const bcrypt = require("bcrypt")
const JWT = require("jsonwebtoken")
const { JWT_TOKEN } = require("../config")
const { Auth, Merchant, Token, Subpermision } = require("../models/model.index")
const { APIError } = require("../utilities/APIError");
const {
  generateError,
  ERROR_STATUS_CODE,
  INTERNAL_SERVER_ERROR,
  EMAIL_NOT_EXISTS,
  WRONG_PASSWORD,
  PERMISSION_DENIED,
  USER_ALREADY_EXISTS,
  WR_PASSEORD,
  REFRESH_TOKEN_EXPIRED,
  PASSWORD_NOT_MATCH
} = require("../utilities/errorContants");
const { marchantResetPassword } = require("../services/nodeMailer/sendMail")


exports.AuthRegistration = async (req, res, next) => {
  const data = req.body;
  const { firstName, lastName, emailId, mobileNo, userRole, companyName, password } = data;
  try {
    const result = await Auth.findOne({ userRole: "admin" });

    if (result.userRole === userRole)
      return next(
        new APIError(ERROR_STATUS_CODE.ALREADY_EXITS, PERMISSION_DENIED)
      );

    const hashPass = await bcrypt.hashSync(password, 10);

    if (userRole === "admin") {
      const newUser = new Auth({ firstName, lastName, emailId, mobileNo, userRole, companyName, password: hashPass });
      const savedUser = await newUser.save();
      const permissionData = await new Subpermision({ userId: savedUser._id }).save()
      res.json(permissionData);
    }

    if (userRole === "sub-admin") {
      const newUser = new Auth({ firstName, lastName, emailId, mobileNo, userRole, companyName, password });
      const savedUser = await newUser.save();
      const permissionData = await new Subpermision({ userId: savedUser._id }).save()
      res.json({ permissionData });
    }

  } catch (error) {
    logger.error(
      `Error while registering user with details ${JSON.stringify(
        req.body
      )} and error ${generateError(error)}`
    );
    return next(
      new APIError(
        ERROR_STATUS_CODE.INTERNAL_SERVER_ERROR_CODE,
        INTERNAL_SERVER_ERROR,
        error.message
      )
    );
  }
};

exports.AuthLogin = async (req, res, next) => {
  const data = req.body;
  const { username, password } = data;
  try {
    const userData = await Auth.findOne({ emailId: username });
    if (!userData)
      return next(
        new APIError(ERROR_STATUS_CODE.BAD_REQUEST_CODE, EMAIL_NOT_EXISTS)
      );

    if (userData.userRole === "admin") {
      const verifyPass = await bcrypt.compareSync(password, userData.password);
      if (!verifyPass)
        return next(
          new APIError(ERROR_STATUS_CODE.BAD_REQUEST_CODE, WR_PASSEORD)
        );
    }

    if (userData.userRole === "sub-admin") {
      if (userData.password !== password)
        return next(
          new APIError(ERROR_STATUS_CODE.BAD_REQUEST_CODE, WR_PASSEORD)
        );

      if (userData.activate !== "active")
        return next(
          new APIError(ERROR_STATUS_CODE.BAD_REQUEST_CODE, PERMISSION_DENIED)
        );
    }

    const tokenData = {
      id: userData._id,
      name: `${userData.firstName} ${userData.lastName}`,
      email: userData.emailId,
    };

    const token = await JWT.sign(tokenData, JWT_TOKEN);
    const authData = await Subpermision.findOne({ userId: userData._id })

    res.json({ status: 200, token, authData });


  } catch (error) {
    logger.error(
      `Error while registering user with details ${JSON.stringify(
        req.body
      )} and error ${generateError(error)}`
    );
    return next(
      new APIError(
        ERROR_STATUS_CODE.INTERNAL_SERVER_ERROR_CODE,
        INTERNAL_SERVER_ERROR,
        error.message
      )
    );
  }
};

exports.verifyProfile = async (req, res, next) => {
  try {
    const { authData } = req;
    res.json({ status: 200, authData });
  } catch (error) {
    logger.error(
      `Error while registering user with details ${JSON.stringify(
        req.body
      )} and error ${generateError(error)}`
    );
    return next(
      new APIError(
        ERROR_STATUS_CODE.INTERNAL_SERVER_ERROR_CODE,
        INTERNAL_SERVER_ERROR,
        error.message
      )
    );
  }
};

exports.AuthGetProfile = async (req, res, next) => {
  try {
    const { authData } = req;
    const userData = await Auth.findOne({ _id: authData.id }, { firstName: 1, lastName: 1, emailId: 1, mobileNo: 1, companyName: 1 });
    res.json({ status: 200, userData });
  } catch (error) {
    logger.error(
      `Error while registering user with details ${JSON.stringify(
        req.body
      )} and error ${generateError(error)}`
    );
    return next(
      new APIError(
        ERROR_STATUS_CODE.INTERNAL_SERVER_ERROR_CODE,
        INTERNAL_SERVER_ERROR,
        error.message
      )
    );
  }
};

exports.AuthUpdateProfile = async (req, res, next) => {
  const data = req.body
  const { _id, firstName, lastName, emailId, mobileNo, companyName } = data
  try {
    const updatedData = await Auth.updateOne({ _id }, {
      $set: {
        firstName,
        lastName,
        emailId,
        mobileNo,
        companyName
      }
    })
    res.json({ status: 200, updatedData });
  } catch (error) {
    logger.error(
      `Error while registering user with details ${JSON.stringify(
        req.body
      )} and error ${                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           (error)}`
    );
    return next(
      new APIError(
        ERROR_STATUS_CODE.INTERNAL_SERVER_ERROR_CODE,
        INTERNAL_SERVER_ERROR,
        error.message
      )
    );
  }
};

exports.AuthChangePassword = async (req, res, next) => {
  const data = req.body;
  const { _id } = req.params
  const { oldpassword, newpassword, confirmpassword } = data
  try {
    const authData = await Auth.findOne({ _id });
    if (authData.userRole === "admin") {
      const verifyPass = await bcrypt.compareSync(oldpassword, authData.password);
      if (verifyPass) {
        if (newpassword === confirmpassword) {
          const hashPass = await bcrypt.hashSync(newpassword, 10);
          const updatePassword = await Auth.updateOne({ _id: authData._id }, {
            $set: {
              password: hashPass
            }
          })
          res.json({ status: 200, message: "successfully changed password", updatePassword })
        } else {
          return next(
            new APIError(
              ERROR_STATUS_CODE.BAD_REQUEST_CODE,
              PASSWORD_NOT_MATCH
            )
          );
        }
      } else {
        return next(
          new APIError(
            ERROR_STATUS_CODE.BAD_REQUEST_CODE,
            WRONG_PASSWORD
          )
        );
      }
    } else {
      const verifyPass = oldpassword === authData.password
      if (verifyPass) {
        if (newpassword === confirmpassword) {
          const updatePassword = await Auth.updateOne({ _id: authData._id }, {
            $set: {
              password: newpassword
            }
          })
          res.json({ status: 200, message: "successfully changed password", updatePassword })
        } else {
          return next(
            new APIError(
              ERROR_STATUS_CODE.BAD_REQUEST_CODE,
              PASSWORD_NOT_MATCH
            )
          );
        }
      } else {
        return next(
          new APIError(
            ERROR_STATUS_CODE.BAD_REQUEST_CODE,
            WRONG_PASSWORD
          )
        );
      }

    }
  } catch (error) {
    logger.error(
      `Error while registering user with details ${JSON.stringify(
        req.body
      )} and error ${generateError(error)}`
    );
    return next(
      new APIError(
        ERROR_STATUS_CODE.INTERNAL_SERVER_ERROR_CODE,
        INTERNAL_SERVER_ERROR,
        error.message
      )
    );
  }
};

exports.authForgotMail = async (req, res, next) => {
  const data = req.body;
  const { emailId } = data
  try {
    const userData = await Auth.findOne({ emailId });
    if (!userData)
      return next(
        new APIError(ERROR_STATUS_CODE.BAD_REQUEST_CODE, EMAIL_NOT_EXISTS)
      )
    let tokenData = {
      id: userData._id,
      name: `${userData.firstName} ${userData.lastName}`,
      email: userData.emailId,
    };
    const token = await JWT.sign(tokenData, JWT_TOKEN);
    const sendmail = marchantResetPassword(
      {
        name: `${userData.firstName} ${userData.lastName}`,
        email: userData.emailId,
        token,
        endPoint: `https://siteadminv2.storagestation.net`,
        // endPoint: `http://api.storagestation.net`,
        // endPoint: `http://localhost:3000`,
      },
      (data, error) => {
        if (!error) {
          console.log(data);
        } else {
          console.log(error);
        }
      }
    );
    await new Token({ token: token }).save();
    res.json({ status: 200, message: `Email Sent Successfully!!` });

  } catch (error) {
    logger.error(
      `Error while registering user with details ${JSON.stringify(
        req.body
      )} and error ${generateError(error)}`
    );
    return next(
      new APIError(
        ERROR_STATUS_CODE.INTERNAL_SERVER_ERROR_CODE,
        INTERNAL_SERVER_ERROR,
        error.message
      )
    );
  }
}

exports.authChangePasswordByEmail = async (req, res, next) => {
  const data = req.body;
  let { newpassword, confirmpassword, token } = data;
  const verifyToken = await JWT.verify(token, JWT_TOKEN);
  try {
    if (verifyToken) {
      if (newpassword === confirmpassword) {
        const authProfile = await Auth.findOne({ _id: verifyToken.id });
        if (authProfile) {
          const hashPass = await bcrypt.hashSync(newpassword, 10);
          await Auth.updateOne({ _id: authProfile._id }, {
            $set: {
              password: hashPass
            }
          })
          res.json({ message: "password changed successfully!" })
        }
      } else {
        return next(
          new APIError(
            ERROR_STATUS_CODE.BAD_REQUEST_CODE,
            PASSWORD_NOT_MATCH,
            error.message
          )
        );
      }
    } else {
      return next(
        new APIError(
          ERROR_STATUS_CODE.BAD_REQUEST_CODE,
          REFRESH_TOKEN_EXPIRED,
          error.message
        )
      );
    }
  } catch (error) {
    logger.error(
      `Error while registering user with details ${JSON.stringify(
        req.body
      )} and error ${generateError(error)}`
    );
    return next(
      new APIError(
        ERROR_STATUS_CODE.INTERNAL_SERVER_ERROR_CODE,
        INTERNAL_SERVER_ERROR,
        error.message
      )
    );
  }
}

/*  ALL MERCHANT AUTH RELATED API'S UPDATED HERE  */

exports.merchantLogin = async (req, res, next) => {
  const data = req.body
  const { username, password } = data
  try {

    const userInfo = await Merchant.findOne({ email: username })
    if (!userInfo)
      return next(
        new APIError(ERROR_STATUS_CODE.BAD_REQUEST_CODE, EMAIL_NOT_EXISTS)
      );

    if (userInfo.activate !== "active")
      return next(
        new APIError(ERROR_STATUS_CODE.BAD_REQUEST_CODE, PERMISSION_DENIED)
      )

    if (userInfo.password !== password)
      return next(
        new APIError(ERROR_STATUS_CODE.BAD_REQUEST_CODE, WR_PASSEORD)
      )

    res.json({ status: 200, name: userInfo.name, id: userInfo._id });

  } catch (error) {
    logger.error(
      `Error while registering user with details ${JSON.stringify(
        req.body
      )} and error ${generateError(error)}`
    );
    return next(
      new APIError(
        ERROR_STATUS_CODE.INTERNAL_SERVER_ERROR_CODE,
        INTERNAL_SERVER_ERROR,
        error.message
      )
    );
  }
}

exports.merchantGetProfile = async (req, res, next) => {
  const { _id } = req.params
  try {
    const userInfo = await Merchant.findOne({ _id })
    res.json({ userInfo })
  } catch (error) {
    logger.error(
      `Error while registering user with details ${JSON.stringify(
        req.body
      )} and error ${generateError(error)}`
    );
    return next(
      new APIError(
        ERROR_STATUS_CODE.INTERNAL_SERVER_ERROR_CODE,
        INTERNAL_SERVER_ERROR,
        error.message
      )
    );
  }
}

exports.merchantEditProfile = async (req, res, next) => {
  const data = req.body
  const { _id } = req.params
  const { name, email, phone, password, companyName, address, pincode, city, state, country, beneficiary_name, bank_name, bank_branch, account_number, ifsc_code } = data
  try {
    const customerData = await Merchant.findOne({ _id })
    if (!customerData)
      return next(
        new APIError(
          ERROR_STATUS_CODE.ALREADY_EXITS,
          USER_ALREADY_EXISTS
        ))

    const updatedCustomer = await Merchant.updateOne({ _id: customerData._id }, {
      $set: {
        name, email, phone, password, companyName, address, pincode, city, state, country, beneficiary_name,
        bank_name, account_number, ifsc_code, bank_branch
      }
    });
    res.json({ status: 200, message: "customer updated successfully!", updatedCustomer })
  } catch (error) {
    logger.error(
      `Error while registering user with details ${JSON.stringify(
        req.body
      )} and error ${generateError(error)}`
    );
    return next(
      new APIError(
        ERROR_STATUS_CODE.INTERNAL_SERVER_ERROR_CODE,
        INTERNAL_SERVER_ERROR,
        error.message
      )
    );
  }
}

exports.merchantChangePassword = async (req, res, next) => {
  const data = req.body
  const { _id } = req.params
  const { oldpassword, newpassword, confirmpassword } = data
  try {
    const userInfo = await Merchant.findOne({ _id });
    if (userInfo.password !== oldpassword)
      return next(
        new APIError(ERROR_STATUS_CODE.BAD_REQUEST_CODE, WRONG_PASSWORD)
      )

    if (newpassword !== confirmpassword)
      return next(
        new APIError(ERROR_STATUS_CODE.BAD_REQUEST_CODE, PASSWORD_NOT_MATCH)
      )

    const updatedPassword = await Merchant.updateOne({ _id: userInfo._id }, {
      $set: {
        password: confirmpassword
      }
    })

    res.json({ status: 200, message: "password changed successfully!!", updatedPassword })

  } catch (error) {
    logger.error(
      `Error while registering user with details ${JSON.stringify(
        req.body
      )} and error ${generateError(error)}`
    );
    return next(
      new APIError(
        ERROR_STATUS_CODE.INTERNAL_SERVER_ERROR_CODE,
        INTERNAL_SERVER_ERROR,
        error.message
      )
    );
  }
}

exports.merchantForgotMail = async (req, res, next) => {
  const data = req.body;
  const { email } = data
  try {
    const userData = await Merchant.findOne({ email });
    if (!userData)
      return next(
        new APIError(ERROR_STATUS_CODE.BAD_REQUEST_CODE, EMAIL_NOT_EXISTS)
      )
    let tokenData = {
      id: userData._id,
      name: userData.name,
      email: userData.email,
    };
    const token = await JWT.sign(tokenData, JWT_TOKEN);
    marchantResetPassword(
      {
        name: userData.name,
        email,
        token,
        endPoint: `https://appv2.storagestation.net`,
        // endPoint: `http://api.storagestation.net`,
        // endPoint: `http://localhost:3000`,
      },
      (data, error) => {
        if (!error) {
          console.log(data);
        } else {
          console.log(error);
        }
      }
    );
    await new Token({ token: token }).save();
    res.json({ status: 200, message: `Email Sent Successfully!!` });

  } catch (error) {
    logger.error(
      `Error while registering user with details ${JSON.stringify(
        req.body
      )} and error ${generateError(error)}`
    );
    return next(
      new APIError(
        ERROR_STATUS_CODE.INTERNAL_SERVER_ERROR_CODE,
        INTERNAL_SERVER_ERROR,
        error.message
      )
    );
  }
}

exports.merchantChangePassFromForgotMail = async (req, res, next) => {
  const data = req.body;
  let { newpassword, confirmpassword, token } = data;
  const verifyToken = JWT.verify(token, JWT_TOKEN);
  try {
    if (verifyToken) {
      if (newpassword === confirmpassword) {
        const merchantData = await Merchant.findOne({ _id: verifyToken.id });
        if (merchantData) {
          await Merchant.updateOne({ _id: merchantData._id }, {
            $set: {
              password: newpassword
            }
          })
          res.json({ message: "password changed successfully!" })
        }
      } else {
        return next(
          new APIError(
            ERROR_STATUS_CODE.BAD_REQUEST_CODE,
            PASSWORD_NOT_MATCH,
            error.message
          )
        );
      }
    } else {
      return next(
        new APIError(
          ERROR_STATUS_CODE.BAD_REQUEST_CODE,
          REFRESH_TOKEN_EXPIRED,
          error.message
        )
      );
    }
  } catch (error) {
    logger.error(
      `Error while registering user with details ${JSON.stringify(
        req.body
      )} and error ${generateError(error)}`
    );
    return next(
      new APIError(
        ERROR_STATUS_CODE.INTERNAL_SERVER_ERROR_CODE,
        INTERNAL_SERVER_ERROR,
        error.message
      )
    );
  }
}
