const { M_STATE, Counter } = require("../../model");


exports.addState = async (req, res) => {
    const { f_countryid, f_state } = req.body;
    try {
        const data = await M_STATE.findOne({ f_state });
        if (data) {
            res.json({ status: 400, message: "alredy exists!" })
        } else {
            const id = await Counter.findOneAndUpdate({ _id: "f_stateid" }, {
                $inc: { sequence: 1 }
            }, { useFindAndModify: false });
            console.log(req.body)
            const saveData = await new M_STATE({
                f_stateid: id.sequence, f_state, f_creationdate: new Date(),
                f_status: true, f_countryid
            }).save();
            console.log(saveData)
            res.json({ status: 200, saveData })
        }
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })

    }
}
exports.getStateNormal = async (req, res) => {
    try {
        const data = await M_STATE.find({});
        res.json({ status: 200, data })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })

    }
}
exports.getStateList = async (req, res) => {
    const { currentPage, itemPerPage, searchData } = req.query;
    const num = parseInt(itemPerPage);
    const start = parseInt(currentPage);
    let pipeline;
    let countline;
    try {
        if (!searchData || searchData === "") {
            pipeline = [
                { $skip: (start - 1) * num },
                { $limit: num },
                {
                    $lookup: {
                        from: "t_country",
                        localField: "f_countryid",
                        foreignField: "f_countryid",
                        as: "country"
                    }
                },
                { $unwind: "$country" },
            ]
            countline = [
                {
                    $lookup: {
                        from: "t_country",
                        localField: "f_countryid",
                        foreignField: "f_countryid",
                        as: "country"
                    }
                },
                { $unwind: "$country" },
                { $count: "totalcount" }
            ]
        } else {
            pipeline = [
                { $match: { f_state: { $regex: searchData, $options: "im" } } },
                { $skip: (start - 1) * num },
                { $limit: num },
                {
                    $lookup: {
                        from: "t_country",
                        localField: "f_countryid",
                        foreignField: "f_countryid",
                        as: "country"
                    }
                },
                { $unwind: "$country" },
            ]
            countline = [
                { $match: { f_state: { $regex: searchData, $options: "im" } } },
                {
                    $lookup: {
                        from: "t_country",
                        localField: "f_countryid",
                        foreignField: "f_countryid",
                        as: "country"
                    }
                },
                { $unwind: "$country" },
                { $count: "totalcount" }
            ]
        }
        const data = await M_STATE.aggregate(pipeline);
        const totalrecord = await M_STATE.aggregate(countline)
        res.json({ status: 200, data, totalrecord })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

exports.getStateListBySearch = async (req, res) => {
    const { search } = req.query;
    try {
        const data = await M_STATE.aggregate([
            {
                $match: { f_state: { $regex: search, $options: "im" } }
            },
            {
                $lookup: {
                    from: "t_country",
                    localField: "f_countryid",
                    foreignField: "f_countryid",
                    as: "country"
                }
            },
            { $unwind: "$country" }
        ])
        res.json({ status: 200, data })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

exports.getStateDetail = async (req, res) => {
    const { _id } = req.params
    try {
        const stateDetail = await M_STATE.findById({ _id });
        res.json({ status: 200, stateDetail })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

exports.editStateDetail = async (req, res) => {
    const { _id, f_state, f_countryid } = req.body
    try {
        const stateDetail = await M_STATE.findByIdAndUpdate({ _id }, {
            $set: {
                f_state,
                f_countryid
            }
        });
        res.json({ status: 200, message: "State updated successfully!" })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

exports.deleteStateDetail = async (req, res) => {
    const { _id } = req.params
    try {
        const stateDetail = await M_STATE.findByIdAndRemove({ _id });
        res.json({ status: 200, message: "State removed successfully!!" })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}