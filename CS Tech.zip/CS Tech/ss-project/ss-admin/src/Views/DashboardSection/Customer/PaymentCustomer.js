import React, { useState, useEffect } from "react";
import { paymentFormDetails } from "../../../Components/FormData/FormElements"
import { Row, Col, Form, Button } from "react-bootstrap";
import { useParams } from "react-router-dom";
import {
  makePaymentToCustomer, getCustomerDetails, getDataForGraphM
} from '../../../Utils/api';
import Model from "../../../Components/Common/Model"

const PaymentCustomer = () => {
  const { _id } = useParams();
  const [FormData, setFormData] = useState({})
  const [isOpen, setIsOpen] = useState(false);
  const [ModelMsg, setModelMsg] = useState("");
  const [AnalaticData, setAnalaticData] = useState({
    totalAmount: 0,
    balanceAmount: 0
  })

  const handleChange = (e) => {
    let { name, value } = e.target
    let data = { ...FormData }
    data[name] = value;
    setFormData({ ...data })
  }

  const onSubmit = async (e) => {
    e.preventDefault();
    if (FormData["account_number"] && FormData["bank_branch"] && FormData["bank_name"] && FormData["beneficiary_name"] && FormData["comment"]
      && FormData["ifsc_code"] && FormData["mode"] && FormData["payed_amount"] && FormData["payment_type"] && FormData["seller_entry_name"] &&
      FormData["transection_no"]) {
      const apiCall = await makePaymentToCustomer({ _id, ...FormData })
      let { status, error } = apiCall
      if (!error) {
        if (status === 200) {
          setModelMsg("success!!");
          modelSet();
        } else {
          setModelMsg("network error!");
          modelSet();
        }
      }
    } else {
      setModelMsg("please fill all the details!!");
      modelSet();
    }

  }

  const modelSet = () => {
    setIsOpen(true);
  };

  useEffect(() => {
    console.log(_id)
    const apiCall = async () => {
      const res = await getCustomerDetails(_id);
      let { customerData } = res
      setFormData(customerData)
    }
    apiCall()
  }, [_id])

  useEffect(() => {
    const apiCall = async () => {
      const res = await getDataForGraphM(_id);
      let { graph, creditAmount, debitAmount } = res;
      const updatedState = { ...AnalaticData }
      updatedState.totalAmount = creditAmount;
      updatedState.balanceAmount = debitAmount;
      setAnalaticData({ ...updatedState })
    }
    apiCall()
  }, [_id]);

  let { totalAmount, balanceAmount } = AnalaticData;

  return (
    <>
      {/* <Modal show={show1} onHide={handleClose1} className="main_reportmodal"> */}
      <Col md={12}>
        <Col lg={12}>
          <div className="page-header row no-gutters pym-4">
            <Col lg={6} md={6} xs={7}>
              <h3 className="page-title">Payment Details</h3>
            </Col>
            <Col lg={6} md={6} xs={5} className="text-right backb">
              {/* <a><button className="addcb"><span><i className="fa fa-arrow-left"></i>
                <span style={{ position: "relative", left: "5px" }}><a href="#/dashboard/customer/get">BACK</a></span></span></button></a> */}
            </Col><hr />
          </div>
        </Col>
        <Form>
          <div className="box_detail mb-0 addc-detailh report_modaltest" style={{ padding: "15px 0px 10px", marginBottom: "0px" }}>
            <Col lg={12} style={{ padding: "0px" }}>
              <div className="head-title1 row no-gutters">
                <Col md={6} xs={9}>
                  <h3 class="page-title subtitile">BANK DETAILS</h3>
                </Col>
                <Col md={6} xs={3} className="text-right">
                  {/* <i variant="secondary" className="fa fa-times close_modalreport"></i> */}
                </Col>
                <hr /></div>
            </Col>
            <Row id="main_form">
              {paymentFormDetails.map((data, inx) => {
                let { section, label, name, type, placeholder, controlId, arr } = data;
                return (
                  <Col lg={6} key={controlId + inx}>
                    {section === "select"
                      ?
                      <Form.Group as={Row} controlId={controlId}>
                        <Form.Label column sm="5">{label}</Form.Label>
                        <Col sm="7">
                          <Form.Control as="select" type={type} placeholder={placeholder} name={name} onChange={handleChange} >
                            {arr.map((info, inx) => <option value={info}>{info}</option>)}
                          </Form.Control>
                        </Col>
                      </Form.Group>
                      :
                      name === "balance" ?
                        <Form.Group as={Row} controlId={controlId}>
                          <Form.Label column sm="5">
                            {label}
                          </Form.Label>
                          <Col sm="7">
                            <Form.Control type={type} value={totalAmount - balanceAmount} placeholder={placeholder} name={name} disabled />

                          </Col>
                        </Form.Group>
                        :
                        <Form.Group as={Row} controlId={controlId}>
                          <Form.Label column sm="5">
                            {label}
                          </Form.Label>
                          <Col sm="7">
                            <Form.Control type={type} value={FormData[name]} placeholder={placeholder} name={name} onChange={handleChange} />

                          </Col>
                        </Form.Group>
                    }
                  </Col>
                )
              })}
            </Row>
            <Row className="form-group">
              <Col lg={6}>
                <Row>
                  <Col sm={5}></Col>
                  <Col sm={7} className="">
                    <div className="demo-btn-group" id="probtnt">
                      <Button type="button" className="subtn_cls" onClick={onSubmit}>SUBMIT</Button>
                      {/* <Button type="button" className="subtn_clsc" onClick={handleClose1}>CLOSE</Button> */}
                    </div>
                  </Col>
                </Row>
              </Col>
              <Col lg={6}></Col>
            </Row>
          </div>
        </Form>
      </Col>
      <Model
        text={ModelMsg}
        open={isOpen}
        onClose={() => setIsOpen(false)}
      />
    </>
  );
};

export default PaymentCustomer;
