const Imagesize = require("express").Router();
const {
    addImageSizeDetail, getImageSizeList, getImageSizeDetail, editImageSizeDetail, deleteImageSizeDetail,
    getTexDetail, updateTexDetail, getRightPayment, updateRightPayment
} = require("../../controllers/Master/master.imagesize.controller");

Imagesize.route("/addimagesizedetail").post(addImageSizeDetail)
Imagesize.route("/getimagesizelist").get(getImageSizeList)
Imagesize.route("/getimagesizedetail/:_id").get(getImageSizeDetail)
Imagesize.route("/editimagesizedetail").post(editImageSizeDetail)
Imagesize.route("/deleteimagesizedetail/:_id").get(deleteImageSizeDetail)

Imagesize.route("/gettaxdetail").get(getTexDetail)
Imagesize.route("/updatetaxdetails").post(updateTexDetail)
Imagesize.route("/getpaymentsrights").get(getRightPayment)
Imagesize.route("/updatepaymentrights").post(updateRightPayment)

module.exports = Imagesize;