import React, { useState } from 'react';
import * as RB from "react-bootstrap";
import { Row } from "react-bootstrap";

import { POST_ADMIN } from "../../../Utils/api"

const AddAdmin = (
    { AddModal, setAddModal, apiCall, modelSet, setModelMsg }
) => {
    const [FormData, setFormData] = useState({});
    const [ErrorMsg, setErrorMsg] = useState("");

    const handleChange = (e) => {
        let { name, value } = e.target;
        setErrorMsg("")
        const data = { ...FormData }
        data[name] = value
        setFormData(data)
    }

    const closeModal = () => {
        setAddModal(false);
    }

    const addCreditPeriod = async () => {
        let { username, password } = FormData;
        const regex = /^[a-zA-Z]*$/;
        const value = regex.test(username);
        if (value) {
            if (!username || !password) {
                setErrorMsg("please fill requirment fields!");
            } else {
                const res = await POST_ADMIN(FormData);
                let { status, message } = res;
                if (status === 200) {
                    // console.log(FormData);
                    setFormData({});
                    setErrorMsg("");
                    apiCall();
                    closeModal();
                } else {
                    setErrorMsg(message)
                }
            }
        } else {
            setErrorMsg("please enter valid text-boxes!");
        }
    }

    return (
        <div>
            <RB.Modal show={AddModal} onHide={closeModal} className="ordermanage_modal">
                <RB.Modal.Header closeButton>
                    <RB.Modal.Title>Add Admin</RB.Modal.Title>
                </RB.Modal.Header>
                <RB.Modal.Body>
                    <RB.Row>
                        <RB.Col lg={12} md={12}>
                            <RB.Row>
                                {ErrorMsg !== "" ? ErrorMsg : ""}
                                <RB.Col lg={12} md={12}>
                                    <RB.Form>
                                        <RB.Form.Group as={Row} controlId="Country_id">
                                            <RB.Col lg={4} md={4}>
                                                <RB.Form.Label>Name :</RB.Form.Label>
                                            </RB.Col>
                                            <RB.Col lg={7} md={8}>
                                                <RB.Form.Control
                                                    type="text"
                                                    name="username"
                                                    onChange={handleChange}
                                                />
                                            </RB.Col>
                                        </RB.Form.Group>
                                        <RB.Form.Group as={Row} controlId="Country_id">
                                            <RB.Col lg={4} md={4}>
                                                <RB.Form.Label>Password :</RB.Form.Label>
                                            </RB.Col>
                                            <RB.Col lg={7} md={8}>
                                                <RB.Form.Control
                                                    type="password"
                                                    name="password"
                                                    onChange={handleChange}
                                                />
                                            </RB.Col>
                                        </RB.Form.Group>
                                        <RB.Row>
                                            <RB.Col lg={4} md={4}></RB.Col>
                                            <RB.Col lg={6} md={7}>
                                                <RB.Button
                                                    size="sm" variant="primary"
                                                    onClick={addCreditPeriod}
                                                >
                                                    ADD
                                                </RB.Button>
                                            </RB.Col>
                                        </RB.Row>
                                    </RB.Form>
                                </RB.Col>
                            </RB.Row>
                        </RB.Col>
                    </RB.Row>
                </RB.Modal.Body>
            </RB.Modal>
        </div>
    )
}

export default AddAdmin;