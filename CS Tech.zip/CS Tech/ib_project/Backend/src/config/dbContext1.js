var sql = require("mssql");

var config1 = {
  user: 'IBBetaLogin184',
  password: 'ib4582#',
  server: '180.179.213.184',
  port: 1533,
  database: 'imagesbazaarDb_mongoDB',
  connectionTimeout: 300000,
  requestTimeout: 300000,
  trustServerCertificate: true,
  pool: {
    idleTimeoutMillis: 300000,
    max: 100
  }
}

global.config1 = config1;

let response = {
  status: 200,
  data: [],
  message: null
};