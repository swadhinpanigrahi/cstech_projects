var sql = require('mssql')
require('../config/dbContext1')

const { T_Orders_IB_MongoDB } = require('../model')
module.exports = {
    updateUserInfo: async (req, res) => {
        try {
            var { userInfo, f_userid } = req.body
            sql.close();
            sql.connect(config1, function (err) {
                if (err) throw err;
                var request = new sql.Request();
                console.log(userInfo)
                request.query("exec csp_Tempusermaster @autenticatekey='images4730bazaarimages4730bazaar', @flag='4',@CS_firstname ='" + userInfo.CS_firstname + "', @CS_lastname='" + userInfo.CS_lastname + "',@CS_jobdesc='" + userInfo.CS_jobdesc + "',@CS_companynames='" + userInfo.CS_companynames + "',@CS_businesstype='" + userInfo.CS_businesstype + "',@CS_country='" + userInfo.CS_country + "',@CS_address='" + userInfo.CS_address + "',@CS_state='" + userInfo.CS_state + "',@CS_pin=" + parseInt(userInfo.CS_pin) + ",@CS_phone =" + parseInt(userInfo.CS_phone) + ", @CS_mobile =" + parseInt(userInfo.CS_mobile) + ",@GSTIN='" + userInfo.f_GSTIN + "',@cs_username='" + userInfo.CS_email + "',@cs_userid='" + parseInt(f_userid) + "',@CS_lightboxname='" + userInfo.CS_lightboxname + "',@CS_comment='" + userInfo.CS_comment + "' ,@CS_active='" + userInfo.CS_active + "',@cs_Commission='" + userInfo.cs_Commission + "' ,@cs_SubscriptionDiscount='" + userInfo.cs_SubscriptionDiscount + "',@Subscriptionccmail='" + userInfo.cs_subscriptionccmail + "'", function (err, rows) {
                    if (err) console.log(err);
                    res.send("updated")
                })
                // }
            })
        } catch (error) {
            console.log("cominfg in catch");
            console.log(error);
        }
    },
    RemoveOrderMongoToSql: async (req, res) => {
        sql.close();
        console.log(req.body);
        sql.connect(config1, function (err) {
            if (err) throw err;
            var request = new sql.Request();
            console.log(req.body)
            // if (rows.recordset.length != 0) {
            request.query("exec csp_Order_processIB @flag='3',@autenticatekey='images4730bazaarimages4730bazaar',@T_orderid='" + req.body.orderId + "'", function (err, rows) {
                if (err) console.log(err);
                console.log(rows);
                res.send(rows)

            })

            // }
        })
    },
    RejectOrderMongoToSql: async (req, res) => {
        sql.close();
        console.log(req.params);
        sql.connect(config1, function (err) {
            if (err) throw err;
            var request = new sql.Request();
            console.log(req.body)
            // if (rows.recordset.length != 0) {
            request.query("exec csp_Order_processIB @flag='11',@autenticatekey='images4730bazaarimages4730bazaar',@T_orderid=" + req.body.orderId + "", function (err, rows) {
                if (err) console.log(err);
                res.send("rejecred")
            })
            // }
        })
    },
    confirmOrderMongoToSql: async (req, res) => {
        var { orderdata } = req.body
        // console.log(orderdata);
        var OrderInfo = await T_Orders_IB_MongoDB.findOne({
            T_orderid: orderdata.orderid,
        });
        sql.close();
        console.log("Your requested data : ", orderdata);

        sql.connect(config1, function (err) {
            if (err) throw err;
            var request = new sql.Request();
            // console.log(req.body)
            // if (rows.recordset.length != 0) {
            request.query("exec csp_order_confirm_upgrade_2020 @flag='1',@T_orderid='" + parseInt(orderdata.orderid) + "',@T_condate='" + orderdata.f_createdate + "',@t_paymentdate='" + orderdata.f_createdate + "',@t_purchaseorder='',@t_comment='" + orderdata.t_comment + "',@t_download='',@T_status='C',@f_address='" + orderdata.CS_address + "',@txtclient='',@T_paymode='',@CompanyName='" + orderdata.f_businesstype + "',@t_discount='" + parseInt(orderdata.cs_discount) + "',@total_amt='" + parseInt(OrderInfo.f_orderAmt) + "',@tax_amt='" + parseInt((OrderInfo.f_orderAmt * 18) / 100) + "',@final_amt='" + parseInt(OrderInfo.f_orderAmt) +
                parseInt((OrderInfo.f_orderAmt * 18) / 100) + "',@t_orderedby='" + OrderInfo.t_client + "',@Name='" + OrderInfo.t_client + "',@txtsearch1='" + orderdata.f_companyname + "',@txtcompanytag='" + orderdata.f_Shortname + "',@txtcompanyGroup='" + orderdata.f_groupname + "',@txtcompanyState='', @rdldiscounttype='',@ddlDiscountterms='',@rblusertype='',@ddlCreaditPeriod='',@dlApprovalmode='',@txtspecialcomment='" + orderdata.t_comment + "',@txtAdditionalEmail='',@dlClosedBy='',@userid='" + orderdata.f_userid + "',@txtdiscounttype='5'", function (err, rows) {
                    console.log(err);
                    console.log(rows.recordset[0].invoiceId);
                    // sql.connect(config1, function (err) {
                    //     if (err) throw err;
                    //     var request = new sql.Request();
                    //     request.query('', function (err, rows) {

                    //     })
                    // })
                    if (err) console.log(err);
                    res.status(200).send(rows)
                    // res.send("Retuned data : ", rows)
                })
            // }
        })
    },
    updateCustomerShortAndGroupNameMongoToSql: async (req, res) => {
        try {
            sql.close();
            var { compData } = req.body;
            console.log(compData);
            sql.connect(config1, function (err) {
                if (err) throw err;
                var request = new sql.Request();
                console.log(req.body)
                // if (rows.recordset.length != 0) {
                request.query("exec csp_compny_report2015 @flag='31',@company_name='" + compData.f_companyname + "',@company_name1='" + compData.f_Shortname + "',@groupcmpname='" + compData.f_groupname + "',@emailid='" + compData.selectedEmails + "'", function (err, rows) {
                    if (err) console.log(err);
                    console.log(rows);
                    res.send("updated")
                })
                // }
            })
        } catch (error) {
            console.log("coming in catch");
            console.log(error);
        }
    },
    createNewOrderMongoToSql: async (req, res) => {
        try {
            var { orderData } = req.body
            sql.close();
            sql.connect(config1, async function (err) {
                if (err) throw err;
                var request = new sql.Request();
                console.log(req.body)
                request.query("exec sp_checkout_NodeJS @flag='1',@getusername='" + orderData.CS_username + "',@t_paymode='" + orderData.T_paymode + "',@t_status='P',@t_client='" + orderData.client_name + "',@t_orderedby='" + orderData.CS_username + "',@sessionamt='" + orderData.f_orderAmt + "',@ip='',@GSTIN='',@country='" + orderData.CS_country + "',@state='" + orderData.CS_state + "',@pin='" + orderData.CS_pin.replace(/\'/gi, '') + "',@Address='" + orderData.CS_address.replace(/\'/gi, '') + "',@editsts='1'", async function (err, rows) {
                    if (err) throw err;
                    res.send(rows)
                })
            })
        } catch (error) {

        }
    },
    FinalizeProposalMongoToSql: async (req, res) => {
        try {
            var { propData } = req.body
            console.log(propData);
            // return
            sql.close();
            sql.connect(config1, async function (err) {
                if (err) throw err;
                var request = new sql.Request();
                // console.log(req.body)
                request.query("exec sp_Buy_Proposal_NodeJS @flag=11,@f_client='" + propData.f_client + "',@username='" + propData.T_username + "',@f_heading='" + propData.f_heading + "',@f_amt='" + parseInt(propData.f_amt) + "',@f_discount='" + propData.f_discount + "',@f_amtpay='" + propData.f_finalamt + "',@f_sertax='" + propData.f_sertax + "',@f_finalamt='" + propData.f_finalamt + "',@ip='',@f_proposaluser='" + propData.T_username + "',@f_Creditperiod='" + propData.f_Creditperiod + "',@state='" + propData.f_state + "',@gstnno='" + propData.f_GSTNNo + "',@userid ='58504'", async function (err, rows) {
                    if (err) throw err;
                    res.send(rows)
                })
            })
        } catch (error) {
            console.log(error);
        }
    },
    DeleteProposalMongoToSql: async (req, res) => {
        sql.close();
        // console.log(req.body);
        var { orderId } = req.body
        sql.connect(config1, function (err) {
            if (err) throw err;
            var request = new sql.Request();
            // console.log(req.body)
            // if (rows.recordset.length != 0) {
            request.query("exec csp_Proposal @flag='3',@autenticatekey='images4730bazaarimages4730bazaar',@T_orderid='" + orderId + "',@loginid=''", function (err, rows) {
                if (err) console.log(err);
                res.send(rows)
            })
        })
    },
    insertDataIntoCart: async (req, res) => {
        sql.close();
        console.log(req.body);
        var PropArr = req.body;

        // PropArr.forEach(element => {
        PropArr.forEach(function (element, index) {
            console.log(element.t_imageid)
            sql.connect(config1, function (err) {
                if (err) throw err;
                var request = new sql.Request();
                // console.log(req.body)
                // if (rows.recordset.length != 0) {
                request.query("exec sp_pricing_NodeJS_UpatedSP @flag='38' ,@imgCode ='" + element.t_imageid + "',@ImgType ='" + element.t_quality + "',@getUserName='hcgupta@cstech.in',@OrderId=''", function (err, rows) {
                    if (err) console.log(err);
                    if (PropArr.length == parseInt(index + 1)) {
                        res.send(rows)
                    }
                    // 
                })
            })
        });
    },
    createNewFollowUpMongoToSql: async (req, res) => {
        console.log("Comung in createNewFollowUpMongoToSql");
        console.log(req.body);
        var { userInfo } = req.body
        try {
            sql.close();
            sql.connect(config1, function (err) {
                if (err) throw err;
                var request = new sql.Request();
                // console.log(req.body)
                // if (rows.recordset.length != 0) {
                request.query("exec csp_DailySalesEntry_CRM2015_Newfortest @flag='2',@f_EmailID='" + userInfo.cs_ccmail + "',@f_AlternateEmail='" + userInfo.f_AlternateEmail + "',@f_designation='',@f_Firstname='" + userInfo.CS_firstname + "',@f_lastName='" + userInfo.CS_lastname + "',@f_CompanyName='" + userInfo.CS_companynames + "',@f_PhoneNumber='" + userInfo.CS_phone + "',@f_MobileNo='" + userInfo.CS_mobile + "',@f_State='" + userInfo.CS_state + "',@f_Country='India',@f_RequirementType='" + userInfo.reqType + "',@f_Requirementfollowups='" + userInfo.followUpType1 + "',@f_Description='" + userInfo.followUpDescriptionType + "',@f_Dateby='" + userInfo.followupDate + "',@f_followupsby='',@ret='',@f_UserType='',@txtCreatedby='',@ddlIbOption='" + userInfo.aboutIB + "',@ddlDescriptiontype='" + userInfo.followupDescription + "',@txtalternateemailSecond='',@ddlDiscountterms='" + userInfo.f_DiscountTerms + "',@ddlCreaditPeriod='" + userInfo.credetPeriod + "',@txtalternatename='',@txtalternateContactNumber='',@imp_follow_ups='',@stateid='',@shortcmp='" + userInfo.sortcmp_name + "',@groupcmp='" + userInfo.group_cmpname + "',@f_Requirementfollowups2='',@ddlDescriptiontype2='',@f_Dateby2='',@f_followupsby2='',@f_Description2=''", function (err, rows) {
                    if (err) console.log(err);
                    res.send(rows)
                })
            })
        } catch (error) {
            console.log("coming in catch");
            console.log(error);
        }
    },
}