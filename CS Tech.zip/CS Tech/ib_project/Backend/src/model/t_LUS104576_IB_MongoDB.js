const mongoose = require("mongoose");

const t_LUS104576_IB_MongoDB_Schema = mongoose.Schema(
  {
    CS_userid: { type: String },
    CS_username: { type: String },
    CS_password: { type: String },
    CS_email: { type: String },
    CS_firstname: { type: String },
    CS_lastname: { type: String },
    CS_status: { type: String },
    CS_IPAddress: { type: String },
    cs_active: { type: Boolean },
    cs_refid: { type: String },
    cs_ecashamt: { type: Number },
    f_EcashSetUp: { type: Boolean },
    CS_companynames: { type: String },
    cs_date: { type: Date },
    CS_mobile: { type: String },
    cs_followups_status: { type: Number },
    f_GSTIN: { type: String },
    f_ISDNo: { type: Boolean },
    f_userAttempt: { type: Number },
    f_attemptTime: { type: Date },
  },
  { collection: "t_LUS104576_IB_MongoDB" }
);

module.exports = t_LUS104576_IB_MongoDB = mongoose.model(
  "t_LUS104576_IB_MongoDB",
  t_LUS104576_IB_MongoDB_Schema
);
