import React, { useState } from 'react';
import * as RB from "react-bootstrap";
import { Row } from "react-bootstrap";

import { ADD_IMAGETYPEDETAIL } from "../../../Utils/api";

const AddImageType = (
    { show_addimagetype, setShow, apiCall, setModelMsg, modelSet }
) => {

    const [FormData, setFormData] = useState({});
    const [ErrorMsg, setErrorMsg] = useState("")

    const closeMode = () => {
        setShow(false);
        setErrorMsg("")
    }

    const handleChange = (e) => {
        let { name, value } = e.target;
        const data = { ...FormData };
        data[name] = value;
        setFormData(data)
    }

    const AddImageTypeFun = async () => {
        let { f_pricetypename } = FormData;
        const regex = /^[a-zA-Z]*$/;
        const value = regex.test(f_pricetypename);
        if (!value || !f_pricetypename) {
            setErrorMsg("fill with valid text-field!")
        } else {
            const res = await ADD_IMAGETYPEDETAIL(FormData);
            let { status, message } = res
            if (status === 200) {
                apiCall();
                setErrorMsg("")
                setShow(false);
                setModelMsg(message);
                modelSet()
            } else {
                setErrorMsg(message)
            }
        }
    }

    return (
        <div>
            <RB.Modal show={show_addimagetype} onHide={closeMode} className="ordermanage_modal">
                <RB.Modal.Header closeButton>
                    <RB.Modal.Title>Add Image Price Type</RB.Modal.Title>
                </RB.Modal.Header>
                <RB.Modal.Body>
                    <RB.Row>
                        <RB.Col lg={12} md={12}>
                            <RB.Row>
                                <RB.Col lg={12} md={12}>
                                    {ErrorMsg !== "" ? ErrorMsg : ""}
                                    <RB.Form>
                                        <RB.Form.Group as={Row} controlId="image_pricet">
                                            <RB.Col lg={5} md={5}>
                                                <RB.Form.Label>Image Price Type Name :</RB.Form.Label>
                                            </RB.Col>
                                            <RB.Col lg={7} md={7}>
                                                <RB.Form.Control
                                                    type="text"
                                                    name="f_pricetypename"
                                                    onChange={handleChange}
                                                />
                                            </RB.Col>
                                        </RB.Form.Group>
                                        <RB.Row>
                                            <RB.Col lg={5} md={5}></RB.Col>
                                            <RB.Col lg={7} md={7}>
                                                <RB.Button
                                                    size="sm" variant="primary"
                                                    onClick={AddImageTypeFun}
                                                >
                                                    SUBMIT
                                                </RB.Button>
                                            </RB.Col>
                                        </RB.Row>
                                    </RB.Form>
                                </RB.Col>
                            </RB.Row>
                        </RB.Col>
                    </RB.Row>
                </RB.Modal.Body>
            </RB.Modal>
        </div>
    )
}

export default AddImageType