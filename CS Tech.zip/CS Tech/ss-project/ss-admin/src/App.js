import React from "react";
import { HashRouter as Router, Switch, Route } from "react-router-dom";
import { ProvideAuth, PrivateRoute } from "./Utils/auth";
import Login from "./Views/LoginSection/Login";
import DashSection from "./Views/DashboardSection";
import LogoutPage from "./Views/LogoutSection/LogoutPage";
import ForgotSendmail from './Views/ForgotSection/ForgotSendmail';
import ForgotSumitPass from "./Views/ForgotSection/ForgotSumitPass";

import CronJobARAMEX from './CronJobARAMEX';
import CronjobSMSA from "./CronjobSMSA"
import CronjobWAYXPRESS from "./CronjobWAYXPRESS";

import ReturnCronJobAramax from "./ReturnCronJobAramax"


function App() {
  return (
    <>
      <ProvideAuth>
        <Router>
          <Switch>
            <Route exact path="/" children={<Login />} />
            <PrivateRoute path="/dashboard" children={<DashSection />} />
            <Route path="/logout" component={LogoutPage} />
            <Route path="/sendemailtogetlink" component={ForgotSendmail} />
            <Route path="/changepassword/:token" component={ForgotSumitPass} />
            <Route path="/statusupdatearamexcronjob" component={CronJobARAMEX} />
            <Route path="/statusupdatearsmsacronjob" component={CronjobSMSA} />
            <Route path="/statusupdatearwayexpresscronjob" component={CronjobWAYXPRESS} />
            <Route path="/statusupdatetodeliverytoreturn" component={ReturnCronJobAramax} />
          </Switch>
        </Router>
      </ProvideAuth>
    </>
  );
}

export default App;
