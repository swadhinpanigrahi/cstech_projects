import React from 'react'
import { Row, Col } from "react-bootstrap"

const FormAddress = ({ info }) => {
    const FormAddressFields = [
        { label: "Name :", value: info.name },
        { label: "Company Name :", value: info.company_name },
        { label: "Address :", value: info.address_1 },
        { label: "Email :", value: info.email },
        { label: "City :", value: info.city },
        { label: "State :", value: info.state },
        { label: "Zip :", value: info.zip },
        { label: "Country :", value: info.country },
        { label: "Phone :", value: info.phone }
    ]
    return (
        <>
            <div style={{ paddingLeft: "5px", paddingRight: "5px" }}>
                {FormAddressFields.map((data, inx) => {
                    let { label, value } = data
                    return (
                        <Row className="form-group" key={"FROMADD" + inx}>
                            <Col lg={4} md={4}>
                                <h6 className="pwdc">{label}</h6>
                            </Col>
                            <Col lg={8} md={8}>
                                <h6 className="namep">{value}</h6>
                            </Col>
                        </Row>
                    )
                })}
            </div>
        </>
    )
}

export default FormAddress
