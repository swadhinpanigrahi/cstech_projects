const IBadminForgetPassTemp = (name, token, endpoint) => {
  return `
  <div>
      <center>
        <div>
          <table cellpadding="0" cellspacing="0" border="0" width="100%" bgcolor="#FFFFFF">
            <tbody><tr>
              <td valign="top" bgcolor="#FFFFFF" width="100%">
                <table width="100%" align="center" cellpadding="0" cellspacing="0" border="0">
                  <tbody><tr>
                    <td width="100%">
                      <table width="100%" cellpadding="0" cellspacing="0" border="0">
                        <tbody><tr>
                          <td>
                            <table width="100%" cellpadding="0" cellspacing="0" border="0" style="width:100%;max-width:600px" align="center">
                              <tbody>
                                <tr>
                                  <td style="padding:0px 0px 0px 0px;color:#000000;text-align:left" bgcolor="#FFFFFF" width="100%" align="left"><table border="0" cellpadding="0" cellspacing="0" width="100%" style="display:none!important;opacity:0;color:transparent;height:0;width:0">
                                    <tbody>
                                      <tr>
                                        <td>
                                          <p></p>
                                        </td>
                                      </tr>
                                    </tbody>
                                  </table>
                                  <table border="0" cellpadding="0" cellspacing="0" width="100%" style="table-layout:fixed">
                                    <tbody>
                                      <tr>
                                        <td style="padding:18px 0px 18px 0px;line-height:22px;text-align:inherit" height="100%" valign="top" bgcolor="">
                                          <div>
                                            <h1 style="text-align:inherit;font-family:inherit"><strong>Reset Password</strong></h1>
                                            <div style="font-family:inherit;text-align:inherit">Dear ${name},</div>
                                            <div style="font-family:inherit;text-align:inherit"><br></div>
                                            <div style="font-family:inherit;text-align:inherit">We have received your request to reset your password. To finish resetting your password, click on the below link::</div><div></div></div></td>
                                          </tr>
                                        </tbody>
                                      </table><table border="0" cellpadding="0" cellspacing="0" style="table-layout:fixed" width="100%">
                                        <tbody>
                                          <tr>
                                            <td align="left" bgcolor="" style="padding:0px 0px 0px 0px">
                                              <table border="0" cellpadding="0" cellspacing="0" style="text-align:center">
                                                <tbody>
                                                  <tr>
                                                    <td align="center" bgcolor="#333333" style="border-radius:6px;font-size:16px;text-align:left;background-color:inherit">
                                                      <a href="${endpoint}/auth/varifypage/${token}" style="background-color:#333333;border:1px solid #333333;border-color:#333333;border-radius:6px;border-width:1px;color:#ffffff;display:inline-block;font-size:14px;font-weight:normal;letter-spacing:0px;line-height:normal;padding:12px 18px 12px 18px;text-align:center;text-decoration:none;border-style:solid">RESET YOUR PASSWORD</a>
                                                    </td>
                                                  </tr>
                                                </tbody>
                                              </table>
                                            </td>
                                          </tr>
                                        </tbody>
                                      </table>
                                      <table border="0" cellpadding="0" cellspacing="0" width="100%" style="table-layout:fixed">
                                        <tbody>
                                          <tr>
                                            <td style="padding:18px 0px 18px 0px;line-height:22px;text-align:inherit" height="100%" valign="top" bgcolor=""><div><div style="font-family:inherit;text-align:inherit">Important: This link expires in 1 hours. Set a new secure password of your choice before the link expires.</div>
                                              <div style="font-family:inherit;text-align:inherit">Thanks for giving us an opportunity to serve you!</div>
                                              <div style="font-family:inherit;text-align:inherit"><br></div>
                                              <div style="font-family:inherit;text-align:inherit">Best Regards,</div>
                                              <div style="font-family:inherit;text-align:inherit">Customer Support Team</div>
                                              <div style="font-family:inherit;text-align:inherit"><a href="#0">www.imagesbazaar.com</a></div>
                                              <div style="font-family:inherit;text-align:inherit">&nbsp;</div><div></div></div>
                                            </td>
                                          </tr>
                                        </tbody>
                                      </table>
                                      <div style="color:#444444;font-size:12px;line-height:20px;padding:16px 16px 16px 16px;text-align:center"><div></div><p style="font-size:12px;line-height:20px"><a>Unsubscribe</a> - <a>Unsubscribe Preferences</a></p></div>
                                      <table align="center" border="0" cellpadding="0" cellspacing="0" width="100%" style="table-layout:fixed">
                                        <tbody>
                                           <tr>
                                            <td valign="top" style="padding:0px 0px 0px 0px;font-size:6px;line-height:10px" align="left">
                                              <table align="left">
                                                <tbody></tbody>
                                              </table>
                                            </td>
                                          </tr>
                                        </tbody>
                                      </table>
                                    </td>
                                  </tr>
                                </tbody>
                              </table>
                            </td>
                        </tr>
                      </tbody></table>
                    </td>
                  </tr>
                </tbody></table>
              </td>
            </tr>
          </tbody></table>
        </div>
      </center>
    </div>
  `;
};

const IBProposalMailTemp = (T_orderid) => {

  return `The following links are to a Wishlist on the ImagesBazaar website.<br/>

  Wishlists store project related images together. When you view this Wishlist, <br/>you'll be able to see those images and any notes the creator of the wishlist added. To view the wishlist sent to you click on link give below:<br/>
  <a href="http://ibadminreact.imagesbazaar.com/#/proposaldetails/${T_orderid}">Click</a> <br/> If the link above is not clickable simply cut and paste it into the location bar of your browser and press enter.<br/>
  The link will expire after 15 days.<br/>
  We look forward to seeing you on ImagesBazaar .<br/>
  View images on any subject! Log on to https://www.imagesbazaar.com <br/>
  `
  // return `<a href="http://ibadminreact.imagesbazaar.com/#/proposaldetails/${T_orderid}">Click</a>`
}

const IBPaidProcessEmailTemp = (email) => {
  return `
      <p>Dear Sir/Madam,
        <br />
        Thanks for giving us an opportunity to serve you!<br />
        This is to confirm that we have received your payment against invoice number(s) <strong>124210</strong>
        <br />
        Please feel free to get in touch with me at <a href="mailto:aastha@imagesbazaar.com">aastha@imagesbazaar.com</a> for any payment query.
        <br />
        For queries related to orders or any other query please mail at <a href="mailto:orders@imagesbazaar.com">orders@imagesbazaar.com</a>
        <br /><br />
        Looking forward to a long term relationship!
        <br /><br />
        Best Regards, <br />
        Aastha Saigal <br />
        Team, ImagesBazaar
        <br /><br /><br />
      Click <a href="#0">here</a> to unsubscribe
    </p>
  `
}

const IBOrderConfirmEmailTemp = (ImageArray, price, tax, NetAmount) => {
  console.log(ImageArray, price, tax, NetAmount)
  return `
  <table width="100%" cellspacing="0" cellpadding="0" border="0">
  <tbody>
      <tr>
          <td style="text-transform:capitalize" width="48%">Dear <b>hukum Gupta</b>,</td>
      </tr>
      <tr>
          <td height="4"></td>
      </tr>
      <tr>
          <td>This is to confirm that we have received your order request and you can download the image(s) you have purchased by clicking on the download link through your My Account section as soon as your payment will be realised.</td>
      </tr>
      <tr>
          <td height="5"></td>
      </tr>
      <tr>
          <td>
              <table width="100%" cellspacing="0" border="0" align="left">
                  <tbody>
                      <tr>
                          <td><b>ORDER ID: 207068</b></td>
                      </tr>
                      <tr>
                          <td><b>Order Date: </b>Sep 20 2021  3:27PM</td>
                      </tr>
                      <tr>
                          <td><b>Mode of Payment: </b>PayNimo</td>
                      </tr>
                  </tbody>
              </table>
              <table valign="bottom" style="border:1px solid #aaaaaa;margin-left:5px" width="100%" cellspacing="0" cellpadding="5" align="left">
                  <tbody>
                      <tr>
                          <td style="font-family:Verdana,Arial,Helvetica,sans-serif;font-size:12px;font-weight:bold" bgcolor="#CCCCCC">Image ID</td>
                          <td style="font-family:Verdana,Arial,Helvetica,sans-serif;font-size:12px;font-weight:bold" bgcolor="#CCCCCC">Type Of Rights</td>
                          <td style="font-family:Verdana,Arial,Helvetica,sans-serif;font-size:12px;font-weight:bold" height="25px" bgcolor="#CCCCCC">Image Size</td>
                          <td style="font-family:Verdana,Arial,Helvetica,sans-serif;font-size:12px;padding-right:20px;font-weight:bold" bgcolor="#CCCCCC" align="right">Price Rs.</td>
                      </tr>
                      <tr>
                          <td style="font-family:Verdana,Arial,Helvetica,sans-serif;font-size:12px" height="25px" align="left">SM562105</td>
                          <td style="font-family:Verdana,Arial,Helvetica,sans-serif;font-size:12px" align="left">Non-Exclusive</td>
                          <td style="font-family:Verdana,Arial,Helvetica,sans-serif;font-size:12px" align="left">MEDIUM</td>
                          <td style="font-family:Verdana,Arial,Helvetica,sans-serif;font-size:12px;padding-right:20px" align="right">22000</td>
                      </tr>
                      <tr><td style="font-family:Verdana,Arial,Helvetica,sans-serif;font-size:12px" height="25px" align="left">SM905700</td>
                          <td style="font-family:Verdana,Arial,Helvetica,sans-serif;font-size:12px" align="left">Non-Exclusive</td>
                          <td style="font-family:Verdana,Arial,Helvetica,sans-serif;font-size:12px" align="left">MEDIUM</td>
                          <td style="font-family:Verdana,Arial,Helvetica,sans-serif;font-size:12px;padding-right:20px" align="right">22000</td>
                      </tr>
                  </tbody>
              </table>
              <table width="60%" cellspacing="0" border="0" align="left">
                  <tbody>
                      <tr>
                          <td style="font-family:Verdana,Arial,Helvetica,sans-serif;font-size:12px;font-weight:bold">&nbsp;Amount: Rs.${price}</td>
                      </tr>
                      <tr></tr>
                      <tr>
                          <td style="font-family:Verdana,Arial,Helvetica,sans-serif;font-size:12px;font-weight:bold">&nbsp;Less: Rs.41800</td>
                      </tr>
                      <tr>
                          <td></td>
                      </tr>
                      <tr></tr>
                      <tr>
                          <td style="font-family:Verdana,Arial,Helvetica,sans-serif;font-size:12px;font-weight:bold">&nbsp;Tax 18%: Rs.${tax}</td>
                      </tr>
                      <tr>
                          <td style="font-family:Verdana,Arial,Helvetica,sans-serif;font-size:12px;font-weight:bold">&nbsp;Net Payable Amount : Rs.${NetAmount}</td>
                      </tr>
                      <tr></tr>
                  </tbody>
              </table>
          </td>
      </tr>
      <tr>
          <td height="5"></td>
      </tr>
      <tr>
          <td><b>Delivery  of Images:</b> <br> For orders placed through Credit Cards (VISA, Master Card or American Express), the link to download the image(s) gets immediately activated as soon as your transaction gets successful, whether its day or night, weekday or weekend. </td>
      </tr>
      <tr>
          <td height="8"></td>
      </tr>
      <tr>
          <td>For orders placed through Net Banking, Cheque/Demand Draft or Electronic Fund Transfer, the link to download the image(s) gets activated as soon as we receive your payment.</td>
      </tr>
      <tr>
          <td height="5"></td>
      </tr>
      <tr>
          <td><p><b>Customer Support:</b><br>Please Call us at +91-99113-66666 or +91-11-66545466 or e-mail us <br>at <a href="mailto:orders@imagesbazaar.com" target="_blank">orders@imagesbazaar.com</a> for any query you may have regarding<br> Pricing, Technical Info or Downloading of images.</p></td>
      </tr>
      <tr>
          <td height="5"></td>
      </tr>
      <tr>
          <td><b>Office Timings (IST): 10:00 AM to 8:30 PM </b><br>(Closed on Sundays and National Holidays of India)</td>
      </tr>
      <tr>
          <td height="8"></td>
      </tr>
      <tr>
          <td><a href="#0">Click here</a> to view the invoice. Alternatively, you can Login to the <a href="https://www.imagesbazaar.com/myaccounts" target="_blank">'My Account'</a> section to View/Print Invoice against this transaction.</td>
      </tr>
      <tr>
          <td height="8"></td>
      </tr>
      <tr>
          <td>Thanks for giving us an opportunity to serve you! </td>
      </tr>
      <tr>
          <td height="5"></td>
      </tr>
      <tr>
          <td>With Warm Regards, <br>Customer Response Team <br><a href="http://www.imagesbazaar.com" target="_blank">www.imagesbazaar.com</a></td>
      </tr>
  </tbody>
</table>
  `
}

/**
 * ORDER-LISTACTION-TEMPLATES
 */

const OrderPaymentMailTemp = ({ email, paymentPrice, payemntLink, T_orderid, PaymentMD }) => {
  //   return `
  //   https://old.imagesbazaar.com/Betalogintest.aspx?id=${T_orderid}&amt=${paymentPrice}&user=${email}&pgt=${PaymentMD} 
  //   `
  // }
  return `<b> Dear ${email} </b>  given below payment link.<br/><br/>
 <b> <a href='${payemntLink}'>Click Here</a></b><br/>
  <p>Thanks for giving an opportunity to server you!</p>
  <p>Customer Response Team. www.imagesbazaar.com</p>

  `
}

const OrderDetailsCCMailTemp = ({ content, orderId }) => {
  return `
  ${content}, ${orderId}
  `
}

const FeedbackEmailTemp = ({ cs_userid, message }) => {
  return `
  ${cs_userid}, ${message}
  `
}

module.exports = {
  IBadminForgetPassTemp,
  IBProposalMailTemp,
  IBPaidProcessEmailTemp,
  IBOrderConfirmEmailTemp,

  OrderPaymentMailTemp,
  OrderDetailsCCMailTemp,
  FeedbackEmailTemp
};
