const Mongoose = require("mongoose")

const authSchema = new Mongoose.Schema(
  {
    firstName: { type: String },
    lastName: { type: String },
    userRole: { type: String },
    activate: { type: String, default: "active" },
    image: { type: String, default: "" },
    emailId: { type: String, trim: true, lowercase: true, unique: true },
    mobileNo: { type: String, unique: true },
    companyName: { type: String },
    token: { type: String, default: "" },
    password: { type: String },
  },
  { timestamps: true },
  { collection: "auth_tbls" }
);

module.exports = authSchema;

