import React, { useState, useEffect } from 'react';
import * as RB from "react-bootstrap";
import { Row } from "react-bootstrap";
import { SubscriptionModalForm } from "../../../Forms/FormElements";
import { UPDATE_SUBPLANDDETAIL } from "../../../../Utils/api";

const DropArrayS = [
    { name: "Web Resolution" },
    { name: "High Resolution" },
    { name: "Super Resolution" },
    { name: "XXL Resolution" },
];

const EditSubscriptionplan = (
    { edit_subscriptionplan, setEdit, UserData, apiCall }
) => {
    const [FormData, setFormData] = useState({});

    const closeModel = () => {
        setEdit(false)
    }

    const handleChange = (e) => {
        let { name, value } = e.target;
        const data = { ...FormData };
        data[name] = value;
        setFormData(data)
    }

    const editSubScriptionPlan = async () => {
        const res = await UPDATE_SUBPLANDDETAIL(FormData);
        apiCall()
        closeModel()
    }

    useEffect(() => {
        setFormData(UserData)
    }, [UserData])
    return (
        <div>
            <RB.Modal show={edit_subscriptionplan} onHide={closeModel} className="ordermanage_modal">
                <RB.Modal.Header closeButton>
                    <RB.Modal.Title>Edit Subscription Plan</RB.Modal.Title>
                </RB.Modal.Header>
                <RB.Modal.Body>
                    <RB.Row>
                        <RB.Col lg={12} md={12}>
                            <RB.Row>
                                <RB.Col lg={12} md={12}>
                                    <RB.Form>
                                        {SubscriptionModalForm.map((data, inx) => {
                                            let { label, type, name, format, controlId, forms } = data;
                                            return (
                                                <>
                                                    {forms === "false" ?
                                                        <RB.Form.Group as={Row} controlId={controlId} key={controlId + inx}>
                                                            <RB.Col lg={5} md={5}>
                                                                <RB.Form.Label>{label} :</RB.Form.Label>
                                                            </RB.Col>
                                                            <RB.Col lg={6} md={6}>
                                                                <RB.Form.Control
                                                                    type={type} name={name} as={format} value={FormData[name]}
                                                                    onChange={handleChange}
                                                                />
                                                            </RB.Col>
                                                        </RB.Form.Group>
                                                        :
                                                        <RB.Form.Group as={Row} controlId={controlId} key={controlId + inx}>
                                                            <RB.Col lg={5} md={5}>
                                                                <RB.Form.Label>{label} :</RB.Form.Label>
                                                            </RB.Col>
                                                            <RB.Col lg={6} md={6}>
                                                                <RB.Form.Control
                                                                    name={name} as={format}
                                                                    onChange={handleChange}
                                                                >
                                                                    <option value={FormData[name]}>{FormData[name]}</option>
                                                                    {DropArrayS.map((data, inx) => {
                                                                        let { name } = data;
                                                                        return (
                                                                            <option value={name} key={`OPTION_SUB_${inx}`}>{name}</option>
                                                                        )
                                                                    })}
                                                                </RB.Form.Control>
                                                            </RB.Col>
                                                        </RB.Form.Group>
                                                    }
                                                </>

                                            );

                                        })}
                                        <RB.Row>
                                            <RB.Col lg={5} md={5}></RB.Col>
                                            <RB.Col lg={6} md={6}>
                                                <RB.Button
                                                    size="sm" variant="primary"
                                                    onClick={editSubScriptionPlan}
                                                >
                                                    UPDATE
                                                </RB.Button>
                                            </RB.Col>
                                        </RB.Row>
                                    </RB.Form>
                                </RB.Col>
                            </RB.Row>
                        </RB.Col>
                    </RB.Row>
                </RB.Modal.Body>
            </RB.Modal>
        </div>
    )
}

export default EditSubscriptionplan