import React, { useState, useEffect } from 'react';
import { customerDetailsForm, customerBankDetails } from "../../Components/FormElement/FormElement";
import { Col, Row, Form, Button } from 'react-bootstrap';
import { inputFieldsValidetor } from "../../Utils/FormValidetor";
import { useHistory } from "react-router-dom";
import { getMerchantProfile, updateCustomerDetails } from "../../Utils/api";
import Model from "../../Components/Common/Model";
import PageHeaders from "../../Components/Common/PageHeaders";
import { useTranslation } from "react-i18next";

const ManageProfile = () => {
    const { t } = useTranslation();
    const history = useHistory();
    const [Validate, setValidate] = useState({
        beneficiary_name: "", bank_name: "", bank_branch: "", account_number: "", ifsc_code: ""
    })
    const [FormData, setFormData] = useState({})
    const [Errors, setErrors] = useState({
        errors: {},
        errMsg1: "",
        errClr: "",
    });
    const [Password, setPassword] = useState("password");
    const [isOpen, setIsOpen] = useState(false);
    const [ModelMsg, setModelMsg] = useState("");

    const changePasswordType = () => {
        Password === "password" ? setPassword("text") : setPassword("password")
    }

    const handleChange = (e) => {
        let { name, value } = e.target
        let data = { ...FormData }
        data[name] = value;
        setFormData({ ...data })
        const updateError = { ...Errors };
        updateError.errors = inputFieldsValidetor(data);
        updateError.errMsg = "";
        updateError.errClr = "";
        setErrors({ ...updateError });
    }

    const onSubmit = async (e) => {
        e.preventDefault();
        if (FormData["name"] && FormData["email"] && FormData["phone"] && FormData["password"] && FormData["companyName"] && FormData["address"]
            && FormData["pincode"] && FormData["city"] && FormData["state"] && FormData["country"]) {
            const res = await updateCustomerDetails(FormData);
            let { message, error } = res;
            if (!error) {
                setModelMsg(message);
                modelSet();
                setTimeout(() => {
                    history.push("/dashboard/analytical")
                }, 1000)
            } else {
                setModelMsg("network error!!");
                modelSet();
            }
        } else {
            const updatedError = { ...Errors };
            updatedError.errors = inputFieldsValidetor(FormData);
            updatedError.errMsg = "";
            updatedError.errClr = "border-danger";
            setErrors({ ...updatedError });
        }
    }

    const modelSet = () => {
        setIsOpen(true);
    };

    useEffect(() => {
        const getCustomerApiCall = async () => {
            const res = await getMerchantProfile()
            let { userInfo } = res
            if (userInfo) {
                setFormData({ ...userInfo });
                setValidate({
                    beneficiary_name: userInfo.beneficiary_name,
                    bank_name: userInfo.bank_name,
                    bank_branch: userInfo.bank_branch,
                    account_number: userInfo.account_number,
                    ifsc_code: userInfo.ifsc_code
                })
                // const updatedError = { ...Errors };
                // updatedError.errors = {};
                // updatedError.errMsg = "";
                // updatedError.errClr = "";
                // setErrors({ ...updatedError });
            }
        }
        getCustomerApiCall()
    }, [])

    let { errors, errClr } = Errors;
    let { beneficiary_name, bank_name, bank_branch, account_number, ifsc_code } = FormData

    return (
        <>
            <Col md={12} className="modal_reports">
                <PageHeaders title={t("change.m_Profile")} />
                <Col md={12}>
                    <Form>

                        <div className="box_detail mb-0 addc-detailh report_modaltest" style={{ padding: "15px 0px 10px" }}>
                            <Col lg={12} style={{ padding: "0px" }}>
                                <div className="head-title1 row no-gutters">
                                    <Col md={6} xs={9}>
                                        <h3 class="page-title subtitile">{t("change.p_DETAILS")}</h3>
                                    </Col>
                                    <Col md={6} xs={3} className="text-right">
                                        {/* <i variant="secondary" onClick={handleClose} className="fa fa-times close_modalreport"></i> */}
                                    </Col>
                                    <hr /></div>
                            </Col>

                            <Col md={12}>
                                <Col md={12}>
                                    <Row id="main_form">
                                        {customerDetailsForm.map((data, inx) => {
                                            let { label, type, name, placeholder, controlId } = data
                                            if (name === "address") {
                                                return (
                                                    <Col lg={6} key={controlId + inx}>
                                                        <Form.Group as={Row} controlId={controlId}>
                                                            <Form.Label className="pwdc" column sm="4">
                                                                {t(`change.${label}`)}
                                                            </Form.Label>

                                                            <Col sm="8">
                                                                <Form.Control type={type} as="textarea" value={FormData[name]} placeholder={placeholder} name={name} onChange={handleChange} className={errClr ? errClr : ""} />
                                                                <Form.Text className="text-danger">
                                                                    {errors[name]}
                                                                </Form.Text>
                                                            </Col>
                                                        </Form.Group>
                                                    </Col>
                                                )
                                            } else if (name === "password") {
                                                return (
                                                    <Col lg={6} key={controlId + inx}>
                                                        <Form.Group as={Row} controlId={controlId}>
                                                            <Form.Label className="pwdc" column sm="4">
                                                                {t(`change.${label}`)}
                                                            </Form.Label>
                                                            <Col sm="8">
                                                                <Form.Control type={Password} value={FormData[name]} placeholder={placeholder} name={name} onChange={handleChange} className={errClr ? errClr : ""} />
                                                                <Form.Text className="text-danger">
                                                                    {errors[name]}
                                                                </Form.Text>
                                                                <Button onClick={changePasswordType} className="see_password"><i className="fa fa-eye"></i></Button>

                                                            </Col>
                                                        </Form.Group>
                                                    </Col>
                                                )
                                            } else {
                                                return (
                                                    <Col lg={6} key={controlId + inx}>
                                                        <Form.Group as={Row} controlId={controlId}>
                                                            <Form.Label className="pwdc" column sm="4">
                                                                {t(`change.${label}`)}
                                                            </Form.Label>
                                                            <Col sm="8">
                                                                <Form.Control type={type} value={FormData[name]} placeholder={placeholder} name={name} onChange={handleChange} className={errClr ? errClr : ""} />
                                                                <Form.Text className="text-danger">
                                                                    {errors[name]}
                                                                </Form.Text>
                                                            </Col>
                                                        </Form.Group>
                                                    </Col>
                                                )
                                            }
                                        })}
                                    </Row>
                                </Col>
                            </Col>
                        </div>


                        <Row style={{ margin: "20px 0px 0px 0px" }}>
                            <div className="box_detail mb-0 addc-detailh report_modaltest" style={{ padding: "15px 0px 10px", marginBottom: "0px" }}>
                                <Col lg={12} style={{ padding: "0px" }}>
                                    <div className="head-title1 row no-gutters">
                                        <Col lg={12} style={{ padding: "0px" }}>
                                            <h3 class="page-title subtitile">{t("change.bank_details")}</h3>
                                        </Col><hr /></div>
                                </Col>
                                {Validate.beneficiary_name === "" && Validate.bank_name === "" && Validate.bank_branch === "" && Validate.account_number === "" && Validate.ifsc_code === "" ?
                                    <Col md={12}>
                                        <Col md={12}>
                                            <Row id="main_form">

                                                {customerBankDetails.map((data, inx) => {
                                                    let { label, type, name, placeholder, controlId } = data
                                                    return (
                                                        <Col lg={6} key={controlId + inx}>
                                                            <Form.Group as={Row} controlId={controlId}>
                                                                <Form.Label className="pwdc" column sm="4">{t(`change.${label}`)}</Form.Label>

                                                                <Col sm="8">
                                                                    <Form.Control type={type} value={FormData[name]} placeholder={placeholder} name={name} onChange={handleChange} />
                                                                    <Form.Text className="text-muted">

                                                                    </Form.Text>
                                                                </Col>
                                                            </Form.Group>

                                                        </Col>
                                                    )
                                                })}
                                            </Row>
                                        </Col>
                                    </Col>
                                    :
                                    <Col md={12}>
                                        <Col md={12}>
                                            <Row id="main_form">
                                                {customerBankDetails.map((data, inx) => {
                                                    let { label, type, name, controlId } = data
                                                    return (
                                                        <Col lg={6} key={controlId + inx}>
                                                            <Form.Group as={Row} controlId={controlId}>
                                                                <Form.Label className="pwdc" column sm="4">{t(`change.${label}`)}</Form.Label>

                                                                <Col sm="8">
                                                                    <Form.Control type={type} value={FormData[name]} disabled />
                                                                    <Form.Text className="text-muted">

                                                                    </Form.Text>
                                                                </Col>
                                                            </Form.Group>

                                                        </Col>
                                                    )
                                                })}
                                            </Row>
                                        </Col>
                                    </Col>
                                }

                                <Col md={12}>
                                    <div>
                                        <Col md={12}>
                                            <Row className="form-group">
                                                <Col lg={6}>
                                                    <Row>
                                                        <Col sm={4}></Col>
                                                        <Col sm={8} className="edit_subbtnn">
                                                            <div className="demo-btn-group" id="probtnt">
                                                                <Button onClick={onSubmit} className="submit">{t("change.submit")}</Button>
                                                            </div>
                                                        </Col>
                                                    </Row>
                                                </Col>
                                                <Col lg={6}></Col>
                                            </Row>
                                        </Col>
                                    </div>
                                </Col>
                            </div>
                        </Row>
                    </Form>
                </Col>
            </Col>
            <Model
                text={ModelMsg}
                open={isOpen}
                onClose={() => setIsOpen(false)}
            />
        </>
    )
}

export default ManageProfile
