const mongoose = require("mongoose");

const MasterImageVideoSubscriptionSchema = mongoose.Schema(
    {
        f_sno: { type: String },
        f_planname: { type: String },
        f_maxallowed: { type: String },
        f_periodindays: { type: String },
        f_totimg: { type: String },
        f_amount: { type: String },
        f_status: { type: String },
        f_imageType: { type: String },
        f_desc: { type: String },
        f_save: { type: String },
        f_shot: { type: String },
        f_upgradamt: { type: String },
        f_couponAmt: { type: String },
        f_customlink: { type: String },
        f_customlink_status: { type: Number },
        f_couponName: { type: String }

    },
    { collection: "t_imagevideossubscriptionplan" }
);

module.exports = M_IMAGEVIDEO = mongoose.model(
    "t_imagevideossubscriptionplan",
    MasterImageVideoSubscriptionSchema
);