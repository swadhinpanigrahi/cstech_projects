const Mongoose = require("mongoose");

const modifyShipDataSchema = new Mongoose.Schema(
    {
        tracking_number: { type: String },
        order_number: { type: String },
        old_tracking_number: { type: String },
        old_shipping_method: { type: String },
        shipping_method: { type: String },
    },
    { timestamps: true },
    { collection: "shipmentlog_tbls" }
)

module.exports = modifyShipDataSchema;