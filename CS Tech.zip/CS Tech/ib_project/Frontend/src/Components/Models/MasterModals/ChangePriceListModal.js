import React, { useState, useEffect } from 'react';
import { Button, Modal } from "react-bootstrap";
import { GET_PRICEESLIST } from "../../../Utils/api";
import * as RB from "react-bootstrap";
import PaginationComponent from "../../Common/PaginationComponent";

const ChangePriceListModal = ({ OpenSearchModel, setOpenSearchModel, getId }) => {
    const [currentPage, setCurrentPage] = useState(1);
    const [itemPerPage, setItemPerPage] = useState(20);
    const [TotalCount, setTotalCount] = useState(0);
    const [Loading, setLoading] = useState(false);
    let [searchData, setSearchData] = useState("");

    let [PriceList, setPriceList] = useState([])


    const closeModal = () => {
        setOpenSearchModel(false)
    }

    const apiCall = async () => {
        setLoading(true)
        const res = await GET_PRICEESLIST(currentPage, itemPerPage, searchData);
        let { data, totalrecord } = res;
        setPriceList(data);
        setTotalCount(totalrecord[0].totalcount)
        setLoading(false)
    }

    useEffect(() => {
        apiCall()
    }, [currentPage, itemPerPage])

    return (
        <>
            <Modal show={OpenSearchModel} onHide={closeModal} animation={false} className="changeprice_model">
                <Modal.Header closeButton>
                    <Modal.Title>Similar Group List</Modal.Title>
                </Modal.Header>
                <Modal.Body>

                    <RB.Col lg={12}>
                        <RB.Row className="rownew1">
                                <RB.Col lg={12} md={12} className="table_span" style={{color: '#0081ad', fontWeight: '600'}}>
                                    <span>Total Records: {TotalCount}</span>
                                </RB.Col>
                        </RB.Row>
                        <div
                            className="table_boxdtl manage_order"
                            style={{border: '1px solid #eee', maxHeight: '300px', overflow: 'auto'}}
                        >
                            <RB.Table striped bordered hover variant="dark" responsive>
                                <thead>
                                    <tr class="vtable">
                                        <th className="text-center">S. No.</th>
                                        <th className="">Group ID</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {Loading ? <tr><td className="no_records" colSpan="11">Loading...</td></tr> : PriceList.length > 0 ? PriceList.map((info, inx) => {
                                        return (
                                            <tr key={`MASTERSID${inx}`}>
                                                <td className="s_notm text-center">{inx + 1}</td>
                                                <td className="" onClick={() => {
                                                    getId(info._id)
                                                    closeModal()
                                                }}>{info._id}</td>
                                            </tr>
                                        )
                                    }) : <tr><td className="no_records" colSpan="11">No Records Found</td></tr>}
                                </tbody>
                            </RB.Table>
                        </div>
                        {/* <PaginationComponent
                            MOCK_DATA={TotalCount}
                            currentPage={currentPage}
                            setCurrentPage={setCurrentPage}
                            itemPerPage={itemPerPage}
                            setItemPerPage={setItemPerPage}
                        /> */}
                    </RB.Col>
                </Modal.Body>
                <Modal.Footer>
                    <Button variant="secondary" onClick={closeModal}>
                        Close
                    </Button>
                </Modal.Footer>
            </Modal>
        </>
    )
}

export default ChangePriceListModal
