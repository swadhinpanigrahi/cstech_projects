const dir = "http://ibadminreactapi.imagesbazaar.com";
// const dir = "http://localhost:5000";
 

module.exports = {
  dir,
};
