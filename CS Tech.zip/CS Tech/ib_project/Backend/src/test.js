const {
  T_Orders_IB_MongoDB,
  Counter
} = require("./model");
const testRoute = require("express").Router();
var sql = require('mssql')
require('./config/dbContext1')
testRoute.get(`/`, async (req, res) => {
  const data = await T_Orders_IB_MongoDB.find({ "T_username": "hcgupta@cstech.in" }).select({ T_orderid: 1 })
  res.send(data);
});

testRoute.get(`/cout`, async (req, res) => {
  res.json({ message: "done" });
});

testRoute.post(`/postcounts`, async (req, res) => {
  let { _id, sequence } = req.body
  try {
    const saveCount = await Counter({ _id, sequence }).save();
    res.json({ status: 200, saveCount })
  } catch (error) {
    res.json({ message: `Error in Controller`, error: error.message });
  }
})

testRoute.get(`/attitest`, async (req, res) => {
  sql.close();
  console.log(req.body);
  sql.connect(config1, function (err) {
    if (err) throw err;
    var request = new sql.Request();
    console.log(req.body)
    // if (rows.recordset.length != 0) {
    request.query("select top 5 * from t_Company_master", function (err, rows) {
      res.send(rows)
      if (err) console.log(err);
    })

    // }
  })
});
module.exports = testRoute;
