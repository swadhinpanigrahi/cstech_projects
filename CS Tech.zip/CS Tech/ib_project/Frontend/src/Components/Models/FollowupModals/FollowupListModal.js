import React from "react";
import { Modal, Table } from "react-bootstrap";
import Moment from 'moment'
const FollowupListModal = ({ FollowupList, followTable, setFollowupList }) => {
  const CloseFollowupList = () => setFollowupList(false);
  return (
    <div>
      <Modal
        show={FollowupList}
        onHide={CloseFollowupList}
        size="lg"
        className="modal_con"
      >
        <Modal.Header closeButton className="follow_listhead">
          <Modal.Title style={{ fontWeight: "bold", fontSize: "22px" }}>
            Daily Sales Entry FollowUps - History
          </Modal.Title>
        </Modal.Header>
        <Modal.Body className="show-grid">
          <Table
            striped
            bordered
            hover
            variant="dark"
            responsive
            className="create_table history_table"
          >
            <thead>
              <tr>
                <th>Creation Date</th>
                <th>Followups Date</th>
                <th>Description</th>
                <th>Contact Person</th>
                <th>Contact No.</th>
                <th>Status</th>
                <th>Requirement Type</th>
                <th>Create By</th>
                <th>Follow up by</th>
                {/* <th>Order Id</th> */}
              </tr>
            </thead>
            <tbody>
              {followTable.map((data, inx) => (
                <tr key={"follow_table_model" + inx}>
                  <td>{Moment(data.f_date).format("DD-MM-YYYY")}  </td>
                  <td>{Moment(data.f_nextfollowupsdate).format("DD-MM-YYYY")} </td>
                  <td>{data.f_desc}</td>
                  <td>{data.f_contactperson}</td>
                  <td>{data.f_contactno}</td>
                  <td>{data.f_status}</td>
                  <td>{data.f_requrement}</td>
                  <td>{data.f_createby}</td>
                  <td>{data.f_followupsby}</td>
                  {/* <td></td> */}
                </tr>
              ))}
            </tbody>
          </Table>
        </Modal.Body>
      </Modal>
    </div>
  );
};

export default FollowupListModal;
