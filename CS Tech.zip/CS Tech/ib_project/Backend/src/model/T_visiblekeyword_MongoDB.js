const mongoose = require("mongoose");

const T_visiblekeyword_MongoDBSchema = mongoose.Schema(
    {
        vid: { type: Number },
        visiblekeyword: { type: String },
        deletedrow: { type: Boolean, default: null },
        f_show: { type: Boolean, default: null },
        aid: { type: String }
    },
    { collection: "T_visiblekeyword_MongoDB" }
)

module.exports = T_visiblekeyword_MongoDB = mongoose.model(
    "T_visiblekeyword_MongoDB",
    T_visiblekeyword_MongoDBSchema
)