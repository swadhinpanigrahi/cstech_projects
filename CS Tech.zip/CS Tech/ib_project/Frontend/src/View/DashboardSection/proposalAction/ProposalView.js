import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import { proposalViewAction } from "../../../Utils/api";

const ProposalView = () => {
  const { _id } = useParams();
  const [ProposalData, setProposalData] = useState({
    table1: {},
    table2: {},
  });
  useEffect(() => {
    const viewApiCall = async () => {
      const res = await proposalViewAction(_id);
      let { proposalData, tblProposalData } = res;
      let updatedData = { ...ProposalData };
      updatedData.table1 = proposalData;
      updatedData.table2 = tblProposalData;
      setProposalData({ ...updatedData });
    };
    viewApiCall();
  }, [_id, ProposalData]);
  return (
    <div id="page">
      <div className="container">
        <div className="row no-gutters head_intop">
          <div className="row new_headinv">
            <div className="col-lg-4 col-md-4 col-12">
              <span className="logo-invoice">
                <img
                  src="http://ibcdn.imagesbazaar.com/Html2015/images/logo_imagesBazaar.png"
                  alt="img1"
                />
              </span>
            </div>
            <div className="col-lg-4 col-md-4 col-9">
              <h3 className="tax_quotation">QUOTATION</h3>
            </div>
            <div className="col-lg-4 col-md-4 col-3 text-right">
              <a href="www.imagesbazaar.com/licensing" className="print_quot">
                <i className="fa fa-print"></i>
              </a>
            </div>
          </div>
        </div>
        <div className="main1">
          <div
            className="row headinv1"
            id="invoicem"
            style={{ borderButtom: "1px", solid: "#707070" }}
          >
            <div className="col-lg-8 col-md-12" id="quot_new">
              <table
                className="table table-bordered inv_table"
                style={{ borderBottom: "0px" }}
              >
                <tbody>
                  <tr
                    style={{ borderButtom: "1px solid #000" }}
                    className="tr_quot"
                  >
                    <td
                      className="invoice_tdl"
                      style={{
                        borderRight: "1px solid #000",
                        borderBottom: "1px solid #000",
                      }}
                    >
                      <p className="mg-b-0">
                        <strong>Quotation No.:</strong>{" "}
                        <strong>34567778</strong>
                      </p>
                    </td>
                  </tr>
                  <tr className="tr_quot">
                    <td
                      className="invoice_tdl"
                      style={{ borderRight: "1px solid #000" }}
                    >
                      <p className="mg-b-0">
                        <strong>Kind Attn :</strong>{" "}
                        <strong>{ProposalData.table2.f_client}</strong>
                      </p>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
            <div className="col-lg-4 col-md-12" id="head2">
              <table className="table table-bordered inv_table">
                <tbody>
                  <tr className="tr_quot">
                    <td
                      className="invoice_tdl"
                      style={{ borderRight: "1px solid #000" }}
                    >
                      <p className="mg-b-0">
                        <strong>Date:</strong>{" "}
                        <strong>{ProposalData.table1.f_createdate}</strong>
                      </p>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          <div className="row headinv" style={{ borderBottom: "0px" }}>
            <table className="table table-bordered inv_table">
              <thead className="theadinv">
                <th
                  className="text-center"
                  style={{ borderRight: "1px solid #000" }}
                >
                  <p className="mg-b-0">
                    <strong>Image</strong>
                  </p>
                </th>
                <th
                  className="text-center"
                  style={{ borderRight: "1px solid #000" }}
                >
                  <p className="mg-b-0">
                    <strong>Image ID</strong>
                  </p>
                </th>
                <th
                  className="text-center"
                  style={{ borderRight: "1px solid #000" }}
                >
                  <p className="mg-b-0">
                    <strong>Image Type</strong>
                  </p>
                </th>
                <th
                  className="text-center"
                  style={{ borderRight: "1px solid #000" }}
                >
                  <p className="mg-b-0">
                    <strong>Dimension (Px)</strong>
                  </p>
                </th>
                <th
                  className="text-center"
                  style={{ borderRight: "1px solid #000" }}
                >
                  <p className="mg-b-0">
                    <strong>Rights</strong>
                  </p>
                </th>
                <th className="text-right">
                  <p className="mg-b-0">
                    <strong>Amount (Rs.)</strong>
                  </p>
                </th>
              </thead>
              <tbody>
                <tr className="bottom_line">
                  <td
                    className="text-center"
                    style={{ borderRight: "1px solid #000" }}
                  >
                    <img src="images/imagec.png" alt="img2" />
                  </td>
                  <td
                    className="text-center"
                    style={{ borderRight: "1px solid #000" }}
                  >
                    <p className="mg-b-0">SM748545</p>
                  </td>
                  <td
                    className="text-center"
                    style={{ borderRight: "1px solid #000" }}
                  >
                    <p className="mg-b-0">SMALL</p>
                  </td>
                  <td
                    className="text-center"
                    style={{ borderRight: "1px solid #000" }}
                  >
                    <p className="mg-b-0">1500X2250 at 300dpi</p>
                  </td>
                  <td
                    className="text-center"
                    style={{ borderRight: "1px solid #000" }}
                  >
                    <p className="mg-b-0">Non-Exclusive</p>
                  </td>
                  <td className="text-right">
                    <p className="mg-b-0">{ProposalData.table2.f_amt}</p>
                  </td>
                </tr>
                <tr className="bottom_line">
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td
                    className="text-right"
                    style={{ borderRight: "1px solid #000" }}
                  >
                    <p className="mg-b-0 resblock">
                      <strong>Total</strong>
                    </p>
                  </td>
                  <td className="text-right">
                    <p className="mg-b-0">
                      <strong>{ProposalData.table2.f_amtpay}</strong>
                    </p>
                  </td>
                </tr>
                <tr className="bottom_line">
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td
                    className="text-right"
                    style={{ borderRight: "1px solid #000" }}
                  >
                    <p className="mg-b-0 resblock">
                      <strong>Discount</strong>
                    </p>
                  </td>
                  <td className="text-right">
                    <p className="mg-b-0">
                      <strong>{ProposalData.table2.f_discount}</strong>
                    </p>
                  </td>
                </tr>
                <tr className="bottom_line">
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td
                    className="text-right"
                    style={{ borderRight: "1px solid #000" }}
                  >
                    <p className="mg-b-0 resblock">
                      <strong>IGST Value @18% (INR)</strong>
                    </p>
                  </td>
                  <td className="text-right">
                    <p className="mg-b-0">
                      <strong>
                        {parseInt(ProposalData.table2.f_amtpay) +
                          parseInt(ProposalData.table2.f_sertax)}
                      </strong>
                    </p>
                  </td>
                </tr>
                <tr className="bottom_line">
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td
                    className="text-right"
                    style={{ borderRight: "1px solid #000" }}
                  >
                    <p className="mg-b-0 resblock">
                      <strong>Net Payable Amount</strong>
                    </p>
                  </td>
                  <td className="text-right">
                    <p className="mg-b-0">
                      <strong>{ProposalData.table2.f_finalamt}</strong>
                    </p>
                  </td>
                </tr>
              </tbody>
            </table>
            <table
              className="table table-bordered inv_table"
              style={{ borderBottom: "0px solid #000" }}
            >
              <tbody>
                <tr style={{ borderBottom: "0px", solid: "#707070" }}>
                  <td className="invoice_tdl">
                    <p className="mg-b-0">
                      PAN No. : <strong>AADCM6333L</strong>
                    </p>
                    <p className="mg-b-0">
                      GSTIN No. :{" "}
                      <strong>{ProposalData.table2.f_GSTNNo}</strong>
                    </p>
                    <p className="mg-b-0">
                      HSN/SAC No. : <strong>AADCM6333L</strong>
                    </p>
                    <p className="quot_imgtext">
                      Imagesbazaar is fully owned subsidiary of Mash Audio
                      Visuals Pvt. Ltd. Usage of images subject to Mash Rights
                      Agreement mentioned on{" "}
                      <a href="www.imagesbazaar.com/licensing">
                        www.imagesbazaar.com/licensing
                      </a>
                    </p>
                    <p className="quot_imgtext">
                      This is a computer generated Quotation and does not
                      require any authorised signatory.
                    </p>
                    <p className="quot_imgtext">
                      Kindly send Cheque/Demand Draft in favour of MASH AUDIO
                      VISUALS PVT. LTD. Payable at NEW DELHI to the address
                      given below :
                    </p>
                    <p className="quot_imgtext">
                      <strong>Mash Audio Visuals Private Limited</strong>
                    </p>
                    <p>
                      <strong>505, Aggarwal Prestige Mall,</strong>
                    </p>
                    <p>
                      <strong>Plot No.2, Road No.44,</strong>
                    </p>
                    <p>
                      <strong>Pitam Pura, New Delhi-110034</strong>
                    </p>
                    <p>
                      <a
                        href="www.imagesbazaar.com/licensing"
                        className="img_head"
                      >
                        www.imagesbazaar.com/licensing
                      </a>
                    </p>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProposalView;
