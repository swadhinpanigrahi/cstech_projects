import React from 'react';
import { Col } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import { useTranslation } from "react-i18next";

const ViewHelper = ({ info }) => {
    const { t } = useTranslation();
    const lableArray1 =
        [
            { label: "ship_Method", name: info.shipping_method }, { label: "order_sid", name: info.order_id },
            { label: "profile", name: "Shipping Method" }, { label: "ful_status", name: info.fulfillment_status },
            { label: "order_no", name: info.order_number }, { label: "ord_amount", name: info.order_amount },
            { label: "shop_name", name: info.shop_name }, { label: "acc_id", name: info.account_id },
            { label: "patner_orderId", name: info.partner_order_id },
            { label: "ship_name", name: info.shipping_name }, { label: "track_no", name: info.tracking_number },
            { label: "download", name: info.label_url }
        ]
    return (
        <>
            {lableArray1.map((data, inx) => {
                let { label, name } = data
                if (label === "Tracking No. :") {
                    return (
                        <Col lg={6} key={"TOTALDATA" + inx} style={{ paddingLeft: "5px", paddingRight: "5px" }}>
                            <div className="form-group row mg-b-13">
                                <div className="col-lg-5 col-md-4">
                                    <h6 className="pwdc">{t(`change.${label}`)}</h6>
                                </div>
                                <div className="col-lg-7 col-md-8">
                                    <h6 className="namep"><Link to={`/dashboard/shipments/track/${name}`} className="view_mod" target="_blank">{name}</Link></h6>
                                </div>
                            </div>
                        </Col>
                    )
                } else {
                    return (
                        <Col lg={6} key={"TOTALDATA" + inx} style={{ paddingLeft: "5px", paddingRight: "5px" }}>
                            <div className="form-group row mg-b-13">
                                <div className="col-lg-5 col-md-4">
                                    <h6 className="pwdc">{t(`change.${label}`)}</h6>
                                </div>
                                <div className="col-lg-7 col-md-8">
                                    <h6 className="namep">{name}</h6>
                                </div>
                            </div>
                        </Col>
                    )
                }
            })}
        </>
    )
}

export default ViewHelper
