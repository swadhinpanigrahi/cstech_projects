const ChangePriceModel = require("express").Router();
const {
    groupImagesList, getPriceDetail
} = require("../../controllers/Master/master.ChangePriceModeCategory")

ChangePriceModel.route(`/groupimageslist`).get(groupImagesList);
ChangePriceModel.route(`/getpricingdetail/:F_group`).get(getPriceDetail);

module.exports = ChangePriceModel;