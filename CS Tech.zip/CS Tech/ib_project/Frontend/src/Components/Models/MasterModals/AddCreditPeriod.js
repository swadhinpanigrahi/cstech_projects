import React, { useState } from 'react';
import * as RB from "react-bootstrap";
import { Row } from "react-bootstrap";

import { ADD_CREDITPERIODDETAIL } from "../../../Utils/api"

const AddCreditPeriod = (
    { show_addcreditperiod, setShow, apiCall, modelSet, setModelMsg }
) => {
    const [FormData, setFormData] = useState({});
    const [ErrorMsg, setErrorMsg] = useState("");

    const handleChange = (e) => {
        let { name, value } = e.target;
        const data = { ...FormData }
        data[name] = value
        setFormData(data)
    }

    const closeModal = () => {
        setFormData({});
        setErrorMsg("");
        setShow(false)
    }

    const addCreditPeriod = async () => {
        let { f_creditperiod, f_description } = FormData;
        if (!f_creditperiod || !f_description) {
            if (!f_creditperiod) {
                setErrorMsg("please fill credit period")
            }
            else if (!f_description) {
                setErrorMsg("please fill credit description!")
            }
        } else {
            const res = await ADD_CREDITPERIODDETAIL(FormData);
            let { status, message } = res;
            if (status === 200) {
                apiCall();
                closeModal()
                setModelMsg(message);
                modelSet()
            } else {
                setErrorMsg(message)
            }
        }
    }

    return (
        <div>
            <RB.Modal show={show_addcreditperiod} onHide={closeModal} className="ordermanage_modal">
                <RB.Modal.Header closeButton>
                    <RB.Modal.Title>Add Credit Period</RB.Modal.Title>
                </RB.Modal.Header>
                <RB.Modal.Body>
                    <RB.Row>
                        <RB.Col lg={12} md={12}>
                            <RB.Row>
                                {ErrorMsg !== "" ? ErrorMsg : ""}
                                <RB.Col lg={12} md={12}>
                                    <RB.Form>
                                        <RB.Form.Group as={Row} controlId="Country_id">
                                            <RB.Col lg={4} md={4}>
                                                <RB.Form.Label>Credit Period :</RB.Form.Label>
                                            </RB.Col>
                                            <RB.Col lg={7} md={8}>
                                                <RB.Form.Control
                                                    type="number"
                                                    name="f_creditperiod"
                                                    onChange={handleChange}
                                                />
                                            </RB.Col>
                                        </RB.Form.Group>
                                        <RB.Form.Group as={Row} controlId="Country_id">
                                            <RB.Col lg={4} md={4}>
                                                <RB.Form.Label>Description :</RB.Form.Label>
                                            </RB.Col>
                                            <RB.Col lg={7} md={8}>
                                                <RB.Form.Control
                                                    as="textarea"
                                                    name="f_description"
                                                    onChange={handleChange}
                                                />
                                            </RB.Col>
                                        </RB.Form.Group>
                                        <RB.Row>
                                            <RB.Col lg={4} md={4}></RB.Col>
                                            <RB.Col lg={6} md={7}>
                                                <RB.Button
                                                    size="sm" variant="primary"
                                                    onClick={addCreditPeriod}
                                                >
                                                    ADD
                                                </RB.Button>
                                            </RB.Col>
                                        </RB.Row>
                                    </RB.Form>
                                </RB.Col>
                            </RB.Row>
                        </RB.Col>
                    </RB.Row>
                </RB.Modal.Body>
            </RB.Modal>
        </div>
    )
}

export default AddCreditPeriod