import React from 'react';
import { Row, Col, Form, Table } from 'react-bootstrap';
import { UserFeedbackAPI, RemoveFeedbackAPI } from "../../../Utils/api";
import PaginationComponent from "../../../Components/Common/PaginationComponent";
import FeedbackReplyMailModel from "../../../Components/Models/UserModals/FeedbackReplyMailModel";


const UserFeedback = () => {
    const [Data, setData] = React.useState([]);
    const [Count, setCount] = React.useState(0);
    const [currentPage, setCurrentPage] = React.useState(1);
    const [itemPerPage, setItemPerPage] = React.useState(20);
    const [Loading, setLoading] = React.useState(false);

    const [ReplyShow, setReplyShow] = React.useState(false);

    const [userData, setUserData] = React.useState({
        cs_userid: "",
        CS_username: ""
    });

    const [searchData, setsearchData] = React.useState("")

    const handleChange = async (e) => {
        setsearchData(e.target.value)
        const res = await UserFeedbackAPI(currentPage, itemPerPage, e.target.value);
        let { customerCount, customerData } = res;
        customerCount.length === 1 ? setCount(customerCount[0].totalcount) : setCount(0);
        setData(customerData);
        setLoading(false)
    }

    const onChangeStatus = async (e) => {
        const res = await UserFeedbackAPI(currentPage, itemPerPage, e.target.value);
        let { customerCount, customerData } = res;
        customerCount.length === 1 ? setCount(customerCount[0].totalcount) : setCount(0);
        setData(customerData);
        setLoading(false)
    }

    const onReply = (cs_userid, CS_username) => {
        setUserData({ cs_userid, CS_username })
        setReplyShow(true)
    }

    const onDelete = async (_id) => {
        const res = await RemoveFeedbackAPI(_id);
        let { status } = res;
        if (status) {
            const res = await UserFeedbackAPI(currentPage, itemPerPage, searchData);
            let { customerCount, customerData } = res;
            customerCount.length === 1 ? setCount(customerCount[0].totalcount) : setCount(0);
            setData(customerData);
            setLoading(false)
        }
    }

    React.useEffect(() => {
        setLoading(true)
        const apiCall = async () => {
            const res = await UserFeedbackAPI(currentPage, itemPerPage);
            let { customerCount, customerData } = res;
            customerCount.length === 1 ? setCount(customerCount[0].totalcount) : setCount(0);
            setData(customerData);
            setLoading(false)
        }
        apiCall();
    }, [currentPage, itemPerPage])

    return (
        <>
            <Row className="rownew1">
                <Col lg={12}>
                    <Row className="page_header1 rownew1">
                        <div className="tableHeader tableHeader1 search_new">
                            <Col md={12} className="table_span">
                                <h3 className="page-title d-flex userv">
                                    <span>Search Results</span>
                                </h3>
                            </Col>
                        </div>
                    </Row>
                </Col>
            </Row>

            <Col lg={12}>
                <div className="box_detail" style={{ borderRadius: "4px" }}>
                    <div className="page-header row">
                        <Col md={12}>
                            <Form className="manage_searchorder">
                                <Row className="mg_row0">
                                    <Col lg={6} md={6}>
                                        <Row className="mg_row0">
                                            <Col lg={6} md={6}>
                                                <Form.Control
                                                    type="text"
                                                    placeholder="Search by Text/Order ID"
                                                    onChange={handleChange}
                                                />
                                            </Col>
                                        </ Row>
                                    </Col>
                                    < Col lg={2} md={2} className="customer_sdate">
                                    </ Col>
                                    < Col lg={4} md={4}>
                                        < Row className="mg_row0">
                                            <Col lg={4}></ Col>
                                            <Col lg={8} className="">
                                                <Form.Group>
                                                    <select className="select_customerd" onChange={onChangeStatus}>
                                                        {["Pending", "Confirm"].map((data, inx) => <option key={`${data}${inx}`}>{data}</option>)}
                                                    </select>
                                                </Form.Group>
                                            </ Col>
                                        </ Row>
                                    </ Col>
                                </Row>
                            </Form>
                        </Col>
                    </div>
                </div>
            </Col>

            <Col lg={12}>
                <Row className="rownew1">
                    <div className="tableHeader tableHeader1 search_new">
                        <Col lg={6} md={6} xs={7} className="table_span">
                            <h3 className="page-title d-flex userv">
                                <span>User Feedback List</span>
                            </h3>
                        </Col>
                        <Col lg={6} md={6} xs={5} className="table_span text-right">
                            Total Count : {Count}
                        </Col>
                    </div>
                </Row>

                <div
                    className="box_detail table_boxdtl manage_order"
                    style={{ marginBottom: "0px" }}
                >
                    <Table striped bordered hover variant="dark" responsive>
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>User Name</th>
                                <th>Contact Number</th>
                                <th>Feedback</th>
                                <th>Create Date</th>
                                <th>Reply</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            {Loading ? <>
                                <td className="no_records" colSpan="11">
                                    Loading...
                                </td>
                            </> : Data.length > 0 ? Data.map((info) => {
                                let { _id, f_name, CS_username, f_mobile, f_feedback, cs_userid, f_createdate } = info;
                                return (
                                    <tr key={_id}>
                                        <td>{f_name}</td>
                                        <td>{CS_username}</td>
                                        <td>{f_mobile}</td>
                                        <td>{f_feedback}</td>
                                        <td>{f_createdate}</td>
                                        <td onClick={() => onReply(cs_userid, CS_username)}>reply</td>
                                        <td onClick={() => onDelete(_id)}>delete</td>
                                    </tr>
                                )
                            }) : <>
                                <td className="no_records" colSpan="11">
                                    No Records Found
                                </td>
                            </>}
                        </tbody>
                    </Table>
                </div>
                <PaginationComponent
                    MOCK_DATA={Count}
                    currentPage={currentPage}
                    setCurrentPage={setCurrentPage}
                    itemPerPage={itemPerPage}
                    setItemPerPage={setItemPerPage}
                />
                <FeedbackReplyMailModel
                    userData={userData}
                    ReplyShow={ReplyShow}
                    setReplyShow={setReplyShow}
                />
            </Col>
        </>
    )
}

export default UserFeedback
