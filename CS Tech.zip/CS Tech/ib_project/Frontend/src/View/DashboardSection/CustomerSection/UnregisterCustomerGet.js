import React, { useState, useEffect } from "react";
import PaginationComponent from "../../../Components/Common/PaginationComponent";
import {
  unregisterCustomerList,
  updateUnregisteredCustomerList,
  getUnregisteredShortAndCompanyName,
} from "../../../Utils/api";
import { Row, Col, Form, Button, Table, Modal } from "react-bootstrap";
import "react-datepicker/dist/react-datepicker.css";

const TableData = ({
  info,
  handleShow,
  selectedEmails: selectedEmail,
  setSelectedEmails,
}) => {
  const handleCheck = (e, f_email) => {
    let { checked } = e.target;
    let selectedEmailVal = [...selectedEmail];
    if (checked) {
      selectedEmailVal.push(f_email);
    } else {
      let delIndex = selectedEmailVal.indexOf(f_email);
      selectedEmailVal.splice(delIndex, 1);
    }
    setSelectedEmails(selectedEmailVal);
  };
  return info.length !== 0 ? (
    info.map((data, inx) => {
      return (
        <tr key={"UN-CUSTOMER_NAV_TBL" + inx}>
          <td>{data.f_userid}</td>
          <td>{data.f_companyname}</td>
          <td>{data.f_email}</td>
          <td>{data.f_groupname}</td>
          <td
            style={{ color: "#0081ad", cursor: "pointer" }}
            onClick={() => handleShow()}
          >
            {data.f_Shortname ? data.f_Shortname : "update"}
          </td>
          <td>{data.f_address}</td>
          <td>
            <Form.Group className="mb-3" controlId="formBasicCheckbox">
              <Form.Check
                type="checkbox"
                name={data.f_email}
                checked={selectedEmail.includes(data.f_email) || false}
                onChange={(e) => {
                  handleCheck(e, data.f_email);
                }}
              />
            </Form.Group>
          </td>
        </tr>
      );
    })
  ) : (
    <tr>
      <td class="no_records" colspan="11">
        No Records Found
      </td>
    </tr>
  );
};

const UnregisterCustomerGet = () => {
  const [Data, setData] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [itemPerPage, setItemPerPage] = useState(20);
  let [searchData, setSearchData] = useState("");
  const [Count, setCount] = useState(0);
  const [Loading, setLoading] = useState(false);

  const [FormData, setFormData] = useState({});
  const [selectedEmails, setSelectedEmails] = useState([]);
  const [show, setShow] = useState(false);

  const onHide = () => setShow(false);

  const onSumit = async () => {
    await updateUnregisteredCustomerList({ ...FormData, selectedEmails });
    setShow(false);
  };

  const handleShow = async () => {
    if (selectedEmails[0]) {
      console.log(selectedEmails[0]);
      const res = await getUnregisteredShortAndCompanyName({
        f_email: selectedEmails[0],
      });
      let { CustomerDetails } = res;
      console.log(CustomerDetails);
      setFormData(CustomerDetails);
      setShow(true);
    } else {
      window.alert("check box missing");
    }
  };

  const FormPostHandleChange = (e) => {
    let { name, value } = e.target;
    const data = { ...FormData };
    data[name] = value;
    setFormData(data);
  };

  const handleChange = async (e) => {
    setSearchData(e.target.value);
    setLoading(true);
    const res = await unregisterCustomerList(
      currentPage,
      itemPerPage,
      (searchData = e.target.value)
    );
    let { customerCount, customerData } = res;
    setData(customerData);
    customerCount.length === 1
      ? setCount(customerCount[0].totalCount)
      : setCount(0);
    setLoading(false);
  };

  const onAllDataClick = async () => {
    setLoading(true);
    const res = await unregisterCustomerList(
      currentPage,
      itemPerPage,
      (searchData = "")
    );
    let { customerCount, customerData } = res;
    setData(customerData);
    customerCount.length === 1
      ? setCount(customerCount[0].totalCount)
      : setCount(0);
    setLoading(false);
  };

  useEffect(() => {
    setLoading(true);
    const GET_API = async () => {
      const res = await unregisterCustomerList(
        currentPage,
        itemPerPage,
        searchData
      );
      let { customerCount, customerData } = res;
      setData(customerData);
      customerCount.length === 1
        ? setCount(customerCount[0].totalCount)
        : setCount(0);
      setLoading(false);
    };
    GET_API();
  }, [currentPage, itemPerPage]);

  return (
    <>
      <Row className="rownew1">
        <Col lg={12}>
          <Row className="page_header1 rownew1">
            <div className="tableHeader tableHeader1 search_new">
              <Col md={12} className="table_span">
                <h3 className="page-title d-flex userv">
                  <span>Search Results</span>
                </h3>
              </Col>
            </div>
          </Row>
        </Col>
        <Col lg={12}>
          <div className="box_detail" style={{ borderRadius: "4px" }}>
            <div className="page-header row">
              <Col md={12}>
                <Form className="manage_searchorder">
                  <Row className="mg_row0">
                    <Col lg={7} md={7}>
                      <Row className="mg_row0">
                        <Col lg={5} md={5}>
                          <Form.Group>
                            <Form.Control
                              type="text"
                              placeholder="Search by Text/User ID"
                              onChange={handleChange}
                            />
                          </Form.Group>
                        </Col>
                      </Row>
                    </Col>

                    <Col lg={3} md={3}>
                      <Row className="mg_row0 go_btnrow">
                        <Button
                          block
                          className="goBtn"
                          onClick={onAllDataClick}
                        >
                          ALL DATA
                        </Button>
                      </Row>
                    </Col>
                  </Row>
                </Form>
              </Col>
            </div>
          </div>
        </Col>

        {/**
         * TABLE
         */}
        <Col lg={12}>
          <Row className="rownew1">
            <div className="tableHeader tableHeader1 search_new">
              <Col lg={6} md={6} className="table_span">
                <h3 className="page-title d-flex userv">
                  <span>Unregistered-Customer List</span>
                </h3>
              </Col>
            </div>
          </Row>
          <div
            className="box_detail table_boxdtl manage_order"
            style={{ marginBottom: "0px" }}
          >
            <Table striped bordered hover variant="dark" responsive>
              <thead>
                <tr class="vtable">
                  <th>User ID</th>
                  <th>Company</th>
                  <th>Email</th>
                  <th>Group Name</th>
                  <th>Short Company Name</th>
                  <th>Address</th>
                  <th>
                    <input type="checkbox" />
                  </th>
                </tr>
              </thead>
              <tbody>
                {Loading ? (
                  <tr>
                    <td class="loadingd" colspan="10">
                      Loading....
                    </td>
                  </tr>
                ) : (
                  <TableData
                    {...{
                      info: Data,
                      handleShow,
                      selectedEmails,
                      setSelectedEmails,
                    }}
                  />
                )}
              </tbody>
            </Table>
          </div>
        </Col>

        <PaginationComponent
          MOCK_DATA={Count}
          currentPage={currentPage}
          setCurrentPage={setCurrentPage}
          itemPerPage={itemPerPage}
          setItemPerPage={setItemPerPage}
        />
      </Row>

      {/**
       * MODEL
       */}

      <Modal show={show} onHide={onHide} animation={false}>
        <Modal.Header closeButton>
          <Modal.Title>Modal heading</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form.Group
            as={Row}
            className="mb-3"
            controlId="formShortCompanyName"
          >
            <Form.Label column sm="2">
              Associative Name
            </Form.Label>
            <Col sm="10">
              <Form.Control
                onChange={FormPostHandleChange}
                type="text"
                name="f_associativename"
                value={FormData.f_associativename}
                placeholder="Enter Associative Name"
              />
            </Col>
          </Form.Group>

          <Form.Group
            as={Row}
            className="mb-3"
            controlId="formShortCompanyName"
          >
            <Form.Label column sm="2">
              Short Name
            </Form.Label>
            <Col sm="10">
              <Form.Control
                onChange={FormPostHandleChange}
                type="text"
                name="f_Shortname"
                value={FormData.f_Shortname}
                placeholder="Enter Short Name"
              />
            </Col>
          </Form.Group>

          <Form.Group as={Row} className="mb-3" controlId="formGroupName">
            <Form.Label column sm="2">
              Group Name
            </Form.Label>
            <Col sm="10">
              <Form.Control
                onChange={FormPostHandleChange}
                type="text"
                name="f_groupname"
                value={FormData.f_groupname}
                placeholder="Enter Group Name"
              />
            </Col>
          </Form.Group>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="primary" onClick={onSumit}>
            SUBMIT
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
};

export default UnregisterCustomerGet;
