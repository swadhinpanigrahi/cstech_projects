const { AdminLogin } = require("../../model");

exports.getAdminList = async (req, res) => {
    const { currentPage, itemPerPage, searchData } = req.query;
    const num = parseInt(itemPerPage)
    const start = parseInt(currentPage);
    let pipeline;
    let countline;
    try {
        if (!searchData || searchData === "") {
            pipeline = [
                { $sort: { _id: -1 } },
                { $skip: (start - 1) * num },
                { $limit: num }
            ]
            countline = [
                { $count: "totalcount" }
            ]
        } else {
            pipeline = [
                { $match: { username: { $regex: searchData, $options: "im" } } },
                { $sort: { _id: -1 } },
                { $skip: (start - 1) * num },
                { $limit: num }
            ]
            countline = [
                { $match: { username: { $regex: searchData, $options: "im" } } },
                { $count: "totalcount" }
            ]
        }
        const data = await AdminLogin.aggregate(pipeline)
        const totalrecord = await AdminLogin.aggregate(countline)
        res.json({ status: 200, data, totalrecord })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

exports.addAdmin = async (req, res) => {
    const { username, password } = req.body;
    try {
        const users = await AdminLogin.find({})
        const user = await AdminLogin.findOne({ username });
        if (user) {
            res.json({ status: 400, message: "admin is already exist" })
        } else {
            await new AdminLogin({ userid: users.length, username, password }).save();
            res.json({ status: 200, message: "admin added successfully!" })
        }
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}