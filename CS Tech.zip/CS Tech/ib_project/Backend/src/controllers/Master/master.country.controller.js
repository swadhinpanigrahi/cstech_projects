const { M_COUNTRY, Counter } = require("../../model");

exports.addCountryDetail = async (req, res) => { //work
    const { f_country } = req.body;
    try {
        const data = await M_COUNTRY.findOne({ f_country })
        if (data) {
            res.json({ status: 400, message: "already exists!" })
        } else {
            const id = await Counter.findOneAndUpdate({ _id: "f_countryid" }, {
                $inc: { sequence: 1 }
            }, { useFindAndModify: false });
            const saveData = await new M_COUNTRY({
                f_countryid: id.sequence, f_country, f_creationdate: new Date(),
                f_status: true, f_state_available: false
            }).save()
            res.json({ status: 200, saveData })
        }
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

exports.getCountrys = async (req, res) => {
    try {
        const data = await M_COUNTRY.find({})
        res.json({ status: 200, data })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

exports.getCountryList = async (req, res) => {
    const { currentPage, itemPerPage, searchData } = req.query;
    const num = parseInt(itemPerPage)
    const start = parseInt(currentPage);
    let pipeline;
    let countline;
    try {
        if (!searchData || searchData === "") {
            pipeline = [
                { $sort: { f_creationdate: -1 } },
                { $skip: (start - 1) * num },
                { $limit: num }
            ]
            countline = [
                { $count: "totalcount" }
            ]
        } else {
            pipeline = [
                { $match: { f_country: { $regex: searchData, $options: "im" } } },
                { $sort: { f_creationdate: -1 } },
                { $skip: (start - 1) * num },
                { $limit: num }
            ]
            countline = [
                { $match: { f_country: { $regex: searchData, $options: "im" } } },
                { $count: "totalcount" }
            ]
        }
        const data = await M_COUNTRY.aggregate(pipeline)
        const totalrecord = await M_COUNTRY.aggregate(countline)
        res.json({ status: 200, data, totalrecord })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

exports.getCountryDetail = async (req, res) => {
    const { _id } = req.params;
    try {
        const data = await M_COUNTRY.findOne({ _id })
        res.json({ status: 200, data })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

exports.editCountryDetail = async (req, res) => {
    const { _id, f_country } = req.body;
    try {
        const data = await M_COUNTRY.findById({ _id });
        console.log(data, req.body)
        if (data) {
            await M_COUNTRY.findByIdAndUpdate({ _id }, { $set: { f_country } })
        }
        res.json({ status: 200, message: "country updated successfully" })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

exports.deleteCountryDetail = async (req, res) => {
    const { _id } = req.params;
    try {
        await M_COUNTRY.findByIdAndRemove({ _id })
        res.json({ status: 200, message: "country removed successfully!!" })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}