const formElement = {
  username: {
    name: "username",
    type: "text",
    placeholder: "Enter Your Username",
    controlId: "formBasicUsername",
  },
  password: {
    label: "Password :",
    name: "password",
    type: "password",
    placeholder: "Enter Your Password",
    controlId: "formBasicPassword",
  },
  name: {
    label: "Name :",
    name: "name",
    type: "text",
    placeholder: "Enter Your Name",
    controlId: "formBasicName",
  },
  email: {
    label: "Email :",
    name: "email",
    type: "email",
    placeholder: "Enter Your Email",
    controlId: "formBasicEmail",
  },
  phone: {
    label: "Mobile Number :",
    name: "phone",
    type: "text",
    placeholder: "Enter Your Mobile Number",
    controlId: "formBasicPhone",
  },
  companyName: {
    label: "Company Name :",
    name: "companyName",
    type: "text",
    placeholder: "Enter Your Company Name",
    controlId: "formBasicCompanyName",
  },
  address: {
    label: "Address :",
    name: "address",
    type: "email",
    placeholder: "Enter Your Address",
    controlId: "formBasicAddress",
  },
  pincode: {
    label: "Pincode :",
    name: "pincode",
    type: "text",
    placeholder: "Enter Your Pincode",
    controlId: "formBasicPincode",
  },
  city: {
    label: "City :",
    name: "city",
    type: "text",
    placeholder: "Enter Your City",
    controlId: "formBasicCity",
  },
  state: {
    label: "State :",
    name: "state",
    type: "text",
    placeholder: "Enter Your State",
    controlId: "formBasicState",
  },
  country: {
    label: "Country :",
    name: "country",
    type: "text",
    placeholder: "Enter Your Country",
    controlId: "formBasicCountry",
  },
  beneficiary_name: {
    label: "Beneficiary Name :",
    name: "beneficiary_name",
    type: "text",
    placeholder: "Enter Your Beneficiary Name",
    controlId: "formBasicBeneficiaryName",
  },
  bank_name: {
    label: "Bank Name :",
    name: "bank_name",
    type: "text",
    placeholder: "Enter Your Bank Name",
    controlId: "formBasicBankName",
  },
  account_number: {
    label: "Account Number :",
    name: "account_number",
    type: "number",
    placeholder: "Enter Your Account Number",
    controlId: "formBasicAccNum",
  },
  ifsc_code: {
    label: "IFSC Code :",
    name: "ifsc_code",
    type: "text",
    placeholder: "Enter Your IFSC Code",
    controlId: "formBasicIFSCcode",
  },
  bank_branch: {
    label: "Bank Branch :",
    name: "bank_branch",
    type: "text",
    placeholder: "Enter Your Bank Branch",
    controlId: "formBasicBankBranch",
  },

  oldpassword: {
    label: "Current Password :",
    name: "oldpassword",
    type: "password",
    placeholder: "Enter Your Current Password",
    className: "form-control",
    required: true,
    controlId: "formBasicOldpassword",
  },
  newpassword: {
    label: "New Password :",
    name: "newpassword",
    type: "password",
    placeholder: "Enter Your New Password",
    className: "form-control",
    required: true,
    controlId: "formBasicNewPassword",
  },
  confirmpassword: {
    label: "Confirm Password :",
    name: "confirmpassword",
    type: "password",
    placeholder: "Re-enter Your New Password",
    className: "form-control",
    required: true,
    controlId: "formBasicRE-enterNewPassword",
  },

  firstName: {
    label: "First Name :",
    name: "firstName",
    type: "text",
    placeholder: "Enter Your First Name",
    className: "form-control",
    required: true,
    controlId: "formBasicNewFirstName",
  },
  lastName: {
    label: "Last Name :",
    name: "lastName",
    type: "text",
    placeholder: "Enter Your Last Name",
    className: "form-control",
    required: true,
    controlId: "formBasicNewLastName",
  },
  emailId: {
    label: "Email ID :",
    name: "emailId",
    type: "text",
    placeholder: "Enter Your Email",
    className: "form-control",
    required: true,
    controlId: "formBasicNewEmailIDAuth",
  },
  mobileNo: {
    label: "Mobile Number :",
    name: "mobileNo",
    type: "text",
    placeholder: "Enter Your Mobile Number",
    className: "form-control",
    required: true,
    controlId: "formBasicNewAuthPhone",
  },
  sub_name: {
    section: "input",
    label: "First Name :",
    name: "sub_name",
    type: "text",
    placeholder: "Enter Your First Name",
    controlId: "formBasicsubusername",
  },
  sub_lname: {
    section: "input",
    label: "Last Name :",
    name: "sub_lname",
    type: "text",
    placeholder: "Enter Your First Name",
    controlId: "formBasicsubuserlname",
  },
  sub_email: {
    section: "input",
    label: "Email :",
    name: "sub_email",
    type: "text",
    placeholder: "Enter Your Email ID",
    controlId: "formBasicsubuserename",
  },
  sub_password: {
    section: "input",
    label: "Password :",
    name: "sub_password",
    type: "text",
    placeholder: "Enter Your Password",
    controlId: "formBasicsubusercname",
  },
  sub_phoneno: {
    section: "input",
    label: "Phone No. :",
    name: "sub_phoneno",
    type: "text",
    placeholder: "Enter Your Phone Nomber",
    controlId: "formBasicsubuserpname",
  },
  sub_cname: {
    section: "input",
    label: "Company Name :",
    name: "sub_cname",
    type: "text",
    placeholder: "Enter Your Company Name",
    controlId: "formBasicsubusercname",
  },
};

const paymentForm = {
  seller_entry_name: {
    section: "input",
    label: "Seller Entity Name :",
    name: "seller_entry_name",
    type: "text",
    placeholder: "Enter Your Seller Entity Name",
    controlId: "formBasicSellerEntityName11",
  },
  account_number: {
    section: "input",
    label: "Account Number :",
    name: "account_number",
    type: "number",
    placeholder: "Enter Your Account Number",
    controlId: "formBasicAccountNumber11",
  },
  beneficiary_name: {
    section: "input",
    label: "Beneficiary Name :",
    name: "beneficiary_name",
    type: "text",
    placeholder: "Enter Your Beneficiary Name",
    controlId: "formBasicBeneficiaryName11",
  },
  bank_name: {
    section: "input",
    label: "Bank Name :",
    name: "bank_name",
    type: "text",
    placeholder: "Enter Your Bank Name",
    controlId: "formBasicBeneBankName11",
  },
  bank_branch: {
    section: "input",
    label: "Bank Branch :",
    name: "bank_branch",
    type: "text",
    placeholder: "Enter Your Bank Branch",
    controlId: "formBasicBeneBankBranch11",
  },
  ifsc_code: {
    section: "input",
    label: "IFSC Code/Swift Code :",
    name: "ifsc_code",
    type: "text",
    placeholder: "Enter Your IFSC Code/Swift Code",
    controlId: "formBasicIFSCCode/SwifCode11",
  },
  balance: {
    section: "input",
    label: "Balance :",
    name: "balance",
    type: "number",
    placeholder: "Enter Your Balance",
    controlId: "formBasicBalance11",
  },
  mode: {
    section: "select",
    label: "Mode Of Payment :",
    name: "mode",
    type: "text",
    arr: ["Bank", "Cheque"],
    placeholder: "Enter Your Mode Of Payment",
    controlId: "formBasicModeOfPayment11",
  },
  payment_type: {
    section: "select",
    label: "Payment Type :",
    name: "payment_type",
    type: "text",
    arr: ["Credit", "Debit"],
    placeholder: "Enter Your Payment Type",
    controlId: "formBasicPaymentType11",
  },
  transection_no: {
    section: "input",
    label: "NEFT/Trans No. :",
    name: "transection_no",
    type: "text",
    placeholder: "Enter Your NEFT/Trans No",
    controlId: "formBasicNEFT/TransNo11",
  },
  payed_amount: {
    section: "input",
    label: "Paid Amount :",
    name: "payed_amount",
    type: "number",
    placeholder: "Enter Your Paid Amount",
    controlId: "formBasicPaidAmount11",
  },
  comment: {
    section: "input",
    label: "Comment :",
    name: "comment",
    type: "text",
    placeholder: "Enter Your Comment",
    controlId: "formBasicComment11",
  },
}

export const addsubuserForm = [
  formElement.firstName, formElement.lastName,
  formElement.emailId, formElement.password,
  formElement.mobileNo, formElement.companyName,
];

export const addsubusermodalForm = [
  formElement.add_subuser, formElement.export_subuser,
];

export const loginForm = [formElement.username, formElement.password];

export const customerDetailsForm = [
  formElement.name, formElement.email,
  formElement.phone, formElement.password,
  formElement.companyName, formElement.address,
  formElement.pincode, formElement.city,
  formElement.state, formElement.country,
];

export const customerBankDetails = [
  formElement.beneficiary_name, formElement.bank_name,
  formElement.account_number, formElement.ifsc_code,
  formElement.bank_branch
]

export const paymentFormDetails = [
  paymentForm.seller_entry_name, paymentForm.account_number,
  paymentForm.beneficiary_name, paymentForm.bank_name,
  paymentForm.bank_branch, paymentForm.ifsc_code,
  paymentForm.balance, paymentForm.mode,
  paymentForm.payment_type, paymentForm.transection_no,
  paymentForm.payed_amount, paymentForm.comment,
]

export const changePasswordForm = [
  formElement.oldpassword,
  formElement.newpassword,
  formElement.confirmpassword,
];

export const AuthEditForm = [
  formElement.firstName, formElement.lastName,
  formElement.emailId, formElement.mobileNo,
  formElement.companyName
]

export const EmailChangePasswordForm = [formElement.newpassword, formElement.confirmpassword]