import React, { useState } from "react";
import { Link } from "react-router-dom";
import "../Dropdown.css";

const MenuItems = [
    {
        nto: "/dashboard/customer/get",
        title: "User",
        cName: "dropdown-link"
    },
    {
        nto: "/dashboard/customer/unregistercustomer/get",
        title: "Unregistered User",
        cName: "dropdown-link"
    },
    {
        nto: "/dashboard/customer/unpaiduser/get",
        title: "Unpaid User",
        cName: "dropdown-link"
    },
    {
        nto: "/dashboard/customer/superimageuser/get",
        title: "Super Image User",
        cName: "dropdown-link"
    },
    {
        nto: "/dashboard/customer/userfeedback/get",
        title: "User Feedback",
        cName: "dropdown-link"
    },
    {
        nto: "/dashboard/customer/bannerimagesdownload/get",
        title: "Banner Images Download",
        cName: "dropdown-link"
    },
]


const CustomerDropDown = () => {

    const [click, setClick] = useState(false);

    const handleClick = () => setClick(!click)

    return (
        <>
            <ul onClick={handleClick} className={click ? "dropdown-menu clicked" : "dropdown-menu"}>
                {MenuItems.map((item, index) => {
                    return (
                        <li key={`KEYDROP_LIST_${index}`}>
                            <Link className={item.cName} to={item.nto} onClick={() => setClick(false)}>
                                {item.title}
                            </Link>
                        </li>
                    )
                })}
            </ul>
        </>
    )
}

export default CustomerDropDown;