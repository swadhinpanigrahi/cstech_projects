import React, { useState, useEffect } from 'react';
import { Link } from "react-router-dom";
import { Col, Row } from 'react-bootstrap';
import PageHeaders from '../../../Components/Common/PageHeaders';
import { getSubUserList, deleteSubUser, ActiveDeactiveSubUser, getSearchSubUserData } from '../../../Utils/api';
import Model from "../../../Components/Common/Model";
import ReactExport from "react-data-export";


const SubuserList = () => {
  const [UserData, setUserData] = useState([]);
  const [Loading, setLoading] = useState(false);

  const [isOpen, setIsOpen] = useState(false);
  const [ModelMsg, setModelMsg] = useState("");

  const [search, setSearch] = useState("");

  const handleChange = async (e) => {
    setSearch(e.target.value);
    const res = await getSearchSubUserData(e.target.value);
    let { searchData } = res;
    let shaloArray = [...searchData];
    setUserData(shaloArray)
  }

  //EXPORT
  const ExcelFile = ReactExport.ExcelFile;
  const ExcelSheet = ReactExport.ExcelFile.ExcelSheet;
  const DataSet = [
    {
      columns: [
        { title: "FIRST NAME" },
        { title: "LAST NAME" },
        { title: "EMAIL" },
        { title: "MOBILE NO." },
        { title: "COMPANY NAME" },
        { title: "CREATION DATE" },
      ],
      data: UserData.map((data) => [
        { value: data.firstName },
        { value: data.lastName },
        { value: data.emailId },
        { value: data.mobileNo },
        { value: data.companyName },
        { value: data.createdAt.slice(0, 10) },
      ]),
    },
  ];
  //EXPORT

  let listData = UserData.length > 0 ?
    UserData.map((data, inx) => (
      <tr key={"SUBUSER_LIST" + inx}>
        <td>{inx + 1}</td>
        <td>{`${data.firstName} ${data.lastName}`}</td>
        <td>{data.emailId}</td>
        <td>{data.mobileNo}</td>
        <td>{data.companyName}</td>
        <td>{data.createdAt.slice(0, 10)}</td>
        <td className="text-center">{data.activate}</td>
        <td className="text-center">
          <span className="iconfa text-primary permission">
            <Link to={`/dashboard/subuser/permission/${data._id}`} target="blank" className="view_mod">P</Link>
          </span>
          <i className="fa fa-eye iconfa" onClick={() => AcountDeactivation(data._id)}></i>
          <Link to={`/dashboard/subuser/editsubadmin/${data._id}`} target="blank"><i className="fa fa-edit iconfa"></i></Link>
          <i className="fa fa-trash text-danger iconfa newi_c" onClick={() => userDelete(data._id)}></i>
        </td>
      </tr >
    )) : <tr ><td className="no_records" colSpan="9">NO RECORDS FOUND</td></tr>

  const modelSet = () => {
    setIsOpen(true);
  };

  const userDelete = async (_id) => {
    const res = await deleteSubUser(_id);
    let { message } = res;
    if (message) {
      setModelMsg("Successfully Deleted")
      modelSet()
      const shaloArray = [...UserData];
      const filteredArray = shaloArray.filter(data => data._id !== _id);
      setUserData([...filteredArray])
    }
  }

  const AcountDeactivation = async (_id) => {
    const res = await ActiveDeactiveSubUser(_id);
    let { status, message } = res
    if (status === 200) {
      setModelMsg(message)
      modelSet()
      const res = await getSubUserList();
      let { subAdminList } = res
      const shaloArray = [...subAdminList]
      setUserData(shaloArray)
    }
  }

  useEffect(() => {
    setLoading(true)
    const apiCall = async () => {
      const res = await getSubUserList();
      let { subAdminList } = res
      setUserData(subAdminList)
      setLoading(false)
    }
    apiCall()
  }, [])

  return (
    <>
      <main className="pd-b-25">
        <Col md={12}>
          <PageHeaders title="User List" />
          <Col md={12}>
            <div
              className="box_detail"
              style={{ padding: "15px 0px 10px 0px", marginBottom: "20px" }}
            >
              <Col lg={12} style={{ padding: "0px" }}>
                <div className="page-header row no-gutters">
                  <Col md={12} style={{ color: "blue !important" }}>
                    <h3 className="page-title subtitile">FILTER BY SEARCH</h3>
                  </Col>
                  <hr />
                </div>
              </Col>
              <Row style={{ padding: "20px 30px" }}>
                <Col lg={4} md={8}>
                  <div className="form-group row mb-0">
                    <Col lg={12}>
                      <input
                        type="text"
                        name="search"
                        onChange={handleChange}
                        placeholder="Serach by Name, Email and Phone"
                        className="form-control"
                      />
                    </Col>
                  </div>
                </Col>
                <div className="col-lg-8 col-md-4 text-right addb">
                  <button className="addc">
                    <span>
                      <i className="fa fa-plus-circle"></i>
                      <span style={{ position: "relative", left: "5px" }}>
                        <Link to="/dashboard/subuser/add">ADD NEW USER</Link>
                      </span>
                    </span>
                  </button>
                </div>
              </Row>
            </div>
          </Col>
          <Col md={12} className="text-right">
            <ExcelFile
              fillename="sheet"
              element={UserData.length !== 0
                ? <button className="export_btn addbce customer_export">EXPORT</button>
                : <button className="export_btn addbce1 customer_export" disabled>EXPORT</button>}
            >
              <ExcelSheet dataSet={DataSet} name="shipment reports" />
            </ExcelFile>
          </Col>

          <Col md={12}>
            <hr />
            <div
              className="box_detail tableboxdc"
              style={{
                paddingTop: "0px",
                paddingBottom: "0px",
                marginBottom: "0px",
              }}
            >
              <table className="table table-bordered table-responsive" id="table-to-xls">
                <thead className="thead-dark">
                  <tr>
                    <th>S NO.</th>
                    <th>NAME</th>
                    <th>EMAIL</th>
                    <th>PHONE NO.</th>
                    <th>COMPANY NAME</th>
                    <th>CREATION DATE</th>
                    <th className="text-center">ACTIVE</th>
                    <th className="text-center">ACTION</th>
                  </tr>
                </thead>
                <tbody>
                  {Loading ? <tr><td className="no_records" colSpan="8">Loading....</td></tr> : [listData]}
                </tbody>
              </table>
            </div>
          </Col>

        </Col>
      </main>
      <Model
        text={ModelMsg}
        open={isOpen}
        onClose={() => setIsOpen(false)}
      />
    </>


  )
}

export default SubuserList
