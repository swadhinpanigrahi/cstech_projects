const mongoose = require("mongoose");

const T_ShopingCart_Schema = mongoose.Schema(
    {
        CS_id: { type: Number },
        CS_sessionId: { type: String, default: "" },
        CS_userid: { type: String },
        CS_username: { type: String },
        CS_imgId: { type: Number },
        CS_imgCode: { type: String },
        CS_Price: { type: Number },
        CS_ImgType: { type: String },
        CS_ImgType_up: { type: String },
        f_image_type: { type: String, default: "" },
        f_country: { type: String, default: "" },
        f_state: { type: String, default: "" },
        f_duration: { type: String, default: "" },
        f_plantype: { type: String, default: "" },
        f_industry: { type: String, default: "" },
        f_rights: { type: String, default: "" },
        f_visadiscount: { type: String, default: "" },
        f_mydimension: { type: String, default: "" },
        f_creationDate: { type: Date, default: Date.now() },
    },
    { collection: "T_ShopingCart_IB_MongoDB" }
);

module.exports = T_ShopingCart = mongoose.model("T_ShopingCart_IB_MongoDB", T_ShopingCart_Schema)