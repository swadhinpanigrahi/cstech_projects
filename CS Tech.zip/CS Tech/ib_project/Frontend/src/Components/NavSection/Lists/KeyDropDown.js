import React, { useState } from "react";
import { Link } from "react-router-dom";
import "../Dropdown.css";

const MenuItems = [
    {
        nto: "/dashboard/keyword/visiblekeys/get",
        title: "Visible Keywords",
        cName: "dropdown-link"
    },
    {
        nto: "/dashboard/keyword/allkeys/get",
        title: "All Keywords",
        cName: "dropdown-link"
    },
    // {
    //     nto: "/dashboard/dailysalesentry",
    //     title: "Daily Sales",
    //     cName: "dropdown-link"
    // },
]


const KeyDropDown = () => {

    const [click, setClick] = useState(false);

    const handleClick = () => setClick(!click)

    return (
        <>
            <ul onClick={handleClick} className={click ? "dropdown-menu clicked" : "dropdown-menu"}>
                {MenuItems.map((item, index) => {
                    return (
                        <li key={`KEYDROP_LIST_${index}`}>
                            <Link className={item.cName} to={item.nto} onClick={() => setClick(false)}>
                                {item.title}
                            </Link>
                        </li>
                    )
                })}
            </ul>
        </>
    )
}

export default KeyDropDown;