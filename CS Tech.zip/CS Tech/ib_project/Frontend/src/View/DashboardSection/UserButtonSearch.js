import React, { useState, useEffect } from "react";
import { useParams, Link } from "react-router-dom";
import { OrderSearchByMail, getOrderDeatils, getOrderInvoice } from "../../Utils/api";
import { AiOutlineFileSearch } from "react-icons/ai";
import { BiCommentDetail } from "react-icons/bi";
import { IoIosArrowBack } from "react-icons/io";
import * as RB from "react-bootstrap";
import OrderInvoiceModel from "../../Components/Models/OrderModals/OrderInvoiceModel";
import OrderDetailsModel from "../../Components/Models/OrderModals/OrderDetailsModel";
import Moment from "moment";

const UserButtonSearch = ({ search, spanOrder }) => {
  const { T_username } = useParams();
  const [Loading, setLoading] = useState(false)

  const [data, setData] = useState([]);
  const [NewArray, setNewArray] = useState([]);
  const [Countes, setCountes] = useState({
    Total: 0,
    Confirmed: 0,
    Pending: 0,
    Rejected: 0
  });

  const [OrderDetailsIsOpen, setOrderDetailsIsOpen] = useState(false);
  const [OrderInvoiceIsOpen, setOrderInvoiceIsOpen] = useState(false);

  const [OrderDataObj, setOrderDataObj] = useState({});
  const [OrderDataList, setOrderDataList] = useState([]);
  const [OrderUser, setOrderUser] = useState({})

  const [OrderInvoiceObj, setOrderInvoiceObj] = useState({});
  const [OrderInvoiceList, setOrderInvoiceList] = useState([])

  const CloseOrderDetails = () => setOrderDetailsIsOpen(false);
  const OrderDetailsClick = async (orderId) => {
    const res = await getOrderDeatils(orderId);
    let { OrderDetail, OrderDetailsList, userDetails } = res;
    setOrderDataObj(OrderDetail);
    setOrderDataList(OrderDetailsList);
    setOrderUser(userDetails)
    setOrderDetailsIsOpen(true);
  };

  const CloseOrderInvoice = () => setOrderInvoiceIsOpen(false);
  const OrderInvoiceClick = async (orderId) => {
    const res = await getOrderInvoice(orderId);
    console.log(orderId, res)
    let { OrderInvoice, OrderInvoiceList } = res;
    setOrderInvoiceObj(OrderInvoice);
    setOrderInvoiceList(OrderInvoiceList);
    console.log(OrderInvoice, OrderInvoiceList);
    setOrderInvoiceIsOpen(true);
  };

  const filtredArray = (status) => {
    if (status === "Confirmed") {
      const shaloArray = [...data];
      const filteredData = shaloArray.filter((info) => info.T_status === "C");
      setNewArray(filteredData);
    } else if (status === "Total") {
      const shaloArray = [...data];
      setNewArray(shaloArray);
    } else if (status === "Rejected") {
      const shaloArray = [...data];
      const filteredData = shaloArray.filter((info) => info.T_status === "R");
      setNewArray(filteredData);
    } else if (status === "Pending") {
      const shaloArray = [...data];
      const filteredData = shaloArray.filter((info) => info.T_status === "P");
      setNewArray(filteredData);
    }
  };

  const countFun = (data) => {
    let conf = 0;
    let pend = 0;
    let rejt = 0;

    for (let i = 0; i < data.length; i++) {
      if (data[i].T_status === "C") {
        conf++
      } else if (data[i].T_status === "R") {
        rejt += 1
      } else if (data[i].T_status === "P") {
        pend += 1
      }
    }

    setCountes({
      Total: data.length,
      Confirmed: conf,
      Pending: pend,
      Rejected: rejt
    })
  }

  useEffect(() => {
    setLoading(true)
    const apiCall = async () => {
      const res = await OrderSearchByMail(T_username);
      const { data } = res;
      setData(data);
      setNewArray(data);
      countFun(data)
      setLoading(false)
    };
    apiCall();
    console.log(T_username)
  }, [T_username, search]);

  let { Total, Confirmed, Pending, Rejected } = Countes
  return (
    <main className="main_afterlogin">
      <RB.Col lg={12}>
        <RB.Row className="rownew1 main_listtop">
          <div className="tableHeader tableHeader1 order_btntable">
            <RB.Col lg={4} md={3} className="table_span">
              <h3 className="page-title d-flex userv">
                <span>All Order List</span>
                {/* <RB.Button
                  as={Link}
                  to="/dashboard/viewalldata/followup"
                  size="sm"
                >
                  View All
                </RB.Button> */}
              </h3>
            </RB.Col>
            <RB.Col lg={8} md={9} className="table_span">
              <RB.ButtonToolbar>
                <RB.ButtonGroup className="mr-2">
                  <RB.Button
                    size="sm"
                    variant="primary"
                    onClick={() => filtredArray("Total")}
                  >{`Total - ${Total}`}</RB.Button>
                </RB.ButtonGroup>
                <RB.ButtonGroup className="mr-2">
                  <RB.Button
                    size="sm"
                    variant="primary"
                    onClick={() => filtredArray("Confirmed")}
                  >{`Confirmed - ${Confirmed}`}</RB.Button>
                </RB.ButtonGroup>
                <RB.ButtonGroup className="mr-2">
                  <RB.Button
                    size="sm"
                    variant="primary"
                    onClick={() => filtredArray("Pending")}
                  >{`Pending - ${Pending}`}</RB.Button>
                </RB.ButtonGroup>
                <RB.ButtonGroup className="mr-2">
                  <RB.Button
                    size="sm"
                    variant="primary"
                    onClick={() => filtredArray("Rejected")}
                  >{`Rejected - ${Rejected}`}</RB.Button>
                </RB.ButtonGroup>
                {/* {spanOrder.map((data, inx) => {
                  let { name, count } = data;
                  return (
                    <RB.ButtonGroup className="mr-2" key={"orderspan" + inx}>
                      <RB.Button
                        size="sm"
                        variant="primary"
                        onClick={() => filtredArray(name)}
                      >{`${name} - ${count}`}</RB.Button>
                    </RB.ButtonGroup>
                  );
                })} */}
                <RB.Button
                  size="sm"
                  variant="primary"
                  className="btn_svg"
                >
                  <Link to="/dashboard/searchdata">
                    <IoIosArrowBack />
                    BACK
                  </Link>
                </RB.Button>
              </RB.ButtonToolbar>
            </RB.Col>
          </div>
        </RB.Row>
      </RB.Col>
      <RB.Col lg={12}>
        <div className="box_detail table_boxdtl">
          <RB.Table striped bordered hover variant="dark" responsive>
            <thead>
              <tr>
                <th className="s_not1 text-center">S. No.</th>
                <th>Order Id</th>
                <th>Invoice Id</th>
                <th>Amount (Rs.)</th>
                <th>Username</th>
                <th className="s_notd">Date</th>
                <th>Client Name</th>
                <th>Order Type</th>
                <th>Payment Status</th>
                <th>Status</th>
                <th className="s_not text-center">Action</th>
              </tr>
            </thead>
            <tbody>
              {Loading ? <tr><td className="no_records" colSpan="11">Loading...</td></tr> : NewArray.length > 0 ? NewArray.map((info, inx) => {
                return (
                  <tr key={"order_btn" + inx}>
                    <td className="s_not1 text-center">{inx + 1}</td>
                    <td>{info.T_orderid}</td>
                    <td>{info.f_invoiceID}</td>
                    <td>{info.f_orderAmt}</td>
                    <td className="company_emmailta">{info.T_username}</td>
                    {/* <td>{info.T_orderdate.slice(0, 10)}</td> */}
                    <td className="s_notd">{Moment(info.T_orderdate).format("DD-MM-YYYY")}</td>
                    <td className="company_emmailta">{info.t_client}</td>
                    <td>{info.f_orderType === 'NPlan' ? 'IB' : "IVS"}</td>
                    <td>{info.t_paymentstatus}</td>
                    <td>{info.T_status}</td>
                    <td className="td_comments text-center">
                      <AiOutlineFileSearch title="Order Details"
                        onClick={() => OrderDetailsClick(info.T_orderid)}
                      />
                      {/* {info.T_status === "C" ? (
                        <BiCommentDetail title="Invoice Details"
                          onClick={() => OrderInvoiceClick(info.T_orderid)}
                        />
                      ) : (
                        ""
                      )} */}

                      {info.T_status === "C" ? (
                        <BiCommentDetail title="Invoice Details"
                          onClick={() => OrderInvoiceClick(info.T_orderid)}
                        />
                      ) : (
                        ""
                      )}
                    </td>
                  </tr>
                );
              }) : <tr><td className="no_records" colSpan="11">No Records Found</td></tr>}
            </tbody>
          </RB.Table>
        </div>
      </RB.Col>

      <OrderDetailsModel
        OrderDetailsIsOpen={OrderDetailsIsOpen}
        CloseOrderDetails={CloseOrderDetails}
        OrderDataObj={OrderDataObj}
        OrderDataList={OrderDataList}
        OrderUser={OrderUser}
      />

      <OrderInvoiceModel
        OrderInvoiceIsOpen={OrderInvoiceIsOpen}
        CloseOrderInvoice={CloseOrderInvoice}
        OrderInvoiceObj={OrderInvoiceObj}
        OrderInvoiceList={OrderInvoiceList}
        OrderUser={OrderDataObj}
      />

    </main>
  );
};

export default UserButtonSearch;
