import React, { useState, useEffect } from "react";
import {
  trakin_details,
  WAYPRESSchangeStatusApi,
  getWAYXPRESSshipments,
} from "./Utils/api";

const CronjobWAYXPRESS = () => {
  const [Loading, setLoading] = useState(true);

  const changeStatusFORwayxpress = async (element) => {
    await WAYPRESSchangeStatusApi(element);
  };

  const wayxpress = async () => {
    const res = await getWAYXPRESSshipments();
    let { trakingDetails } = res;
    console.log(trakingDetails);
    trakingDetails.forEach(async (element, inx) => {
      let { tracking_number, shipping_method } = element;
      const trakData = await trakin_details(tracking_number, shipping_method);
      let { statuses, error } = trakData;
      console.log(inx, tracking_number, statuses);
      if (!error && statuses) {
        statuses.forEach(async (element) => {
          if (element !== undefined) {
            await changeStatusFORwayxpress(element);
          }
        });
      }
    });
    setLoading(false);
  };

  useEffect(() => {
    wayxpress();
  }, []);

  return (
    <div>
      <h2>Waypress Script is running.....</h2>
      <p>{Loading ? "Loading..." : "Done"}</p>
    </div>
  );
};

export default CronjobWAYXPRESS;
