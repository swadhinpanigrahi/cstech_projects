import React, { useState, useEffect } from 'react';
import * as RB from 'react-bootstrap';
import { MdAddCircleOutline } from 'react-icons/md';
import { RiDeleteBin6Line } from "react-icons/ri";
import { BiCommentEdit } from "react-icons/bi";
import AddCompanyDetail from "../../../Components/Models/MasterModals/AddCompanyDetail"
import EditCompany from "../../../Components/Models/MasterModals/MasterEdit/EditCompany"

import PaginationComponent from "../../../Components/Common/PaginationComponent";

import Modal from "../../../Components/Common/Modal";


import {
    GET_COMPANYIST, GET_COMPANYDETAIL, REMOVE_COMPANYDETAIL
} from "../../../Utils/api";

const CompanyList = () => {
    const [currentPage, setCurrentPage] = useState(1);
    const [itemPerPage, setItemPerPage] = useState(20);
    let [searchData, setSearchData] = useState("");

    const [EditModalShow, setEditShowModal] = useState(false)
    const [AddModalShow, setAddModalShow] = useState(false)

    const [CompanyList, setCompanyList] = useState([]);
    const [CompanyDetail, setCompanyDetail] = useState({});
    const [Loading, setLoading] = useState(false)

    const [TotalCount, setTotalCount] = useState(0);

    const [isOpen, setIsOpen] = useState(false);
    const [ModelMsg, setModelMsg] = useState("");

    const modelSet = async () => {
        setIsOpen(true);
    };

    const SearchDataFun = async (e) => {
        setSearchData(e.target.value)
        const res = await GET_COMPANYIST(currentPage, itemPerPage, (searchData = e.target.value));
        let { data, totalrecord } = res;
        setCompanyList(data);
        totalrecord.length === 1
            ? setTotalCount(totalrecord[0].totalcount)
            : setTotalCount(0);
    }

    const editCompanyShow = async (id) => {
        const res = await GET_COMPANYDETAIL(id);
        let { companyData } = res;
        setCompanyDetail(companyData)
        setEditShowModal(true)
    }

    const deleteCompany = async (id) => {
        const res = await REMOVE_COMPANYDETAIL(id);
        let { message } = res;
        apiCall();
        setModelMsg(message);
        modelSet();
    }

    const apiCall = async () => {
        setLoading(true)
        const res = await GET_COMPANYIST(currentPage, itemPerPage, searchData);
        let { data, totalrecord } = res;
        setCompanyList(data);
        setTotalCount(totalrecord[0].totalcount)
        setLoading(false)
    }

    useEffect(() => {
        apiCall()
    }, [currentPage, itemPerPage]);

    return (
        <RB.Row className="rownew1">
            <RB.Col lg={12}>
                <RB.Row className="rownew1" style={{ paddingTop: "25px" }}>
                    <div className="tableHeader tableHeader1 order_btntable">
                        <RB.Col md={6} xs={12} className="table_span">
                            <h3 className="page-title d-flex userv">
                                <span>Search Results</span>
                            </h3>
                        </RB.Col>
                        <RB.Col md={6} xs={12} className="table_span">
                            <div className="float-right responsive_floatbtn">
                                <RB.Button size="sm" variant="primary" className="btn_svg"
                                    onClick={() => setAddModalShow(true)}
                                >
                                    <MdAddCircleOutline style={{ marginRight: "3px" }} />
                                    ADD COUNTRY
                                </RB.Button>
                            </div>
                        </RB.Col>
                    </div>
                </RB.Row>
            </RB.Col>

            <RB.Col lg={12}>
                <div className="box_detail" style={{ borderRadius: "4px" }}>
                    <div className="page-header row">
                        <RB.Col md={12}>
                            <RB.Form className="manage_searchorder">
                                <RB.Row className="mg_row0">
                                    <RB.Col lg={12} md={12} className="customer_leftsrh">
                                        <RB.Row className="mg_row0">
                                            <RB.Col lg={3} md={3} className="customer_sdate">
                                                <RB.Form.Group>
                                                    <RB.Form.Control
                                                        id="searchText"
                                                        type="text"
                                                        placeholder="Search by Text"
                                                        onChange={SearchDataFun}
                                                    />
                                                </RB.Form.Group>
                                            </RB.Col>
                                        </RB.Row>
                                    </RB.Col>

                                </RB.Row>
                            </RB.Form>
                        </RB.Col>
                    </div>
                </div>
            </RB.Col>

            <RB.Col lg={12}>
                <RB.Row className="rownew1">
                    <div className="tableHeader tableHeader1 search_new">
                        <RB.Col lg={6} md={6} className="table_span">
                            <h3 className="page-title d-flex userv">
                                <span>Company List</span>
                            </h3>
                        </RB.Col>
                        <RB.Col lg={6} md={6} className="table_span total_recordt">
                            <span>Total Records: {TotalCount}</span>
                        </RB.Col>
                    </div>
                </RB.Row>
                <div
                    className="box_detail table_boxdtl manage_order"
                    style={{}}
                >
                    <RB.Table striped bordered hover variant="dark" responsive>
                        <thead>
                            <tr class="vtable">
                                <th className="text-center">S. No.</th>
                                <th className="text-center">F. No.</th>
                                <th className="" >Company Name</th>
                                <th className="" >Similar Company Name</th>
                                <th className="" >Company Group</th>
                                <th className="" >Discount(%)</th>
                                <th className="" >State</th>
                                <th className="text-center action_align">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            {Loading ? <tr><td className="no_records" colSpan="11">Loading...</td></tr> : CompanyList.length > 0 ? CompanyList.map((info, inx) => {
                                let { f_sno, f_companyname, f_companygroup, f_similarcompanyname, f_discount, f_city } = info;
                                return (
                                    <tr key={`COUNTRYLIST_${inx}`}>
                                        {/* <td className="s_notm text-center">{f_countryid}</td> */}
                                        <td className="s_notm text-center">{inx + 1}</td>
                                        <td className="">{f_sno}</td>
                                        <td className="">{f_companyname}</td>
                                        <td className="">{f_similarcompanyname}</td>
                                        <td className="">{f_companygroup}</td>
                                        <td className="">{f_discount}</td>
                                        <td className="">{f_city}</td>
                                        <td className="td_comments text-center">
                                            <BiCommentEdit title="Edit Country" onClick={() => editCompanyShow(info._id)} />
                                            <RiDeleteBin6Line title="Delete Country" className="text-danger1" onClick={() => { deleteCompany(info._id) }} />
                                        </td>
                                    </tr>
                                )
                            }) : <tr><td className="no_records" colSpan="11">No Records Found</td></tr>}
                        </tbody>
                    </RB.Table>
                </div>

                <PaginationComponent
                    MOCK_DATA={TotalCount}
                    currentPage={currentPage}
                    setCurrentPage={setCurrentPage}
                    itemPerPage={itemPerPage}
                    setItemPerPage={setItemPerPage}
                />

                <AddCompanyDetail
                    AddModalShow={AddModalShow}
                    setAddModalShow={setAddModalShow}
                    apiCall={apiCall}
                />

                <EditCompany
                    EditModalShow={EditModalShow}
                    setEditShowModal={setEditShowModal}
                    CompanyDetail={CompanyDetail}
                    apiCall={apiCall}
                />

                <Modal text={ModelMsg} open={isOpen} onClose={() => setIsOpen(false)} />

            </RB.Col>
        </RB.Row>
    )
}

export default CompanyList
