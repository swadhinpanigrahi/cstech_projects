const { M_IMAGEVIDEO } = require("../../model");


exports.addImageVideoDetail = async (req, res) => { //work
    const {
        f_planname, f_maxallowed, f_periodindays, f_totimg, f_amount, f_imageType,
        f_save, f_desc, f_upgradamt, f_couponAmt
    } = req.body;
    try {
        const existingData = await M_IMAGEVIDEO.findOne({ f_planname });
        if (existingData) {
            res.json({ status: 400, message: "already exist" })
        }
        if (!existingData) {
            const Data = await new M_IMAGEVIDEO({
                f_planname, f_maxallowed, f_periodindays, f_totimg, f_amount, f_imageType,
                f_save, f_desc, f_upgradamt, f_couponAmt
            }).save();
            if (Data) {
                res.json({ status: 200, message: "added successfully" })
            }
        }
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

exports.getImageVideoList = async (req, res) => {
    const { currentPage, itemPerPage, searchData } = req.query;
    const num = parseInt(itemPerPage)
    const start = parseInt(currentPage);
    let pipeline;
    let countline;
    try {
        if (!searchData || searchData === "") {
            pipeline = [
                { $sort: { _id: -1 } },
                { $skip: (start - 1) * num },
                { $limit: num },
            ]
            countline = [
                { $count: "totalcount" }
            ]
        } else {
            pipeline = [
                { $match: { f_planname: { $regex: searchData, $options: "im" } } },
                { $sort: { _id: -1 } },
                { $skip: (start - 1) * num },
                { $limit: num },
            ]
            countline = [
                { $match: { f_planname: { $regex: searchData, $options: "im" } } },
                { $count: "totalcount" }
            ]
        }
        const data = await M_IMAGEVIDEO.aggregate(pipeline)
        const totalrecord = await M_IMAGEVIDEO.aggregate(countline)
        res.json({ status: 200, data, totalrecord })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

exports.getImageVideoDetail = async (req, res) => {
    const { _id } = req.params;
    try {
        const data = await M_IMAGEVIDEO.findOne({ _id })
        res.json({ status: 200, data })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

exports.editImageVideoDetail = async (req, res) => {
    const {
        _id, f_planname, f_maxallowed, f_periodindays, f_totimg, f_amount, f_imageType,
        f_save, f_desc, f_upgradamt, f_couponAmt
    } = req.body;
    try {
        const data = await M_IMAGEVIDEO.findOne({ _id });
        if (data) {
            await M_IMAGEVIDEO.findByIdAndUpdate({ _id }, {
                $set: {
                    f_planname, f_maxallowed, f_periodindays, f_totimg, f_amount, f_imageType,
                    f_save, f_desc, f_upgradamt, f_couponAmt
                }
            })
        }
        res.json({ status: 200, message: "Image/Video subscription updated successfully" })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

exports.deleteImageVideoDetail = async (req, res) => {
    const { _id } = req.params;
    try {
        await M_IMAGEVIDEO.findByIdAndRemove({ _id })
        res.json({ status: 200, message: "Image/Video subscription removed successfully!!" })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}