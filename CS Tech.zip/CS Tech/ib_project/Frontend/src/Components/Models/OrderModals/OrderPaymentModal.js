import React from 'react';
import * as RB from "react-bootstrap";
import { Row } from "react-bootstrap";

const OrderPaymentModal = (
    { show, handleClose, paymentUsername, paymentPrice, payemntLink, onChangePayment, T_orderid, paymentEmailFun }
) => {
    return (
        <RB.Modal show={show} onHide={handleClose} className="ordermanage_modal">
            <RB.Modal.Header closeButton>
                <RB.Modal.Title>Create Payment Link</RB.Modal.Title>
            </RB.Modal.Header>
            <RB.Modal.Body>
                <RB.Row>
                    <RB.Col lg={12} md={12}>
                        <RB.Row>
                            <RB.Col lg={12} md={12}>
                                <h4 className="payment_link">Create A Payment Link For Order Id: {T_orderid}</h4>
                            </RB.Col>
                            <RB.Col lg={12} md={12}>
                                <RB.Form>
                                    <RB.Form.Group as={Row} controlId="formbasicemailo">
                                        <RB.Col lg={4} md={4}>
                                            <RB.Form.Label>Email Address :</RB.Form.Label>
                                        </RB.Col>
                                        <RB.Col lg={6} md={7}>
                                            <RB.Form.Control type="text" value={paymentUsername} />
                                        </RB.Col>
                                    </RB.Form.Group>
                                    <RB.Form.Group as={Row} controlId="formbasicamount">
                                        <RB.Col lg={4} md={4}>
                                            <RB.Form.Label>Amount :</RB.Form.Label>
                                        </RB.Col>
                                        <RB.Col lg={6} md={7}>
                                            <RB.Form.Control type="text" value={paymentPrice} disabled />
                                        </RB.Col>
                                    </RB.Form.Group>
                                    <RB.Form.Group as={Row} controlId="formbasicselect">
                                        <RB.Col lg={4} md={4}>
                                            <RB.Form.Label>Payment Mode :</RB.Form.Label>
                                        </RB.Col>
                                        <RB.Col lg={6} md={7}>
                                            <RB.Form.Control as="select" onChange={(e) => onChangePayment(e.target.value)} name="paymentMode" >
                                                <option value="">Select</option>
                                                <option value="Mobikwik">MobiKwik</option>
                                                <option value="HDFC">HDFC</option>
                                                <option value="American Express">American Express</option>
                                            </RB.Form.Control>
                                        </RB.Col>
                                    </RB.Form.Group>
                                    <RB.Form.Group as={Row} controlId="formbasiclink">
                                        <RB.Col lg={4} md={4}>
                                            <RB.Form.Label>Link :</RB.Form.Label>
                                        </RB.Col>
                                        <RB.Col lg={6} md={7}>
                                            <RB.Form.Control type="text" value={payemntLink} placeholder='Payment Link' disabled />
                                        </RB.Col>
                                    </RB.Form.Group>
                                    <RB.Row>
                                        <RB.Col lg={4} md={4}></RB.Col>
                                        <RB.Col lg={6} md={7}>
                                        <RB.Button size="sm" variant="primary" onClick={paymentEmailFun}>SUBMIT</RB.Button>
                                        </RB.Col>
                                    </RB.Row>
                                </RB.Form>
                            </RB.Col>
                        </RB.Row>
                    </RB.Col>
                </RB.Row>
            </RB.Modal.Body>
        </RB.Modal>
    )
}

export default OrderPaymentModal;
