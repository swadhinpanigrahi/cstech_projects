import React, { useState, useEffect } from 'react';
import * as RB from "react-bootstrap";
import { Row } from "react-bootstrap";

import { UPDATE_COMPANYDETAIL } from "../../../../Utils/api"

const EditCompany = ({ EditModalShow, setEditShowModal, CompanyDetail, apiCall }) => {
    const [FormData, setFormData] = useState({});

    const handleChange = (e) => {
        let { name, value } = e.target;
        const data = { ...FormData };
        data[name] = value
        setFormData(data)
    }
    const closeModal = () => {
        setEditShowModal(false)
    }

    const editCompany = async () => {
        const res = await UPDATE_COMPANYDETAIL(FormData);
        let { message } = res;
        if (message) {
            apiCall();
            closeModal()
        }
        console.log(FormData)
    }
    useEffect(() => {
        setFormData(CompanyDetail)
    }, [CompanyDetail])
    return (
        <div>
            <RB.Modal show={EditModalShow} onHide={closeModal} className="ordermanage_modal">
                <RB.Modal.Header closeButton>
                    <RB.Modal.Title>Add New Country</RB.Modal.Title>
                </RB.Modal.Header>
                <RB.Modal.Body>
                    <RB.Row>
                        <RB.Col lg={12} md={12}>
                            <RB.Row>
                                <RB.Col lg={12} md={12}>
                                    <RB.Form>
                                        <RB.Form.Group as={Row} controlId="Country_id">
                                            <RB.Col lg={4} md={4}>
                                                <RB.Form.Label>Company Name :</RB.Form.Label>
                                            </RB.Col>
                                            <RB.Col lg={7} md={8}>
                                                <RB.Form.Control
                                                    type="text"
                                                    name="f_companyname"
                                                    value={FormData.f_companyname}
                                                    onChange={handleChange}
                                                />
                                            </RB.Col>
                                        </RB.Form.Group>
                                        <RB.Form.Group as={Row} controlId="Country_id">
                                            <RB.Col lg={4} md={4}>
                                                <RB.Form.Label>Similar Company Name :</RB.Form.Label>
                                            </RB.Col>
                                            <RB.Col lg={7} md={8}>
                                                <RB.Form.Control
                                                    type="text"
                                                    name="f_similarcompanyname"
                                                    value={FormData.f_similarcompanyname}
                                                    onChange={handleChange}
                                                />
                                            </RB.Col>
                                        </RB.Form.Group>
                                        <RB.Form.Group as={Row} controlId="Country_id">
                                            <RB.Col lg={4} md={4}>
                                                <RB.Form.Label>Company Group :</RB.Form.Label>
                                            </RB.Col>
                                            <RB.Col lg={7} md={8}>
                                                <RB.Form.Control
                                                    type="text"
                                                    name="f_companygroup"
                                                    value={FormData.f_companygroup}
                                                    onChange={handleChange}
                                                />
                                            </RB.Col>
                                        </RB.Form.Group>
                                        <RB.Form.Group as={Row} controlId="Country_id">
                                            <RB.Col lg={4} md={4}>
                                                <RB.Form.Label>Discount(%) :</RB.Form.Label>
                                            </RB.Col>
                                            <RB.Col lg={7} md={8}>
                                                <RB.Form.Control
                                                    type="text"
                                                    name="f_discount"
                                                    value={FormData.f_discount}
                                                    onChange={handleChange}
                                                />
                                            </RB.Col>
                                        </RB.Form.Group>
                                        <RB.Form.Group as={Row} controlId="Country_id">
                                            <RB.Col lg={4} md={4}>
                                                <RB.Form.Label>State :</RB.Form.Label>
                                            </RB.Col>
                                            <RB.Col lg={7} md={8}>
                                                <RB.Form.Control
                                                    type="text"
                                                    name="f_city"
                                                    value={FormData.f_city}
                                                    onChange={handleChange}
                                                />
                                            </RB.Col>
                                        </RB.Form.Group>
                                        <RB.Row>
                                            <RB.Col lg={4} md={4}></RB.Col>
                                            <RB.Col lg={6} md={7}>
                                                <RB.Button
                                                    size="sm" variant="primary"
                                                    onClick={editCompany}
                                                >
                                                    ADD
                                                </RB.Button>
                                            </RB.Col>
                                        </RB.Row>
                                    </RB.Form>
                                </RB.Col>
                            </RB.Row>
                        </RB.Col>
                    </RB.Row>
                </RB.Modal.Body>
            </RB.Modal>
        </div>
    )
}

export default EditCompany
