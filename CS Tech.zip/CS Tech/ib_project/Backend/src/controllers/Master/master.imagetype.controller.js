const { M_IMAGETYPE } = require("../../model");

exports.addImageTypeDetail = async (req, res) => { //work
    const { f_pricetypename } = req.body
    try {
        const existingData = await M_IMAGETYPE.findOne({ f_pricetypename });
        if (existingData) {
            res.json({ status: 400, message: "already exist" })
        }
        if (!existingData) {
            const Data = await new M_IMAGETYPE({
                f_pricetypename
            }).save();
            if (Data) {
                res.json({ status: 200, message: "added successfully" })
            }
        }
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

exports.getImageTypeList = async (req, res) => {
    const { currentPage, itemPerPage, searchData } = req.query;
    const num = parseInt(itemPerPage)
    const start = parseInt(currentPage);
    let pipeline;
    let countline;
    try {
        if (!searchData || searchData === "") {
            pipeline = [
                { $sort: { _id: -1 } },
                { $skip: (start - 1) * num },
                { $limit: num }
            ]
            countline = [
                { $count: "totalcount" }
            ]
        } else {
            pipeline = [
                { $match: { f_pricetypename: { $regex: searchData, $options: "im" } } },
                { $sort: { _id: -1 } },
                { $skip: (start - 1) * num },
                { $limit: num }
            ]
            countline = [
                { $match: { f_pricetypename: { $regex: searchData, $options: "im" } } },
                { $count: "totalcount" }
            ]
        }
        const data = await M_IMAGETYPE.aggregate(pipeline)
        const totalrecord = await M_IMAGETYPE.aggregate(countline)
        res.json({ status: 200, data, totalrecord })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

exports.getImageTypeDetail = async (req, res) => {
    const { _id } = req.params;
    try {
        const data = await M_IMAGETYPE.findOne({ _id })
        res.json({ status: 200, data })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

exports.editImageTypeDetail = async (req, res) => {
    const { _id, f_pricetypename } = req.body;
    try {
        const data = await M_IMAGETYPE.findById({ _id });
        console.log(data, req.body)
        if (data) {
            await M_IMAGETYPE.findByIdAndUpdate({ _id }, { $set: { f_pricetypename } })
        }
        res.json({ status: 200, message: "ImageType updated successfully" })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

exports.deleteImageTypeDetail = async (req, res) => {
    const { _id } = req.params;
    try {
        await M_IMAGETYPE.findByIdAndRemove({ _id })
        res.json({ status: 200, message: "ImageType removed successfully!!" })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}
