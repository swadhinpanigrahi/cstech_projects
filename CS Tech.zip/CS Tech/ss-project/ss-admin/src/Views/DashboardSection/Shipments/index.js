import React from 'react'
import { Route } from 'react-router'

import Shipments from "./Shipments"
import ShipmentTraking from './ShipmentTraking'
// import ShipmentView from './ShipmentView'

const ShipmentDash = () => {
    return (
        <>
            <main className="pd-b-25">
                <Route path="/dashboard/shipments/get" component={Shipments} />
                <Route path="/dashboard/shipments/track/:tracking_number" component={ShipmentTraking} />
                {/* <Route path="/dashboard/shipments/view/:tracking_number" component={ShipmentView} /> */}
            </main>
        </>
    )
}

export default ShipmentDash
