const mongoose = require("mongoose");

const MasterStateSchema = mongoose.Schema(
    {
        f_stateid: { type: String },
        f_state: { type: String },
        f_status: { type: Boolean },
        f_creationdate: { type: Date },
        f_countryid: { type: String }

    },
    { collection: "t_state" }
);

module.exports = M_STATE = mongoose.model(
    "t_state",
    MasterStateSchema
);