import React, { useState, useEffect } from "react";
import { useHistory, Link } from "react-router-dom";
import {
  Button,
  Row,
  Col,
} from "react-bootstrap";
import { IoIosArrowBack } from "react-icons/io";
import { RiDeleteBin6Line } from "react-icons/ri"
import '../../Stylesheet/css/editProf.css'
import {
  getCountryList, getStateList, fetchCompanyDataByKeyPress,
  SubMitFollowUpRecord, fetchEmailByKeyPress
} from "../../Utils/api";
import {
  IB_FORM, STAR_FORM, PACKES_FORM, SPECIAL_FORM, OTHER_FORM
} from "./FormComponents";

const array = [
  { type: "checkbox", name: "IB" },
  { type: "checkbox", name: "Star Collection" },
  { type: "checkbox", name: "Packs" },
  { type: "checkbox", name: "Special Package" },
  { type: "checkbox", name: "Others" },
];

const CreateFollowups = () => {
  const history = useHistory();
  const [countryList, setCountryList] = useState([]);
  const [stateList, setStateList] = useState([]);
  const [usrInfo, setUserInfo] = useState({});
  const [boxInfo, setboxInfo] = useState({})
  const [isTrue, setisTrue] = useState(false);
  const [isTrueEmail, setisTrueEmail] = useState(false);
  const [CompanyInfo, setCompanyInfo] = useState([]);
  const [EmailInfo, setEmailInfo] = useState([]);
  const [email, setEmail] = useState("");

  const [AdditionalDetails, setAdditionalDetails] = useState({})
  const [AdditionalList, setAdditionalList] = useState([])

  const [errMsg, setErrMsg] = useState("");

  const onInputChange1 = (e) => {
    let { name, type, value } = e.target;
    if (type === "date") {
      setboxInfo({ ...usrInfo, followupDate: new Date(value) })
    } else {
      const data = { ...usrInfo }
      data[name] = value;
      setboxInfo(data)
    }
  };

  const [checkData, setCheckData] = useState([
    {
      name: "IB",
      checked: false,
      Form: <IB_FORM onInputChange={onInputChange1} />
    },
    {
      name: "Star Collection",
      checked: false,
      Form: <STAR_FORM onInputChange={onInputChange1} />,
    },
    {
      name: "Packs",
      checked: false,
      Form: <PACKES_FORM onInputChange={onInputChange1} />
    },
    {
      name: "Special Package",
      checked: false,
      Form: <SPECIAL_FORM onInputChange={onInputChange1} />
    },
    {
      name: "Others",
      checked: false,
      Form: <OTHER_FORM onInputChange={onInputChange1} />
    },
  ]);

  const handleFormVisibility = (forms, name, checked) => {
    return forms.map((data) => {
      let formName = data.name; // Prestored form data
      //   name --> this is coming from user input
      if (formName === name) {
        data["checked"] = checked;
      }
      return data;
    });
  };

  const additionalhandlechange = (e) => {
    let { name, value } = e.target;
    const data = { ...AdditionalDetails };
    data[name] = value;
    setAdditionalDetails(data);
  }

  const AddInfoSubmit = () => {
    const shaloArray = [...AdditionalList];
    shaloArray.push(AdditionalDetails)
    setAdditionalList(shaloArray);
    setAdditionalDetails({})
  }

  const AddInfoRemove = (add_email) => {
    const filteredData = AdditionalList.filter((data) => data.add_email !== add_email);
    setAdditionalList(filteredData);
  }

  const handleChange = (event) => {
    let { name, checked } = event.target;
    let checkedData = checkData.filter((data) => data.checked); // if(data.checked){return data;}
    let updateData = [...checkData];
    setErrMsg("");

    if (checkedData.length < 2) {
      updateData = handleFormVisibility(checkData, name, checked);
    } else {
      setErrMsg("Only two fields can be checked");
    }
    if (!checked) {
      updateData = handleFormVisibility(checkData, name, checked);
    }
    setCheckData([...updateData]);
  };

  const onCountryChange = async (e) => {
    const state = await getStateList(101);
    const stateList = state.res.data.stateList
    setStateList(stateList);
  };

  const onCompanySelect = async (id) => {
    const compInfo = CompanyInfo.filter(i => i._id === id)[0];
    setisTrue(false)
    setUserInfo(
      {
        ...usrInfo,
        "CS_companynames": compInfo.f_companyname,
        "group_cmpname": compInfo.f_companygroup,
        "sortcmp_name": compInfo.f_similarcompanyname
      }
    );
  }

  const onEmailSelect = async (id) => {
    const emInfo = EmailInfo.filter(i => i._id === id)[0];
    setisTrueEmail(false)
    console.log(emInfo);
    setEmail(emInfo.cs_ccmail)
    setUserInfo(
      {
        ...usrInfo,
        "cs_ccmail": emInfo.cs_ccmail,
        "CS_firstname": emInfo.CS_firstname,
        "CS_lastname": emInfo.CS_lastname,
        "CS_mobile": emInfo.CS_mobile,
        "CS_phone": emInfo.CS_phone,
        "CS_pin": emInfo.CS_pin,
        "CS_companynames": emInfo.CS_companynames,
        "group_cmpname": emInfo.group_cmpname,
        "sortcmp_name": emInfo.sortcmp_name
      }
    );
  }

  const onInputChange = (e) => {
    let { name, value } = e.target;
    const data = { ...usrInfo }
    data[name] = value;
    setUserInfo(data)
  };

  const onInputChangeCompany = async (e) => {
    var compName = e.target.value
    // setCompanyData(compName)
    if (compName !== "" && compName.length >= 1) {
      const companyDate = await fetchCompanyDataByKeyPress(compName);
      setCompanyInfo(companyDate.res.data.companyData)
      setisTrue(true)
    }
  }

  const onInputChangeEmail = async (e) => {
    var emailId = e.target.value
    setEmail(emailId)
    if (emailId !== "" && emailId.length >= 1) {
      const emailData = await fetchEmailByKeyPress(emailId);
      var emailFounds = emailData.res.data.EmailData
      setEmailInfo(emailFounds)
      setisTrueEmail(true)
    } else {
      setisTrueEmail(false)
    }
  }

  const onSubmit = async (e) => {
    e.preventDefault();
    console.log({ ...usrInfo, ...boxInfo, AdditionalList })
    let {
      CS_firstname, CS_mobile, followUpType1, followUpDescriptionType, followupOrderID,
      followupDate, followupDescription
    } = usrInfo;
    if (!CS_firstname) {
      alert("name is required!!")
    } else if (!email) {
      alert("email is required!!")
    } else if (!CS_mobile) {
      alert("number is required!!")
    } else {
      const filteredData = checkData.filter((data) => data.checked === true);
      if (filteredData.length > 0) {
        if (!followUpType1) {
          alert("Requirement Followups is required!!")
        } else if (!followUpDescriptionType) {
          alert("Description Type is required!!")
        } else if (!followupOrderID) {
          alert("Order ID is required!!")
        } else if (!followupDate) {
          alert("Followups Date is required!!")
        } else if (!followupDescription) {
          alert("Description is required!!")
        } else {
          console.log({ ...usrInfo, f_RequirementType: filteredData[0].name })
          const data1 = await SubMitFollowUpRecord({
            ...usrInfo,
            ...boxInfo,
            f_RequirementType: filteredData[0].name, AdditionalList
          });
          console.log("data1", data1)
          alert('follow up created successfully..')
          history.push("/dashboard/dailysalesentry")
        }
      } else {
        alert("please select checkbox froms!!")
      }
    }
  };


  useEffect(() => {
    const apiCall = async () => {
      const res = await getCountryList();
      const contr = res.res.data.CountryList
      setCountryList(contr);
      onCountryChange(101)
    };
    apiCall();
  }, []);

  return (

    <Row className="rownew1" style={{ paddingTop: "30px" }}>
      <Col lg={12}>
        <Row className="add_button">
          <div className="tableHeader tableHeader1">
            <Col md={6} xs={5} className="table_span">
              <h3 className="page-title">Add User</h3>
            </Col>
            <Col md={6} xs={7} className="table_span back_btn">
              <Button
                size="sm"
                variant="primary"
                className="btn_svg"
              >
                <Link to="/dashboard/searchdata">
                  <IoIosArrowBack />BACK
                </Link>
              </Button>
            </Col>
          </div>
        </Row>
      </Col>

      <div class="col-md-12">
        <div class="box_detail" style={{ paddingLeft: "0px", paddingRight: "0px", paddingTop: "0px", borderRadius: "4px" }}>
          <div class="page-header row no-gutters inside_header">
            <div class="col-md-12">
              <h3 class="page-title" style={{ color: "#000", marginBottom: "0px", paddingBottom: "0px", fontSize: "1.5rem" }}>Basic Information</h3>
            </div>
          </div>
          <hr class="m-t-25 m-b-25" />
          <div class="form-body createf_settings">

            <div class="row">
              <div class="col-md-6 pr-50">
                <div class="form-group">
                  <label class="control-label">User Type</label>
                  <div class="">
                    <table id="rbt_todaysdeal" class="input" border="0" style={{ width: "150px", marginTop: "7px" }}>
                      <tbody>
                        <tr>
                          <td>
                            <input type="radio" name="userType" id="userType" value="New" tabindex="4" onChange={(e) => onInputChange(e)} />
                            <label for="userType" class="pd-l-5 labelin">New</label>
                          </td>
                          <td>
                            <input type="radio" name="userType" id=
                              'userType1' value="Exksting" tabindex="4" onChange={(e) => onInputChange(e)} />
                            <label for="userType1" class="pd-l-5 labelin">Existing</label>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>

            <div class="row">
              <div class="col-md-6  pr-50">
                <div class="form-group">
                  <label class="control-label">Email Id : <span style={{ color: "red" }}>*</span> </label>
                  <div class="">
                    <input class="form-control" type="email" placeholder="Enter email address" name="cs_ccmail" id="cs_ccmail" value={usrInfo.cs_ccmail} onChange={(e) => onInputChangeEmail(e)} autoComplete="off" />
                    {isTrueEmail === true ? <div class="auto_searchdata">
                      {EmailInfo.slice(0, 20).map((data, inx) => {
                        return (
                          <p style={{ cursor: "pointer" }} onClick={(e) => onEmailSelect(data._id)} >{data.cs_ccmail}</p>
                        );
                      })}
                    </div> : ""}
                  </div>
                </div>
              </div>
              <div class="col-md-6 pl-50">
                <div class="form-group">
                  <label class="control-label">First Name : <span style={{ color: "red" }}>*</span> </label>
                  <div class="">
                    <input class="form-control" type="text" placeholder="Enter first name" name="CS_firstname" id="CS_firstname" value={usrInfo.CS_firstname} onChange={(e) => onInputChange(e)} />
                  </div>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-6 pr-50">
                <div class="form-group">
                  <label class="control-label">Last Name : <span style={{ color: "red" }}>*</span> </label>
                  <div class="">
                    <input class="form-control" type="text" value={usrInfo.CS_lastname} placeholder="Enter last name" name="lastName" id="lastName" onChange={(e) => onInputChange(e)} />


                  </div>
                </div>
              </div>
              <div class="col-md-6 pl-50">
                <div class="form-group">
                  <label class="control-label">Alternative Email Id :</label>
                  <div class="">
                    <input class="form-control" type="text" placeholder="Enter alternative email address" name="f_AlternateEmail" id="f_AlternateEmail" value={usrInfo.f_AlternateEmail} onChange={(e) => onInputChange(e)} />
                  </div>
                </div>
              </div>

            </div>
            <div className="row">
              <div class="col-md-6 pr-50">
                <div class="form-group select_shortcom">
                  <label class="control-label">Search Short Company : </label>
                  <div class="">
                    <input class="form-control" type="text" placeholder="Search short company" name="CS_companynames" id="CS_companynames" autoComplete="off" value={usrInfo.CS_companynames} onChange={(e) => onInputChangeCompany(e)} />
                    {isTrue === true ? <div class="auto_searchdata">
                      {CompanyInfo.slice(0, 20).map((data, inx) => {
                        return (
                          <p style={{ cursor: "pointer" }} onClick={(e) => onCompanySelect(data._id)} >{data.f_companyname}</p>
                        );
                      })}
                    </div> : ""}


                  </div>
                </div>
              </div>
              <div class="col-md-6 pl-50">
                <div class="form-group">
                  <label class="control-label">Company Name : <span style={{ color: "red" }}>*</span> </label>
                  <div class="">
                    <input class="form-control" type="text"
                      placeholder="Enter company name"
                      name="CS_businesstype" id="CS_businesstype"
                      value={usrInfo.CS_companynames}
                      onChange={(e) => onInputChange(e)} />
                  </div>
                </div>
              </div>
            </div>

            <div class="row">
              <div class="col-md-6 pr-50">
                <div class="form-group">
                  <label class="control-label">Short Company Name : <span style={{ color: "red" }}>*</span> </label>
                  <div class="">
                    <input class="form-control" type="text" placeholder="Enter short name" name="sortcmp_name" id="sortcmp_name" value={usrInfo.sortcmp_name} onChange={(e) => onInputChange(e)} />
                  </div>
                </div>
              </div>
              <div class="col-md-6 pl-50">
                <div class="form-group">
                  <label class="control-label">Group Name :</label>
                  <div class="">
                    <input class="form-control" type="text" placeholder="Enter group name" name="group_cmpname" id="group_cmpname" value={usrInfo.group_cmpname} onChange={(e) => onInputChange(e)} />
                  </div>
                </div>
              </div>
            </div>

            <div class="row">
              <div class="col-md-6 pr-50">
                <div class="form-group">
                  <label class="control-label">Mobile Number : <span style={{ color: "red" }}>*</span> </label>
                  <div class="">
                    <input class="form-control" type="number" placeholder="Enter mobile number" name="CS_mobile" id="CS_mobile" value={usrInfo.CS_mobile} onChange={(e) => onInputChange(e)} />
                  </div>
                </div>
              </div>
              <div class="col-md-6 pl-50">
                <div class="form-group">
                  <label class="control-label">Landline Contact Number :</label>
                  <div class="">
                    <input class="form-control"
                      type="number"
                      placeholder="Enter contact number" name="CS_phone"
                      value={usrInfo.CS_phone}
                      onChange={(e) => onInputChange(e)}
                    />
                  </div>
                </div>
              </div>
            </div>

            <div class="row">

              <div class="col-md-6 pr-50">
                <div class="form-group">
                  <label class="control-label">Country : <span style={{ color: "red" }}>*</span> </label>
                  <div class="">
                    <select class="form-control" name="CS_country" id="CS_country" value="101" onChange={(e) => { onCountryChange(e); onInputChange(e) }}>
                      <option value="">Select Country</option>
                      {countryList.map((data, inx) => (
                        <option key={`${data.ID}${inx}`} value={data.ID}>{data.Name}</option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>
              <div class="col-md-6 pl-50">
                <div class="form-group">
                  <label class="control-label">State : <span style={{ color: "red" }}>*</span> </label>
                  <div class="">
                    <select class="form-control" name="CS_state" id="CS_state" value={usrInfo.CS_state} onChange={(e) => onInputChange(e)}>
                      {stateList.map((data, inx) => (

                        <option key={`${data.Name}${inx}`} value={data.Name}>{data.Name}</option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>
            </div>

            <div class="row">

              <div class="col-md-6 pr-50">
                <div class="form-group">
                  <label class="control-label">Alternative Name : <span style={{ color: "red" }}>*</span> </label>
                  <div class="">
                    <input class="form-control" type="text" placeholder="Enter alternative Name" name="CS_mobile" id="CS_mobile" value={usrInfo.CS_mobile} onChange={(e) => onInputChange(e)} />
                  </div>
                </div>
              </div>
              <div class="col-md-6 pl-50">
                <div class="form-group">
                  <label class="control-label">Alternative Contact Number :</label>
                  <div class="">
                    <input class="form-control"
                      type="number"
                      placeholder="Enter alternative contact number"
                      name="CS_phone" id="CS_phone" value={usrInfo.CS_phone}
                      onChange={(e) => onInputChange(e)}
                    />
                  </div>
                </div>
              </div>
            </div>

            <div class="row">

              <div class="col-md-6 pr-50">
                <div class="form-group">
                  <label class="control-label">Designation : <span style={{ color: "red" }}>*</span> </label>
                  <div class="">
                    <input class="form-control" type="text" placeholder="Enter designation" name="CS_mobile" id="designation" value={usrInfo.CS_mobile} onChange={(e) => onInputChange(e)} />
                  </div>
                </div>
              </div>
              {/* <div class="col-md-6 pl-50">
                <div class="form-group">
                  <label class="control-label">Landline Contact Number :</label>
                  <div class="">
                    <input class="form-control" type="number" placeholder="Enter contact number" name="CS_phone" id="CS_phone" value={usrInfo.CS_phone} onChange={(e) => onInputChange(e)} />
                  </div>
                </div>
              </div> */}
            </div>


          </div>

        </div>
      </div>

      <div class="col-md-12">
        <div class="box_detail" style={{ paddingLeft: "0px", paddingRight: "0px", paddingTop: "0px", borderRadius: "4px" }}>
          <div class="page-header row no-gutters inside_header">
            <div class="col-md-12">
              <h3 class="page-title" style={{ color: "#000", marginBottom: "0px", paddingBottom: "0px", fontSize: "1.5rem" }}>User Setting</h3>
            </div>
          </div>
          <hr class="m-t-25 m-b-25" />

          <div class="form-body createf_settings">
            {/* <div class="row">


            </div> */}
            <div class="row">
              <div class="col-md-6 pr-50">
                <div class="form-group">
                  <label class="control-label">Credit Period :</label>
                  <div class="">
                    <select class="form-control" name="credetPeriod" id="creditPeriod" onChange={(e) => onInputChange(e)}>
                      <option value="">0 days</option>
                      <option value="7days">7 days</option>
                      <option value="15days">15 days</option>
                      <option value="15days">15 days</option>
                      <option value="30days">30 days</option>
                      <option value="45days">45 days</option>
                      <option value="60days">60 days</option>
                      <option value="90days">90 days</option>

                    </select>
                  </div>
                </div>
              </div>
              <div class="col-md-6 pl-50">
                <div class="form-group">
                  <label class="control-label">Discount Terms :</label>
                  <div class="">
                    <select class="form-control" name="f_DiscountTerms" id="f_DiscountTerms" value={usrInfo.f_DiscountTerms} onChange={(e) => onInputChange(e)}>
                      <option value="Commision">Commision</option>
                      <option value="Corporate Deal">Corporate Deal</option>
                      <option selected="selected" value="NO Discount">NO Discount</option>
                      <option value="Performa">Performa</option>
                      <option value="Publication Pckg">Publication Pckg</option>
                      <option value="Publicis Group Discount">Publicis Group Discount</option>
                      <option value="UpFront">UpFront</option>
                      <option value="WPP Discount">WPP Discount</option>
                    </select>
                  </div>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-6 pr-50">
                <div class="form-group">
                  <label class="control-label">Approval Mode :</label>
                  <div class="">
                    <select class="form-control" name="approvalMode" id="approvalMode" onChange={(e) => onInputChange(e)}>
                      <option selected="selected" value="Select Approval Mode">Select Approval Mode</option>
                      <option value="Cheque copy/deposit slip">Cheque copy/deposit slip</option>
                      <option value="PO">PO</option>
                      <option value="Quotation approval">Quotation approval</option>
                      <option value="Mail approval">Mail approval</option>
                      <option value="PDC">PDC</option>
                      <option value="Upfront">Upfront</option>
                      <option value="NEFT/SWIFT">NEFT/SWIFT</option>
                    </select>
                  </div>
                </div>
              </div>
              <div class="col-md-6 pl-50">
                <div class="form-group">
                  <label class="control-label">About IB :</label>
                  <div class="">
                    <select class="form-control" name="aboutIB" id="aboutIB" onChange={(e) => onInputChange(e)}>
                      <option value="select">Please Select</option>
                      <option value="Google">Google</option>
                      <option value="Word of Mouth">Word of Mouth</option>
                      <option value="Through Agency">Through Agency</option>
                      <option value="Newspaper">Newspaper</option>
                      <option value="Emailer">Emailer</option>
                      <option value="Afaq">Afaq</option>
                      <option value="Sales">Sales</option>
                      <option value="Know before">Know before</option>
                      <option value="Site">Site</option>
                      <option value="Seminar">Seminar</option>
                      <option value="Google">From us</option>
                      <option value="New registration">New registration</option>
                      <option value="Others">Others</option>
                    </select>
                  </div>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-6 pr-50">
                <div class="form-group">
                  <label class="control-label">Special Comment :</label>
                  <div class="">
                    <input class="form-control" type="text" placeholder="Enter comment" name="specialComment" id="specialComment" onChange={(e) => onInputChange(e)} />
                  </div>
                </div>
              </div>
              <div class="col-md-6 pl-50">
                <div class="form-group">
                  <label class="control-label">Order Id :</label>
                  <div class="">
                    <input class="form-control" type="number" placeholder="Enter order id" name="orderID" id="orderID" onChange={(e) => onInputChange(e)} />
                  </div>
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>



      <div class="col-md-12">
        <div class="box_detail" style={{ paddingLeft: "0px", paddingRight: "0px", paddingTop: "0px", borderRadius: "4px" }}>
          <div class="page-header row no-gutters inside_header">
            <div class="col-md-12">
              <h3 class="page-title" style={{ color: "#000", marginBottom: "0px", paddingBottom: "0px", fontSize: "1.5rem" }}>Additional Information</h3>
            </div>
          </div>
          <hr class="m-t-25 m-b-25" />

          <div class="form-body">
            <div class="row">
              <div class="col-md-5">
                <div class="form-group">
                  <label class="control-label">Type :</label>
                  <div class="">
                    <select class="form-control" name="add_userType" id="add_userType" onChange={additionalhandlechange}>
                      <option value="">Select Type</option>
                      <option value="Accountant">Accountant</option>
                      <option value="Manager">Manager</option>
                    </select>
                  </div>
                </div>

                <div class="form-group">
                  <label class="control-label">Name :</label>
                  <div class="">
                    <input class="form-control" type="text"
                      placeholder="Enter name" name="add_name"
                      id="add_name" onChange={additionalhandlechange}
                    />
                  </div>
                </div>

                <div class="form-group">
                  <label class="control-label">Email Id :</label>
                  <div class="">
                    <input class="form-control" type="text"
                      placeholder="Enter email address"
                      name="add_email" onChange={additionalhandlechange}
                    />
                  </div>
                </div>

                <div class="form-group">
                  <label class="control-label">Contact Number :</label>
                  <div class="">
                    <input class="form-control" type="number"
                      placeholder="Enter contact number" name="add_contact"
                      onChange={additionalhandlechange}
                    />
                  </div>
                </div>

                <div class="form-group">
                  <label class="control-label">Designation :</label>
                  <div class="">
                    <input class="form-control" type="text" placeholder="Enter designation"
                      name="add_designation"
                      onChange={additionalhandlechange}
                    />
                  </div>
                </div>

                {/* <div class="form-group">
                  <div id="important" class="checkbox">
                    <label> <input type="checkbox" value="important" name="add_imp" id="add_imp" onChange={(e) => onInputChange(e)} /> Imp</label>
                  </div>
                </div> */}

                <div class="form-group">
                  <button class="btn btn-block btn-add mb-2" onClick={AddInfoSubmit}>
                    ADD CONTACT
                  </button>
                </div>
              </div>
              <div class="col-md-7">
                <table class="table table-bordered" style={{ border: "1px solid #dee2e6" }}>
                  <thead class="thead-dark">
                    <tr>
                      <th style={{ borderLeft: "1px solid #454d55" }}>Type</th>
                      <th>Name</th>
                      <th>Email</th>
                      <th>Mobile No.</th>
                      <th>Designation</th>
                      <th class="text-center" style={{ borderRight: "1px solid #454d55" }}></th>
                    </tr>
                  </thead>
                  <tbody>
                    {AdditionalList.length > 0 ? AdditionalList.map((data, inx) => {
                      return (
                        <tr key={`${data.add_contact}${inx}`}>
                          <td className="company_nameadd">{data.add_userType}</td>
                          <td className="company_nameadd">{data.add_name}</td>
                          <td className="company_emmailadd"><a href="mailto:manish@cstech.in">{data.add_email}</a></td>
                          <td>{data.add_contact}</td>
                          <td>{data.add_designation}</td>
                          <td className="text-center td_comments">
                            <RiDeleteBin6Line className="text-danger1" onClick={() => AddInfoRemove(data.add_email)} />
                          </td>
                        </tr>
                      )
                    }) : <tr><td className="no_records" colSpan="11">No Records</td></tr>}

                  </tbody>
                </table>
              </div>
            </div>
          </div>

        </div>
      </div>



      <div class="col-md-12">
        <div class="box_detail" style={{ paddingLeft: "0px", paddingRight: "0px", paddingTop: "0px", borderRadius: "4px" }}>
          <div class="page-header row no-gutters inside_header">
            <div class="col-md-12">
              <h3 class="page-title" style={{ color: "#000", marginBottom: "0px", paddingBottom: "0px", fontSize: "1.5rem" }}>FollowUps Details</h3>
            </div>
          </div>
          <hr class="m-t-25 m-b-25" />
          <label className="text-danger text-center errMsg_text">{errMsg}</label>
          <div class="form-body">
            <ul class="row form-group followups_checkbox">
              {array.map((data, inx) => {
                let { type, name, checked } = data;
                if (type === "checkbox") {
                  checked = checkData.filter((data) => data.name === name)[0].checked;
                }
                return (
                  <li>
                    <div id="imp1" class="checkbox">
                      <div key={"section5_input" + inx}>
                        <Col>
                          <label> {name} </label>&nbsp;
                          <input
                            type={type}
                            name={name}
                            onChange={handleChange}
                            checked={checked}
                          />
                        </Col>
                      </div>
                    </div>
                  </li>
                );
              })}

            </ul>
            <Row className="rownew1 check_detailsf">
              {checkData.map((data, inx) => {
                let { checked, Form } = data;
                return (
                  checked && (
                    Form
                  )
                );
              })}
            </Row>



            <Row className="rownew1 submit_checkfollow">
              <div className="col-md-12">
                <div className="form-group" >
                  <Button size="sm" variant="primary"
                    onClick={onSubmit}
                  >
                    SUBMIT
                  </Button>
                </div>
              </div>
            </Row>
          </div>

        </div>
      </div>


    </Row>

  );
};

export default CreateFollowups;
