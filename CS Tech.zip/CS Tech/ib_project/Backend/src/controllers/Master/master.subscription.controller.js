const { M_SUBSCRIPTION } = require("../../model");

exports.addSubscription = async (req, res) => {
    const { f_planname, f_maxallowed, f_periodindays, f_totimg, f_amount,
        f_status, f_imageType, f_desc, f_save, f_shot
    } = req.body;
    try {
        const existingData = await M_SUBSCRIPTION.findOne({ f_planname });
        if (existingData) {
            res.json({ status: 400, message: "subscription plan already exist" })
        }
        if (!existingData) {
            const Data = await new M_SUBSCRIPTION({
                f_planname, f_maxallowed, f_periodindays, f_totimg, f_amount,
                f_status, f_imageType, f_desc, f_save, f_shot
            }).save();
            if (Data) {
                res.json({ status: 200, message: "subscription plan added successfully" })
            }
        }
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

exports.getSubscriptionlList = async (req, res) => {
    const { currentPage, itemPerPage, searchData } = req.query;
    const num = parseInt(itemPerPage)
    const start = parseInt(currentPage);
    let pipeline;
    let countline;
    try {
        if (!searchData || searchData === "") {
            pipeline = [
                { $skip: (start - 1) * num },
                { $limit: num },
                { $sort: { _id: -1 } }
            ]
            countline = [
                { $count: "totalcount" }
            ]
        } else {
            pipeline = [
                { $match: { f_planname: { $regex: searchData, $options: "im" } } },
                { $skip: (start - 1) * num },
                { $limit: num },
                { $sort: { _id: -1 } }
            ]
            countline = [
                { $match: { f_planname: { $regex: searchData, $options: "im" } } },
                { $count: "totalcount" }
            ]
        }
        const data = await M_SUBSCRIPTION.aggregate(pipeline)
        const totalrecord = await M_SUBSCRIPTION.aggregate(countline)
        res.json({ status: 200, data, totalrecord })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

exports.sendSubscriptionPlanEmail = async (req, res) => {
    try {

    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

exports.getSubscriptionDetail = async (req, res) => {
    const { _id } = req.params;
    try {
        const subscriptionplandetail = await M_SUBSCRIPTION.findOne({ _id });
        res.json({ status: 200, subscriptionplandetail })

    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

exports.editSubscriptionPlan = async (req, res) => {
    const {
        _id, f_planname, f_maxallowed, f_periodindays,
        f_totimg, f_amount, f_imageType, f_save
    } = req.body;
    try {
        const data = await M_SUBSCRIPTION.findOne({ _id });
        if (data) {
            await M_SUBSCRIPTION.findByIdAndUpdate({ _id }, {
                $set: {
                    f_planname, f_maxallowed, f_periodindays,
                    f_totimg, f_amount, f_imageType, f_save
                }
            })
            res.json({ status: 200, message: "Subscription Plan Updated" })
        }
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

exports.removeSubscriptionPlan = async (req, res) => {
    const { _id } = req.params;
    try {
        await M_SUBSCRIPTION.findByIdAndRemove({ _id })
        res.json({ status: 200, message: "Subscription Plan Removed" })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}