const Company = require("express").Router();
const {
    addCompany, getCompanyList, getCompanyDetail, updateCompanyDetail, removeCompanyDetail
} = require("../../controllers/Master/master.company.controller")

Company.route(`/addcompany`).post(addCompany);
Company.route(`/getcompanylist`).get(getCompanyList);
Company.route(`/getcompanydetail/:_id`).get(getCompanyDetail);
Company.route(`/updatecompanydetail`).post(updateCompanyDetail);
Company.route(`/removecompanydetail/:_id`).get(removeCompanyDetail);

module.exports = Company;