const logger = require("../utilities/logger")
const { Merchant, Payment, TrackData } = require("../models/model.index")
const { APIError } = require("../utilities/APIError")
const {
    generateError,
    ERROR_STATUS_CODE,
    INTERNAL_SERVER_ERROR,
    EMAIL_NOT_EXISTS,
    WRONG_PASSWORD,
    PERMISSION_DENIED,
    USER_ALREADY_EXISTS,
    UNEXPECTED_ERROR
} = require("../utilities/errorContants");
const { getDateArr } = require("../utilities/helper");
const { merchantAutoRegistrationEmail } = require("../services/nodeMailer/sendMail");
const Moment = require("moment")

//START----Analatical
exports.getshipment15daysrecords = async (req, res, next) => {
    const dateArr = getDateArr(16);
    let { [dateArr.length - 1]: ed_date } = dateArr;
    try {
        var pipeline = [
            {
                $match: {
                    createdAt: {
                        $lte: new Date(),
                        $gte: ed_date,
                    },
                },
            },
            {
                $group: {
                    _id: {
                        $dateToString: {
                            format: "%Y-%m-%d",
                            date: "$createdAt",
                        },
                    },
                    count: {
                        $sum: 1,
                    },
                },
            },
            {
                $sort: {
                    _id: -1
                }
            }
        ];
        let query = TrackData.aggregate(pipeline);
        const totalOrder = await TrackData.aggregate([{ $count: "totalcount" }])
        const totalCustomer = await Merchant.aggregate([{ $count: "totalcount" }])
        let graph = await query.exec();
        res.json({ status: 200, graph, totalOrder: totalOrder[0].totalcount, totalCustomer: totalCustomer[0].totalcount });
    } catch (error) {
        logger.error(
            `Error while registering user with details ${JSON.stringify(
                req.body
            )} and error ${generateError(error)}`
        );
        return next(
            new APIError(
                ERROR_STATUS_CODE.INTERNAL_SERVER_ERROR_CODE,
                INTERNAL_SERVER_ERROR,
                error.message
            )
        );
    }
}
//END----Analatical

//START----CRU Customer
exports.getCustomerDetailsList = async (req, res, next) => {
    const { pagecount, searchbyname } = req.query
    let limit = 20
    try {
        if (!searchbyname) {
            const merchantCount = await Merchant.aggregate([{ $count: "total" }])
            const merchantData = await Merchant
                .find({})
                .sort({ createdAt: -1 })
                .skip(limit * pagecount)
                .limit(20)
            const merchantDataForExport = await Merchant
                .find({})
                .sort({ createdAt: -1 })
            res.json({ merchantData, merchantCount: merchantCount[0].total, merchantDataForExport })
        }

        if (searchbyname !== "") {
            const merchantData = await Merchant.find({
                name: { $regex: searchbyname, $options: "im" },
            }).sort({ createdAt: -1 }).skip(limit * pagecount).limit(20)
            const merchantDataForExport = await Merchant.find({ name: { $regex: searchbyname, $options: "im" } }).sort({ createdAt: -1 })
            if (merchantData <= 0) {
                const merchantData = await Merchant.find({
                    email: { $regex: searchbyname, $options: "im" },
                }).sort({ createdAt: -1 }).skip(limit * pagecount).limit(20)
                const merchantDataForExport = await Merchant.find({ email: { $regex: searchbyname, $options: "im" } }).sort({ createdAt: -1 })
                if (merchantData <= 0) {
                    const merchantData = await Merchant.find({
                        phone: { $regex: searchbyname, $options: "im" },
                    }).skip(limit * pagecount).limit(20)
                    const merchantDataForExport = await Merchant.find({ phone: { $regex: searchbyname, $options: "im" } }).sort({ createdAt: -1 })
                    res.json({ merchantData, merchantCount: merchantDataForExport.length, merchantDataForExport });
                } else {
                    res.json({ merchantData, merchantCount: merchantDataForExport.length, merchantDataForExport });
                }
            } else {
                res.json({ merchantData, merchantCount: merchantDataForExport.length, merchantDataForExport });
            }
        }
    } catch (error) {
        logger.error(
            `Error while registering user with details ${JSON.stringify(
                req.body
            )} and error ${generateError(error)}`
        );
        return next(
            new APIError(
                ERROR_STATUS_CODE.INTERNAL_SERVER_ERROR_CODE,
                INTERNAL_SERVER_ERROR,
                error.message
            )
        );
    }
}

exports.createCustomer = async (req, res, next) => {
    const data = req.body
    const { name, email, phone, password, companyName, address, pincode, city, state, country, beneficiary_name,
        bank_name, account_number, ifsc_code, bank_branch } = data
    try {
        const customerData = await Merchant.findOne({ $or: [{ email }, { phone }] });
        if (customerData)
            return next(
                new APIError(
                    ERROR_STATUS_CODE.ALREADY_EXITS,
                    USER_ALREADY_EXISTS
                ))
        const newCustomer = new Merchant({
            name, email, phone, password, companyName, address, pincode, city, state, country,
            beneficiary_name, bank_name, account_number, ifsc_code, bank_branch
        })
        await newCustomer.save((err, docs) => {
            if (!err && docs) {
                merchantAutoRegistrationEmail(
                    {
                        email: docs.email,
                        password: docs.password,
                        name: docs.name,
                    },
                    (data, error) => {
                        if (!error) {
                            logger.info(
                                `Email created successfully and this is the info () => ${data}`
                            );
                        } else {
                            logger.error(
                                `This is the error while generating emai info () => ${error}`
                            );
                        }
                    }
                );
                res.json({ status: 200, newCustomer: docs })
            }
        })
    } catch (error) {
        logger.error(
            `Error while registering user with details ${JSON.stringify(
                req.body
            )} and error ${generateError(error)}`
        );
        return next(
            new APIError(
                ERROR_STATUS_CODE.INTERNAL_SERVER_ERROR_CODE,
                INTERNAL_SERVER_ERROR,
                error.message
            )
        );
    }
}

exports.getCustomerDetail = async (req, res, next) => {
    const { _id } = req.params
    try {
        const customerData = await Merchant.findOne({ _id })
        if (!customerData)
            return next(
                new APIError(
                    ERROR_STATUS_CODE.ALREADY_EXITS,
                    USER_ALREADY_EXISTS
                ))
        res.json({ status: 200, customerData })
    } catch (error) {
        logger.error(
            `Error while registering user with details ${JSON.stringify(
                req.body
            )} and error ${generateError(error)}`
        );
        return next(
            new APIError(
                ERROR_STATUS_CODE.INTERNAL_SERVER_ERROR_CODE,
                INTERNAL_SERVER_ERROR,
                error.message
            )
        );
    }
}

exports.updateCustomerDetail = async (req, res, next) => {
    const data = req.body
    const { _id } = req.params
    const { name, email, phone, password, companyName, address, pincode, city, state, country, beneficiary_name,
        bank_name, account_number, ifsc_code, bank_branch } = data
    try {
        const customerData = await Merchant.findOne({ _id })
        if (!customerData)
            return next(
                new APIError(
                    ERROR_STATUS_CODE.ALREADY_EXITS,
                    USER_ALREADY_EXISTS
                ))

        const updatedCustomer = await Merchant.updateOne({ _id: customerData._id }, {
            $set: {
                name, email, phone, password, companyName, address, pincode, city, state, country, beneficiary_name,
                bank_name, account_number, ifsc_code, bank_branch
            }
        });
        res.json({ status: 200, message: "customer updated successfully!", updatedCustomer })
    } catch (error) {
        logger.error(
            `Error while registering user with details ${JSON.stringify(
                req.body
            )} and error ${generateError(error)}`
        );
        return next(
            new APIError(
                ERROR_STATUS_CODE.INTERNAL_SERVER_ERROR_CODE,
                INTERNAL_SERVER_ERROR,
                error.message
            )
        );
    }
}
//END----CRU Customer

//START----Payment
exports.createPayment = async (req, res, next) => {
    const data = req.body
    try {
        const pipeline = [
            {
                $group: {
                    _id: data._id,
                    total: {
                        $sum: "$order_amount",
                    },
                },
            },
        ];
        const merchantShipData = await TrackData.aggregate(pipeline);
        const totalCost = merchantShipData[0].total;
        if (data.payed_amount > totalCost) {
            return next(
                new APIError(
                    ERROR_STATUS_CODE.BAD_REQUEST_CODE,
                    PERMISSION_DENIED,
                )
            );
        } else {
            let { _id, seller_entry_name, ifsc_code, account_number, beneficiary_name, bank_name, bank_branch, mode, payment_type, transection_no, payed_amount, comment } = data
            const newData = await new Payment({
                userId: _id, seller_entry_name, ifsc_code, account_number, beneficiary_name, bank_name, bank_branch, mode, payment_type, transection_no, payed_amount, comment
            }).save();
            res.json({ status: 200, newData })
        }
    } catch (error) {
        logger.error(
            `Error while registering user with details ${JSON.stringify(
                req.body
            )} and error ${generateError(error)}`
        );
        return next(
            new APIError(
                ERROR_STATUS_CODE.INTERNAL_SERVER_ERROR_CODE,
                INTERNAL_SERVER_ERROR,
                error.message
            )
        );
    }
}

exports.getCustomerAmount = async (req, res, next) => {
    const { _id } = req.params;
    try {
        const customerData = await Merchant.findOne({ _id })
        const pipeline = [
            {
                $match: { userId: _id }
            },
            {
                $group: { _id: null, total: { $sum: "$order_amount" } }
            }
        ]
        const query = TrackData.aggregate(pipeline)
        query.exec((err, data) => {
            if (!err && customerData !== null)
                res.json({ status: 200, amount: data[0].total, name: customerData.name })
            else
                return next(
                    new APIError(
                        ERROR_STATUS_CODE.BAD_REQUEST_CODE,
                        UNEXPECTED_ERROR,
                    )
                );
        })
    } catch (error) {
        logger.error(
            `Error while registering user with details ${JSON.stringify(
                req.body
            )} and error ${generateError(error)}`
        );
        return next(
            new APIError(
                ERROR_STATUS_CODE.INTERNAL_SERVER_ERROR_CODE,
                INTERNAL_SERVER_ERROR,
                error.message
            )
        );
    }
}

exports.getPaymentSatelments = async (req, res, next) => {
    try {
        const { _id } = req.params
        const records = await Payment.find({ userId: _id }).sort({ createdAt: -1 })
        let sumCredit = 0;
        let sumDebit = 0;
        for (let i = 0; i < records.length; i++) {
            if (records[i].payment_type === "Credit") {
                sumCredit = sumCredit + records[i].payed_amount;
            } else {
                sumDebit = sumDebit + records[i].payed_amount;
            }
        }
        let netPayble = sumCredit > sumDebit ? sumCredit - sumDebit : 0;
        let netReceiveble =
            sumDebit > sumCredit ? Math.abs(sumDebit - sumCredit) : 0;
        res.json({ status: 200, records, sumCredit, sumDebit, netPayble, netReceiveble })
    } catch (error) {
        logger.error(
            `Error while registering user with details ${JSON.stringify(
                req.body
            )} and error ${generateError(error)}`
        );
        return next(
            new APIError(
                ERROR_STATUS_CODE.INTERNAL_SERVER_ERROR_CODE,
                INTERNAL_SERVER_ERROR,
                error.message
            )
        );
    }
}

exports.paymentDateFilter = async (req, res, next) => {
    const data = req.body;
    const { _id } = req.params
    const { startDate, endDate } = data
    let s_date = new Date(startDate);
    let e_date = new Date(endDate);
    s_date.setHours(1);
    e_date.setHours(23);
    let pipeline;
    if (startDate !== 0 || endDate !== 0) {
        pipeline = [
            {
                $match: {
                    userId: _id,
                    createdAt: {
                        $gte: s_date,
                        $lte: e_date,
                    },
                },
            },
            { $sort: { createdAt: -1 } }
        ]
    } else {
        pipeline = [
            {
                $match: {
                    userId: _id,
                },
            },
            { $sort: { createdAt: -1 } }
        ]
    }
    try {
        const paymentDetails = await Payment.aggregate(pipeline);
        let sumCredit = 0;
        let sumDebit = 0;
        for (let i = 0; i < paymentDetails.length; i++) {
            if (paymentDetails[i].payment_type === "Credit") {
                sumCredit = sumCredit + paymentDetails[i].payed_amount;
            } else {
                sumDebit = sumDebit + paymentDetails[i].payed_amount;
            }
        }
        let netPayble = sumCredit > sumDebit ? sumCredit - sumDebit : 0;
        let netReceiveble =
            sumDebit > sumCredit ? Math.abs(sumDebit - sumCredit) : 0;
        res.json({ paymentDetails, sumCredit, sumDebit, netPayble, netReceiveble })
    } catch (error) {
        logger.error(
            `Error while registering user with details ${JSON.stringify(
                req.body
            )} and error ${generateError(error)}`
        );
        return next(
            new APIError(
                ERROR_STATUS_CODE.INTERNAL_SERVER_ERROR_CODE,
                INTERNAL_SERVER_ERROR,
                error.message
            )
        );
    }
}

exports.paymentDateFilterV2 = async (req, res, next) => {
    const data = req.body;
    const { _id } = req.params
    const { startDate, endDate } = data
    let s_date = new Date(startDate);
    let e_date = new Date(endDate);
    s_date.setHours(1);
    e_date.setHours(23);
    let pipeline;
    let pipeline1;
    let paymentDetails = [];
    try {
        const user = await Merchant.findOne({ _id });
        if (startDate !== 0 || endDate !== 0) {
            pipeline = [
                {
                    $match: {
                        $and: [
                            { "from_address.company_name": user.companyName },
                            {
                                $or: [
                                    { createdAt: { $gte: s_date, $lte: e_date } },
                                    { t_delivery_date: { $gte: s_date, $lte: e_date } },
                                    { $and: [{ fulfillment_status: "pending" }, { createdAt: { $lte: s_date } }] }
                                ]
                            }
                        ]
                    }
                },
                { $sort: { createdAt: -1 } }
            ]
            pipeline1 = [
                {
                    $match: {
                        userId: _id,
                    }
                },
                { $sort: { createdAt: -1 } }
            ]
        } else {
            pipeline = [
                {
                    $match: {
                        userId: _id,
                    },
                },
                { $sort: { createdAt: -1 } }
            ]
        }

        const TrackDetails = await TrackData.aggregate(pipeline);;
        for (let i = 0; i < TrackDetails.length; i++) {
            const paymentData = await Payment.findOne({ tracking_number: TrackDetails[i].tracking_number });
            paymentDetails.push(paymentData)
        }
        let sumCredit = 0;
        let sumDebit = 0;
        for (let i = 0; i < paymentDetails.length; i++) {
            if (paymentDetails[i].payment_type === "Credit") {
                sumCredit = sumCredit + paymentDetails[i].payed_amount;
            } else {
                sumDebit = sumDebit + paymentDetails[i].payed_amount;
            }
        }
        let netPayble = sumCredit > sumDebit ? sumCredit - sumDebit : 0;
        let netReceiveble =
            sumDebit > sumCredit ? Math.abs(sumDebit - sumCredit) : 0;
        res.json({ user, paymentDetails, sumCredit, sumDebit, netPayble, netReceiveble })
    } catch (error) {
        logger.error(
            `Error while registering user with details ${JSON.stringify(
                req.body
            )} and error ${generateError(error)}`
        );
        return next(
            new APIError(
                ERROR_STATUS_CODE.INTERNAL_SERVER_ERROR_CODE,
                INTERNAL_SERVER_ERROR,
                error.message
            )
        );
    }
}
//END----Payment

//START----Traking
exports.searchBarDropdown = async (req, res, next) => {
    try {
        const pipeline = [
            {
                $group: { _id: { provider: "$shipping_method" } },
            }
        ]
        const pipeline1 = [
            {
                $group: { _id: { status: "$fulfillment_status" } },
            }
        ]
        const pipeline2 = [
            {
                $group: { _id: { company: "$from_address.company_name" } },
            }
        ]
        const data = await TrackData.aggregate(pipeline);
        const data1 = await TrackData.aggregate(pipeline1);
        const data2 = await TrackData.aggregate(pipeline2);
        let provider = ["All Provider"];
        let status = ["All Status"];
        let company = ["All Company"];
        data.forEach(element => {
            provider.push(element._id.provider)
        })
        data1.forEach(element => {
            status.push(element._id.status)
        })
        data2.forEach(element => {
            company.push(element._id.company)
        })
        res.json({ provider, status, company })

    } catch (error) {
        logger.error(
            `Error while registering user with details ${JSON.stringify(
                req.body
            )} and error ${generateError(error)}`
        );
        return next(
            new APIError(
                ERROR_STATUS_CODE.INTERNAL_SERVER_ERROR_CODE,
                INTERNAL_SERVER_ERROR,
                error.message
            )
        );
    }
}

exports.getTrakingDetails = async (req, res, next) => {
    const { pagecount, searchbyname } = req.query;
    let limit = 20
    try {
        if (!searchbyname) {
            const count = await TrackData.aggregate([{ $count: "count" }])
            const trakingDetailsList = await TrackData
                .find({}, { t_delivery_date: 1, shipping_method: 1, order_number: 1, order_id: 1, shipping_method: 1, order_amount: 1, tracking_number: 1, createdAt: 1, fulfillment_status: 1, from_address: 1, t_return_date: 1 })
                .sort({ createdAt: -1 })
                .skip(limit * pagecount)
                .limit(20)
            res.json({ status: 200, trakingDetailsList, count: count[0].count })
        }
        if (searchbyname !== "") {
            const trakingDetailsList = await TrackData.find({
                tracking_number: { $regex: searchbyname, $options: "im" },
            }).sort({ createdAt: -1 })
            if (trakingDetailsList <= 0) {
                const trakingDetailsList = await TrackData.find({
                    "from_address.name": { $regex: searchbyname, $options: "im" },
                }).sort({ createdAt: -1 })
                if (trakingDetailsList <= 0) {
                    const trakingDetailsList = await TrackData.find({
                        order_id: { $regex: searchbyname, $options: "im" },
                    }).sort({ createdAt: -1 })
                    res.json({ status: 200, trakingDetailsList, count: trakingDetailsList.length });
                } else {
                    res.json({ status: 200, trakingDetailsList, count: trakingDetailsList.length });
                }
            } else {
                res.json({ status: 200, trakingDetailsList, count: trakingDetailsList.length });
            }
        }

    } catch (error) {
        logger.error(
            `Error while registering user with details ${JSON.stringify(
                req.body
            )} and error ${generateError(error)}`
        );
        return next(
            new APIError(
                ERROR_STATUS_CODE.INTERNAL_SERVER_ERROR_CODE,
                INTERNAL_SERVER_ERROR,
                error.message
            )
        );
    }
}

exports.getTrakingDetailsView = async (req, res, next) => {
    try {
        const { tracking_number } = req.params
        const trakingData = await TrackData.findOne({ tracking_number })
        res.json({ status: 200, trakingData })
    } catch (error) {
        logger.error(
            `Error while registering user with details ${JSON.stringify(
                req.body
            )} and error ${generateError(error)}`
        );
        return next(
            new APIError(
                ERROR_STATUS_CODE.INTERNAL_SERVER_ERROR_CODE,
                INTERNAL_SERVER_ERROR,
                error.message
            )
        );
    }
}

exports.getTrakingDetailsByButtonSearch = async (req, res, next) => {
    const data = req.body;
    const limit = 20;
    let { shipping_method, fulfillment_status, startDate, endDate, pagination } = data;
    if (!shipping_method) shipping_method = "All Provider"
    if (!fulfillment_status) fulfillment_status = "All Status"
    var s_date = new Date(startDate);
    var e_date = new Date(endDate);
    s_date.setHours(1);
    e_date.setHours(23);
    let pipeline;
    try {
        if (shipping_method === "All Provider" && fulfillment_status === "All Status" && startDate === 0 && endDate === 0) {
            const filteredData = await TrackData.find({}).skip(limit * pagination).limit(20).sort({ createdAt: -1 });
            res.json({ filteredData })
        }

        if (startDate == 0 && endDate == 0) {
            if (shipping_method != "All Provider" && fulfillment_status != "All Status") {
                pipeline = [{ $match: { shipping_method, fulfillment_status } }, { $skip: limit * pagination }, { $limit: 20 }, { $sort: { createdAt: -1 } }]
            }
            if (shipping_method != "All Provider" && fulfillment_status == "All Status") {
                pipeline = [{ $match: { shipping_method } }, { $skip: limit * pagination }, { $limit: 20 }, { $sort: { createdAt: -1 } }]
            }
            if (shipping_method == "All Provider" && fulfillment_status != "All Status") {
                pipeline = [{ $match: { fulfillment_status } }, { $skip: limit * pagination }, { $limit: 20 }, { $sort: { createdAt: -1 } }]
            }
        }

        if (startDate != 0 && endDate != 0) {
            if (shipping_method == "All Provider" && fulfillment_status == "All Status") {
                pipeline = [
                    {
                        $match: {
                            createdAt: {
                                $gte: s_date,
                                $lte: e_date,
                            },
                        }
                    },
                    {
                        $skip: limit * pagination
                    },
                    {
                        $limit: 20
                    },
                    {
                        $sort: { createdAt: -1 }
                    }
                ];
            }
            if (shipping_method != "All Provider" && fulfillment_status != "All Status") {
                pipeline = [
                    {
                        $match: {
                            shipping_method,
                            fulfillment_status,
                            createdAt: {
                                $gte: s_date,
                                $lte: e_date,
                            },
                        }
                    },
                    {
                        $skip: limit * pagination
                    },
                    {
                        $limit: 20
                    },
                    {
                        $sort: { createdAt: -1 }
                    }
                ];
            }
            if (shipping_method != "All Provider" && fulfillment_status == "All Status") {
                pipeline = [
                    {
                        $match: {
                            shipping_method,
                            createdAt: {
                                $gte: s_date,
                                $lte: e_date,
                            },
                        }
                    },
                    {
                        $skip: limit * pagination
                    },
                    {
                        $limit: 20
                    },
                    {
                        $sort: { createdAt: -1 }
                    }
                ];
            }
            if (shipping_method == "All Provider" && fulfillment_status != "All Status") {
                pipeline = [
                    {
                        $match: {
                            fulfillment_status,
                            createdAt: {
                                $gte: s_date,
                                $lte: e_date,
                            },
                        }
                    },
                    {
                        $skip: limit * pagination
                    },
                    {
                        $limit: 20
                    },
                    {
                        $sort: { createdAt: -1 }
                    }
                ];
            }

        }
        const filteredData = await TrackData.aggregate(pipeline);
        res.json({ filteredData })

    } catch (error) {
        logger.error(
            `Error while registering user with details ${JSON.stringify(
                req.body
            )} and error ${generateError(error)}`
        );
        return next(
            new APIError(
                ERROR_STATUS_CODE.INTERNAL_SERVER_ERROR_CODE,
                INTERNAL_SERVER_ERROR,
                error.message
            )
        );
    }
}

exports.CODbuttonSearch = async (req, res, next) => {
    const data = req.body;
    let limit = 20;
    let { company_name, shipping_method, startDate, endDate, pagination } = data;
    if (!shipping_method) shipping_method = "All Provider"
    if (!company_name) company_name = "All Company";
    var s_date = new Date(Moment(startDate).add(1, 'day'));
    var e_date = new Date(Moment(endDate).add(2, 'day'));
    s_date.setHours(-18)
    e_date.setHours(-19);
    let count;
    let pipeline;
    try {
        if (company_name === "All Company" && shipping_method === "All Provider" && startDate === 0 && endDate === 0) {
            count = [{ $count: "count" }]
            const filteredData = await TrackData.find({}).skip(limit * pagination).limit(20).sort({ createdAt: -1 })
            res.json({ message: "1st", filteredData })
        }

        if (startDate === 0 && endDate === 0) {
            if (shipping_method !== "All Provider") {
                count = [{ $match: { shipping_method } }, { $count: "count" }]
                pipeline = [{ $match: { shipping_method } }, { $skip: limit * pagination }, { $limit: 20 }, { $sort: { createdAt: -1 } }]
            }

            if (company_name !== "All Company") {
                count = [{ $match: { "from_address.company_name": company_name } }, { $count: "count" }]
                pipeline = [{ $match: { "from_address.company_name": company_name } }, { $skip: limit * pagination }, { $limit: 20 }, { $sort: { createdAt: -1 } }]
            }

            if (company_name !== "All Company" && shipping_method !== "All Provider") {
                count = [{ $match: { $and: [{ "from_address.company_name": company_name }, { shipping_method }] } }, { $count: "count" }]
                pipeline = [{
                    $match: {
                        "from_address.company_name": company_name,
                        shipping_method,
                    }
                }, { $skip: limit * pagination }, { $limit: 20 }, { $sort: { createdAt: -1 } }]
            }
        }

        if (startDate != 0 && endDate != 0) {
            if (shipping_method === "All Provider" && company_name !== "All Company") {
                count = [{ $match: { createdAt: { $gte: s_date, $lte: e_date } } }, { $count: "count" }];
                pipeline = [
                    {
                        $match: {
                            createdAt: {
                                $gte: s_date,
                                $lte: e_date,
                            },
                        },
                    },
                    {
                        $skip: limit * pagination
                    },
                    {
                        $limit: 20
                    },
                    {
                        $sort: { createdAt: -1 }
                    }
                ];
            }

            if (shipping_method !== "All Provider" && company_name === "All Company") {
                count = [{ $match: { shipping_method, createdAt: { $gte: s_date, $lte: e_date } } }, { $count: "count" }];
                pipeline = [
                    {
                        $match: {
                            shipping_method,
                            createdAt: {
                                $gte: s_date,
                                $lte: e_date,
                            },
                        },
                    },
                    {
                        $skip: limit * pagination
                    },
                    {
                        $limit: 20
                    },
                    {
                        $sort: { createdAt: -1 }
                    }
                ];
            }

            if (company_name === "All Company" && shipping_method !== "All Provider") {
                count = [{ $match: { createdAt: { $gte: s_date, $lte: e_date } } }, { $count: "count" }];
                pipeline = [
                    {
                        $match: {
                            createdAt: {
                                $gte: s_date,
                                $lte: e_date,
                            },
                        },
                    },
                    {
                        $skip: limit * pagination
                    },
                    {
                        $limit: 20
                    },
                    {
                        $sort: { createdAt: -1 }
                    }
                ];
            }

            if (company_name !== "All Company" && shipping_method === "All Provider") {
                count = [{ $match: { "from_address.company_name": company_name, createdAt: { $gte: s_date, $lte: e_date } } }, { $count: "count" }];
                pipeline = [
                    {
                        $match: {
                            "from_address.company_name": company_name,
                            createdAt: {
                                $gte: s_date,
                                $lte: e_date,
                            },
                        },
                    },
                    {
                        $skip: limit * pagination
                    },
                    {
                        $limit: 20
                    },
                    {
                        $sort: { createdAt: -1 }
                    }
                ];
            }

            if (company_name !== "All Company" && shipping_method !== "All Provider") {
                count = [{ $match: { "from_address.company_name": company_name, shipping_method, createdAt: { $gte: s_date, $lte: e_date } } }, { $count: "count" }];
                pipeline = [
                    {
                        $match: {
                            "from_address.company_name": company_name,
                            shipping_method,
                            createdAt: {
                                $gte: s_date,
                                $lte: e_date,
                            },
                        },
                    },
                    {
                        $skip: limit * pagination
                    },
                    {
                        $limit: 20
                    },
                    {
                        $sort: { createdAt: -1 }
                    }
                ];
            }

            if (company_name === "All Company" && shipping_method === "All Provider") {
                count = [{ $match: { createdAt: { $gte: s_date, $lte: e_date } } }, { $count: "count" }];
                pipeline = [
                    {
                        $match: {
                            createdAt: {
                                $gte: s_date,
                                $lte: e_date,
                            },
                        },
                    },
                    {
                        $skip: limit * pagination
                    },
                    {
                        $limit: 20
                    },
                    {
                        $sort: { createdAt: -1 }
                    }
                ];
            }
        }

        const filteredData = await TrackData.aggregate(pipeline);
        const merchantCountCheck = await TrackData.aggregate(count);
        let merchantCount;
        if (merchantCountCheck.length === 0) {
            merchantCount = 0
        } else {
            merchantCount = merchantCountCheck[0].count
        }
        res.json({ filteredData: filteredData, merchantCount })

    } catch (error) {
        logger.error(
            `Error while registering user with details ${JSON.stringify(
                req.body
            )} and error ${generateError(error)}`
        );
        return next(
            new APIError(
                ERROR_STATUS_CODE.INTERNAL_SERVER_ERROR_CODE,
                INTERNAL_SERVER_ERROR,
                error.message
            )
        );
    }
}
//END----Traking

//Start----OutStanding
exports.getCustomerOutstanding = async (req, res, next) => {
    try {
        const userData = await Merchant.find({}).sort({ createdAt: -1 });
        let dataArr = [];
        for (let i = 0; i < userData.length; i++) {
            let paymentData = await Payment.find({ userId: userData[i]._id });
            let credit = 0;
            let debit = 0;
            for (let j = 0; j < paymentData.length; j++) {
                if (paymentData[j].payment_type === "Credit") {
                    credit = credit + paymentData[j].payed_amount;
                } else {
                    debit = debit + paymentData[j].payed_amount;
                }
            }
            if (credit != debit) {
                dataArr.push(userData[i]);
            }
        }
        res.json({ dataArr });
    } catch (error) {
        logger.error(
            `Error while registering user with details ${JSON.stringify(
                req.body
            )} and error ${generateError(error)}`
        );
        return next(
            new APIError(
                ERROR_STATUS_CODE.INTERNAL_SERVER_ERROR_CODE,
                INTERNAL_SERVER_ERROR,
                error.message
            )
        );
    }

}

exports.getCustomerOutstandingV2 = async (req, res, next) => {
    let pipeline = [
        {
            $group: {
                _id: {
                    userId: "$from_address.email"
                },
            },
        }
    ];
    let customerArray = [];
    try {
        const ShipmentData = await TrackData.aggregate(pipeline);
        for (let i = 0; i < ShipmentData.length; i++) {
            const isAvailable = await TrackData.findOne({ "from_address.email": ShipmentData[i]._id.userId, fulfillment_status: "delivered" });
            if (isAvailable) {
                const customerData = await Merchant.findOne({ email: isAvailable.from_address.email });
                if (customerData) {
                    customerArray.push(customerData)
                }
            }
        }
        res.json({ ShipmentData, customerArray });
    } catch (error) {
        logger.error(
            `Error while registering user with details ${JSON.stringify(
                req.body
            )} and error ${generateError(error)}`
        );
        return next(
            new APIError(
                ERROR_STATUS_CODE.INTERNAL_SERVER_ERROR_CODE,
                INTERNAL_SERVER_ERROR,
                error.message
            )
        );
    }

}

exports.getCustomerOutstandingNew = async (req, res, next) => {
    const data = req.body;
    // const limit = 20;
    let { startDate, endDate, pagination } = data;
    // if (!shipping_method) shipping_method = "All Provider"
    // if (!fulfillment_status) fulfillment_status = "All Status"
    var s_date = new Date(startDate);
    var e_date = new Date(endDate);
    s_date.setHours(1);
    e_date.setHours(23);
    let pipeline;
    try {
        if (startDate != 0 && endDate != 0) {
            pipeline = [
                {
                    $match: {
                        createdAt: {
                            $gte: s_date,
                            $lte: e_date,
                        },
                    }
                },
                {
                    $group: {
                        _id: { userId: "$userId", status: "$fulfillment_status" }
                    }
                }
            ]
        }
        let customerArray = [];
        const ShipmentData = await TrackData.aggregate(pipeline);
        for (let i = 0; i < ShipmentData.length; i++) {
            if (ShipmentData[i]._id.status === "delivered") {
                console.log(ShipmentData[i]._id.userId)
                const Customer = await Merchant.findOne({ _id: ShipmentData[i]._id.userId });
                console.log(Customer)
                if (Customer) {
                    customerArray.push(Customer)
                }
            }
        }
        res.json({ customerArray })
    } catch (error) {
        logger.error(
            `Error while registering user with details ${JSON.stringify(
                req.body
            )} and error ${generateError(error)}`
        );
        return next(
            new APIError(
                ERROR_STATUS_CODE.INTERNAL_SERVER_ERROR_CODE,
                INTERNAL_SERVER_ERROR,
                error.message
            )
        );
    }

}
//END----OutStanding

exports.accountDeactivate = async (req, res, next) => {
    try {
        const { _id } = req.params
        const merchantData = await Merchant.findOne({ _id });
        if (merchantData && merchantData.activate === "active") {
            await Merchant.updateOne(
                { _id: merchantData._id },
                {
                    $set: {
                        activate: "deactive",
                    },
                }
            );
            res.json({ status: 200, message: `account deactivated successfully` });
        } else {
            await Merchant.updateOne(
                { _id: merchantData._id },
                {
                    $set: {
                        activate: "active",
                    },
                }
            );
            res.json({ status: 200, message: `account activated successfully` });
        }
    } catch (error) {
        logger.error(
            `Error while registering user with details ${JSON.stringify(
                req.body
            )} and error ${generateError(error)}`
        );
        return next(
            new APIError(
                ERROR_STATUS_CODE.INTERNAL_SERVER_ERROR_CODE,
                INTERNAL_SERVER_ERROR,
                error.message
            )
        );
    }
};

exports.totalCounts = async (req, res, next) => {
    try {
        const merchantCount = await Merchant.aggregate([{ $count: "total" }])
        const shipmentCount = await TrackData.aggregate([{ $count: "total" }])
        res.json({ merchantCount: merchantCount[0].total, shipmentCount: shipmentCount[0].total })
    } catch (error) {
        logger.error(
            `Error while registering user with details ${JSON.stringify(
                req.body
            )} and error ${generateError(error)}`
        );
        return next(
            new APIError(
                ERROR_STATUS_CODE.INTERNAL_SERVER_ERROR_CODE,
                INTERNAL_SERVER_ERROR,
                error.message
            )
        );
    }
}

/**
 * FOR 
*/

exports.shipmentListForAllExport = async (req, res, next) => {
    try {
        const shipmenyDetails = await TrackData.find({});
        res.json({ status: 200, shipmenyDetails })
    } catch (error) {
        logger.error(
            `Error while registering user with details ${JSON.stringify(
                req.body
            )} and error ${generateError(error)}`
        );
        return next(
            new APIError(
                ERROR_STATUS_CODE.INTERNAL_SERVER_ERROR_CODE,
                INTERNAL_SERVER_ERROR,
                error.message
            )
        );
    }
}

exports.shipmentFilterByButtonExport = async (req, res, next) => {
    const data = req.body;
    const limit = 20;
    let { shipping_method, fulfillment_status, startDate, endDate, pagination } = data;
    if (!shipping_method) shipping_method = "All Provider"
    if (!fulfillment_status) fulfillment_status = "All Status"
    console.log(shipping_method, fulfillment_status, startDate, endDate)
    var s_date = new Date(startDate);
    var e_date = new Date(endDate);
    s_date.setHours(1);
    e_date.setHours(23);
    let pipeline1;
    try {
        if (shipping_method === "All Provider" && fulfillment_status === "All Status" && startDate === 0 && endDate === 0) {
            const shipExportList = await TrackData.find({}).skip(limit * pagination).limit(20).sort({ createdAt: -1 });
            res.json({ shipExportList })
        }

        if (startDate == 0 && endDate == 0) {
            if (shipping_method != "All Provider" && fulfillment_status != "All Status") {
                pipeline1 = [{ $match: { shipping_method, fulfillment_status } }, { $sort: { createdAt: -1 } }]
            }
            if (shipping_method != "All Provider" && fulfillment_status == "All Status") {
                pipeline1 = [{ $match: { shipping_method } }, { $sort: { createdAt: -1 } }]
            }
            if (shipping_method == "All Provider" && fulfillment_status != "All Status") {
                pipeline1 = [{ $match: { fulfillment_status } }, { $sort: { createdAt: -1 } }]
            }
        }

        if (startDate != 0 && endDate != 0) {
            if (shipping_method == "All Provider" && fulfillment_status == "All Status") {
                pipeline1 = [
                    {
                        $match: {
                            createdAt: {
                                $gte: s_date,
                                $lte: e_date,
                            },
                        }
                    },
                    { $sort: { createdAt: -1 } }
                ]
            }
            if (shipping_method != "All Provider" && fulfillment_status != "All Status") {
                pipeline1 = [
                    {
                        $match: {
                            shipping_method,
                            fulfillment_status,
                            createdAt: {
                                $gte: s_date,
                                $lte: e_date,
                            },
                        }
                    },
                    { $sort: { createdAt: -1 } }
                ]
            }
            if (shipping_method != "All Provider" && fulfillment_status == "All Status") {
                pipeline1 = [
                    {
                        $match: {
                            shipping_method,
                            createdAt: {
                                $gte: s_date,
                                $lte: e_date,
                            },
                        }
                    },
                    { $sort: { createdAt: -1 } }
                ]
            }
            if (shipping_method == "All Provider" && fulfillment_status != "All Status") {
                pipeline1 = [
                    {
                        $match: {
                            fulfillment_status,
                            createdAt: {
                                $gte: s_date,
                                $lte: e_date,
                            },
                        }
                    },
                    { $sort: { createdAt: -1 } }
                ]
            }

        }
        const shipExportList = await TrackData.aggregate(pipeline1);
        res.json({ shipExportList })
    } catch (error) {
        logger.error(
            `Error while registering user with details ${JSON.stringify(
                req.body
            )} and error ${generateError(error)}`
        );
        return next(
            new APIError(
                ERROR_STATUS_CODE.INTERNAL_SERVER_ERROR_CODE,
                INTERNAL_SERVER_ERROR,
                error.message
            )
        );
    }
}

exports.CODbuttonSearchForExport = async (req, res, next) => {
    const data = req.body;
    let limit = 20;
    let { company_name, shipping_method, startDate, endDate, pagination } = data;
    if (!shipping_method) shipping_method = "All Provider"
    if (!company_name) company_name = "All Company"
    var s_date = new Date(Moment(startDate).add(1, 'day'));
    var e_date = new Date(Moment(endDate).add(2, 'day'));
    s_date.setHours(-18)
    e_date.setHours(-19);

    let pipeline1;
    try {
        if (company_name === "All Company" && shipping_method === "All Provider" && startDate === 0 && endDate === 0) {
            count = [{ $count: "count" }]
            const filteredData = await TrackData.find({}).skip(limit * pagination).limit(20).sort({ createdAt: -1 })
            res.json({ message: "1st", filteredData })
        }

        if (startDate === 0 && endDate === 0) {
            if (shipping_method !== "All Provider") {
                pipeline1 = [{ $match: { shipping_method } }]
            }

            if (company_name !== "All Company") {
                pipeline1 = [{ $match: { "from_address.company_name": company_name } }]
            }

            if (company_name !== "All Company" && shipping_method !== "All Provider") {
                pipeline1 = [{ $match: { $and: [{ "from_address.company_name": company_name }, { shipping_method }] } }]
            }
        }

        if (startDate != 0 && endDate != 0) {
            if (shipping_method === "All Provider" && company_name !== "All Company") {
                pipeline1 = [
                    {
                        $match: {
                            createdAt: {
                                $gte: s_date,
                                $lte: e_date,
                            },
                        },
                    },
                ]
            }

            if (shipping_method !== "All Provider" && company_name === "All Company") {
                pipeline1 = [
                    {
                        $match: {
                            shipping_method,
                            createdAt: {
                                $gte: s_date,
                                $lte: e_date,
                            },
                        },
                    },
                ]
            }

            if (company_name === "All Company" && shipping_method !== "All Provider") {
                pipeline1 = [
                    {
                        $match: {
                            createdAt: {
                                $gte: s_date,
                                $lte: e_date,
                            },
                        },
                    },
                ]
            }

            if (company_name !== "All Company" && shipping_method === "All Provider") {
                pipeline1 = [
                    {
                        $match: {
                            "from_address.company_name": company_name,
                            createdAt: {
                                $gte: s_date,
                                $lte: e_date,
                            },
                        },
                    },
                ]
            }

            if (company_name !== "All Company" && shipping_method !== "All Provider") {
                pipeline1 = [
                    {
                        $match: {
                            "from_address.company_name": company_name,
                            shipping_method,
                            createdAt: {
                                $gte: s_date,
                                $lte: e_date,
                            },
                        },
                    },
                ]
            }

            if (company_name === "All Company" && shipping_method === "All Provider") {
                pipeline1 = [
                    {
                        $match: {
                            createdAt: {
                                $gte: s_date,
                                $lte: e_date,
                            },
                        },
                    },
                ]
            }
        }

        const shipmentExport = await TrackData.aggregate(pipeline1);
        res.json({ shipmentExport })

    } catch (error) {
        logger.error(
            `Error while registering user with details ${JSON.stringify(
                req.body
            )} and error ${generateError(error)}`
        );
        return next(
            new APIError(
                ERROR_STATUS_CODE.INTERNAL_SERVER_ERROR_CODE,
                INTERNAL_SERVER_ERROR,
                error.message
            )
        );
    }
}


// TEST-----------------API


exports.CODV2buttonSearch = async (req, res, next) => {
    const data = req.body;
    let limit = 20;
    let { company_name, shipping_method, startDate, endDate, pagination } = data;
    if (!shipping_method) shipping_method = "All Provider"
    if (!company_name) company_name = "All Company"
    var s_date = new Date(Moment(startDate).add(1, 'day'));
    var e_date = new Date(Moment(endDate).add(2, 'day'));
    s_date.setHours(-18)
    e_date.setHours(-19);
    let count;
    let pipeline;
    console.log(company_name, shipping_method, startDate, endDate, pagination)
    try {
        if (company_name === "All Company" && shipping_method === "All Provider" && startDate === 0 && endDate === 0) {
            count = [{ $count: "count" }]
            const filteredData = await TrackData.find({}).skip(limit * pagination).limit(20).sort({ createdAt: -1 })
            res.json({ message: "1st", filteredData })
        }

        if (startDate === 0 && endDate === 0) {
            if (shipping_method !== "All Provider") {
                count = [{ $match: { shipping_method } }, { $count: "count" }]
                pipeline = [{ $match: { shipping_method } }, { $skip: limit * pagination }, { $limit: 20 }, { $sort: { createdAt: -1 } }]
            }

            if (company_name !== "All Company") {
                count = [{ $match: { "from_address.company_name": company_name } }, { $count: "count" }]
                pipeline = [{ $match: { "from_address.company_name": company_name } }, { $skip: limit * pagination }, { $limit: 20 }, { $sort: { createdAt: -1 } }]
            }

            if (company_name !== "All Company" && shipping_method !== "All Provider") {
                count = [{ $match: { $and: [{ "from_address.company_name": company_name }, { shipping_method }] } }, { $count: "count" }]
                pipeline = [{
                    $match: {
                        "from_address.company_name": company_name,
                        shipping_method,
                    }
                }, { $skip: limit * pagination }, { $limit: 20 }, { $sort: { createdAt: -1 } }]
            }
        }

        if (startDate != 0 && endDate != 0) {
            console.log("1st")
            if (shipping_method === "All Provider" && company_name !== "All Company") {
                count = [
                    {
                        $match: {
                            $or: [
                                { createdAt: { $gte: s_date, $lte: e_date } },
                                { t_delivery_date: { $gte: s_date, $lte: e_date } },
                                { $and: [{ fulfillment_status: "pending" }, { createdAt: { $lte: s_date } }] }
                            ]
                        },
                    }, { $count: "count" }];
                pipeline = [
                    {
                        $match: {
                            $or: [
                                { createdAt: { $gte: s_date, $lte: e_date } },
                                { t_delivery_date: { $gte: s_date, $lte: e_date } },
                                { $and: [{ fulfillment_status: "pending" }, { createdAt: { $lte: s_date } }] }
                            ]
                        },
                    },
                    {
                        $skip: limit * pagination
                    },
                    {
                        $limit: 20
                    },
                    {
                        $sort: { createdAt: -1 }
                    }
                ];
            }

            if (shipping_method !== "All Provider" && company_name === "All Company") {
                console.log("2st")

                count = [
                    {
                        $match: {
                            $and: [
                                { shipping_method },
                                {
                                    $or: [
                                        { createdAt: { $gte: s_date, $lte: e_date } },
                                        { t_delivery_date: { $gte: s_date, $lte: e_date } },
                                        { $and: [{ fulfillment_status: "pending" }, { createdAt: { $lte: s_date } }] }
                                    ]
                                }
                            ]
                        }
                    }, { $count: "count" }];
                pipeline = [
                    {
                        $match: {
                            $and: [
                                { shipping_method },
                                {
                                    $or: [
                                        { createdAt: { $gte: s_date, $lte: e_date } },
                                        { t_delivery_date: { $gte: s_date, $lte: e_date } },
                                        { $and: [{ fulfillment_status: "pending" }, { createdAt: { $lte: s_date } }] }
                                    ]
                                }
                            ]
                        }
                    },
                    {
                        $skip: limit * pagination
                    },
                    {
                        $limit: 20
                    },
                    {
                        $sort: { createdAt: -1 }
                    }
                ];
            }

            if (company_name === "All Company" && shipping_method !== "All Provider") {
                console.log("3st")

                count = [
                    {
                        $match: {
                            $or: [
                                { createdAt: { $gte: s_date, $lte: e_date } },
                                { t_delivery_date: { $gte: s_date, $lte: e_date } },
                                { $and: [{ fulfillment_status: "pending" }, { createdAt: { $lte: s_date } }] }
                            ]
                        },
                    }, { $count: "count" }];
                pipeline = [
                    {
                        $match: {
                            $or: [
                                { createdAt: { $gte: s_date, $lte: e_date } },
                                { t_delivery_date: { $gte: s_date, $lte: e_date } },
                                { $and: [{ fulfillment_status: "pending" }, { createdAt: { $lte: s_date } }] }
                            ]
                        },
                    },
                    {
                        $skip: limit * pagination
                    },
                    {
                        $limit: 20
                    },
                    {
                        $sort: { createdAt: -1 }
                    }
                ];
            }

            if (company_name !== "All Company" && shipping_method === "All Provider") {
                console.log("4st")
                count = [
                    {
                        $match: {
                            $and: [
                                { "from_address.company_name": company_name },
                                {
                                    $or: [
                                        { createdAt: { $gte: s_date, $lte: e_date } },
                                        { t_delivery_date: { $gte: s_date, $lte: e_date } },
                                        { $and: [{ fulfillment_status: "pending" }, { createdAt: { $lte: s_date } }] }
                                    ]
                                }
                            ]
                        }
                    }, { $count: "count" }];
                pipeline = [
                    {
                        $match: {
                            $and: [
                                { "from_address.company_name": company_name },
                                {
                                    $or: [
                                        { createdAt: { $gte: s_date, $lte: e_date } },
                                        { t_delivery_date: { $gte: s_date, $lte: e_date } },
                                        { $and: [{ fulfillment_status: "pending" }, { createdAt: { $lte: s_date } }] }
                                    ]
                                }
                            ]
                        }
                    },
                    {
                        $skip: limit * pagination
                    },
                    {
                        $limit: 20
                    },
                    {
                        $sort: { createdAt: -1 }
                    }
                ];
            }

            if (company_name !== "All Company" && shipping_method !== "All Provider") {
                console.log("5st")

                count = [
                    {
                        $match: {
                            $and: [
                                { "from_address.company_name": company_name },
                                { shipping_method },
                                {
                                    $or: [
                                        { createdAt: { $gte: s_date, $lte: e_date } },
                                        { t_delivery_date: { $gte: s_date, $lte: e_date } },
                                        { $and: [{ fulfillment_status: "pending" }, { createdAt: { $lte: s_date } }] }
                                    ]
                                }
                            ]
                        }
                    }, { $count: "count" }];
                pipeline = [
                    {
                        $match: {
                            $and: [
                                { "from_address.company_name": company_name },
                                { shipping_method },
                                {
                                    $or: [
                                        { createdAt: { $gte: s_date, $lte: e_date } },
                                        { t_delivery_date: { $gte: s_date, $lte: e_date } },
                                        { $and: [{ fulfillment_status: "pending" }, { createdAt: { $lte: s_date } }] }
                                    ]
                                }
                            ]
                        }
                    },
                    {
                        $skip: limit * pagination
                    },
                    {
                        $limit: 20
                    },
                    {
                        $sort: { createdAt: -1 }
                    }
                ];
            }

            if (company_name === "All Company" && shipping_method === "All Provider") {
                console.log("6st")

                count = [
                    {
                        $match: {
                            $or: [
                                { createdAt: { $gte: s_date, $lte: e_date } },
                                { t_delivery_date: { $gte: s_date, $lte: e_date } },
                                { $and: [{ fulfillment_status: "pending" }, { createdAt: { $lte: s_date } }] }
                            ]
                        },
                    }, { $count: "count" }];
                pipeline = [
                    {
                        $match: {
                            $or: [
                                { createdAt: { $gte: s_date, $lte: e_date } },
                                { t_delivery_date: { $gte: s_date, $lte: e_date } },
                                { $and: [{ fulfillment_status: "pending" }, { createdAt: { $lte: s_date } }] }
                            ]
                        },
                    },
                    {
                        $skip: limit * pagination
                    },
                    {
                        $limit: 20
                    },
                    {
                        $sort: { createdAt: -1 }
                    }
                ];
            }
        }

        const filteredData = await TrackData.aggregate(pipeline);
        const merchantCountCheck = await TrackData.aggregate(count);
        let merchantCount;
        if (merchantCountCheck.length === 0) {
            merchantCount = 0
        } else {
            merchantCount = merchantCountCheck[0].count
        }
        res.json({ filteredData, merchantCount })

    } catch (error) {
        logger.error(
            `Error while registering user with details ${JSON.stringify(
                req.body
            )} and error ${generateError(error)}`
        );
        return next(
            new APIError(
                ERROR_STATUS_CODE.INTERNAL_SERVER_ERROR_CODE,
                INTERNAL_SERVER_ERROR,
                error.message
            )
        );
    }
}


exports.CODV2buttonExportSearch = async (req, res, next) => {
    const data = req.body;
    let limit = 20;
    let { company_name, shipping_method, startDate, endDate, pagination } = data;
    if (!shipping_method) shipping_method = "All Provider"
    if (!company_name) company_name = "All Company"
    var s_date = new Date(Moment(startDate).add(1, 'day'));
    var e_date = new Date(Moment(endDate).add(2, 'day'));
    s_date.setHours(-18)
    e_date.setHours(-19);
    let count;
    let pipeline;
    try {
        if (company_name === "All Company" && shipping_method === "All Provider" && startDate === 0 && endDate === 0) {
            count = [{ $count: "count" }]
            const filteredData = await TrackData.find({}).sort({ createdAt: -1 })
            res.json({ message: "1st", filteredData })
        }

        if (startDate === 0 && endDate === 0) {
            if (shipping_method !== "All Provider") {
                count = [{ $match: { shipping_method } }, { $count: "count" }]
                pipeline = [{ $match: { shipping_method } }, { $sort: { createdAt: -1 } }]
            }

            if (company_name !== "All Company") {
                count = [{ $match: { "from_address.company_name": company_name } }, { $count: "count" }]
                pipeline = [{ $match: { "from_address.company_name": company_name } }, { $sort: { createdAt: -1 } }]
            }

            if (company_name !== "All Company" && shipping_method !== "All Provider") {
                count = [{ $match: { $and: [{ "from_address.company_name": company_name }, { shipping_method }] } }, { $count: "count" }]
                pipeline = [{
                    $match: {
                        "from_address.company_name": company_name,
                        shipping_method,
                    }
                }, { $sort: { createdAt: -1 } }]
            }
        }

        if (startDate != 0 && endDate != 0) {
            if (shipping_method === "All Provider" && company_name !== "All Company") {
                pipeline = [
                    {
                        $match: {
                            $or: [
                                { createdAt: { $gte: s_date, $lte: e_date } },
                                { t_delivery_date: { $gte: s_date, $lte: e_date } },
                                { $and: [{ fulfillment_status: "pending" }, { createdAt: { $lte: s_date } }] }
                            ]
                        },
                    },
                    {
                        $sort: { createdAt: -1 }
                    }
                ];
            }

            if (shipping_method !== "All Provider" && company_name === "All Company") {
                pipeline = [
                    {
                        $match: {
                            $and: [
                                { shipping_method },
                                {
                                    $or: [
                                        { createdAt: { $gte: s_date, $lte: e_date } },
                                        { t_delivery_date: { $gte: s_date, $lte: e_date } },
                                        { $and: [{ fulfillment_status: "pending" }, { createdAt: { $lte: s_date } }] }
                                    ]
                                }
                            ]
                        }
                    },
                    {
                        $sort: { createdAt: -1 }
                    }
                ];
            }

            if (company_name === "All Company" && shipping_method !== "All Provider") {
                pipeline = [
                    {
                        $match: {
                            $or: [
                                { createdAt: { $gte: s_date, $lte: e_date } },
                                { t_delivery_date: { $gte: s_date, $lte: e_date } },
                                { $and: [{ fulfillment_status: "pending" }, { createdAt: { $lte: s_date } }] }
                            ]
                        },
                    },
                    {
                        $sort: { createdAt: -1 }
                    }
                ];
            }

            if (company_name !== "All Company" && shipping_method === "All Provider") {
                pipeline = [
                    {
                        $match: {
                            $and: [
                                { "from_address.company_name": company_name },
                                {
                                    $or: [
                                        { createdAt: { $gte: s_date, $lte: e_date } },
                                        { t_delivery_date: { $gte: s_date, $lte: e_date } },
                                        { $and: [{ fulfillment_status: "pending" }, { createdAt: { $lte: s_date } }] }
                                    ]
                                }
                            ]
                        }
                    },
                    {
                        $sort: { createdAt: -1 }
                    }
                ];
            }

            if (company_name !== "All Company" && shipping_method !== "All Provider") {
                pipeline = [
                    {
                        $match: {
                            $and: [
                                { "from_address.company_name": company_name },
                                { shipping_method },
                                {
                                    $or: [
                                        { createdAt: { $gte: s_date, $lte: e_date } },
                                        { t_delivery_date: { $gte: s_date, $lte: e_date } },
                                        { $and: [{ fulfillment_status: "pending" }, { createdAt: { $lte: s_date } }] }
                                    ]
                                }
                            ]
                        }
                    },
                    {
                        $sort: { createdAt: -1 }
                    }
                ];
            }

            if (company_name === "All Company" && shipping_method === "All Provider") {
                pipeline = [
                    {
                        $match: {
                            $or: [
                                { createdAt: { $gte: s_date, $lte: e_date } },
                                { t_delivery_date: { $gte: s_date, $lte: e_date } },
                                { $and: [{ fulfillment_status: "pending" }, { createdAt: { $lte: s_date } }] }
                            ]
                        },
                    },
                    {
                        $sort: { createdAt: -1 }
                    }
                ];
            }
        }

        const filteredData = await TrackData.aggregate(pipeline);
        res.json({ filteredData })

    } catch (error) {
        logger.error(
            `Error while registering user with details ${JSON.stringify(
                req.body
            )} and error ${generateError(error)}`
        );
        return next(
            new APIError(
                ERROR_STATUS_CODE.INTERNAL_SERVER_ERROR_CODE,
                INTERNAL_SERVER_ERROR,
                error.message
            )
        );
    }
}