const mongoose = require("mongoose");

const MasterCreditPeriodSchema = mongoose.Schema(
    {
        f_sno: { type: String },
        f_creditperiod: { type: String },
        f_description: { type: String },
    },
    { collection: "t_creditperiod" }
);

module.exports = M_CREDITPERIOD = mongoose.model(
    "t_creditperiod",
    MasterCreditPeriodSchema
);