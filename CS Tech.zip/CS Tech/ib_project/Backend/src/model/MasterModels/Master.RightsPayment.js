const mongoose = require("mongoose");

const MasterRightsPaymentSchema = mongoose.Schema(
    {
        f_sno: { type: Boolean },
        f_hdfc: { type: Boolean },
        f_icici: { type: Boolean },
        f_ameriexp: { type: Boolean },
        f_cellpay: { type: Boolean },
        f_elecfund: { type: Boolean },
        f_paypall: { type: Boolean },
        f_ebs: { type: Boolean },
        f_payzippy: { type: Boolean },
        f_Mobikwik: { type: Boolean },
    },
    { collection: "t_rightspaymentgetway" }
);

module.exports = M_PAYMENTGATWAY = mongoose.model(
    "t_rightspaymentgetway",
    MasterRightsPaymentSchema
);