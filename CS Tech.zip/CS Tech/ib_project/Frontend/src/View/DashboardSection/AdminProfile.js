import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import { IoIosArrowBack } from "react-icons/io";
import { Link } from "react-router-dom";
import * as RB from "react-bootstrap";
import { getAdminInfo } from "../../Utils/api";
const AdminProfile = () => {
    const { userId } = useParams();
    const [AdminInfo, setAdminInfo] = useState({});
    useEffect(() => {
        const apiCall = async () => {
            const res = await getAdminInfo(userId);
            console.log(res.data);
            var userInfo = res.data;
            setAdminInfo(userInfo);

        };
        apiCall();
    }, [userId]);
    return (
        <div>
            <main className="main_afterlogin">
                <div>

                    <div className="row" style={{ paddingTop: "25px", margin: '0px' }}>

                        <RB.Col lg={12}>
                            <RB.Row className="rownew1">
                                <div className="tableHeader tableHeader1 search_new">
                                    <RB.Col lg={6} md={6} xs={7} className="table_span">
                                        <h3 className="page-title d-flex userv">
                                            <span>Admin Informationt</span>
                                        </h3>
                                    </RB.Col>
                                    <RB.Col lg={6} md={6} xs={5} className="table_span text-right">
                                        <RB.Button size="sm" variant="primary"
                                            className="btn_svg"
                                        >
                                            <Link to="/dashboard/home"><IoIosArrowBack /> BACK</Link>
                                        </RB.Button>
                                    </RB.Col>
                                </div>
                            </RB.Row>
                        </RB.Col>


                        <div className="col-md-12">
                            <div
                                className="box_detail"
                                style={{
                                    paddingLeft: "0px",
                                    paddingRight: "0px",
                                    borderRadius: "4px",
                                    paddingTop: "0px"
                                }}
                            >
                                <div className="page-header row no-gutters inside_header">
                                    <div className="col-md-12">
                                        <h3
                                            className="page-title"
                                            style={{
                                                color: "#000",
                                                marginBottom: "0px",
                                                paddingBottom: "0px",
                                                fontSize: "1.5rem",
                                            }}
                                        >
                                            Admin Basic Information
                                        </h3>
                                    </div>
                                </div>
                                <hr className="m-t-25 m-b-25" />
                                <form method="post">
                                    <div className="form-body">
                                        <div className="row">
                                            <div className="col-md-6 pr-50">
                                                <div className="form-group">
                                                    <label className="control-label">User ID :</label>
                                                    <div className="">
                                                        <input
                                                            className="form-control"
                                                            type="text"
                                                            name="CS_username"
                                                            placeholder="Enter user id"
                                                            value={AdminInfo.userid}

                                                        />
                                                    </div>
                                                </div>
                                            </div>

                                            <div className="col-md-6 pl-50">
                                                <div className="form-group">
                                                    <label className="control-label">
                                                        Username :
                                                    </label>
                                                    <div className="">
                                                        <input
                                                            className="form-control"
                                                            type="text"
                                                            placeholder="Enter usernamee"
                                                            name="username"
                                                            value={AdminInfo.username}

                                                        />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div className="row">
                                            <div className="col-md-6 pr-50">
                                                <div className="form-group">
                                                    <label className="control-label">Email Id :</label>
                                                    <div className="">
                                                        <input
                                                            className="form-control"
                                                            type="text"
                                                            name="emailID"
                                                            placeholder="Enter user id"
                                                            value={AdminInfo.email}
                                                        />
                                                    </div>
                                                </div>
                                            </div>

                                            <div className="col-md-6 pl-50">
                                                <div className="form-group">
                                                    <label className="control-label">
                                                        Password :
                                                    </label>
                                                    <div className="">
                                                        <input
                                                            className="form-control"
                                                            type="text"
                                                            placeholder="Enter usernamee"
                                                            name="username"
                                                            value={AdminInfo.password}

                                                        />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    )

}

export default AdminProfile;
