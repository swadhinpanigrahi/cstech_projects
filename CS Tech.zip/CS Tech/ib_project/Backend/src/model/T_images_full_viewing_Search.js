const mongoose = require("mongoose");

const T_images_full_viewing_Search_Schema = mongoose.Schema(
    {
        rownumber: { type: Number },
        keyword: { type: String },
        tc: { type: String },
        f_imgid: { type: String },
        f_sno: { type: Number },
        f_group: { type: Number },
        f_rank: { type: Number },
        f_rank1: { type: String },
        f_Orientation: { type: String },
        modelid: { type: String },
        f_imgtype: { type: String },
    },
    { collection: "T_images_full_viewing_Search" }
)

module.exports = T_images_full_viewing_Search = mongoose.model(
    "T_images_full_viewing_Search",
    T_images_full_viewing_Search_Schema
);
