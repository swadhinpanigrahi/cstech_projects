const mongoose = require("mongoose");

const MasterImageTypeSchema = mongoose.Schema(
    {
        f_sno: { type: Number },
        f_pricetypename: { type: String },
    },
    { collection: "t_pricetype" }
);

module.exports = M_IMAGETYPE = mongoose.model(
    "t_pricetype",
    MasterImageTypeSchema
);