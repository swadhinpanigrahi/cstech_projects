import React from "react";
import { Modal, Button, Row, Form, Col } from "react-bootstrap";
import DatePicker from "react-datepicker";

import "react-datepicker/dist/react-datepicker.css";

const FollowupCreateMoadal = ({
  FollowupCreate,
  FormData,
  setFormData,
  handleChange,
  onSubmit,
  setFollowupCreate,
  f_creationdate,
  setF_creationdate
}) => {
  const CloseFollowupCreateFrom = () => setFollowupCreate(false);
  return (
    <div>
      <Modal show={FollowupCreate} onHide={CloseFollowupCreateFrom} size="lg">
        <Modal.Header closeButton className="view_create">
          <Modal.Title style={{ fontWeight: "bold", fontSize: "22px" }}>
            Daily Sales Entry Follow Ups - Create
          </Modal.Title>
        </Modal.Header>
        <Modal.Body className="show-grid view_create">
          <Form>
            <Form.Group as={Row} controlId="formPlaintextEmail">
              <Col sm="6" className="right_mar">
                <Form.Label>Email</Form.Label>
                <Form.Control
                  text
                  readOnly
                  defaultValue={FormData.f_AlternateEmail}
                />
              </Col>
              <Col sm="6" className="left_mar">
                <Form.Label>Requirement followups</Form.Label>
                <Form.Control
                  as="select"
                  onChange={(e) => {
                    const data = { ...FormData };
                    data.f_status = e.target.value;
                    setFormData({ ...data });
                  }}
                  value={FormData.f_status}
                >
                  <option value="Open">Open</option>
                  <option value="Close">Close</option>
                  <option value="PClose">PClose</option>
                  <option value="Sold">Sold</option>
                  <option value="UpgradeSold">Upgrade Sold</option>
                  <option value="QPackSold">QPack Sold</option>
                  <option value="DQuerySold">DQuery Sold</option>
                  <option value="DPackSold">DPack Sold</option>
                  <option value="ExcludeSold">Exclude Sold</option>
                </Form.Control>
              </Col>
            </Form.Group>

            <Form.Group as={Row} controlId="exampleForm.ControlTextarea1">
              <Col sm="6" className="right_mar">
                <Form.Label>Description</Form.Label>
                <Form.Control
                  as="textarea" style={{ minHeight: "120px" }}
                  className="textarea"
                  name="discription"
                  onChange={handleChange}
                />
              </Col>
              <Col sm="6" className="left_mar">
                <div style={{ marginBottom: "1rem" }}>
                  <Form.Label>Followups by</Form.Label>
                  <Form.Control
                    as="select"
                    onChange={(e) => {
                      const data = { ...FormData };
                      data.f_followpby = e.target.value;
                      setFormData({ ...data });
                    }}
                  >
                    <option value={`${FormData.f_followpby}`}>
                      {FormData.f_followpby}
                    </option>
                    <option value="Email">Email</option>
                    <option value="Call">Call</option>
                  </Form.Control>
                </div>
                <div>
                  <Form.Label>State</Form.Label>
                  <Form.Control
                    as="select"
                    onChange={(e) => {
                      const data = { ...FormData };
                      data.f_State = e.target.value;
                      setFormData({ ...data });
                    }}
                  >
                    <option value={`${FormData.f_State}`}>
                      {FormData.f_State}
                    </option>


                    <option selected="selected" value="Delhi">Delhi</option>
                    <option value="Andaman and Nicobar Islands">Andaman and Nicobar Islands</option>
                    <option value="Andhra Pradesh">Andhra Pradesh</option>
                    <option value="Andhra Pradesh (New)">Andhra Pradesh (New)</option>
                    <option value="Arunachal Pradesh">Arunachal Pradesh</option>
                    <option value="Assam">Assam</option>
                    <option value="Bihar">Bihar</option>
                    <option value="Chandigarh">Chandigarh</option>
                    <option value="Chhattisgarh">Chhattisgarh</option>
                    <option value="Dadra and Nagar Haveli">Dadra and Nagar Haveli</option>
                    <option value="Daman and Diu">Daman and Diu</option>
                    <option value="Delhi">Delhi</option>
                    <option value="Goa">Goa</option>
                    <option value="Gujarat">Gujarat</option>
                    <option value="Haryana">Haryana</option>
                    <option value="Himachal Pradesh">Himachal Pradesh</option>
                    <option value="Jammu and Kashmir">Jammu and Kashmir</option>
                    <option value="Jharkhand">Jharkhand</option>
                    <option value="Karnataka">Karnataka</option>
                    <option value="Kerala">Kerala</option>
                    <option value="Lakshadweep">Lakshadweep</option>
                    <option value="Madhya Pradesh">Madhya Pradesh</option>
                    <option value="Maharashtra">Maharashtra</option>
                    <option value="Manipur">Manipur</option>
                    <option value="Meghalaya">Meghalaya</option>
                    <option value="Mizoram">Mizoram</option>
                    <option value="Nagaland">Nagaland</option>
                    <option value="Odisha">Odisha</option>
                    <option value="Other">Other</option>
                    <option value="Puducherry">Puducherry</option>
                    <option value="Punjab">Punjab</option>
                    <option value="Rajasthan">Rajasthan</option>
                    <option value="Sikkim">Sikkim</option>
                    <option value="Tamil Nadu">Tamil Nadu</option>
                    <option value="Telangana">Telangana</option>
                    <option value="Tripura">Tripura</option>
                    <option value="Uttar Pradesh">Uttar Pradesh</option>
                    <option value="Uttarakhand">Uttarakhand</option>
                    <option value="West Bengal">West Bengal</option>



                  </Form.Control>
                </div>
              </Col>
            </Form.Group>

            <Form.Group as={Row} controlId="formPlaintextPassword">
              <Col sm="6" className="right_mar">
                <Form.Label>How they came to know about IB</Form.Label>
                <Form.Control
                  as="select"
                  onChange={(e) => {
                    const data = { ...FormData };
                    data.f_IbOption = e.target.value;
                    setFormData({ ...data });
                  }}
                >
                  <option value={`${FormData.f_IbOption}`}>
                    {FormData.f_IbOption}
                  </option>

                  <option selected="selected" value="Sales">Sales</option>
                  <option value="Google">Google</option>
                  <option value="Word of Mouth">Word of Mouth</option>
                  <option value="Through Agency">Through Agency</option>
                  <option value="Newspaper">Newspaper</option>
                  <option value="Emailer">Emailer</option>
                  <option value="Afaq">Afaq</option>
                  <option value="Sales">Sales</option>
                  <option value="Know before">Know before</option>
                  <option value="Site">Site</option>
                  <option value="Seminar">Seminar</option>
                  <option value="From us">From us</option>
                  <option value="Others">Others</option>


                  {/* <option value="KnowBefore">Know before</option>
                  <option value="Google">Google</option>
                  <option value="Emailer">Emailer</option>
                  <option value="sales">Sales</option> */}
                </Form.Control>
              </Col>
              <Col sm="6" className="left_mar">
                <Form.Label>Company name</Form.Label>
                <Form.Control
                  type="text"
                  placeholder="Enter Company Name"
                  name="f_CompanyName"
                  value={FormData.f_CompanyName}
                  onChange={handleChange}
                />
              </Col>
            </Form.Group>

            <Form.Group as={Row} controlId="formPlaintextEmail">
              <Col sm="6" className="right_mar">
                <Form.Label>Followups Date</Form.Label>
                <DatePicker selected={f_creationdate} onChange={(date) => setF_creationdate(date)} />
                {/* <Form.Control
                  type="text"
                  placeholder="Enter Date"
                  name="f_creationdate"
                  value={Moment(FormData.f_creationdate).format("DD-MM-YYYY")}
                  onChange={handleChange}
                /> */}
              </Col>
              <Col sm="6" className="left_mar">
                <Form.Label>Contact NO.</Form.Label>
                <Form.Control
                  type="text"
                  placeholder="Enter Mobile Number"
                  name="f_MobileNo"
                  value={FormData.f_MobileNo}
                  onChange={handleChange}
                />
              </Col>
            </Form.Group>

            <Form.Group as={Row} controlId="formPlaintextEmail">
              <Col sm="6" className="right_mar">
                <Form.Label>Contact person</Form.Label>
                <Form.Control
                  type="text"
                  placeholder="Enter Contact Person"
                  name="f_Firstname"
                  value={FormData.f_Firstname}
                  onChange={handleChange}
                />
              </Col>
              <Col sm="6" className="left_mar">
                <Form.Label>Alternate Email</Form.Label>
                <Form.Control
                  type="email"
                  placeholder="Enter Alternative Email"
                  name="f_AlternateEmail"
                  value={FormData.f_AlternateEmail}
                  onChange={handleChange}
                />
              </Col>
            </Form.Group>

            <Form.Group as={Row} controlId="formPlaintextEmail">
              <Col sm="6" className="right_mar">
                <Form.Label>Requirement Type</Form.Label>
                <Form.Control
                  type="text"
                  placeholder="Enter Requirment Type"
                  name="f_RequirementType"
                  value={FormData.f_RequirementType}
                  onChange={handleChange}
                />
              </Col>
              {/* <Col sm="6" className="left_mar">
                <Form.Label>Order Id</Form.Label>
                <Form.Control
                  type="text"
                  placeholder="Enter Order ID"
                  name="orderid"
                  value={FormData.orderid}
                  onChange={handleChange}
                />
              </Col> */}
            </Form.Group>

            <Form.Group as={Row} controlId="formBasicCheckbox" style={{ marginBottom: "0px" }}>
              <Col sm="6" className="right_mar">
                <Form.Label>Important follow ups</Form.Label>
                <Form.Check type="checkbox" />
              </Col>
              <Col sm="6" className="left_mar">
                <Form.Label>Created by</Form.Label>
                <Form.Control
                  plaintext
                  readOnly
                  defaultValue="admin"
                />
              </Col>
            </Form.Group>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button size="sm" variant="primary" onClick={onSubmit}>
            SUBMIT
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
};

export default FollowupCreateMoadal;
