import React, { useState, useEffect } from 'react';
import * as RB from 'react-bootstrap';
import { MdAddCircleOutline } from 'react-icons/md';
import { RiDeleteBin6Line } from "react-icons/ri";
import { IoCreateSharp } from 'react-icons/io5';
import { BiCommentEdit } from "react-icons/bi";
import SubscriptionModal from "../../../Components/Models/MasterModals/SubscriptionModal";
import ExpiryEmailModal from "../../../Components/Models/MasterModals/ExpiryEmailModal";
import EditSubscriptionplan from "../../../Components/Models/MasterModals/MasterEdit/EditSubscriptionplan"

import {
  GET_SUBSCRIPTIONPLANLIST, GET_SUBPLANDETAIL, REMOVE_SUBPLANDDETAIL
} from "../../../Utils/api";

import PaginationComponent from "../../../Components/Common/PaginationComponent";

import Modal from "../../../Components/Common/Modal";

export const SubscriptionPlanList = () => {
  const [currentPage, setCurrentPage] = useState(1);
  const [itemPerPage, setItemPerPage] = useState(20);
  let [searchData, setSearchData] = useState("");
  const [TotalCount, setTotalCount] = useState(0);

  const [SubscriptionList, setSubscriptionList] = useState([]);
  const [UserData, setUserData] = useState({});
  const [Loading, setLoading] = useState(false)


  const [isOpen, setIsOpen] = useState(false);
  const [ModelMsg, setModelMsg] = useState("");
  const [show_subscriptiomvideo, setShow] = useState(false);
  const [edit_subscriptionplan, setEdit] = useState(false)
  const [show_subscriptionedit, subscriptioneditShow] = useState(false);

  const subscriptionmodalShow = () => setShow(true);  //M

  const subscriptioeditClose = () => subscriptioneditShow(false);  //M
  const subscriptioneditmodalShow = () => subscriptioneditShow(true);  //M

  const SearchDataFun = async (e) => {
    setSearchData(e.target.value);
    const res = await GET_SUBSCRIPTIONPLANLIST(currentPage, itemPerPage, (searchData = e.target.value));
    let { data, totalrecord } = res;
    setSubscriptionList(data);
    totalrecord.length === 1
      ? setTotalCount(totalrecord[0].totalcount)
      : setTotalCount(0);
  }

  const EditSubsriptionAction = async (id) => {
    const res = await GET_SUBPLANDETAIL(id);
    let { subscriptionplandetail } = res;
    console.log(subscriptionplandetail)
    setUserData(subscriptionplandetail)
    setEdit(true)
  }

  const modelSet = async () => {
    setIsOpen(true);
  };

  const RemoveSubscription = async (id) => {
    const res = await REMOVE_SUBPLANDDETAIL(id);
    const { message } = res;
    apiCall();
    setModelMsg(message);
    modelSet()
  }

  const apiCall = async () => {
    setLoading(true)
    const res = await GET_SUBSCRIPTIONPLANLIST(currentPage, itemPerPage, searchData);
    let { data, totalrecord } = res;
    setSubscriptionList(data);
    setTotalCount(totalrecord[0].totalcount)
    setLoading(false)
  }

  useEffect(() => {
    apiCall()
  }, [currentPage, itemPerPage]);

  return (
    <RB.Row className="rownew1">
      <RB.Col lg={12}>
        <RB.Row className="rownew1" style={{ paddingTop: "25px" }}>
          <div className="tableHeader tableHeader1 order_btntable">
            <RB.Col md={6} xs={12} className="table_span">
              <h3 className="page-title d-flex userv">
                <span>Search Results</span>
              </h3>
            </RB.Col>
            <RB.Col md={6} xs={12} className="table_span">
              <div className="float-right responsive_floatbtn">
                <RB.Button size="sm" variant="primary" className="btn_svg" onClick={subscriptionmodalShow}
                >
                  <MdAddCircleOutline style={{ marginRight: "3px" }} />
                  ADD NEW RECORDS
                </RB.Button>
              </div>
            </RB.Col>
          </div>
        </RB.Row>
      </RB.Col>

      <RB.Col lg={12}>
        <div className="box_detail" style={{ borderRadius: "4px" }}>
          <div className="page-header row">
            <RB.Col md={12}>
              <RB.Form className="manage_searchorder">
                <RB.Row className="mg_row0">
                  <RB.Col lg={12} md={12} className="customer_leftsrh">
                    <RB.Row className="mg_row0">
                      <RB.Col lg={3} md={3} className="customer_sdate">
                        <RB.Form.Group>
                          <RB.Form.Control
                            id="searchText"
                            type="text"
                            placeholder="Search by Text"
                            onChange={SearchDataFun}
                          />
                        </RB.Form.Group>
                      </RB.Col>
                    </RB.Row>
                  </RB.Col>

                </RB.Row>
              </RB.Form>
            </RB.Col>
          </div>
        </div>
      </RB.Col>

      <RB.Col lg={12}>
        <RB.Row className="rownew1">
          <div className="tableHeader tableHeader1 search_new">
            <RB.Col lg={6} md={6} className="table_span">
              <h3 className="page-title d-flex userv">
                <span>Subscription Plan List</span>
              </h3>
            </RB.Col>
            <RB.Col lg={6} md={6} className="table_span total_recordt">
              <span>Total Records: {TotalCount}</span>
            </RB.Col>
          </div>
        </RB.Row>
        <div
          className="box_detail table_boxdtl manage_order"
          style={{}}
        >
          <RB.Table striped bordered hover variant="dark" responsive>
            <thead>
              <tr class="vtable">
                <th className="text-center">S. No.</th>
                <th className="">Plan Name</th>
                <th className="">Plan Type</th>
                <th className="">Max Allowed</th>
                <th className="">Period in Days</th>
                <th className="">Amount(INR)</th>
                <th className="">Total No.Images</th>
                <th className="">Savings</th>
                <th className="text-center">Expiry Email</th>
                <th className="text-center action_align">Action</th>
              </tr>
            </thead>
            <tbody>
              {Loading ? <tr><td className="no_records" colSpan="11">Loading...</td></tr> : SubscriptionList.length > 0 ? SubscriptionList.map((info, inx) => {
                return (
                  <tr key={`SUBSCRIPTIONPLANLIST_${inx}`}>
                    <td className="s_notm text-center">{inx + 1}</td>
                    <td className="subscription_plan">{info.f_planname}</td>
                    <td className="">{info.f_imageType}</td>
                    <td className="subscription_plan">{info.f_maxallowed}</td>
                    <td className="">{info.f_periodindays}</td>
                    <td className="">{info.f_amount}</td>
                    <td className="">{info.f_totimg}</td>
                    <td className="">{info.f_save}</td>
                    <td className="td_comments text-center">
                      <IoCreateSharp title="Create" onClick={subscriptioneditmodalShow} />
                    </td>
                    <td className="td_comments text-center">
                      <BiCommentEdit title="Edit Plan" onClick={() => EditSubsriptionAction(info._id)} />
                      <RiDeleteBin6Line title="Delete Plan" className="text-danger1"
                        onClick={() => RemoveSubscription(info._id)}
                      />
                    </td>
                  </tr>
                )
              }) : <tr><td className="no_records" colSpan="11">No Records Found</td></tr>}
            </tbody>
          </RB.Table>
        </div>

        <PaginationComponent
          MOCK_DATA={TotalCount}
          currentPage={currentPage}
          setCurrentPage={setCurrentPage}
          itemPerPage={itemPerPage}
          setItemPerPage={setItemPerPage}
        />

      </RB.Col>

      <SubscriptionModal
        show_subscriptiomvideo={show_subscriptiomvideo}
        setShow={setShow}
        apiCall={apiCall}
        setModelMsg={setModelMsg}
        modelSet={modelSet}
      />

      <EditSubscriptionplan
        edit_subscriptionplan={edit_subscriptionplan}
        setEdit={setEdit}
        UserData={UserData}
        apiCall={apiCall}
      />

      <ExpiryEmailModal
        show_subscriptionedit={show_subscriptionedit}
        subscriptioeditClose={subscriptioeditClose}
      />

      <Modal text={ModelMsg} open={isOpen} onClose={() => setIsOpen(false)} />


    </RB.Row>


  )
}

export default SubscriptionPlanList