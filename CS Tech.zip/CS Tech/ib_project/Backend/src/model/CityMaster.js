const mongoose = require("mongoose");

const CityMasterDB = mongoose.Schema(
    {
        id: { type: String },
        name: { type: String },
        state_id: { type: String },
    },
    { collection: "CityMaster" }
);

module.exports = CityMasterSchema = mongoose.model(
    "CityMaster",
    CityMasterDB
);