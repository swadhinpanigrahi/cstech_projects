const mongoose = require("mongoose");

const stateSchema = mongoose.Schema(
  {
    ID: { type: Number },
    Name: { type: String },
    CountryID: { type: Number }
  },
  { collection: "StateMaster" }
);

module.exports = StateSchema = mongoose.model(
  "StateMaster",
  stateSchema
);
