import React from "react";
import footerlogo from "../../Images/footerlogo.png";

const Footer = () => {
    return (
        <footer className="footer">
            <div className="container-fluid">
                <div className="row">
                    <div className="col-md-8" id="copytext">
                        copyright © 2021 www.storagestation.net, all rights reserved
                    </div>
                    <div className="col-md-4" id="imgfooter">
                        <img src={footerlogo} alt="footer-logo" />
                    </div>
                </div>
            </div>
        </footer>
    );
};

export default Footer;
