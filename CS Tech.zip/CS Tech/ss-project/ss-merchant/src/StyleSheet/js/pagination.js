$('.page-item1').click(function(){
    var className = $(this).attr('class');
    if(className != "active"){
      $('.page-item1').removeClass('active')
      $(this).addClass('active')
    }
  });
   $('prev').click(function(){
   
   });