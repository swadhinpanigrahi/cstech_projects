import React, { useState, useEffect } from 'react';
import { Modal, Form, Row, Col, Button } from "react-bootstrap";

const EditImage = ({ showEditModal, setShowEditModal, ImageDetail, apiCall }) => {
    const [FormData, setFormData] = useState({});

    const closeModal = () => {
        setShowEditModal(false);
    }

    const editFun = async () => {
        console.log(FormData)
    }

    useEffect(() => {
        setFormData(ImageDetail)
    }, [ImageDetail]);

    return (
        <>
            <Modal
                show={showEditModal}
                onHide={closeModal}
                backdrop="static"
                keyboard={false}
                className="edit_imgm"
            >
                <Modal.Header closeButton>
                    <Modal.Title>Edit Image</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <Form>
                        <Form.Group as={Row} className="mb-3" controlId="formPlaintextPassword">
                            <Form.Label column sm="4">
                                Image Name :
                            </Form.Label>
                            <Col sm="8">
                                <Form.Control type="text"
                                    placeholder="Image Name"
                                    value={FormData.F_imgid}
                                />
                            </Col>
                        </Form.Group>
                        <Form.Group as={Row} className="mb-3" controlId="formPlaintextPassword">
                            <Form.Label column sm="4">
                                Image Type :
                            </Form.Label>
                            <Col sm="8">
                                <Form.Control as="select"
                                    placeholder="Image Name"
                                    value={FormData.f_imgType}
                                >
                                    <option>I</option>
                                    <option>S</option>
                                </Form.Control>
                            </Col>
                        </Form.Group>
                        <Form.Group as={Row} className="mb-3" controlId="formPlaintextPassword">
                            <Form.Label column sm="4">
                                Image Rank :
                            </Form.Label>
                            <Col sm="8">
                                <Form.Control type="number"
                                    placeholder="Image Name"
                                    value={FormData.F_rank}
                                />
                            </Col>
                        </Form.Group>
                        <Form.Group as={Row} className="mb-3" controlId="formPlaintextPassword">
                            <Form.Label column sm="4">
                                Pricing Mode :
                            </Form.Label>
                            <Col sm="8">
                                <Form.Control type="number"
                                    placeholder="Image Name"
                                    value={FormData.f_pricing}
                                />
                            </Col>
                        </Form.Group>
                        <Form.Group as={Row} className="mb-3" controlId="formPlaintextPassword">
                            <Form.Label column sm="4">
                                Rank :
                            </Form.Label>
                            <Col sm="8">
                                <Form.Control type="text"
                                    placeholder="Image Name"
                                    value={FormData.f_rank1}
                                />
                            </Col>
                        </Form.Group>
                    </Form>
                    <Row>
                        <Col sm={4}></Col>
                        <Col sm={8}>
                        <Button size="sm" variant="primary" onClick={editFun}>SUBMIT</Button>
                        </Col>
                    </Row>
                </Modal.Body>
            </Modal>
        </>
    )
}

export default EditImage
