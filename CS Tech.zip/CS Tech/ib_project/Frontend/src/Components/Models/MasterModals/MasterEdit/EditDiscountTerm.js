import React, { useState, useEffect } from 'react';
import * as RB from "react-bootstrap";
import { Row } from "react-bootstrap";
import { UPDATE_DISCOUNTTERMDETAIL } from "../../../../Utils/api"

const EditDiscountTerm = (
    { show_discountterm, setEdit, userData, apiCall }
) => {
    const [FormData, setFormData] = useState({});

    const handleChange = (e) => {
        let { name, value } = e.target;
        const data = { ...FormData }
        data[name] = value
        setFormData(data)
    }

    const closeModal = () => {
        setEdit(false)
    }

    const editDiscountTerm = async () => {
        const res = await UPDATE_DISCOUNTTERMDETAIL(FormData);
        let { message } = res;
        if (message) {
            apiCall()
            setEdit(false)
        }
    }

    useEffect(() => {
        setFormData(userData)
    }, [userData])
    return (
        <div>
            <RB.Modal show={show_discountterm} onHide={closeModal} className="ordermanage_modal">
                <RB.Modal.Header closeButton>
                    <RB.Modal.Title>Edit Discount Term</RB.Modal.Title>
                </RB.Modal.Header>
                <RB.Modal.Body>
                    <RB.Row>
                        <RB.Col lg={12} md={12}>
                            <RB.Row>
                                <RB.Col lg={12} md={12}>
                                    <RB.Form>
                                        <RB.Form.Group as={Row} controlId="Country_id">
                                            <RB.Col lg={4} md={4}>
                                                <RB.Form.Label>Name :</RB.Form.Label>
                                            </RB.Col>
                                            <RB.Col lg={7} md={8}>
                                                <RB.Form.Control
                                                    type="text"
                                                    name="f_discountterm"
                                                    value={FormData.f_discountterm}
                                                    onChange={handleChange}
                                                />
                                            </RB.Col>
                                        </RB.Form.Group>
                                        <RB.Form.Group as={Row} controlId="Country_id">
                                            <RB.Col lg={4} md={4}>
                                                <RB.Form.Label>Description :</RB.Form.Label>
                                            </RB.Col>
                                            <RB.Col lg={7} md={8}>
                                                <RB.Form.Control
                                                    as="textarea"
                                                    name="f_description"
                                                    value={FormData.f_description}
                                                    onChange={handleChange}
                                                />
                                            </RB.Col>
                                        </RB.Form.Group>
                                        <RB.Row>
                                            <RB.Col lg={4} md={4}></RB.Col>
                                            <RB.Col lg={6} md={7}>
                                                <RB.Button
                                                    size="sm" variant="primary"
                                                    onClick={editDiscountTerm}
                                                >
                                                    UPDATE
                                                </RB.Button>
                                            </RB.Col>
                                        </RB.Row>
                                    </RB.Form>
                                </RB.Col>
                            </RB.Row>
                        </RB.Col>
                    </RB.Row>
                </RB.Modal.Body>
            </RB.Modal>
        </div>
    )
}

export default EditDiscountTerm