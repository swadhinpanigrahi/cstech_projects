const ImageVideoSubscription = require("express").Router();
const {
    addImageVideoDetail, getImageVideoList, getImageVideoDetail, editImageVideoDetail, deleteImageVideoDetail
} = require("../../controllers/Master/master.imagevideosubscription.controller");

ImageVideoSubscription.route("/addimagevediosubscription").post(addImageVideoDetail)
ImageVideoSubscription.route("/getimagevideolist").get(getImageVideoList)
ImageVideoSubscription.route("/getimagevideodetail/:_id").get(getImageVideoDetail)
ImageVideoSubscription.route("/editimagevideodetail").post(editImageVideoDetail)
ImageVideoSubscription.route("/deleteimagevideodetail/:_id").get(deleteImageVideoDetail)

module.exports = ImageVideoSubscription;