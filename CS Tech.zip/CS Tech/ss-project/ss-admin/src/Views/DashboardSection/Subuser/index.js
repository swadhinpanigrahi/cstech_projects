import React from 'react';
import { Route } from "react-router-dom"
import SubuserList from './SubuserList';
import AddSubuser from './AddSubuser';
import SubuserPermission from './SubuserPermission';
import EditSubuser from './EditSubuser'

const SubUser = () => {
    return (
        <div>
            <Route path="/dashboard/subuser/get" component={SubuserList} />
            <Route path="/dashboard/subuser/add" component={AddSubuser} />
            <Route path="/dashboard/subuser/permission/:_id" component={SubuserPermission} />
            <Route path="/dashboard/subuser/editsubadmin/:_id" component={EditSubuser} />
        </div>
    )
}

export default SubUser;
