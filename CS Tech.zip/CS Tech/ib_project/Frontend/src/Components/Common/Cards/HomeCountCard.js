import React from "react";

const HomeCountCard = ({ icon, header, count }) => {
  return (
    <div className="box_detail">
      <h3 className="card_details">
        <span>
          <img src={icon} alt={icon} className="imgm" />
        </span>
        {header}
      </h3>
      <div className="lineb"></div>
      <div className="text-center maint">
        <h1 className="maintcount">{count}</h1>
      </div>
    </div>
  );
};

export default HomeCountCard;
