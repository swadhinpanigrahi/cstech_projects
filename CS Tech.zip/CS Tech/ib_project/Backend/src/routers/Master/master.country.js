const Country = require("express").Router();
const {
    getCountrys, getCountryList, getCountryDetail,
    addCountryDetail, editCountryDetail, deleteCountryDetail
} = require("../../controllers/Master/master.country.controller")

Country.route(`/getcountrys`).get(getCountrys);
Country.route(`/getcountrylist`).get(getCountryList);
Country.route(`/getcountrydetail/:_id`).get(getCountryDetail);
Country.route(`/addcountrydetail`).post(addCountryDetail);
Country.route(`/editcountrydetail`).post(editCountryDetail);
Country.route(`/deletecountrydetail/:_id`).get(deleteCountryDetail);

module.exports = Country;