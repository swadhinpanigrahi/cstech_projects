const express = require("express")

const { createValidator } = require("express-joi-validation")
//validatores
// import { createCustomerValidetor, updateCustomerValidetor } from '../validators/Admin.Validator'
const { createCustomerValidetor, updateCustomerValidetor } = require("../validators/Admin.Validator")

//middlewares
// import { generateJwtToken } from "../middlewares/Auth.middleware";
const { generateJwtToken } = require("../middlewares/Auth.middleware")
//controllers
const {
    getshipment15daysrecords,
    getCustomerDetailsList, createCustomer, getCustomerDetail, updateCustomerDetail,
    searchBarDropdown, getTrakingDetails, getTrakingDetailsView, getTrakingDetailsByButtonSearch, CODbuttonSearch,
    createPayment, getCustomerAmount, getPaymentSatelments, paymentDateFilter, paymentDateFilterV2,
    getCustomerOutstanding, getCustomerOutstandingV2, getCustomerOutstandingNew,
    accountDeactivate,
    totalCounts,
    shipmentListForAllExport, shipmentFilterByButtonExport, CODbuttonSearchForExport,
    CODV2buttonSearch, CODV2buttonExportSearch
} = require("../controllers/Admin.Controller")

const validator = createValidator({ passError: true });
const adminRoutes = express.Router();

adminRoutes.route('/getshipment15daysrecords').get(generateJwtToken, getshipment15daysrecords);

adminRoutes.route('/getcustomerlist').get(generateJwtToken, getCustomerDetailsList);
adminRoutes.route('/createcustomer').post(validator.body(createCustomerValidetor), generateJwtToken, createCustomer);
adminRoutes.route('/getcustomer/:_id').get(generateJwtToken, getCustomerDetail);
adminRoutes.route('/updatecustomer/:_id').post(validator.body(updateCustomerValidetor), generateJwtToken, updateCustomerDetail);

adminRoutes.route('/shipdropdata').get(generateJwtToken, searchBarDropdown);
adminRoutes.route('/trakingdetails').get(generateJwtToken, getTrakingDetails);
adminRoutes.route('/trakingdetailsview/:tracking_number').get(generateJwtToken, getTrakingDetailsView);
adminRoutes.route('/trakingdetailsearchbybutton').post(generateJwtToken, getTrakingDetailsByButtonSearch);
adminRoutes.route('/trakingCODdetailsearchbybutton').post(generateJwtToken, CODbuttonSearch);

adminRoutes.route('/createpayment').post(generateJwtToken, createPayment);
adminRoutes.route('/paymentamtandname/:_id').get(generateJwtToken, getCustomerAmount);
adminRoutes.route('/getpaymentsatelments/:_id').get(generateJwtToken, getPaymentSatelments);
adminRoutes.route('/getpaymentdetailsbydatefilter/:_id').post(generateJwtToken, paymentDateFilter);
adminRoutes.route('/getpaymentdetailsbydatefilterV2/:_id').post(generateJwtToken, paymentDateFilterV2);

adminRoutes.route('/getoutstandingreports').get(generateJwtToken, getCustomerOutstanding);
adminRoutes.route('/getoutstandingreportsv2').get(generateJwtToken, getCustomerOutstandingV2);
adminRoutes.route('/getoutstandingreportsnew').post(generateJwtToken, getCustomerOutstandingNew);

adminRoutes.route('/customerdeactivation/:_id').get(generateJwtToken, accountDeactivate);

adminRoutes.route('/datacount').get(generateJwtToken, totalCounts);

adminRoutes.route('/allexportslist').get(generateJwtToken, shipmentListForAllExport);

adminRoutes.route('/shipmentbuttonsearch').post(generateJwtToken, shipmentFilterByButtonExport);
adminRoutes.route('/shipmentCODbuttonsearch').post(generateJwtToken, CODbuttonSearchForExport);

//TEST
adminRoutes.route('/trakingCODV2detailsearchbybutton').post(generateJwtToken, CODV2buttonSearch);
adminRoutes.route('/shipmentCODV2buttonsearch').post(generateJwtToken, CODV2buttonExportSearch);




module.exports = adminRoutes