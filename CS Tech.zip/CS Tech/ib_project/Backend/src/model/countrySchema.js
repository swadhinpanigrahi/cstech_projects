const mongoose = require("mongoose");

const conSchema = mongoose.Schema(
  {
    ID: { type: Number },
    Name: { type: String },
    CountryCode: { type: String }
  },
  { collection: "CountryMaster" }
);

module.exports = CountrySchema = mongoose.model(
  "CountryMaster",
  conSchema
);
