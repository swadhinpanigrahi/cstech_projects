exports.errorHandler = (err, req, res, next) => {
  if (err && err.error && err.error.isJoi) {
    res.json({
      status: 400,
      message: err.error.message,
    });
  } else if (err.status === 500) {
    res.json({ ...err });
  } else {
    res.json({ ...err });
  }
};
