import React, { useState } from "react";
import { Row, Col, Button } from "react-bootstrap";
import { useParams, Link } from "react-router-dom";
import { IoIosArrowBack } from "react-icons/io";

import FollowupCreateMoadal from "../../Components/Models/FollowupModals/FollowupCreateMoadal";
import FollowupListModal from "../../Components/Models/FollowupModals/FollowupListModal";
import ProposalViewModal from "../../Components/Models/ProposalModals/ProposalViewModal";

import Modal from "../../Components/Common/Modal"

import {
  RegisterUserTable,
  RegisterCompanyTable,
  OrderTable,
  ProposalTable,
  FollowupTable,
} from "../../Components/Common/Tables/Tables";

import {
  getFollowupsDetails, getFollowupsDetailsTable, postNextFollowup, deleteProposalDetail
} from "../../Utils/api";


const UsersearchViewAll = ({
  search,
  CustomerData,
  OrderData,
  spanOrder,
  ProposelData,
  Followups,
  spanArr,
}) => {
  const { tbl_name } = useParams();
  const [f_sno, setId] = useState("");
  const [followFilterData, setFollowFilterData] = useState(Followups);
  const [T_orderid, setT_orderid] = useState("");
  const [ProposalView, setProposalView] = useState(false);
  const [FollowupCreate, setFollowupCreate] = useState(false);
  const [followTable, setFollowTable] = useState([]);
  const [FollowupList, setFollowupList] = useState(false);
  const [FormData, setFormData] = useState({
    f_sno,
    f_EmailID: "",
    f_CompanyName: "",
    f_creationdate: "",
    f_MobileNo: "",
    f_Firstname: "",
    f_AlternateEmail: "",
    f_RequirementType: "",
    orderid: "",
    f_status: "",
    f_followpby: "",
    f_State: "",
    f_IbOption: "",
    f_createdby: "",
  });

  const [isOpen, setIsOpen] = useState(false);
  const [ModelMsg, setModelMsg] = useState("");

  const handleChange = (e) => {
    setFormData({ ...FormData, [e.target.name]: e.target.value });
  };

  const FollowupListOpen = async (f_sno) => {
    const res = await getFollowupsDetailsTable(f_sno);
    const { followupsData } = res;
    setFollowTable(followupsData);
    setFollowupList(true);
  };

  const openFilter = (name) => {
    if (name === "Open") {
      const shaloFollowUpData = [...Followups];
      const FollowUpfilterData = shaloFollowUpData.filter(
        (data) => data.f_followups_status === "Open"
      );
      setFollowFilterData([...FollowUpfilterData]);
    }
    if (name === "Close") {
      const shaloFollowUpData = [...Followups];
      const FollowUpfilterData = shaloFollowUpData.filter(
        (data) => data.f_followups_status === "Close"
      );
      setFollowFilterData([...FollowUpfilterData]);
    }
    if (name === "Sold") {
      const shaloFollowUpData = [...Followups];
      const FollowUpfilterData = shaloFollowUpData.filter(
        (data) => data.f_followups_status === "Sold"
      );
      setFollowFilterData([...FollowUpfilterData]);
    }
  };

  const FollowupCreateSubmit = async (f_sno) => {
    setId(f_sno);
    const res = await getFollowupsDetails(f_sno);
    const { followupsData } = res;
    setFormData({
      f_sno,
      f_EmailID: followupsData.f_EmailID,
      f_CompanyName: followupsData.f_CompanyName,
      f_creationdate: followupsData.f_creationdate,
      f_MobileNo: followupsData.f_MobileNo,
      f_Firstname: followupsData.f_Firstname,
      f_AlternateEmail: followupsData.f_AlternateEmail,
      f_RequirementType: followupsData.f_RequirementType,
      orderid: followupsData.orderid,
      f_status: "",
      f_followpby: followupsData.f_followpby,
      f_State: followupsData.f_State,
      f_IbOption: followupsData.f_IbOption,
      f_createdby: followupsData.f_createdby,
    });
    setFollowupCreate(true);
  };

  const GetProposalId = (T_orderid) => {
    console.log("Get from proposal", T_orderid);
    setT_orderid(T_orderid);
    setProposalView(true);
  };

  const onSubmit = async (e) => {
    e.preventDefault();
    const res = await postNextFollowup(FormData);
    const { message, error } = res;
    if (!error && message === "added successfully") {
      setTimeout(() => {
        setFollowupCreate();
      }, 1000);
    } else {
      console.log(error);
    }
  };

  const PROPOSAL_DELETE_FUNCTION = async (T_orderid) => {
    const res = await deleteProposalDetail(T_orderid);
    let { status, message } = res;
    if (status === 200) {
      // await GET_API()
      setModelMsg(message)
      modelSet()
    } else {
      setModelMsg(message)
      modelSet()
    }
  }

  const modelSet = () => {
    setIsOpen(true);
  };



  return (
    <Row style={{ paddingTop: "30px" }} className="rownew1">
      <Col lg={12}>
        <div className="box_detail" style={{ borderRadius: "4px" }}>
          <div className="page-header row">
            <Col md={12}>
              <h3
                className="page-title"
                style={{ fontWeight: "bold", fontSize: "24px" }}
              >
                Search Results -{" "}
                <span style={{ color: "#0081ad" }}>"{search}"</span>
              </h3>
            </Col>
          </div>

        </div>
      </Col>
      <Col lg={12}>

      </Col>

      {tbl_name === "user" ? (
        <RegisterUserTable REG_BODY={CustomerData} isView={false} />
      ) : tbl_name === "orders" ? (
        <OrderTable
          ORDER_BODY={OrderData}
          isView={false}
          spanOrder={spanOrder}
        />
      ) : tbl_name === "proposal" ? (
        <ProposalTable
          PROPOSAL_BODY={ProposelData}
          isView={false}
          GetProposalId={GetProposalId}
          PROPOSAL_DELETE_FUNCTION={PROPOSAL_DELETE_FUNCTION}
        />
      ) : tbl_name === "followup" ? (
        <FollowupTable
          FOLLOWUP_BODY={followFilterData}
          isView={false}
          spanArr={spanArr}
          openFilter={openFilter}
          FollowupCreateSubmit={FollowupCreateSubmit}
          FollowupListOpen={FollowupListOpen}
        />
      ) : (
        <RegisterCompanyTable REG_BODY={CustomerData} isView={false} />
      )}

      <FollowupCreateMoadal
        FollowupCreate={FollowupCreate}
        setFollowupCreate={setFollowupCreate}
        setFormData={setFormData}
        handleChange={handleChange}
        onSubmit={onSubmit}
        FormData={FormData}
      />

      <FollowupListModal
        FollowupList={FollowupList}
        setFollowupList={setFollowupList}
        followTable={followTable}
      />

      <ProposalViewModal
        ProposalView={ProposalView}
        setProposalView={setProposalView}
        T_orderid={T_orderid}
      />

      <Modal
        text={ModelMsg}
        open={isOpen}
        onClose={() => setIsOpen(false)}
      />
    </Row>
  );
};

export default UsersearchViewAll;
