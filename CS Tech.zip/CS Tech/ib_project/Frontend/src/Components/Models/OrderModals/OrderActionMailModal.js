import React from 'react';
import * as RB from "react-bootstrap";
import { Form, Row, Button } from "react-bootstrap"

const OrderActionMailModal = (
    { show6, handleClose6, orderId, paymentUsername, handleChange, sendEmailFun }
) => {
    return (
        <>
            <RB.Modal show={show6} onHide={handleClose6} id="Sendmail_modal">
                <RB.Modal.Header closeButton>
                    <RB.Modal.Title>Send Mail</RB.Modal.Title>
                </RB.Modal.Header>
                <form>
                    <RB.Modal.Body className="">
                        <RB.Row>
                            <RB.Col lg={6} md={6}>
                                <p><strong>Order Number: </strong> {orderId}</p>
                            </RB.Col>
                            <RB.Col lg={6} md={6}>
                                <div className="float-right">
                                    <p><strong>User Name: </strong> {paymentUsername}</p>
                                </div>
                            </RB.Col>
                        </RB.Row>
                        <RB.Row className="mg-t-5">
                            <RB.Col lg={12} md={12}>
                                <p><strong>Dear {paymentUsername}</strong></p>
                                <p>Thanks for placing an order at ImagesBazaar! You can download the image(s) you have purchased by clicking on the link given below:</p>
                            </RB.Col>
                        </RB.Row>
                        <RB.Row className="mg-t-15">
                            <RB.Col lg={12} md={12}>
                                <p><strong><a href="#0">Click Here</a></strong></p>
                            </RB.Col>
                        </RB.Row>
                        <RB.Row className="mg-t-10">
                            <RB.Col lg={6} md={6}>
                                <p><Form.Group className="mb-0" controlId="formBasicEmail">
                                    <Form.Control name="content" onChange={handleChange} type="text" as="textarea" rows="3" />
                                </Form.Group>
                                </p>
                            </RB.Col>
                        </RB.Row>
                        <RB.Row className="mg-t-20">
                            <RB.Col lg={6} md={6}>
                                <p className="start_modal">***********************************</p>
                                <p className="code_modalo">
                                    <strong>Order Code: </strong> {orderId}
                                </p>
                                <p className="start_modal">***********************************</p>
                            </RB.Col>
                        </RB.Row>

                        <RB.Row className="mg-t-10">
                            <RB.Col lg={12} md={12}>
                                <p>Kindly write your order code at the back of your Cheque/Draft and send it in favour of Mash Audio Visuals Pvt. Ltd. payable at DELHI at:</p>
                                <p>Mash Audio Visuals Pvt. Ltd.</p>
                                <p>505, Aggarwal Prestige Mall,</p>
                                <p>Plot No.2, Road No.44,</p>
                                <p>Pitam Pura, New Delhi-110034</p>
                            </RB.Col>
                        </RB.Row>

                        <RB.Row className="mg-t-20">
                            <RB.Col lg={6} md={6}>
                                <p className="start_modal">***********************************</p>
                                <p className="code_modalo">Customer Control Panel</p>
                                <p className="start_modal">***********************************</p>
                            </RB.Col>
                        </RB.Row>

                        <RB.Row className="mg-t-10">
                            <RB.Col lg={12} md={12}>
                                <p>You can Login to the [My Account] section on the right hand top Menu bar of  <a href="https://www.imagesbazaar.com/ibregistration">https://www.imagesbazaar.com/ibregistration</a> and Print Invoice or Download Image(s) against this transaction by entering your Email and Password in the LOGIN details.</p>
                                <p>Mash Audio Visuals Pvt. Ltd.</p>
                                <p>505, Aggarwal Prestige Mall,</p>
                                <p>Plot No.2, Road No.44,</p>
                                <p>Pitam Pura, New Delhi-110034</p>
                            </RB.Col>
                        </RB.Row>
                        <hr></hr>
                        <RB.Row className="mg-t-5">
                            <RB.Col lg={12} md={12}>
                                <Form.Group as={Row} className="mb-0 mglr-0" controlId="formBasicEmail">
                                    <Form.Label className="col-lg-2 col-md-3"><strong>Send CC TO</strong></Form.Label>
                                    <Form.Control className="col-lg-4 col-md-4" name="email" type="text" onChange={handleChange} />
                                </Form.Group>
                            </RB.Col>
                        </RB.Row>
                        <RB.Row className="mg-t-10">
                            <RB.Col lg={12} md={12}>
                                <RB.Row>
                                    <RB.Col lg={2} md={3}></RB.Col>
                                    <RB.Col lg={4} md={4}>
                                        <Button block
                                            className="goBtnm btn btn-sm"
                                            onClick={sendEmailFun}
                                        >
                                            SUBMIT
                                        </Button>
                                    </RB.Col>
                                </RB.Row>
                            </RB.Col>
                        </RB.Row>

                    </RB.Modal.Body>
                </form>
            </RB.Modal>
        </>
    )
}

export default OrderActionMailModal;
