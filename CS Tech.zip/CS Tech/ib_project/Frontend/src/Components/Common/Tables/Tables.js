import {
  Col,
  Table,
  Button,
  ButtonToolbar,
  ButtonGroup,
  Row,
} from "react-bootstrap";

import { Link } from "react-router-dom";

import {
  RegisterUserHeader,
  RegisterCompanyHeader,
  OrderHeader,
  FollowupsHeader,
  ProposalHeader,
  // FollowupsHeader,
} from "./TableHeaders";

import { AiOutlineFileSearch } from "react-icons/ai";
import { RiDeleteBin6Line } from "react-icons/ri";
import { IoExitOutline } from "react-icons/io5";
import { IoIosArrowBack } from "react-icons/io";

import Moment from "moment";

export const RegisterUserTable = ({ REG_BODY, isView }) => {
  return (
    <>
      <Col lg={12}>
        <Row className="rownew1">
          <div className="tableHeader tableHeader1">
            {isView ? (
              <Col lg={5} md={4} xs={12} className="table_span">
                <h3 className="page-title d-flex userv">
                  <span>User </span>
                  {REG_BODY.length > 10 ?
                    <Button
                      size="sm"
                      variant="primary"
                    // disabled={REG_BODY.length > 10 ? false : true}
                    >
                      <Link to="/dashboard/viewalldata/user" className="btn_viewall" >View All</Link>
                    </Button> : null
                  }

                </h3>
              </Col>
            ) : (
              <Col lg={5} md={2} xs={5} className="table_span">
                <h3 className="page-title d-flex userv">
                  <span>User </span>
                </h3>
              </Col>
            )}
            {isView ? <Col lg={7} md={8} xs={12} className="table_span">

            </Col>
              :
              <Col lg={7} md={10} xs={7} className="table_span">
                <div className="float-right">
                  <Button size="sm" variant="primary" className="btn_svg">
                    <Link to="/dashboard/searchdata"><IoIosArrowBack />BACK</Link>
                  </Button>
                </div>
              </Col>
            }

          </div>
        </Row>
        <div className="box_detail table_boxdtl">
          <Table striped bordered hover variant="dark" responsive>
            <thead>
              <tr className="head_trmain">
                {RegisterUserHeader.map((head, inx) => {
                  return <th key={`REG_USR_TBL_HEAD${inx}`}>{head}</th>;
                })}
              </tr>
            </thead>
            <tbody>
              {isView
                ? REG_BODY.length > 0 ? REG_BODY.slice(0, 10).map((body, inx) => {
                  return (
                    <tr key={`REG_USR_TBL_BODY${inx}`}>
                      <td className="s_not1 text-center">{inx + 1}</td>
                      <td>{body.f_userid}</td>
                      <td>{body.f_fullname}</td>
                      <td className="company_emmailta">{body.f_email}</td>
                      <td>{body.f_mobileno}</td>
                      <td>{body.f_companyname}</td>
                      <td>{body.f_registrationType}</td>
                      <td className="s_not text-center td_comments">
                      <Link
                          to={`/dashboard/useraction/${body.f_userid}/from_usersearch`}
                        >
                          <AiOutlineFileSearch title="User Details" />
                      </Link>
                      </td>
                    </tr>
                  );
                }) : <tr><td className="no_records" colSpan="8">No Records Found</td></tr>
                : REG_BODY.map((body, inx) => {
                  return (
                    <tr key={`REG_USRALL_TBL_BODY${inx}`}>
                      <td className="s_not1 text-center">{inx + 1}</td>
                      <td>{body.f_userid}</td>
                      <td>{body.f_fullname}</td>
                      <td className="company_emmailta">{body.f_email}</td>
                      <td>{body.f_mobileno}</td>
                      <td>{body.f_companyname}</td>
                      <td>{body.f_registrationType}</td>
                      <td className="s_not text-center td_comments">
                        <Link
                          to={`/dashboard/useraction/${body.f_userid}/from_usersearch`}
                        >
                          <AiOutlineFileSearch title="User Details" />
                        </Link>
                      </td>
                    </tr>
                  );
                })}
            </tbody>
          </Table>
        </div>
      </Col>
    </>
  );
};

export const RegisterCompanyTable = ({ REG_BODY, isView }) => {
  return (
    <>
      <Col lg={12}>
        <Row className="add_button">
          <div className="tableHeader tableHeader1">
            {isView ? (
              <Col lg={5} md={4} xs={12} className="table_span">
                <h3 className="page-title d-flex userv">
                  <span>Company </span>
                  {REG_BODY.length > 10 ?
                    <Button
                      size="sm"
                      variant="primary"
                    // disabled={REG_BODY.length > 10 ? false : true}
                    >
                      <Link to="/dashboard/viewalldata/company" className="btn_viewall" >View All</Link>
                    </Button> : null
                  }

                </h3>
              </Col>
            ) : (
              <Col lg={5} md={2} xs={5} className="table_span">
                <h3 className="page-title d-flex userv">
                  <span>Company </span>
                </h3>
              </Col>
            )}
            {isView ? <Col lg={7} md={8} xs={12} className="table_span">

            </Col>
              :
              <Col lg={7} md={10} xs={7} className="table_span">
                <div className="float-right">
                  <Button size="sm" variant="primary" className="btn_svg">
                    <Link to="/dashboard/searchdata"><IoIosArrowBack />BACK</Link>
                  </Button>
                </div>
              </Col>
            }

          </div>
        </Row>
        <div className="box_detail table_boxdtl">
          <Table striped bordered hover variant="dark" responsive>
            <thead>
              <tr className="head_trmain">
                {RegisterCompanyHeader.map((head, inx) => {
                  return <th key={`REG_CMPY_TBL_HEAD${inx}`}>{head}</th>;
                })}
              </tr>
            </thead>
            <tbody>
              {isView
                ? REG_BODY.length > 0 ? REG_BODY.slice(0, 10).map((body, inx) => {
                  return (
                    <tr key={`REG_CMPY_TBL_BODY${inx}`} className="company_alldt">
                      <td className="s_not1 text-center">{inx + 1}</td>
                      <td>{body.f_companyname}</td>
                      <td>{body.f_groupname}</td>
                      <td className="company_emmailta">{body.f_email}</td>
                      <td>{body.f_mobileno}</td>
                      <td>{body.f_Shortname}</td>
                      <td className="addresstd">{body.f_address}</td>
                      <td>{body.f_state}</td>
                      <td>View Details</td>
                      <td>View Details</td>
                      <td>{body.f_giftpolicy}</td>
                      <td>{body.f_commissionpolicy}</td>
                      <td className="s_not td_comments text-center">
                        <Link to={`/dashboard/groupdetails/${body.f_userid}`}>
                          <AiOutlineFileSearch title="Company Details" />
                        </Link>
                      </td>
                    </tr>
                  );
                }) : <tr><td className="no_records" colSpan="13">No Records Found</td></tr>
                : REG_BODY.map((body, inx) => {
                  return (
                    <tr key={`REG_CMPYALL_TBL_BODY${inx}`} className="company_alldt">
                      <td className="s_not1 text-center">{inx + 1}</td>
                      <td>{body.f_companyname}</td>
                      <td>{body.f_groupname}</td>
                      <td className="company_emmailta">{body.f_email}</td>
                      <td>{body.f_mobileno}</td>
                      <td>{body.f_Shortname}</td>
                      <td className="addresstd">{body.f_address}</td>
                      <td>{body.f_state}</td>
                      <td>View Details</td>
                      <td>View Details</td>
                      <td>{body.f_giftpolicy}</td>
                      <td>{body.f_commissionpolicy}</td>
                      <td className="s_not td_comments text-center">
                        <Link to={`/dashboard/groupdetails/${body.f_userid}`}>
                          <AiOutlineFileSearch title="Company Details" />
                        </Link>
                      </td>
                    </tr>
                  );
                })}
            </tbody>
          </Table>
        </div>
      </Col>
    </>
  );
};

export const OrderTable = ({ ORDER_BODY, isView, spanOrder }) => {
  return (
    <>
      <Col lg={12}>
        <Row className="add_button">
          <div className="tableHeader tableHeader1 order_btntable">
            {isView ? (
              <Col lg={5} md={4} xs={12} className="table_span">
                <h3 className="page-title d-flex userv">
                  <span>Orders </span>
                  {ORDER_BODY.length > 10 ? <Button
                    size="sm"
                    variant="primary"
                  // disabled={ORDER_BODY.length > 10 ? false : true}
                  >
                    <Link to="/dashboard/viewalldata/orders" className="btn_viewall">View All</Link>
                  </Button> : null
                  }

                </h3>
              </Col>
            ) : (
              <Col lg={5} md={2} xs={12} className="table_span">
                <h3 className="page-title d-flex userv">
                  <span>Orders </span>
                </h3>
              </Col>
            )}
            {isView ? <Col lg={7} md={8} xs={12} className="table_span">
              <ButtonToolbar>
                {spanOrder.map((data, inx) => {
                  let { name, count, path } = data;
                  return (
                    <ButtonGroup className="mr-2" key={"orderspan" + inx}>
                      <Button
                        as={Link}
                        to={`/dashboard/btndata/${path}`}
                        size="sm"
                      >{`${name} - ${count}`}
                      </Button>

                    </ButtonGroup>
                  );
                })}
              </ButtonToolbar>
            </Col>
              :
              <Col lg={7} md={10} xs={12} className="table_span">
                <ButtonToolbar>
                  {spanOrder.map((data, inx) => {
                    let { name, count, path } = data;
                    return (
                      <ButtonGroup className="mr-2" key={"orderspan" + inx}>
                        <Button
                          size="sm"
                          variant="primary"
                        >
                          <Link to={`/dashboard/btndata/${path}`}>{`${name} - ${count}`}</Link>
                        </Button>

                      </ButtonGroup>
                    );
                  })}
                  <Button size="sm" variant="primary" className="btn_svg">
                    <Link to="/dashboard/searchdata"><IoIosArrowBack />BACK</Link>
                  </Button>
                </ButtonToolbar>
              </Col>
            }

          </div>
        </Row>
        <div className="box_detail table_boxdtl">
          <Table striped bordered hover variant="dark" responsive>
            <thead>
              <tr className="head_trmain">
                {OrderHeader.map((head, inx) => {
                  return <th key={`ORDER_TBL_HEAD${inx}`}>{head}</th>;
                })}
              </tr>
            </thead>
            <tbody>
              {isView
                ? ORDER_BODY.length > 0 ? ORDER_BODY.slice(0, 10).map((body, inx) => {
                  return (
                    <tr key={`ORDER_TBL_BODY${inx}`}>
                      <td className="s_not1 text-center">{inx + 1}</td>
                      <td>{body.f_clientname}</td>
                      <td className="company_emmailta">{body.f_email}</td>
                      <td>{body.f_mobileno}</td>
                      {/* <td>{data.f_totalamtwithGST}</td> */}
                      <td>{body.f_order_total}</td>
                      <td>{body.f_order_Unpaid}</td>
                      <td>{body.f_order_Current_Discount_Per}</td>
                      <td>{body.f_approval_mode}</td>
                      <td>{body.f_credit_period}</td>
                      <td>{body.f_order_Pending}</td>
                      <td className="s_not td_comments text-center">
                        <Link to={`/dashboard/btndata/${body.f_email}`}>
                          <AiOutlineFileSearch title="Order Details" />
                        </Link>
                      </td>
                    </tr>
                  );
                }) : <tr><td className="no_records" colSpan="11">No Records Found</td></tr>
                : ORDER_BODY.map((body, inx) => {
                  return (
                    <tr key={`ORDERALL_TBL_BODY${inx}`}>
                      <td className="s_not1 text-center">{inx + 1}</td>
                      <td>{body.f_clientname}</td>
                      <td className="company_emmailta">{body.f_email}</td>
                      <td>{body.f_mobileno}</td>
                      {/* <td>{data.f_totalamtwithGST}</td> */}
                      <td>{body.f_order_total}</td>
                      <td>{body.f_order_Unpaid}</td>
                      <td>{body.f_order_Current_Discount_Per}</td>
                      <td>{body.f_approval_mode}</td>
                      <td>{body.f_credit_period}</td>
                      <td>{body.f_order_Pending}</td>
                      <td className="s_not td_comments text-center">
                        <Link to={`/dashboard/btndata/${body.f_email}`}>
                          <AiOutlineFileSearch title="Order Details" />
                        </Link>
                      </td>
                    </tr>
                  );
                })}
            </tbody>
          </Table>
        </div>
      </Col>
    </>
  );
};

export const ProposalTable = ({ PROPOSAL_BODY, isView, GetProposalId, PROPOSAL_DELETE_FUNCTION }) => {
  return (
    <>
      <Col lg={12}>
        <Row className="add_button">
          <div className="tableHeader tableHeader1">
            {isView ? (
              <Col lg={5} md={4} xs={12} className="table_span">
                <h3 className="page-title d-flex userv">
                  <span>Proposal </span>
                  {PROPOSAL_BODY.length > 10 ? <Button
                    size="sm"
                    variant="primary"
                  // disabled={PROPOSAL_BODY.length > 10 ? false : true}
                  >
                    <Link to="/dashboard/viewalldata/proposal" className="btn_viewall" >View All</Link>
                  </Button> : null
                  }

                </h3>
              </Col>
            ) : (
              <Col lg={5} md={2} xs={5} className="table_span">
                <h3 className="page-title d-flex userv">
                  <span>Proposal </span>
                </h3>
              </Col>
            )}
            {isView ? <Col lg={7} md={8} xs={12} className="table_span">

            </Col>
              :
              <Col lg={7} md={10} xs={7} className="table_span">
                <div className="float-right">
                  <Button size="sm" variant="primary" className="btn_svg">
                    <Link to="/dashboard/searchdata"><IoIosArrowBack />BACK</Link>
                  </Button>
                </div>
              </Col>
            }

          </div>
        </Row>

        <div className="box_detail table_boxdtl">
          <Table striped bordered hover variant="dark" responsive>
            <thead>
              <tr>
                {ProposalHeader.map((head, inx) => {
                  return <th key={`PROPOSAL_TBL_HEAD${inx}`}>{head}</th>;
                })}
              </tr>
            </thead>
            <tbody>
              {isView
                ? PROPOSAL_BODY.length > 0 ? PROPOSAL_BODY.slice(0, 10).map((body, inx) => {
                  return (
                    <tr key={`PROPOSAL_TBL_BODY${inx}`}>
                      <td className="s_not1">{body.T_orderid}</td>
                      <td>{body.T_username}</td>
                      <td>{body.f_heading}</td>
                      <td className="createdate_tablet">
                        {Moment(body.f_createdate).format("DD-MM-YYYY")}
                      </td>
                      <td>{body.f_totimg}</td>
                      <td>{body.f_amtpay}</td>
                      <td>{body.f_discount}</td>
                      <td>{body.f_sertax}</td>
                      <td>{body.f_finalamt}</td>
                      <td className="s_not td_comments text-center">
                        <AiOutlineFileSearch title="Proposal Details"
                          onClick={() => GetProposalId(body.T_orderid)}
                        />
                        <RiDeleteBin6Line className="text-danger1" title="Proposal Delete"
                          onClick={() => PROPOSAL_DELETE_FUNCTION(body.T_orderid)}
                        />
                      </td>
                    </tr>
                  );
                }) : <tr><td className="no_records" colSpan="10">No Records Found</td></tr>
                : PROPOSAL_BODY.map((body, inx) => {
                  return (
                    <tr key={`PROPOSALALL_TBL_BODY${inx}`}>
                      <td className="s_not1">{body.T_orderid}</td>
                      <td>{body.T_username}</td>
                      <td>{body.f_heading}</td>
                      <td className="createdate_tablet">
                        {Moment(body.f_createdate).format("DD-MM-YYYY")}
                      </td>
                      <td>{body.f_totimg}</td>
                      <td>{body.f_amtpay}</td>
                      <td>{body.f_discount}</td>
                      <td>{body.f_sertax}</td>
                      <td>{body.f_finalamt}</td>
                      <td className="s_not td_comments text-center">
                        <AiOutlineFileSearch title="Proposal Details"
                          onClick={() => GetProposalId(body.T_orderid)}
                        />
                        <RiDeleteBin6Line className="text-danger1" title="Proposal Delete"
                          onClick={() => PROPOSAL_DELETE_FUNCTION(body.T_orderid)}
                        />
                      </td>
                    </tr>
                  );
                })}
            </tbody>
          </Table>
        </div>
      </Col>
    </>
  );
};

export const FollowupTable = ({
  FOLLOWUP_BODY,
  isView,
  spanArr,
  openFilter,
  FollowupCreateSubmit,
  FollowupListOpen,
}) => {
  return (
    <>
      <Col lg={12}>
        <Row className="add_button">
          <div className="tableHeader tableHeader1 order_btntable">
            {isView ? (
              <Col lg={5} md={4} xs={12} className="table_span">
                <h3 className="page-title d-flex userv">
                  <span>Followup </span>
                  {FOLLOWUP_BODY.length > 10 ?
                    <Button
                      size="sm"
                      variant="primary"
                    // disabled={FOLLOWUP_BODY.length > 10 ? false : true}
                    >
                      <Link to="/dashboard/viewalldata/followup" className="btn_viewall">View All</Link>
                    </Button> : null
                  }

                </h3>
              </Col>
            ) : (
              <Col lg={5} md={2} xs={12} className="table_span">
                <h3 className="page-title d-flex userv">
                  <span>Followup </span>
                </h3>
              </Col>
            )}

            {isView ? <Col lg={7} md={8} xs={12} className="table_span">
              <ButtonToolbar>
                {spanArr.map((data, inx) => {
                  let { name, count } = data;
                  return (
                    <ButtonGroup className="mr-2" key={"followupspan" + inx}>
                      <Button
                        onClick={() => {
                          openFilter(name);
                        }}
                        size="sm"
                      >{`${name} - ${count}`}</Button>
                    </ButtonGroup>
                  );
                })}
              </ButtonToolbar>
            </Col>
              :
              <Col lg={7} md={10} xs={12} className="table_span">
                <ButtonToolbar>
                  {spanArr.map((data, inx) => {
                    let { name, count } = data;
                    return (
                      <ButtonGroup className="mr-2" key={"followupspan" + inx}>
                        <Button
                          onClick={() => {
                            openFilter(name);
                          }}
                          size="sm"
                        >{`${name} - ${count}`}</Button>
                      </ButtonGroup>
                    );
                  })}
                  <Button size="sm" variant="primary" className="btn_svg">
                    <Link to="/dashboard/searchdata"><IoIosArrowBack />BACK</Link>
                  </Button>
                </ButtonToolbar>
              </Col>
            }
          </div>
        </Row>
        <div className="box_detail table_boxdtl">
          <Table striped bordered hover variant="dark" responsive>
            <thead>
              <tr className="head_trmain">
                {FollowupsHeader.map((head, inx) => {
                  return <th key={`ORDER_TBL_HEAD${inx}`}>{head}</th>;
                })}
              </tr>
            </thead>
            <tbody>
              {isView
                ? FOLLOWUP_BODY.length > 0 ? FOLLOWUP_BODY.slice(0, 10).map((body, inx) => {
                  return (
                    <tr key={`ORDER_TBL_BODY${inx}`}>
                      <td className="s_not1 text-center">{inx + 1}</td>
                      <td className="company_emmailta">
                        {body.f_fullname}
                        {<br />}
                        {body.f_email}
                        {<br />}
                        {body.f_state}
                      </td>
                      <td className="company_emmailta">{body.f_CompanyName}</td>
                      <td>{body.f_usertype}</td>
                      <td>{body.f_RequirementType}</td>
                      <td>upload image</td>
                      <td>{body.f_followups_status}</td>
                      <td className="createdate_tablet">
                        {Moment(body.f_creationdate).format("DD-MM-YYYY")}
                      </td>
                      <td>{body.f_usertype}</td>
                      <td>{body.f_DiscountTerms}</td>
                      <td className="s_not td_comments text-center">
                        <AiOutlineFileSearch title="Followup Details"
                          onClick={() => FollowupCreateSubmit(body.f_sno)}
                        />
                        <IoExitOutline title="Followup History"
                          onClick={() => FollowupListOpen(body.f_sno)}
                        />
                      </td>
                    </tr>
                  );
                }) : <tr><td className="no_records" colSpan="11">No Records Found</td></tr>
                : FOLLOWUP_BODY.map((body, inx) => {
                  return (
                    <tr key={`ORDERALL_TBL_BODY${inx}`}>
                      <td className="s_not1 text-center">{inx + 1}</td>
                      <td className="company_emmailta">
                        {body.f_fullname}
                        {<br />}
                        {body.f_email}
                        {<br />}
                        {body.f_state}
                      </td>
                      <td className="company_emmailta">{body.f_CompanyName}</td>
                      <td>{body.f_usertype}</td>
                      <td>{body.f_RequirementType}</td>
                      <td>upload image</td>
                      <td>{body.f_followups_status}</td>
                      <td className="createdate_tablet">
                        {Moment(body.f_creationdate).format("DD-MM-YYYY")}
                      </td>
                      <td>{body.f_usertype}</td>
                      <td>{body.f_DiscountTerms}</td>
                      <td className="s_not td_comments text-center">
                        <AiOutlineFileSearch title="Followup Details"
                          onClick={() => FollowupCreateSubmit(body.f_sno)}
                        />
                        <IoExitOutline title="Followup History"
                          onClick={() => FollowupListOpen(body.f_sno)}
                        />
                      </td>
                    </tr>
                  );
                })}
            </tbody>
          </Table>
        </div>
      </Col>
    </>
  );
};
