// import Mongoose from "mongoose";
const Mongoose = require("mongoose")

const paymentModelSchema = new Mongoose.Schema(
  {
    userId: { type: String },
    seller_entry_name: { type: String },
    account_number: { type: String },
    beneficiary_name: { type: String },
    bank_name: { type: String },
    bank_branch: { type: String },
    ifsc_code: { type: String },
    mode: { type: String },
    payment_type: { type: String },
    transection_no: { type: String },
    payed_amount: { type: Number },
    tracking_number: { type: String },
    comment: { type: String },
  },
  { timestamps: true },
  { collection: "payment_tbls" }
);

module.exports = paymentModelSchema


