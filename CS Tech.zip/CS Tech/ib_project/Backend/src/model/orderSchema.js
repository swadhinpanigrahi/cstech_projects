const mongoose = require("mongoose");

const OrderSchemas = mongoose.Schema(
  {
    T_orderid: { type: Number },
    T_username: { type: String },
    T_orderdate: { type: Date },
    T_paymode: { type: String },
    T_status: { type: String },
    T_condate: { type: Date },
    t_comment: { type: String },
    t_client: { type: String },
    t_orderedby: { type: String },
    t_download: { type: String },
    t_paymentstatus: { type: String },
    t_paymentdate: { type: String },
    t_purchaseorder: { type: String },
    t_followup_status: { type: Number },
    t_invoiceid: { type: String },
    f_paidDate: { type: Date },
    f_PreOrderid: { type: String },
    f_clientGSTIN_no: { type: String },
    f_invoiceID:{type:String},
    f_orderAmt: { type: Number },
    
  },
  { collection: "T_Orders_IB_MongoDB" }
);

module.exports = orderSchema = mongoose.model("T_Orders_IB_MongoDB", OrderSchemas);
