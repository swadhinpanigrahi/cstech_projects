import React, { useState, useEffect } from 'react';
import * as RB from "react-bootstrap";
import { Row } from "react-bootstrap";
import { getOrderDetailAPI, bounceChequeAPI } from "../../../Utils/api"

const OrderBounceChequeModal = ({ BounceChequeModel, setBounceChequeModel, T_orderid }) => {
    const [OrderData, setOrderData] = useState({});

    const CloseModal = () => setBounceChequeModel(false);

    const onChangeHandler = (e) => {
        let { name, value } = e.target
        const data = { ...OrderData };
        data[name] = value;
        setOrderData(data);
    }

    const onSubmit = async (e) => {
        e.preventDefault();
        const FormData = {
            f_bouncedchequedesc: OrderData.f_bouncedchequedesc,
            T_orderid: OrderData.T_orderid
        }
        const res = await bounceChequeAPI(FormData);
        let { status, message, error } = res;
        if (!error) {
            if (status === 200 && message) {
                setBounceChequeModel(false)
            }
        } else {
            window.alert("API ERROR")
        }

    }

    useEffect(() => {
        const apiCall = async () => {
            const res = await getOrderDetailAPI(T_orderid);
            const { T_OrderData, error, message } = res
            if (!error) {
                if (T_OrderData) {
                    setOrderData(T_OrderData)
                } else {
                    // window.alert(message)
                }
            } else {
                // window.alert(error)
            }
        }
        apiCall()
    }, [T_orderid]);

    return (
        <>
            <RB.Modal show={BounceChequeModel} onHide={CloseModal} className="ordermanage_modal">
                <RB.Modal.Header closeButton>
                    <RB.Modal.Title>Bounce Cheque</RB.Modal.Title>
                </RB.Modal.Header>
                <RB.Modal.Body>
                    <RB.Row>
                        <RB.Col lg={12} md={12}>
                            <RB.Row>
                                <RB.Col lg={12} md={12}>
                                    <RB.Form>
                                        <RB.Form.Group as={Row} controlId="formbasicemailo">
                                            <RB.Col lg={3} md={3}>
                                                <RB.Form.Label>Order ID :</RB.Form.Label>
                                            </RB.Col>
                                            <RB.Col lg={7} md={7}>
                                                <p className="text_modalp">{OrderData.T_orderid}</p>
                                            </RB.Col>
                                        </RB.Form.Group>
                                        <RB.Form.Group as={Row} controlId="formbasicemailo">
                                            <RB.Col lg={3} md={3}>
                                                <RB.Form.Label>Description :</RB.Form.Label>
                                            </RB.Col>
                                            <RB.Col lg={7} md={7}>
                                                <RB.Form.Control
                                                    onChange={onChangeHandler}
                                                    name="f_bouncedchequedesc"
                                                    as="textarea" rows={3}
                                                    value={
                                                        OrderData.f_bouncedchequedesc === null ?
                                                            "" : OrderData.f_bouncedchequedesc
                                                    }
                                                />
                                            </RB.Col>
                                        </RB.Form.Group>
                                        <RB.Row>
                                            <RB.Col lg={3} md={3}></RB.Col>
                                            <RB.Col lg={7} md={7}>
                                                <RB.Button
                                                    type="submit"
                                                    size="sm"
                                                    variant="primary"
                                                    onClick={onSubmit}
                                                >
                                                    UPDATE
                                                </RB.Button>
                                            </RB.Col>
                                        </RB.Row>
                                    </RB.Form>
                                </RB.Col>
                            </RB.Row>
                        </RB.Col>
                    </RB.Row>
                </RB.Modal.Body>
            </RB.Modal>
        </>
    )
}

export default OrderBounceChequeModal
