const mongoose = require("mongoose");

const MasterIndustrySchema = mongoose.Schema(
    {
        f_sno: { type: String },
        f_category: { type: String },
        f_subcategory: { type: String },
        f_groupid: { type: String },
    },
    { collection: "t_star_Industry" }
);

module.exports = M_INDUSTRY = mongoose.model(
    "t_star_Industry",
    MasterIndustrySchema
);