const mongoose = require("mongoose");

const t_DailySalesEntry_sales_IB_MongoDB_Schema = mongoose.Schema(
  {
    f_sno: { type: String },
    f_EmailID: { type: String },
    f_AlternateEmail: { type: String },
    f_Firstname: { type: String },
    f_lastName: { type: String },
    f_CompanyName: { type: String },
    f_PhoneNumber: { type: String },
    f_MobileNo: { type: String },
    f_State: { type: String },
    f_Country: { type: String },
    f_UserType: { type: String },
    f_RequirementType: { type: String },
    f_followups_status: { type: String },
    f_Description: { type: String },
    f_followupsdate: { type: Date },
    f_followpby: { type: String },
    f_createdby: { type: String },
    f_orderby: { type: String },
    f_IbOption: { type: String },
    f_Descriptiontype: { type: String },
    f_alternateemailSecond: { type: String },
    f_Discountterms: { type: String },
    f_CreaditPeriod: { type: String },
    f_alternatename: { type: String },
    f_alternateContactNumber: { type: String },
    f_creationdate: { type: Date },
    f_designation: { type: String },
    imp_follow_ups: { type: Number },
    orderid: { type: String },
    sortcmp_name: { type: String },
    group_cmpname: { type: String },
  },
  { collection: "t_DailySalesEntry_sales_IB_MongoDB" }
);

module.exports = t_DailySalesEntry_sales_IB_MongoDB = mongoose.model(
  "t_DailySalesEntry_sales_IB_MongoDB",
  t_DailySalesEntry_sales_IB_MongoDB_Schema
);
