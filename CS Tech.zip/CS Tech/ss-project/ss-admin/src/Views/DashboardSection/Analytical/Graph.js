import React, { useState, useEffect } from "react";
import { getDataForGraph } from '../../../Utils/api';
import CountCard from "./CountCard";


const Graph = () => {
    const [AnalaticData, setAnalaticData] = useState({
        graphArray: [],
        shipmentCount: 0,
        customerCount: 0
    })

    useEffect(() => {
        const apiCall = async () => {
            const res = await getDataForGraph();
            let { graph, totalOrder, totalCustomer } = res;
            const updatedState = { ...AnalaticData }
            updatedState.graphArray = graph;
            updatedState.shipmentCount = totalOrder;
            updatedState.customerCount = totalCustomer;
            setAnalaticData({ ...updatedState })
        }
        apiCall()
    }, [])

    return (
        <>
            <CountCard orderCount={AnalaticData.shipmentCount} userCount={AnalaticData.customerCount} graph={AnalaticData.graphArray} />
        </>
    );
};

export default Graph;

