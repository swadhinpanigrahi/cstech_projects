import React from 'react'
import { Route } from "react-router-dom"

import Outstanding from "./Outstanding";
import OutstandingNew from "./OutstandingNew";

const OutstandingDash = () => {
    return (
        <>
            <main className="pd-b-25">
                <Route path="/dashboard/outstandingreport/get" component={Outstanding} />
                <Route path="/dashboard/outstandingreport/getnew" component={OutstandingNew} />
            </main>
        </>
    )
}

export default OutstandingDash
