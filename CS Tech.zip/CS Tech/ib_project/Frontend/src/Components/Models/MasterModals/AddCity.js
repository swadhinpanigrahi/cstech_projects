import React, { useState } from 'react';
import * as RB from "react-bootstrap";
import { Row } from "react-bootstrap";
import { CREATE_CITY } from "../../../Utils/api";

const AddCity = (
    { show_addcity, addcityClose, StateData, CountryData, apiCall }
) => {

    const [FormData, setFormData] = useState({
        f_country: "1",
        f_stateid: "98",
        f_cityname: ""
    });
    const [Err, setErr] = useState("");

    const Closes = () => {
        setFormData({})
        setErr("")
        addcityClose()
    }

    const handleChange = (e) => {
        let { name, value } = e.target;
        const data = { ...FormData }
        data[name] = value
        setFormData(data)
    }

    const addCityFun = async () => {
        let { f_cityname } = FormData;
        const regex = /^[a-zA-Z]*$/;
        const value = regex.test(f_cityname);
        if (value && f_cityname !== "") {
            const res = await CREATE_CITY(FormData);
            let { status, saveData, message } = res;
            if (status === 200 && saveData) {
                setFormData({})
                setErr("")
                apiCall()
                addcityClose()
            } else {
                setErr(message)
            }
        } else {
            setErr("Please Enter a Valid City Name!")
        }
    }

    return (
        <div>
            <RB.Modal show={show_addcity} onHide={Closes} className="ordermanage_modal">
                <RB.Modal.Header closeButton>
                    <RB.Modal.Title>Add New City</RB.Modal.Title>
                </RB.Modal.Header>
                <RB.Modal.Body>
                    <RB.Row>
                        <RB.Col lg={12} md={12}>
                            <RB.Row>
                                <RB.Col lg={12} md={12}>
                                    {Err === "" ? null : Err}
                                    <RB.Form>
                                        <RB.Form.Group as={Row} controlId="Country_id">
                                            <RB.Col lg={4} md={4}>
                                                <RB.Form.Label>Select Country :</RB.Form.Label>
                                            </RB.Col>
                                            <RB.Col lg={7} md={8}>
                                                <select className="select_customerd" name="f_countryid" onChange={handleChange}
                                                    value={FormData.f_country}>
                                                    <option value="1">INDIA</option>
                                                </select>
                                            </RB.Col>
                                        </RB.Form.Group>
                                        <RB.Form.Group as={Row} controlId="Country_id">
                                            <RB.Col lg={4} md={4}>
                                                <RB.Form.Label>State Name :</RB.Form.Label>
                                            </RB.Col>
                                            <RB.Col lg={7} md={8}>
                                                <select className="select_customerd" name="f_stateid" onChange={handleChange}>
                                                    {StateData.map((info, inx) => {
                                                        return (
                                                            <option value={info.f_stateid} key={`STATE_DROPDOWN_IN_CITY${inx}`}>
                                                                {info.f_state}
                                                            </option>
                                                        )
                                                    })}
                                                </select>
                                            </RB.Col>
                                        </RB.Form.Group>
                                        <RB.Form.Group as={Row} controlId="Country_id">
                                            <RB.Col lg={4} md={4}>
                                                <RB.Form.Label>City Name :</RB.Form.Label>
                                            </RB.Col>
                                            <RB.Col lg={7} md={8}>
                                                <RB.Form.Control type="text" name="f_cityname" onChange={handleChange} />
                                            </RB.Col>
                                        </RB.Form.Group>
                                        <RB.Row>
                                            <RB.Col lg={4} md={4}></RB.Col>
                                            <RB.Col lg={6} md={7}>
                                                <RB.Button
                                                    size="sm" variant="primary"
                                                    onClick={addCityFun}
                                                >
                                                    SUBMIT
                                                </RB.Button>
                                            </RB.Col>
                                        </RB.Row>
                                    </RB.Form>
                                </RB.Col>
                            </RB.Row>
                        </RB.Col>
                    </RB.Row>
                </RB.Modal.Body>
            </RB.Modal>
        </div>
    )
}

export default AddCity