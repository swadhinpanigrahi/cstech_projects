import React, { useState } from 'react';
import Header from "../../Components/Common/Header";
import { EmailChangePasswordForm } from "../../Components/FormElement/FormElement";
import Model from "../../Components/Common/Model";
import { Link, useParams } from "react-router-dom";
import { useTranslation } from "react-i18next";
import { forgotEmailPasswordChange } from '../../Utils/api'

const ForgotSumitPass = () => {
    const { token } = useParams()
    const { t } = useTranslation();
    const [isOpen, setIsOpen] = useState(false);
    const [FormData, setFormData] = useState({});
    const [ErrModel, setErrModel] = useState("");
    const handleChange = (e) => {
        let { name, value } = e.target;
        let data = { ...FormData };
        data[name] = value;
        setFormData(data);
    };

    const onSubmit = async (e) => {
        e.preventDefault();
        if (FormData["newpassword"] && FormData["confirmpassword"]) {
            if (FormData["newpassword"] === FormData["confirmpassword"]) {
                console.log({ ...FormData, token })
                const res = await forgotEmailPasswordChange({ ...FormData, token })
                let { error, message } = res;
                if (!error) {
                    setErrModel(message);
                    modelSet();
                } else {
                    setErrModel("Network Error");
                    modelSet();
                }
            } else {
                setErrModel("please enter new and confirm-password correctly");
                modelSet();
            }
        } else {
            setErrModel("please fill all this details!!");
            modelSet();
        }
    };

    const modelSet = () => {
        setIsOpen(true);
    };
    return (
        <>
            <Header />
            <div id="page" className="theia-exception">
                <main className="mainl">
                    <div className="container-flud">
                        <div id="signin">
                            <div className="boxes">
                                <h4 className="title text-center">Enter New Password</h4>
                                <p className="fortext">{t("change.f_ufup")}</p>
                                <p className="fortext" style={{ paddingBottom: "25px" }}>
                                    {t("change.f_youcanchange")}
                                </p>
                                <form id="form">
                                    <div className="form-group">
                                        {EmailChangePasswordForm.map((data, inx) => {
                                            let { name, type, placeholder } = data;
                                            return (
                                                <input
                                                    type={type}
                                                    className="input mt-3"
                                                    name={name}
                                                    placeholder={placeholder}
                                                    onChange={handleChange}
                                                />
                                            )
                                        })}
                                    </div>
                                    <div className="form-group" style={{ marginBottom: "15px" }}>
                                        <button className="btn-login" onClick={onSubmit}>
                                            SUBMIT
                                        </button>
                                        <div className="forgot">
                                            <Link to="/">Click Here For Login</Link>
                                        </div>
                                        <Model
                                            text={ErrModel}
                                            open={isOpen}
                                            onClose={() => setIsOpen(false)}
                                        />
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
        </>
    )
}

export default ForgotSumitPass
