import React, { useState, useEffect, useRef } from "react";
import { customerTable, DeletedUserRecord, getCustomerExport } from "../../../Utils/api";
import PaginationComponent from "../../../Components/Common/PaginationComponent";
import { IoExitOutline } from "react-icons/io5";
import { AiOutlineFileSearch, AiOutlineEye } from "react-icons/ai";
import { BiUser } from "react-icons/bi";
import { Link, useLocation } from "react-router-dom";
import * as RB from "react-bootstrap";
import { Form, Button } from "react-bootstrap";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import ReactExport from "react-data-export";
import Moment from "moment";
// import Modal from "../../../Components/Common/Modal";

const DropDownArray1 = [
  { name: "Buyer" },
  { name: "Register" },
  { name: "Confirmed" },
  { name: "International" },
  { name: "Photographer" },
  { name: "Student" },
  { name: "Unconfirmed" },
  { name: "Other" },
];

function useQuery() {
  return new URLSearchParams(useLocation().search);
}

const CustomerGet = () => {
  let query = useQuery();
  const num = query.get("num") || 1;
  const searchText = useRef(null);

  const [Data, setData] = useState([]);
  const [currentPage, setCurrentPage] = useState(num);
  const [itemPerPage, setItemPerPage] = useState(20);
  const [selectData, setSelectData] = useState("");
  let [searchData, setSearchData] = useState("");
  const [startDate, setStartDate] = useState(null);
  const [endDate, setEndDate] = useState(null);
  const [Count, setCount] = useState(0);
  const [ExportData, setExportData] = useState([])

  const [Loading, setLoading] = useState(false);
  const [isExport, setIsExport] = useState(false);

  // const [isOpen, setIsOpen] = useState(false);
  // const [ModelMsg, setModelMsg] = useState("");

  /**
   * EXPORT
  */

  const ExcelFile = ReactExport.ExcelFile;
  const ExcelSheet = ReactExport.ExcelFile.ExcelSheet;
  const DataSet = [
    {
      columns: [
        { title: "USER ID" },
        { title: "NAME" },
        { title: "MOBILE" },
        { title: "EMAIL" },
        { title: "COMPANY NAME" },
        // { title: "ADDRESS" },
        // { title: "GROUP NAME" },
        // { title: "SHORT NAME" },
        // { title: "TYPE" },
        // { title: "CREATE DATE" },
        // { title: "STATE" },
        // { title: "COUNTRY" },
      ],
      data: ExportData.map((data) => [
        { value: data.f_userid },
        { value: data.f_fullname },
        { value: data.f_mobileno },
        { value: data.f_email },
        { value: data.f_companyname },
        //   { value: data.f_address },
        //   { value: data.f_groupname },
        //   { value: data.f_Shortname },
        //   { value: data.f_registrationType },
        //   { value: data.f_createdate },
        //   { value: data.f_state },
        //   { value: data.f_country },
      ]),
    },
  ];

  // const modelSet = () => {
  //   setIsOpen(true);
  // };


  const hideAndShowPassword = (data, userId, e) => {
    document.getElementsByClassName("show_tbl_pass" + userId)[0].innerHTML =
      data;
  };

  const UserLogin = async (userId) => {
    window.open('http://testing.imagesbazaar.com/ibregistration?usr=' + window.btoa(userId))
  }

  // const DeleteUser = async (userId) => {
  //   const res = await DeletedUserRecord(userId);
  //   let { message } = res;
  //   const res1 = await customerTable(currentPage, itemPerPage, startDate, endDate, selectData, searchData);
  //   let { customerCount, customerData } = res1;
  //   setData(customerData);
  //   customerCount.length === 1
  //     ? setCount(customerCount[0].totalCount)
  //     : setCount(0);
  //   setModelMsg(message)
  //   modelSet()
  // };

  const tableData = (info) => {
    return info.length !== 0 ? (
      info.map((data) => {
        return (
          <tr key={data._id}>
            <td>{data.f_userid}</td>
            <td className="company_emmailt">{data.f_email}</td>
            <td className={`show_tblpass show_tbl_pass${data.f_userid}`}>
              ********
              <AiOutlineEye
                className="password_shhi"
                title="Show Password"
                onClick={(e) =>
                  hideAndShowPassword(data.CS_password, data.f_userid, e)
                }
              />
            </td>
            <td>{data.f_fullname}</td>
            <td>{data.f_companyname}</td>
            <td>{data.f_registrationType}</td>
            <td>{data.f_Identify_User}</td>
            <td>{data.f_mobileno}</td>
            <td>{Moment(data.f_createdate).format("DD-MM-YYYY")}</td>
            <td>{data.CS_regType}</td>
            <td className="td_comments text-center">
              <Link
                to={`/dashboard/useraction/${data.f_userid}/from_customerlist`}
                title="User Details"
              >
                <AiOutlineFileSearch />
              </Link>
              <Link
                to={`/dashboard/useractioneditprofile/${data.f_userid}/from_customerlist_edit?num=${currentPage}`}
                title="User Edit"
              >
                <IoExitOutline />
              </Link>
              <span title="User Login" onClick={(e) => UserLogin(data.f_userid)}>
                <BiUser />
              </span>
              {/* <span title="User Login" onClick={(e) => DeleteUser(data.f_userid)}>
                <RiDeleteBinLine className="text-danger1" />
              </span> */}


            </td>
          </tr>
        );
      })
    ) : (

      <tr>
        <td className="no_records" colSpan="11">
          No Records Found
        </td>
      </tr>
    );
  };

  const handleChange = async (e) => {
    setSearchData(e.target.value);
    const res = await customerTable(currentPage, itemPerPage, startDate, endDate, selectData, (searchData = e.target.value));
    let { customerCount, customerData } = res;
    setData(customerData);
    customerCount.length === 1
      ? setCount(customerCount[0].totalCount)
      : setCount(0);
  };

  const onSearchClick = async () => {
    document.querySelector("#searchText").value = "";
    setLoading(true);
    const res = await customerTable(currentPage, itemPerPage, startDate, endDate, selectData, searchData = "");
    let { customerCount, customerData } = res;
    setData(customerData);
    customerCount.length === 1
      ? setCount(customerCount[0].totalCount)
      : setCount(0);
    const res1 = await getCustomerExport(startDate, endDate, selectData, searchData);
    setExportData(res1.customerData)
    setLoading(false);
    setIsExport(true)
  };

  const onTempororyChange = async (e) => {
    console.log(e.target.value)
    const res = await customerTable(currentPage, itemPerPage, startDate, endDate, selectData, searchData, e.target.value);
    let { customerCount, customerData } = res;
    setData(customerData);
    customerCount.length === 1
      ? setCount(customerCount[0].totalCount)
      : setCount(0);
    setLoading(false);
  }

  useEffect(() => {
    // alert("called from customer")
    setLoading(true);
    const apiCall = async () => {
      const res = await customerTable(currentPage, itemPerPage, startDate, endDate, selectData, searchData);
      let { customerCount, customerData } = res;
      setData(customerData);
      customerCount.length === 1
        ? setCount(customerCount[0].totalCount)
        : setCount(0);
      setLoading(false);
    };
    apiCall();
  }, [currentPage, itemPerPage]);

  let listData = tableData(Data);

  return (
    <RB.Row className="rownew1">
      <RB.Col lg={12}>
        <RB.Row className="page_header1 rownew1">
          <div className="tableHeader tableHeader1 search_new">
            <RB.Col md={12} className="table_span">
              <h3 className="page-title d-flex userv">
                <span>Search Results</span>
              </h3>
            </RB.Col>
          </div>
        </RB.Row>
      </RB.Col>

      <RB.Col lg={12}>
        <div className="box_detail" style={{ borderRadius: "4px" }}>
          <div className="page-header row">
            <RB.Col md={12}>
              <Form className="manage_searchorder">
                <RB.Row className="mg_row0">
                  <RB.Col lg={7} md={7} className="customer_leftsrh">
                    <RB.Row className="mg_row0">
                      <RB.Col lg={4} md={4}>
                        <select
                          onChange={(e) => setSelectData(e.target.value)}
                          className="select_customerd"
                        >
                          <option>--select--</option>
                          {DropDownArray1.map((data, inx) => {
                            let { name } = data;
                            return (
                              <option
                                key={"CUSTOMER_DROP_DATA" + inx}
                                value={name}
                                className="extrasearch"
                              >
                                {name}
                              </option>
                            );
                          })}
                        </select>
                      </RB.Col>
                      <RB.Col lg={4} md={4}>
                        <select
                          onChange={onTempororyChange}
                          className="select_customerd"
                        >
                          <option>--select--</option>
                          {["Buyer", "Temporary"].map((data, inx) => {
                            return (
                              <option
                                key={data + inx}
                                value={data}
                                className="extrasearch"
                              >
                                {data}
                              </option>
                            );
                          })}
                        </select>
                      </RB.Col>
                      <RB.Col lg={4} md={4} className="customer_sdate">
                        <DatePicker
                          className="startdate extrasearch"
                          placeholderText="Start Date"
                          selected={startDate}
                          onChange={(date) => setStartDate(date)}
                          isClearable={true}
                          dateFormat="dd-MM-yyyy"
                        />
                      </RB.Col>
                      <RB.Col lg={4} md={4}>
                        <DatePicker
                          className="enddate extrasearch"
                          placeholderText="End Date"
                          selected={endDate}
                          onChange={(date) => setEndDate(date)}
                          isClearable={true}
                          dateFormat="dd-MM-yyyy"
                        />
                      </RB.Col>
                    </RB.Row>
                  </RB.Col>
                  <RB.Col lg={2} md={2} className="customer_sdate">
                    <RB.Col lg={12} className="customer_sdate1">
                      <Button className="customer_srhbtn" size="sm" variant="primary" onClick={onSearchClick}>
                        SEARCH
                      </Button>
                    </RB.Col>
                  </RB.Col>
                  <RB.Col lg={3} md={3}>
                    <RB.Row className="mg_row0">
                      <RB.Col lg={12} className="">
                        <Form.Group>
                          <Form.Control
                            id="searchText"
                            ref={searchText}
                            type="text"
                            placeholder="Search by Text"
                            onChange={handleChange}
                          />
                        </Form.Group>
                      </RB.Col>
                    </RB.Row>
                  </RB.Col>
                </RB.Row>
              </Form>
            </RB.Col>
          </div>
        </div>
      </RB.Col>

      <RB.Col lg={12}>
        <RB.Row className="rownew1">
          <div className="tableHeader tableHeader1 search_new">
            <RB.Col lg={6} md={6} xs={7} className="table_span">
              <h3 className="page-title d-flex userv">
                <span>Customer List</span>
              </h3>
            </RB.Col>
            <RB.Col lg={6} md={6} xs={5} className="table_span text-right">
              {
                isExport ? <ExcelFile fillename="customer" element={<button className="btn btn-primary btn-sm">EXPORT</button>}>
                  <ExcelSheet dataSet={DataSet} name="shipment reports" />
                </ExcelFile>
                  :
                  ""
              }
            </RB.Col>
          </div>
        </RB.Row>

        <div
          className="box_detail table_boxdtl manage_order"
          style={{ marginBottom: "0px" }}
        >
          <RB.Table striped bordered hover variant="dark" responsive>
            <thead>
              <tr className="vtable">
                <th className="s_not">User ID</th>
                <th>Email</th>
                <th>Password</th>
                <th>Name</th>
                <th>Company</th>
                <th> User Type</th>
                <th>Identify User</th>
                <th>Mobile</th>
                <th className="s_notd">Date</th>
                <th className="s_notd">Reg Type</th>
                <th className="action_align text-center">Action</th>
              </tr>
            </thead>

            <tbody>
              {Loading ? (
                <tr>
                  <td className="loadingd" colSpan="10">
                    Loading....
                  </td>
                </tr>
              ) : (
                [listData]
              )}
            </tbody>
          </RB.Table>
        </div>
      </RB.Col>

      {/* <Modal text={ModelMsg} open={isOpen} onClose={() => setIsOpen(false)} /> */}


      <PaginationComponent
        MOCK_DATA={Count}
        currentPage={currentPage}
        setCurrentPage={setCurrentPage}
        itemPerPage={itemPerPage}
        setItemPerPage={setItemPerPage}
      />
      {/* <RB.Col lg={12}>
        <RB.Row className="rownew1">
          <div className="tableHeader tableHeader1 search_new">
            <RB.Col lg={5} md={5} className="table_span">

            </RB.Col>
            <RB.Col lg={2} md={2} className="table_span">
              Go To Page :    <input type="number" className="form-control" value={gotoPage} onChange={(e) => setGoToPage(e.target.value)} /> <button type="submit" onClick={gotToPage}>Go</button>
            </RB.Col>
            <RB.Col lg={5} md={5} className="table_span">


            </RB.Col>
          </div>
        </RB.Row>
      </RB.Col> */}
    </RB.Row>
  );
};

export default CustomerGet;
