exports.getDateArr = (X) => {
    let dates = [];
    for (let i = 0; i < Math.abs(X); i++) {
        dates.push(
            new Date(
                new Date().setHours(0, 0, 0, 0) -
                (X >= 0 ? i : i - i - i) * 24 * 60 * 60 * 1000
            )
        );
    }
    return dates;
};

exports.randomId = (startWith, length, alpha) => {
    var text = startWith ? startWith : "";
    var possible = `0123456789${alpha ? "ABCDEFGHIJKLMNOPQRSTUVWXYZ" : ""}`;

    // Generating random id with specified length
    for (var i = 0; i < length; i++)
        text += possible.charAt(Math.floor(Math.random() * possible.length));

    return text;
};