const KeywordRoute = require("express").Router();

const VisibleKey = require("./visiblekeywords.routes");
const AllKeywords = require("./allkeywords.routes")

KeywordRoute.use(`/keyword`, VisibleKey);
KeywordRoute.use(`/keyword`, AllKeywords)


module.exports = KeywordRoute;