const mongoose = require("mongoose");

const CompanyMaster = mongoose.Schema(
  {
    f_sno: { type: String },
    f_companyname: { type: String },
    f_companygroup: { type: String },
    f_similarcompanyname: { type: String },
    f_discount: { type: String },
    f_city: { type: String },
    f_Assign: { type: String },
    f_email: { type: String }
  },
  { collection: "t_Company_master_IB_MongoDB" }
);

module.exports = CompanyMasterSchema = mongoose.model(
  "t_Company_master_IB_MongoDB",
  CompanyMaster
);
