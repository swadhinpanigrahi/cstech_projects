const Starsize = require("express").Router();
const {
    addStarSize, getStarSizeList, getStarSizeDetail, editStarSizeDetails, deleteStarSizeDetails
} = require("../../controllers/Master/master.starsize.controller");

Starsize.route("/addstarsize").post(addStarSize)
Starsize.route("/getstarsizelist").get(getStarSizeList)
Starsize.route("/getstarsizedetail/:_id").get(getStarSizeDetail)
Starsize.route("/editstarsizedetail").post(editStarSizeDetails)
Starsize.route("/deletestarsizedetail/:_id").get(deleteStarSizeDetails)

module.exports = Starsize;