const {
    registration,
    t_TUR0615518_IB_MongoDB,
    t_LUS104576_IB_MongoDB,
    T_Orders_IB_MongoDB,
    t_BannerImgInfo,
    t_feedback,
    t_HighresUserList,
    t_Highres_down
} = require("../model");
var request = require('request')
var { SQL_URL } = require('../config/config');
const { FeedbackEmail } = require("../utils/nodeMailer/sendMail");

exports.getUnregisteredCustomerList = async (req, res) => {
    let { currentPage, itemPerPage, searchData } = req.query;
    console.log(currentPage, itemPerPage, searchData)
    const num = parseInt(itemPerPage)
    const start = parseInt(currentPage);
    let pipeline;
    let customerCount;
    try {
        if (!searchData || searchData === "") {
            pipeline = [
                { $match: { $and: [{ f_Shortname: { $eq: null } }, { f_groupname: { $eq: null } }] } },
                { $sort: { f_createdate: -1 } },
                { $skip: (start - 1) * num },
                { $limit: num }
            ]
            customerCount = await registration.aggregate([
                { $match: { $and: [{ f_Shortname: { $eq: null } }, { f_groupname: { $eq: null } }] } },
                { $count: "totalCount" }
            ]);
        }

        if (searchData) {
            pipeline = [
                {
                    $match: {
                        $or: [
                            { f_email: { $regex: searchData } },
                            { f_companyname: { $regex: searchData } },
                            { f_Shortname: { $regex: searchData } },
                            { f_groupname: { $regex: searchData } },
                        ]
                    }
                },
                { $sort: { f_createdate: -1 } },
                { $skip: (start - 1) * num },
                { $limit: num }
            ]
            customerCount = await registration.aggregate([
                {
                    $match: {
                        $or: [
                            { f_email: { $regex: searchData } }, { f_companyname: { $regex: searchData } },
                            { f_Shortname: { $regex: searchData } }, { f_groupname: { $regex: searchData } }
                        ]
                    }
                },
                { $count: "totalCount" }
            ])
        }

        const customerData = await registration.aggregate(pipeline);
        res.json({ customerCount: customerCount, customerData });

    } catch (error) {
        res.json({ message: `Error in Controller`, error: error.message });
    }
}

exports.getShortAndGroupName = async (req, res) => {
    const { f_email } = req.body;
    try {
        const CustomerDetails = await registration.findOne({ f_email });
        res.json({ status: 200, CustomerDetails })
    } catch (error) {
        res.json({ message: `Error in Controller`, error: error.message })
    }
}

exports.updateCustomerShortAndGroupName = async (req, res) => {
    // console.log(req.body);
    const { f_Shortname, f_groupname, f_associativename, selectedEmails } = req.body;
    try {
        selectedEmails.forEach(async (email) => {
            const CustomerDetails = await registration.findOne({ f_email: email });
            const t_TUR_Data = await t_TUR0615518_IB_MongoDB.findOne({ CS_userid: CustomerDetails.f_userid })
            console.log(CustomerDetails, t_TUR_Data)

            await registration.updateOne({ _id: CustomerDetails._id }, {
                $set: {
                    f_associativename,
                    f_Shortname,
                    f_groupname
                }
            })
            await t_TUR0615518_IB_MongoDB.updateOne({ _id: t_TUR_Data._id }, {
                $set: {
                    f_associativename,
                    sortcmp_name: f_Shortname,
                    group_cmpname: f_groupname
                }
            })
        })
        request({
            url: `${SQL_URL}/admin/updateCustomerShortAndGroupNameMongoToSql`,
            method: "POST",
            headers: {
                "content-type": "application/json",
            },
            body: {
                "compData": req.body
            },
            json: true
        }, function (err, httpResponse, body) {
            console.log("Response Error", err);
            console.log("Response Data ", body);
            res.json({ status: 200, message: "user updated successfully!!" });
        });
        // res.json({ status: 200, message: "user updated successfully!!" });

    } catch (error) {
        console.log(error);
        res.json({ message: `Error in Controller`, error: error.message });
    }
}


exports.getCustomerData = async (req, res) => {
    let { currentPage, itemPerPage, startDate, endDate, selectData, searchData, regtype } = req.query;
    selectData === "--select--" ? selectData = "" : selectData = selectData
    const num = parseInt(itemPerPage)
    const start = parseInt(currentPage);
    let pipeline;
    let customerCount;
    try {
        if (regtype === "Temporary") {
            if (startDate === undefined && endDate === undefined && !selectData && !searchData) {
                pipeline = [
                    { $match: { CS_regType: "Temporary" } },
                    { $sort: { f_createdate: -1 } },
                    { $skip: (start - 1) * num },
                    { $limit: num }
                ]
                customerCount = await registration.aggregate([{ $match: { CS_regType: "Temporary" } }, { $count: "totalCount" }], (docs, error) => {
                    console.log("am i calling", docs, error)
                });
            }

            if (startDate !== undefined && endDate !== undefined && !selectData && !searchData) {
                var s_date = new Date(startDate);
                var e_date = new Date(endDate);
                s_date.setHours(1);
                e_date.setHours(23);
                pipeline = [
                    { $match: { f_createdate: { $gte: s_date, $lte: e_date, }, CS_regType: "Temporary" } },
                    { $sort: { _id: -1 } },
                    { $skip: (start - 1) * num },
                    { $limit: num }
                ]
                customerCount = await registration.aggregate([
                    { $match: { f_createdate: { $gte: s_date, $lte: e_date }, CS_regType: "Temporary" } },
                    { $count: "totalCount" }
                ]);
            }

            if (searchData) {
                pipeline = [
                    {
                        $match: {
                            CS_regType: "Temporary",
                            $or: [
                                { f_email: { $regex: searchData } },
                                { f_userid: { $regex: searchData } },
                                { f_companyname: { $regex: searchData } },
                                { f_fullname: { $regex: searchData } },
                            ]
                        }
                    },
                    { $sort: { _id: -1 } },
                    { $skip: (start - 1) * num },
                    { $limit: num }
                ]
                customerCount = await registration.aggregate([
                    { $match: { CS_regType: "Temporary", $or: [{ f_email: { $regex: searchData } }, { f_userid: { $regex: searchData } }, { f_companyname: { $regex: searchData } }, { f_fullname: { $regex: searchData } }] } },
                    { $count: "totalCount" }
                ])
            }

            if (selectData && startDate === undefined && endDate === undefined && !searchData) {
                pipeline = [
                    { $match: { f_Identify_User: selectData, CS_regType: "Temporary" } },
                    { $sort: { f_createdate: -1 } },
                    { $skip: (start - 1) * num },
                    { $limit: num }
                ]
                customerCount = await registration.aggregate([
                    { $match: { f_Identify_User: selectData, CS_regType: "Temporary" } },
                    { $count: "totalCount" }
                ])
            }

            if (selectData && startDate !== undefined && endDate !== undefined && !searchData) {
                var s_date = new Date(startDate);
                var e_date = new Date(endDate);
                s_date.setHours(1);
                e_date.setHours(23);
                pipeline = [
                    { $match: { f_createdate: { $gte: s_date, $lte: e_date, }, f_Identify_User: selectData, CS_regType: "Temporary" } },
                    { $sort: { f_createdate: -1 } },
                    { $skip: (start - 1) * num },
                    { $limit: num }
                ]

                customerCount = await registration.aggregate([{ $match: { f_createdate: { $gte: s_date, $lte: e_date }, f_Identify_User: selectData, CS_regType: "Temporary" } }, { $count: "totalCount" }]);

            }

            const customerData = await registration.aggregate(pipeline);
            res.json({ customerCount: customerCount, customerData });

        } else if (regtype === "Buyer") {
            if (startDate === undefined && endDate === undefined && !selectData && !searchData) {
                pipeline = [
                    { $match: { CS_regType: "Buyer" } },
                    { $sort: { f_createdate: -1 } },
                    { $skip: (start - 1) * num },
                    { $limit: num }
                ]
                customerCount = await registration.aggregate([{ $match: { CS_regType: "Buyer" } }, { $count: "totalCount" }], (docs, error) => {
                    console.log("am i calling", docs, error)
                });
            }

            if (startDate !== undefined && endDate !== undefined && !selectData && !searchData) {
                var s_date = new Date(startDate);
                var e_date = new Date(endDate);
                s_date.setHours(1);
                e_date.setHours(23);
                pipeline = [
                    { $match: { f_createdate: { $gte: s_date, $lte: e_date, }, CS_regType: "Buyer" } },
                    { $sort: { _id: -1 } },
                    { $skip: (start - 1) * num },
                    { $limit: num }
                ]
                customerCount = await registration.aggregate([
                    { $match: { f_createdate: { $gte: s_date, $lte: e_date }, CS_regType: "Buyer" } },
                    { $count: "totalCount" }
                ]);
            }

            if (searchData) {
                pipeline = [
                    {
                        $match: {
                            CS_regType: "Buyer",
                            $or: [
                                { f_email: { $regex: searchData } },
                                { f_userid: { $regex: searchData } },
                                { f_companyname: { $regex: searchData } },
                                { f_fullname: { $regex: searchData } },
                            ]
                        }
                    },
                    { $sort: { _id: -1 } },
                    { $skip: (start - 1) * num },
                    { $limit: num }
                ]
                customerCount = await registration.aggregate([
                    { $match: { CS_regType: "Buyer", $or: [{ f_email: { $regex: searchData } }, { f_userid: { $regex: searchData } }, { f_companyname: { $regex: searchData } }, { f_fullname: { $regex: searchData } }] } },
                    { $count: "totalCount" }
                ])
            }

            if (selectData && startDate === undefined && endDate === undefined && !searchData) {
                pipeline = [
                    { $match: { f_Identify_User: selectData, CS_regType: "Buyer" } },
                    { $sort: { f_createdate: -1 } },
                    { $skip: (start - 1) * num },
                    { $limit: num }
                ]
                customerCount = await registration.aggregate([
                    { $match: { f_Identify_User: selectData, CS_regType: "Buyer" } },
                    { $count: "totalCount" }
                ])
            }

            if (selectData && startDate !== undefined && endDate !== undefined && !searchData) {
                var s_date = new Date(startDate);
                var e_date = new Date(endDate);
                s_date.setHours(1);
                e_date.setHours(23);
                pipeline = [
                    { $match: { f_createdate: { $gte: s_date, $lte: e_date, }, f_Identify_User: selectData, CS_regType: "Buyer" } },
                    { $sort: { f_createdate: -1 } },
                    { $skip: (start - 1) * num },
                    { $limit: num }
                ]

                customerCount = await registration.aggregate([{ $match: { f_createdate: { $gte: s_date, $lte: e_date }, f_Identify_User: selectData, CS_regType: "Buyer" } }, { $count: "totalCount" }]);

            }

            const customerData = await registration.aggregate(pipeline);
            res.json({ customerCount: customerCount, customerData });
        } else {
            if (startDate === undefined && endDate === undefined && !selectData && !searchData) {
                pipeline = [
                    { $sort: { f_createdate: -1 } },
                    { $skip: (start - 1) * num },
                    { $limit: num }
                ]
                customerCount = await registration.aggregate([{ $count: "totalCount" }]);
            }

            if (startDate !== undefined && endDate !== undefined && !selectData && !searchData) {
                var s_date = new Date(startDate);
                var e_date = new Date(endDate);
                s_date.setHours(1);
                e_date.setHours(23);
                pipeline = [
                    { $match: { f_createdate: { $gte: s_date, $lte: e_date, }, } },
                    { $sort: { _id: -1 } },
                    { $skip: (start - 1) * num },
                    { $limit: num }
                ]
                customerCount = await registration.aggregate([{ $match: { f_createdate: { $gte: s_date, $lte: e_date } } }, { $count: "totalCount" }]);
            }

            if (searchData) {
                pipeline = [
                    {
                        $match: {
                            $or: [
                                { f_email: { $regex: searchData } },
                                { f_userid: { $regex: searchData } },
                                { f_companyname: { $regex: searchData } },
                                { f_fullname: { $regex: searchData } },
                            ]
                        }
                    },
                    { $sort: { _id: -1 } },
                    { $skip: (start - 1) * num },
                    { $limit: num }
                ]
                customerCount = await registration.aggregate([
                    { $match: { $or: [{ f_email: { $regex: searchData } }, { f_userid: { $regex: searchData } }, { f_companyname: { $regex: searchData } }, { f_fullname: { $regex: searchData } }] } },
                    { $count: "totalCount" }
                ])
            }

            if (selectData && startDate === undefined && endDate === undefined && !searchData) {
                pipeline = [
                    { $match: { f_Identify_User: selectData } },
                    { $sort: { f_createdate: -1 } },
                    { $skip: (start - 1) * num },
                    { $limit: num }
                ]
                customerCount = await registration.aggregate([
                    { $match: { f_Identify_User: selectData } },
                    { $count: "totalCount" }
                ])
            }

            if (selectData && startDate !== undefined && endDate !== undefined && !searchData) {
                var s_date = new Date(startDate);
                var e_date = new Date(endDate);
                s_date.setHours(1);
                e_date.setHours(23);
                pipeline = [
                    { $match: { f_createdate: { $gte: s_date, $lte: e_date, }, f_Identify_User: selectData } },
                    { $sort: { f_createdate: -1 } },
                    { $skip: (start - 1) * num },
                    { $limit: num }
                ]
                customerCount = await registration.aggregate([
                    { $match: { f_createdate: { $gte: s_date, $lte: e_date }, f_Identify_User: selectData } },
                    { $count: "totalCount" }
                ]);
            }
            const customerData = await registration.aggregate(pipeline);
            res.json({ customerCount: customerCount, customerData });
        }
    } catch (error) {
        res.json({ message: `Error in Controller`, error: error.message });
    }

}

exports.DeleteUserRecord = async (req, res) => {
    const { userId } = req.params;
    let status;
    let message;
    try {
        const REG_DATA = await registration.findOne({ f_userid: userId })
        const TUR_DATA = await t_TUR0615518_IB_MongoDB.findOne({ CS_userid: userId })
        const LUS_DATA = await t_LUS104576_IB_MongoDB.findOne({ CS_userid: userId });

        if (REG_DATA && TUR_DATA && LUS_DATA) {
            await registration.deleteOne({ _id: REG_DATA._id });
            await t_TUR0615518_IB_MongoDB.deleteOne({ _id: TUR_DATA._id })
            await t_LUS104576_IB_MongoDB.deleteOne({ _id: LUS_DATA._id })
            status = 200
            message = "User Deleted Successfully!"
        } else {
            status = 400
            message = "Error While Deleting User!"
        }

        res.json({ status, message, userId });
    } catch (error) {
        res
            .status(500)
            .json({ message: `Error in Controller`, error: error.message });
    }
}

exports.getExportCustomerData = async (req, res) => {
    let { startDate, endDate, selectData, searchData } = req.query;
    selectData === "--select--" ? selectData = "" : selectData = selectData
    console.log(startDate, endDate, selectData, searchData)
    let pipeline;
    try {
        if (startDate === undefined && endDate === undefined && !selectData && !searchData) {
            pipeline = [
                { $sort: { _id: -1 } },
            ]
        }

        if (startDate !== undefined && endDate !== undefined && !selectData && !searchData) {
            var s_date = new Date(startDate);
            var e_date = new Date(endDate);
            s_date.setHours(1);
            e_date.setHours(23);
            pipeline = [
                { $match: { f_createdate: { $gte: s_date, $lte: e_date, }, } },
                { $sort: { _id: -1 } },
            ]
        }

        if (searchData) {
            pipeline = [
                {
                    $match: {
                        $or: [
                            { f_email: { $regex: searchData } },
                            { f_userid: { $regex: searchData } },
                            { f_companyname: { $regex: searchData } },
                            { f_fullname: { $regex: searchData } },
                        ]
                    }
                },
                { $sort: { _id: -1 } },
            ]
        }

        if (selectData && startDate === undefined && endDate === undefined && !searchData) {
            pipeline = [
                { $match: { f_Identify_User: selectData } },
                { $sort: { _id: -1 } },
            ]
        }

        if (selectData && startDate !== undefined && endDate !== undefined && !searchData) {
            var s_date = new Date(startDate);
            var e_date = new Date(endDate);
            s_date.setHours(1);
            e_date.setHours(23);
            pipeline = [
                { $match: { f_createdate: { $gte: s_date, $lte: e_date, }, f_Identify_User: selectData } },
                { $sort: { _id: -1 } },
            ]
        }

        const customerData = await registration.aggregate(pipeline);
        res.json({ customerData });

    } catch (error) {
        res.json({ message: `Error in Controller`, error: error.message });
    }
}

exports.UnpaidUser = async (req, res) => {
    let { currentPage, itemPerPage, searchData } = req.query;
    const num = parseInt(itemPerPage)
    const start = parseInt(currentPage);
    let pipeline;
    let countpipeline;
    console.log(currentPage, itemPerPage, searchData)
    try {
        if (!searchData) {
            pipeline = [
                { $match: { t_paymentstatus: "Unpaid" } },
                { $group: { _id: "$T_username" } },
                { $skip: (start - 1) * num },
                { $limit: num },
                {
                    $lookup: {
                        from: "t_LUS104576_IB_MongoDB",
                        localField: "_id",
                        foreignField: "CS_username",
                        as: "LUS"
                    }
                },
                { $unwind: { path: "$LUS" } },
                {
                    $lookup: {
                        from: "t_TUR0615518_IB_MongoDB",
                        localField: "LUS.CS_userid",
                        foreignField: "CS_userid",
                        as: "TUR"
                    }
                },
                { $unwind: { path: "$TUR" } },
            ]
            countpipeline = [
                { $match: { t_paymentstatus: "Unpaid" } },
                { $group: { _id: "$T_username" } },
                { $count: "totalCount" }
            ]
        }

        if (searchData) {
            pipeline = [
                { $match: { t_paymentstatus: "Unpaid", T_username: { $regex: searchData } } },
                { $group: { _id: "$T_username" } },
                { $skip: (start - 1) * num },
                { $limit: num },
                {
                    $lookup: {
                        from: "t_LUS104576_IB_MongoDB",
                        localField: "_id",
                        foreignField: "CS_username",
                        as: "LUS"
                    }
                },
                { $unwind: { path: "$LUS" } },
                {
                    $lookup: {
                        from: "t_TUR0615518_IB_MongoDB",
                        localField: "LUS.CS_userid",
                        foreignField: "CS_userid",
                        as: "TUR"
                    }
                },
                { $unwind: { path: "$TUR" } },
            ]
            countpipeline = [
                { $match: { t_paymentstatus: "Unpaid" }, T_username: { $regex: searchData } },
                { $group: { _id: "$T_username" } },
                { $count: "totalCount" }
            ]
        }


        const customerData = await T_Orders_IB_MongoDB.aggregate(pipeline)
        const customerCount = await T_Orders_IB_MongoDB.aggregate(countpipeline)
        res.json({ customerCount, customerData });
    } catch (error) {
        res.json({ message: `Error in Controller`, error: error.message });
    }
}

exports.superImageUser = async (req, res) => {
    let { currentPage, itemPerPage, searchData } = req.query;
    const num = parseInt(itemPerPage)
    const start = parseInt(currentPage);
    let pipeline;
    let countpipeline;
    try {
        if (!searchData) {
            pipeline = [
                { $sort: { _id: -1 } },
                { $skip: (start - 1) * num },
                { $limit: num },
            ]
            countpipeline = [
                { $count: "totalcount" }
            ]
        } else {
            pipeline = [
                { $match: { f_planname: { $regex: searchData } } },
                { $sort: { _id: -1 } },
                { $skip: (start - 1) * num },
                { $limit: num },
            ]
            countpipeline = [
                { $count: "totalcount" }
            ]
        }

        const customerData = await t_HighresUserList.aggregate(pipeline);
        const customerCount = await t_HighresUserList.aggregate(countpipeline);

        res.json({ customerData, customerCount })
    } catch (error) {
        res.json({ message: `Error in Controller`, error: error.message });
    }
}

exports.superImageUserViewList = async (req, res) => {
    const { f_email } = req.params;
    try {
        const customerData = await t_Highres_down.find({ Emailid: f_email })
        res.json({ email: f_email, customerCount: customerData.length, customerData })
    } catch (error) {
        res.json({ message: `Error in Controller`, error: error.message });
    }
}

exports.feedbackUser = async (req, res) => {
    let { currentPage, itemPerPage, searchData, searchSelect } = req.query;
    const num = parseInt(itemPerPage)
    const start = parseInt(currentPage);
    let pipeline;
    let countpipeline;
    try {
        if (!searchData && !searchSelect) {
            pipeline = [
                { $sort: { _id: -1 } },
                { $skip: (start - 1) * num },
                { $limit: num },
            ]
            countpipeline = [
                { $count: "totalcount" }
            ]
        }

        if (searchData) {
            if (searchData === "Pending" || searchData === "Confirm") {
                let condition = searchData === "Pending" ? 0 : 1
                pipeline = [
                    {
                        $match: { f_status: condition }
                    },
                    { $sort: { _id: -1 } },
                    { $skip: (start - 1) * num },
                    { $limit: num },
                ]
                countpipeline = [
                    {
                        $match: { f_status: condition }
                    },
                    { $count: "totalcount" }
                ]
            } else {
                pipeline = [
                    {
                        $match: {
                            $or: [
                                { CS_username: { $regex: searchData } },
                                { f_name: { $regex: searchData } },
                            ]
                        }
                    },
                    { $sort: { _id: -1 } },
                    { $skip: (start - 1) * num },
                    { $limit: num },
                ]
                countpipeline = [
                    {
                        $match: {
                            $or: [
                                { CS_username: { $regex: searchData } },
                                { f_name: { $regex: searchData } },
                            ]
                        }
                    },
                    { $count: "totalcount" }
                ]
            }
        }

        const customerData = await t_feedback.aggregate(pipeline);
        const customerCount = await t_feedback.aggregate(countpipeline);

        res.json({ customerData, customerCount })

    } catch (error) {
        res.json({ message: `Error in Controller`, error: error.message });
    }
}

exports.ReplayEmail = async (req, res) => {
    const { CS_username, cs_userid, message } = req.body;
    try {
        await FeedbackEmail(
            { CS_username, cs_userid, message },
            (data, error) => {
                if (!error) {
                    console.log(data);
                } else {
                    console.log(error);
                }
            }
        )

        res.json({ status: 200, message: "Mail Send Successfully!" });

    } catch (error) {
        res.json({ message: `Error in Controller`, error: error.message });
    }
}

exports.deleteFeedback = async (req, res) => {
    const { _id } = req.params;
    try {
        const deletedData = await t_feedback.findByIdAndRemove({ _id });
        res.json({ status: 200, deletedData })
    } catch (error) {
        res.json({ message: `Error in Controller`, error: error.message });
    }
}

exports.BannerImageUser = async (req, res) => {
    let { currentPage, itemPerPage, searchData } = req.query;
    const num = parseInt(itemPerPage)
    const start = parseInt(currentPage);
    let pipeline;
    let countpipeline;
    console.log(currentPage, itemPerPage, searchData)
    try {
        if (!searchData) {
            pipeline = [
                { $sort: { _id: -1 } },
                { $skip: (start - 1) * num },
                { $limit: num },
            ]
            countpipeline = [
                { $count: "totalcount" }
            ]
        } else {
            pipeline = [
                { $match: { $or: [{ Ip: { $regex: searchData } }, { Email: { $regex: searchData } }] } },
                { $sort: { _id: -1 } },
                { $skip: (start - 1) * num },
                { $limit: num },
            ]
            countpipeline = [
                { $count: "totalcount" }
            ]
        }

        const customerData = await t_BannerImgInfo.aggregate(pipeline);
        const customerCount = await t_BannerImgInfo.aggregate(countpipeline);

        res.json({ customerData, customerCount })
    } catch (error) {
        res.json({ message: `Error in Controller`, error: error.message });
    }
}
