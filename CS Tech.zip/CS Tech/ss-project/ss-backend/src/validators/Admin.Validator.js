// import joi from "joi";
const joi = require("joi")

exports.createCustomerValidetor = joi.object({
    name: joi.string().required(),
    email: joi.string().email().required(),
    phone: joi.string().required(),
    password: joi.string().required(),
    companyName: joi.string().required(),
    address: joi.string().required(),
    pincode: joi.string().required(),
    city: joi.string().required(),
    state: joi.string().required(),
    country: joi.string().required(),
    beneficiary_name: joi.string().allow(''),
    bank_name: joi.string().allow(''),
    account_number: joi.string().allow(''),
    ifsc_code: joi.string().allow(''),
    bank_branch: joi.string().allow('')
});

exports.updateCustomerValidetor = joi.object({
    name: joi.string().required(),
    email: joi.string().email().required(),
    phone: joi.string().required(),
    password: joi.string().required(),
    companyName: joi.string().required(),
    address: joi.string().required(),
    pincode: joi.string().required(),
    city: joi.string().required(),
    state: joi.string().required(),
    country: joi.string().required(),
    beneficiary_name: joi.string().allow(''),
    bank_name: joi.string().allow(''),
    account_number: joi.string().allow(''),
    ifsc_code: joi.string().allow(''),
    bank_branch: joi.string().allow(''),
    activate: joi.allow(),
    _id: joi.allow(),
    isUpdate: joi.allow(),
    createdAt: joi.allow(),
    updatedAt: joi.allow(),
    __v: joi.allow(),
});