import React, { useState } from 'react';
import * as RB from "react-bootstrap";
import { Row } from "react-bootstrap";
import { AddVideoModalForm } from "../../../Components/Forms/FormElements";

const AddVideo = (
    { show_addvideo, setShow }
) => {
    const [FormData, setFormData] = useState({});

    const closeModal = () => {
        setShow(false)
    }
    const handleChange = (e) => {
        let { name, value, type, checked } = e.target;
        if (type === "number") {
            const data = { ...FormData }
            data[name] = value
            setFormData(data)
        } else {
            const data = { ...FormData }
            data[name] = !checked
            setFormData(data)
        }
    }

    const addVedioModel = async () => {
        console.log(FormData)
    }
    return (
        <div>
            <RB.Modal show={show_addvideo} onHide={closeModal} className="ordermanage_modal">
                <RB.Modal.Header closeButton>
                    <RB.Modal.Title>Add Modal Video</RB.Modal.Title>
                </RB.Modal.Header>
                <RB.Modal.Body>
                    <RB.Row>
                        <RB.Col lg={12} md={12}>
                            <RB.Row>
                                <RB.Col lg={12} md={12}>
                                    <RB.Form>
                                        {AddVideoModalForm.map((data, inx) => {
                                            let { label, type, name, controlId } = data;
                                            return (

                                                <>
                                                    {type === "number" ?
                                                        <RB.Form.Group as={Row} controlId={controlId} key={controlId + inx}>
                                                            <RB.Col lg={4} md={4}>
                                                                <RB.Form.Label>{label} :</RB.Form.Label>
                                                            </RB.Col>
                                                            <RB.Col lg={6} md={7}>
                                                                <RB.Form.Control type={type} name={name} onChange={handleChange} />
                                                            </RB.Col>
                                                        </RB.Form.Group>
                                                        :
                                                        <RB.Form.Group as={Row} controlId={controlId} key={controlId + inx}
                                                            style={{ marginBottom: "5px" }}>
                                                            <RB.Col lg={4} md={4}>
                                                                <RB.Form.Label>{label} :</RB.Form.Label>
                                                            </RB.Col>
                                                            <RB.Col lg={6} md={7}>
                                                                <RB.Form.Check type={type} name={name} checked={FormData.f_map} onChange={handleChange} />
                                                            </RB.Col>
                                                        </RB.Form.Group>

                                                    }
                                                </>

                                            );

                                        })}
                                        <RB.Row>
                                            <RB.Col lg={4} md={4}></RB.Col>
                                            <RB.Col lg={6} md={7}>
                                                <RB.Button
                                                    size="sm" variant="primary"
                                                    onClick={addVedioModel}
                                                >
                                                    SUBMIT
                                                </RB.Button>
                                            </RB.Col>
                                        </RB.Row>
                                    </RB.Form>
                                </RB.Col>
                            </RB.Row>
                        </RB.Col>
                    </RB.Row>
                </RB.Modal.Body>
            </RB.Modal>
        </div>
    )
}

export default AddVideo