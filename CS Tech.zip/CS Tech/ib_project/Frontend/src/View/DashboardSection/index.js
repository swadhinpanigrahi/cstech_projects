import React, { useState } from "react";
import { Route, Switch, useHistory } from "react-router-dom";
import { Container } from "react-bootstrap";
import { customerFilter, orderFilter, proposalFilter, followerFilter } from "../../Utils/api";
import { ROUTES } from "../NavComponents";
import Footer from "../../Components/NavSection/Footer"

import TopBar from "../../Components/NavSection/TopBar"
import AuthButton from "../LogoutSection/AuthButton";

const DashSection = () => {
  const history = useHistory();
  const [search, setSearch] = useState("");
  const [CustomerData, setCustomerData] = useState([]);
  const [OrderData, setOrderData] = useState([]);
  const [ProposelData, setProposelData] = useState([]);
  const [Followups, setFollowups] = useState([]);
  const [spanArr, setSpanArr] = useState([]);
  const [spanOrder, setSpanOrder] = useState([]);
  const [Loading, setLoading] = useState(false);
  const [Error, setError] = useState({
    errMsg: "",
    errClr: "",
  });

  const handleSearch = (e) => {
     
    setSearch(e.target.value)
  }

  const fun1 = async () => {
    const cusApi = await customerFilter({ search });
    let { userData } = cusApi;
    setCustomerData(userData);
  };

  const fun2 = async () => {
    const orderApi = await orderFilter({ search });
    let { countArr, userData } = orderApi;
    setOrderData(userData);
    setSpanOrder(countArr);
  };

  const fun3 = async () => {
    const proposalApi = await proposalFilter({ search });
    let { userData } = proposalApi;
    setProposelData(userData);
  };

  const fun4 = async () => {
    const followApi = await followerFilter({ search });
    let { userData, spanArray } = followApi;
    setFollowups(userData);
    setSpanArr(spanArray);
  };

  const onSearch = (e) => {
    e.preventDefault();
    // e.target.name = setSearch(document.getElementById("getSearchValue").value);
    if (search === "") {
      let updateError = { ...Error };
      updateError.errCls = "border-danger";
      setError({ ...updateError });
    } else {
      setLoading(true);
      fun1();
      fun2();
      fun3();
      fun4();
      setTimeout(() => {
        history.push("/dashboard/searchdata");
        setLoading(false);
      }, 2000);
    }
  };

  let { errClr } = Error;

  return (
    <>
      <TopBar isVisible={true} onSearch={onSearch} errClr={errClr} Loading={Loading} handleSearch={handleSearch} />
      <AuthButton />
      <main className="main_afterlogin">
        <Container fluid>
          <Switch>
            {ROUTES.map((data, inx) => {
              let { path, Components } = data;
              return (
                <Route key={"ROUTES" + inx} path={path}
                  component={() => (
                    <Components
                      search={search}
                      CustomerData={CustomerData}
                      OrderData={OrderData}
                      ProposelData={ProposelData}
                      Followups={Followups}
                      spanArr={spanArr}
                      spanOrder={spanOrder}
                      setProposelData={setProposelData}
                    />
                  )}
                />
              );
            })}
          </Switch>
        </Container>
      </main>
      <Footer />
    </>
  );
};

export default DashSection;
