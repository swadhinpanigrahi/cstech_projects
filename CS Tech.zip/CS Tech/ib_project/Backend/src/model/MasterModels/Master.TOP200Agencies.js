const mongoose = require("mongoose");

const MasterAgenciesSchema = mongoose.Schema(
    {
        f_sno: { type: String },
        f_ip: { type: String },
        f_email: { type: String },
        f_Cname: { type: String },
        f_createdate: { type: Date },
        f_status: { type: String }
    },
    { collection: "t_TOP200Agencies" }
);

module.exports = M_AGENCIES = mongoose.model(
    "t_TOP200Agencies",
    MasterAgenciesSchema
);