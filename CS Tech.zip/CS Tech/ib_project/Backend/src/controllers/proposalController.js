const {
  t_orderproposal_IB_MongoDB,
  t_ordproposal_details_IB_MongoDB,
  RegistrationSchema,
  t_LUS104576_IB_MongoDB,
  t_TUR0615518_IB_MongoDB,
  t_Images,
  t_pricingdetail,
  T_ShopingCart,
  Counter
} = require("../model");
const request = require('request')
const { dir } = require("../config/fileSource");
const { SQL_URL } = require('../config/config')
const { IBProposal } = require("../utils/nodeMailer/sendMail")

exports.getProposalData = async (req, res) => {
  let { currentPage, itemPerPage, searchData } = req.query;
  console.log(currentPage, itemPerPage, searchData);
  const num = parseInt(itemPerPage);
  const start = parseInt(currentPage);
  let pipeline;
  let proposalCount;
  try {
    if (!searchData) {
      pipeline = [
        { $sort: { T_orderdate: -1 } },
        { $skip: (start - 1) * num },
        { $limit: num },
      ];
      proposalCount = await t_orderproposal_IB_MongoDB.aggregate([
        { $count: "totalCount" },
      ]);
    }

    if (searchData) {
      pipeline = [
        {
          $match: {
            $or: [
              { T_username: { $regex: searchData } },
              { T_orderid: { $regex: searchData } },
            ],
          },
        },
        { $sort: { T_orderdate: -1 } },
        { $skip: (start - 1) * num },
        { $limit: num },
      ];
      proposalCount = await t_orderproposal_IB_MongoDB.aggregate([
        {
          $match: {
            $or: [
              { T_username: { $regex: searchData } },
              { T_orderid: { $regex: searchData } },
            ],
          },
        },
        { $count: "totalCount" },
      ]);
    }

    const proposalData = await t_orderproposal_IB_MongoDB.aggregate(pipeline);
    res.json({ proposalCount: proposalCount, proposalData });
  } catch (error) {
    res.json({ message: `Error in Controller`, error: error.message });
  }
};

exports.getProposalDetails = async (req, res) => {
  const { T_orderid } = req.params;
  try {
    const proposalDetail = await t_orderproposal_IB_MongoDB.findOne({
      T_orderid: T_orderid,
    });
    const proposalDetails = await t_ordproposal_details_IB_MongoDB.find({
      t_orderid: proposalDetail.T_orderid,
    });
    const userDetails = await RegistrationSchema.findOne({
      f_email: proposalDetail.T_username,
    }); //await proposal.findOne({ f_proposal_RefrencesID: T_orderid  })

    res.json({ status: 200, proposalDetail, proposalDetails, userDetails });
  } catch (error) {
    res.json({ message: `Error in Controller`, error: error.message });
  }
};

exports.deleteProposalDetail = async (req, res) => {
  const { T_orderid } = req.params;
  try {
    request({
      url: `${SQL_URL}/admin/DeleteProposalMongoToSql`,
      method: "POST",
      headers: {
        "content-type": "application/json",
      },
      body: {
        "orderId": T_orderid
      },
      json: true
    }, async function (err, httpResponse, ResBodybody) {
      console.log(err, ResBodybody);
      const t_proposal = await t_orderproposal_IB_MongoDB.findOne({ T_orderid });
      const t_proposalDetails = await t_ordproposal_details_IB_MongoDB.findOne({
        t_orderid: T_orderid,
      });
      if (t_proposal && t_proposalDetails) {
        await t_orderproposal_IB_MongoDB.deleteOne({ _id: t_proposal._id });
        await t_ordproposal_details_IB_MongoDB.deleteOne({
          _id: t_proposalDetails._id,
        });
        res.json({ status: 200, message: "successfully deleted proposal" });
      } else {
        res.json({ status: 400, message: "error while deleting proposal" });
      }
    }
    );



    return

  } catch (error) {
    res.json({ message: `Error in Controller`, error: error.message });
  }
};

exports.sendProposalMail = async (req, res) => {
  const { email, T_orderid } = req.body;
  try {
    await IBProposal(
      { email, T_orderid },
      (data, error) => {
        if (!error) {
          console.log(data);
        } else {
          console.log(error);
        }
      }
    )
    res.json({ status: 200, message: "Mail Send Successfully!" })
  } catch (error) {
    res.json({ message: `Error in Controller`, error: error.message });
  }
}

exports.getImageSizeDrop = async (req, res) => {
  const { f_pricing } = req.params
  try {
    if (f_pricing === "29") {
      const imageSize = await t_pricingdetail.find(
        { f_id: { $in: [172, 173, 174] } }, { f_typename: 1, f_price: 1, f_dimenation: 1, f_dpi: 1, f_outputsize: 1 }
      ).sort({ f_typename: -1 });
      res.json({ status: 200, imageSize })
    } else {
      const imageSize = await t_pricingdetail.find(
        { f_id: { $in: [168, 169, 170, 171] } }, { f_typename: 1, f_price: 1, f_dimenation: 1, f_dpi: 1, f_outputsize: 1 }
      ).sort({ f_typename: -1 });
      res.json({ status: 200, imageSize })
    }
  } catch (error) {
    res.json({ message: `Error in Controller`, error: error.message });
  }
}

exports.getImageById = async (req, res) => {
  const { f_imgid } = req.body;
  let imageArray = f_imgid.split(" ");
  imageArray = [... new Set(imageArray)];
  try {

    let imageData = [];
    for (let i = 0; i < imageArray.length; i++) {
      const image = await t_Images.findOne({ F_imgid: imageArray[i] });
      if (image) {
        imageData.push(image)
      }
    }

    res.json({ status: 200, imageData })
  } catch (error) {
    res.json({ message: `Error in Controller`, error: error.message });
  }
}

exports.getFromCartArray = async (req, res) => {
  const { CS_username } = req.params;
  try {
    const ImageData = await T_ShopingCart.find({ CS_username }).sort({ _id: -1 });
    res.json({ status: 200, ImageDetails: ImageData })
  } catch (error) {
    res.json({ message: `Error in Controller`, error: error.message });
  }
}

exports.addTocart = async (req, res) => {
  const { CS_username, CS_imgCode, CS_imgId, CS_id,
    CS_userid, CS_ImgType, CS_Price, f_dimenation, f_dpi, f_outputsize } = req.body;
  let status;
  let message;
  try {
    const ImageData = await T_ShopingCart.findOne({ CS_username, CS_imgCode });
    if (ImageData) {
      status = 400;
      message = "already added in cart!"
    } else {
      await T_ShopingCart(
        {
          CS_username, CS_imgCode, CS_imgId, CS_id, CS_userid, CS_ImgType, CS_ImgType_up: CS_ImgType,
          CS_Price, f_mydimension: `${f_dimenation} at ${f_dpi}`,
        }
      ).save();
      status = 200;
      message = "image added in cart successfully!"
    }
    res.json({ status, message })
  } catch (error) {
    res.json({ message: `Error in Controller`, error: error.message });
  }
}

exports.deleteFromCart = async (req, res) => {
  const { CS_username, CS_imgCode } = req.body;
  try {
    const ImageData = await T_ShopingCart.findOne({ CS_username, CS_imgCode });
    await T_ShopingCart.deleteOne({ _id: ImageData._id })
    res.json({ status: 200, message: `remove from cart successfully!` })
  } catch (error) {
    res.json({ message: `Error in Controller`, error: error.message });
  }
}

exports.FinalizeProposal = async (req, res) => {
  let {
    T_username, f_Creditperiod, f_GSTNNo, f_amt, f_amtpay, f_client, f_discount, f_finalamt,
    f_heading, f_sertax, f_state, f_totimg, ImageArray
  } = req.body
  try {
    request({
      url: `${SQL_URL}/admin/FinalizeProposalMongoToSql`,
      method: "POST",
      headers: {
        "content-type": "application/json",
      },
      body: {
        "propData": req.body
      },
      json: true
    }, async function (err, httpResponse, Resbody) {
      console.log(err, Resbody);
      //  res.json({ status: 200, message: "Invoice Rejected" })
      var propOrderId = Resbody.recordset[0].orderId
      const f_unique_T_orderid = await Counter.findOneAndUpdate({ _id: "proposal_t_orderid" }, {
        $inc: { sequence: 1 }
      }, { useFindAndModify: false });

      const proposalDetail = await t_orderproposal_IB_MongoDB(
        {
          T_orderid: propOrderId, T_username, f_Creditperiod, f_GSTNNo, f_amt,
          f_amtpay, f_client, f_discount, f_finalamt,
          f_heading, f_sertax, f_state, f_totimg, f_proposaluser: f_client
        }
      ).save()

      ImageArray.forEach(async (data) => {
        const f_unique_t_sno = await Counter.findOneAndUpdate({ _id: "proposal_t_sno" }, {
          $inc: { sequence: 1 }
        }, { useFindAndModify: false });
        const proposalDetails = await t_ordproposal_details_IB_MongoDB(
          {
            t_sno: f_unique_t_sno.sequence, t_orderid: propOrderId,
            t_imageid: data.CS_imgCode, t_price: data.CS_Price, t_quality: data.CS_ImgType,
            f_rank: data.CS_imgId, f_state, f_mydimension: data.f_mydimension
          }
        ).save()
        if (proposalDetails) {
          const removeFromCart = await T_ShopingCart.findOne({ CS_username: T_username, CS_imgCode: data.CS_imgCode });
          if (removeFromCart) {
            await T_ShopingCart.deleteOne({ _id: removeFromCart._id })
          }
        }
      })

      res.json({ status: 200, message: "proposal created successfully" });
    }
    );

    return


  } catch (error) {
    res.json({ message: `Error in Controller`, error: error.message });
  }
}

exports.getOrderUserDetails = async (req, res) => {
  let { CS_username } = req.params
  try {
    const LUS = await t_LUS104576_IB_MongoDB.findOne({ CS_username });
    const TUR = await t_TUR0615518_IB_MongoDB.findOne({ CS_userid: LUS.CS_userid });

    const userData = {
      CS_userid: LUS.CS_userid,
      CS_firstname: LUS.CS_firstname,
      CS_lastname: LUS.CS_lastname,
      CS_username: LUS.CS_username,
      CS_companynames: LUS.CS_companynames,
      CS_mobile: LUS.CS_mobile,
      f_GSTIN: LUS.f_GSTIN,
      CS_country: TUR.CS_country,
      CS_state: TUR.CS_state,
      CS_pin: TUR.CS_pin,
      CS_address: TUR.CS_address
    }

    res.json({ status: 200, userData })
  } catch (error) {
    res.json({ message: `Error in Controller`, error: error.message });
  }
}

