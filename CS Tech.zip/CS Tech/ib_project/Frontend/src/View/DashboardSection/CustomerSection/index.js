import React from 'react';
import { Route } from "react-router-dom";
import CustomerGet from "./CustomerGet";
import UnregisterCustomerGet from "./UnregisterCustomerGet";
import UnpaidUserList from "./UnpaidUserList";
import SuperImageUser from "./SuperImageUser";
import UserFeedback from "./UserFeedback";
import BannerImagesDownload from "./BannerImagesDownload";


const CustomerSection = () => {
    return (
        <div>
            <Route path="/dashboard/customer/get" component={CustomerGet} />
            <Route path="/dashboard/customer/unregistercustomer/get" component={UnregisterCustomerGet} />
            <Route path="/dashboard/customer/unpaiduser/get" component={UnpaidUserList} />
            <Route path="/dashboard/customer/superimageuser/get" component={SuperImageUser} />
            <Route path="/dashboard/customer/userfeedback/get" component={UserFeedback} />
            <Route path="/dashboard/customer/bannerimagesdownload/get" component={BannerImagesDownload} />
        </div>
    )
}

export default CustomerSection
