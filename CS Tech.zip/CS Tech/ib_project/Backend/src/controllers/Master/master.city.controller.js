const { M_CITY, M_STATE, Counter } = require("../../model");

exports.ststeListForCity = async (req, res) => {
    try {
        console.log("object")
        const data = await M_STATE.find({ f_countryid: "1" }).sort({ f_state: 1 })
        res.json({ data })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

exports.CreateCity = async (req, res) => {
    const { f_countryid, f_stateid, f_cityname } = req.body;
    try {
        if (!f_cityname || f_cityname === "") {
            res.json({ status: 400, message: "enter city name" })
        } else {
            const data = await M_CITY.findOne({ f_cityname });
            if (data) {
                res.json({ status: 400, message: "already exists" })
            } else {
                const id = await Counter.findOneAndUpdate({ _id: "f_cityid" }, {
                    $inc: { sequence: 1 }
                }, { useFindAndModify: false });
                const saveData = await new M_CITY({
                    f_cityid: id.sequence, f_countryid, f_creationdate: new Date(),
                    f_status: "1", f_stateid, f_cityname
                }).save()
                res.json({ status: 200, saveData })
            }
        }
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

exports.getCityList = async (req, res) => {
    const { currentPage, itemPerPage, searchData } = req.query;
    const num = parseInt(itemPerPage)
    const start = parseInt(currentPage);
    let pipeline;
    let countline;
    try {
        if (!searchData || searchData === "") {
            pipeline = [
                { $sort: { f_creationdate: -1 } },
                { $skip: (start - 1) * num },
                { $limit: num },
                {
                    $lookup: {
                        from: "t_country",
                        localField: "f_countryid",
                        foreignField: "f_countryid",
                        as: "country"
                    }
                },
                { $unwind: "$country" },
                {
                    $lookup: {
                        from: "t_state",
                        localField: "f_stateid",
                        foreignField: "f_stateid",
                        as: "state"
                    }
                },
                { $unwind: "$state" },
            ]
            countline = [
                { $count: "totalcount" }
            ]
        } else {
            pipeline = [
                { $match: { f_cityname: { $regex: searchData, $options: "im" } } },
                { $skip: (start - 1) * num },
                { $limit: num },
                {
                    $lookup: {
                        from: "t_country",
                        localField: "f_countryid",
                        foreignField: "f_countryid",
                        as: "country"
                    }
                },
                { $unwind: "$country" },
                {
                    $lookup: {
                        from: "t_state",
                        localField: "f_stateid",
                        foreignField: "f_stateid",
                        as: "state"
                    }
                },
                { $unwind: "$state" },
            ]
            countline = [
                { $match: { f_cityname: { $regex: searchData, $options: "im" } } },
                { $count: "totalcount" }
            ]
        }
        const data = await M_CITY.aggregate(pipeline);
        const totalrecord = await M_CITY.aggregate(countline)
        res.json({ status: 200, data, totalrecord })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

exports.getCityListBySearch = async (req, res) => {
    const { search } = req.query
    try {
        const data = await M_CITY.aggregate([
            { $match: { f_cityname: { $regex: search, $options: "im" } } },
            {
                $lookup: {
                    from: "t_country",
                    localField: "f_countryid",
                    foreignField: "f_countryid",
                    as: "country"
                }
            },
            { $unwind: "$country" },
            {
                $lookup: {
                    from: "t_state",
                    localField: "f_stateid",
                    foreignField: "f_stateid",
                    as: "state"
                }
            },
            { $unwind: "$state" },
        ])
        res.json({ status: 200, data })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

exports.getCityDetail = async (req, res) => {
    const { _id } = req.params
    try {
        const cityDetail = await M_CITY.findOne({ _id });
        res.json({ status: 200, cityDetail })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

exports.editCityDetails = async (req, res) => {
    const { f_countryid, f_stateid, _id, f_cityname } = req.body
    try {
        const cityDetail = await M_CITY.findByIdAndUpdate({ _id }, {
            $set: {
                f_countryid,
                f_stateid,
                f_cityname
            }
        });
        res.json({ status: 200, message: "City updated successfully!" })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

exports.deleteCityDetails = async (req, res) => {
    const { _id } = req.params
    try {
        const cityDetail = await M_CITY.findByIdAndRemove({ _id });
        res.json({ status: 200, message: "City deleted successfully!" })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}