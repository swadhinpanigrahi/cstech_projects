import React, { useState, useEffect } from "react";
import { Row, Col } from "react-bootstrap";
import HomeCountCard from "../../../Components/Common/Cards/HomeCountCard";
// import PageHeaders from "../../../Components/Common/PageHeaders";
import pendingo from "../../../Images/pendingo.png";
import follow from "../../../Images/follow.png";
import groupn from "../../../Images/groupn.png";
import { Link } from "react-router-dom";
import { countApi } from "../../../Utils/api";

const resetArr = [
  {
    icon: pendingo,
    header: "Pending Orders",
    count: "",
    name: "pendingOrders",
    link: "/dashboard/order/pendingorder/get"
  },
  {
    icon: follow,
    header: "Followup",
    count: "",
    name: "followup_count",
    link: "/dashboard/dailysalesentry"
  },
  {
    icon: groupn,
    header: "Proposals",
    count: "",
    name: "poposalEmail",
    link: "/dashboard/proposal/get"
  },
  {
    icon: groupn,
    header: "Ungroup New User",
    count: "",
    name: "unregisted",
    link: "/dashboard/customer/unregistercustomer/get"
  },
];

const Home = () => {
  const [countArray, setCountarray] = useState([...resetArr]);

  useEffect(() => {
    const countFunction = async () => {
      const res = await countApi();
      let { arr } = res;
      setCountarray(() => {
        if (arr.length === countArray.length) {
          return resetArr.map((data, inx) => {
            let { name } = data;
            if (arr[inx][name]) {
              data.count = arr[inx][name];
            }
            return data;
          });
        } else {
          // window.alert("Network error!");
          return [];
        }
      });
    };
    countFunction();
  }, [countArray.length]);
  return (
    <>
      <Row className="rownew1" style={{ paddingTop: "20px" }}>
        <Col lg={12}>
          <Row className="rownew1">
            <div className="tableHeader tableHeader1 search_new">
              <Col lg={12} md={12} xs={12} className="table_span">
                <h3 className="page-title d-flex userv">
                  <span>Dashboard</span>
                </h3>
              </Col>
            </div>
          </Row>
        </Col>
      </Row>
      <Row className="rownew1">
        {countArray.map((data, inx) => {
          let { icon, header, count, link } = data;
          return (
            <Col lg={4} md={6} key={"HomeCard" + inx}>
              {
                <Link to={link}>
                  <HomeCountCard icon={icon} header={header} count={count} />
                </Link>
              }
            </Col>
          );
        })}
      </Row>
    </>
  );
};

export default Home;
