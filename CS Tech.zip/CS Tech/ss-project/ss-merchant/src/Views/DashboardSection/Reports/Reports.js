import React, { useState, useEffect } from 'react';
import PageHeaders from '../../../Components/Common/PageHeaders'
import { getShipmentDetailsList, getShipmentDropdownList, shipmentCODButtonFilter, getShipmentDetailsForView, shipCount } from "../../../Utils/api";
import { Link } from "react-router-dom"
import { Col } from 'react-bootstrap'
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import ReactExport from "react-data-export";
import { useTranslation } from "react-i18next";

import ShipmentView from "../Shipments/ShipmentView";

const Reports = () => {
    const { t } = useTranslation();
    const [ShipmentData, setShipmentData] = useState([]);
    const [Loading, setLoading] = useState(false)
    const [Search, setSearch] = useState("");
    const [pagination, setPagination] = useState(0);
    const [totalPage, setTotalPage] = useState(0);
    // const [BrkPoint, setBrkPoint] = useState(3);
    const [SearchHeader, setSearchHeader] = useState({
        provider: [],
        status: []
    })
    const [ButtonForm, setButtonForm] = useState({})
    let [startDate, setStartDate] = useState(0);
    let [endDate, setEndDate] = useState(0);

    //VIEW MODAL
    const [TrakingData, setTrakingData] = useState({
        totalData: {},
        from_data: {},
        to_data: {}
    })
    const [show, setShow] = useState(false);

    const [Short, setShort] = useState("ascending");
    const [ExportData, setExportData] = useState([]);

    const handleClose = () => setShow(false);
    const handleShow = async (tracking_number) => {
        console.log(tracking_number);
        const res = await getShipmentDetailsForView(tracking_number)
        let { status, trakingData, error } = res
        if (!error && status === 200) {
            const updateState = { ...TrakingData }
            updateState.totalData = trakingData
            updateState.from_data = trakingData.from_address
            updateState.to_data = trakingData.to_address
            setTrakingData({ ...updateState })
        } else {
            window.alert("Network Error")
        }
        setShow(true)
    };
    //VIEW MODEL

    startDate = startDate === null ? setStartDate(0) : startDate;
    endDate = endDate === null ? setEndDate(0) : endDate;


    const handleChange = async (e) => {
        setSearch(e.target.value)
        const res = await getShipmentDetailsList(pagination, e.target.value)
        let { trakingDetailsList, shipExportList } = res
        const shaloArray = [...trakingDetailsList]
        setShipmentData(shaloArray)
        setExportData(shipExportList)
    }

    const buttonHandleChange = async (e, date) => {
        let { name, value, type } = e.target;
        if (type === "select-one") {
            let data = { ...ButtonForm }
            data[name] = value;
            setButtonForm({ ...data })
        } else {
            const updateState = { ...ButtonForm }
            ButtonForm.startDate = date
            setButtonForm({ ...updateState })
        }
    }

    const onScrollHandler = async (e) => {
        let button = e.target.scrollHeight - e.target.scrollTop - e.target.clientHeight < 50;
        let { shipping_method } = ButtonForm
        if (button) {
            if (startDate === 0 && endDate === 0 && !shipping_method) {
                setPagination(pagination + 1);
                const res = await getShipmentDetailsList(pagination, Search);
                let { trakingDetailsList } = res;
                let mergeArray = [...ShipmentData, ...trakingDetailsList]
                setShipmentData(mergeArray)
            } else {
                setPagination(pagination + 1);
                const res = await shipmentCODButtonFilter({ ...ButtonForm, startDate, endDate, pagination });
                let { error, filteredData } = res
                if (!error) {
                    console.log(filteredData)
                    let mergeArray = [...ShipmentData, ...filteredData]
                    setShipmentData(mergeArray)
                }
            }

        }
    }

    const apiCall = async () => {
        setLoading(true)
        const res = await getShipmentDetailsList(pagination, Search)
        let { error, status, trakingDetailsList, shipExportList } = res;
        const count = await shipCount();
        let { shipmentCount } = count
        if (!error && status === 200) {
            setShipmentData([...trakingDetailsList])
            setTotalPage(shipmentCount)
            setLoading(false)
            setExportData(shipExportList)
        } else {
            window.alert("network error!!")
        }
    }

    const onSearch = async (e) => {
        e.preventDefault();
        setPagination(0);
        const res = await shipmentCODButtonFilter({ ...ButtonForm, startDate, endDate, pagination });
        let { error, filteredData, shipExportList } = res
        if (!error) {
            console.log(filteredData)
            const shaloArray = [...filteredData];
            setShipmentData(shaloArray)
            setExportData(shipExportList)
        }
    }

    //EXPORT
    const ExcelFile = ReactExport.ExcelFile;
    const ExcelSheet = ReactExport.ExcelFile.ExcelSheet;
    const DataSet = [
        {
            columns: [
                { title: "ORDER ID" },
                { title: "PARTNER ORDERID" },
                { title: "SHIPING PROVIDER" },
                { title: "TYPE" },
                { title: "ORDER NUMBER" },
                { title: "AMOUNT (SAR)" },
                { title: "SHOP NAME" },
                { title: "SHIPING NAME" },
                { title: "ACCOUNT ID" },
                { title: "TRACKING NUMBER" },
                { title: "CREATION DATE" },
                { title: "STATUS" },
        
                { title: "FROM NAME" },
                { title: "FROM COMPANY NAME" },
                { title: "FROM ADDRESS" },
                { title: "FROM EMAIL" },
                { title: "FROM CITY" },
                { title: "FROM STATE" },
                { title: "FROM ZIP" },
                { title: "FROM COUNTRY" },
                { title: "FROM PHONE" },
        
                { title: "TO NAME" },
                // { title: "TO COMPANY NAME" },
                // { title: "TO ADDRESS" },
                // { title: "TO EMAIL" },
                // { title: "TO CITY" },
                // { title: "TO STATE" },
                // { title: "TO ZIP" },
                // { title: "TO COUNTRY" },
                // { title: "TO PHONE" },
            ],
            data: ExportData.map((data) => [
                { value: data.order_id },
                { value: data.partner_order_id },
                { value: data.shipping_method },
                { value: "COD" },
                { value: data.order_number },
                { value: data.order_amount },
                { value: data.shop_name },
                { value: data.shipping_name },
                { value: data.account_id },
                { value: data.tracking_number },
                { value: data.createdAt.slice(0, 10) },
                { value: data.fulfillment_status },
        
                { value: data.from_address.name },
                { value: data.from_address.company_name },
                { value: data.from_address.address_1 },
                { value: data.from_address.email },
                { value: data.from_address.city },
                { value: data.from_address.state },
                { value: data.from_address.zip },
                { value: data.from_address.country },
                { value: data.from_address.phone },
        
                { value: data.to_address.name },
                // { value: data.to_address.company_name },
                // { value: data.to_address.address_1 },
                // { value: data.to_address.email },
                // { value: data.to_address.city },
                // { value: data.to_address.state },
                // { value: data.to_address.zip },
                // { value: data.to_address.country },
                // { value: data.to_address.phone },
            ]),
        },
    ];
    //EXPORT

    // const TotalPage = Math.ceil(totalPage / 20);

    const sortFun = (type) => {
        if (type === "order_number") {
            if (Short === "ascending") {
                const shaloArray = [...ShipmentData];
                const shortedArray = shaloArray.sort((a, b) => {
                    if (a.order_number > b.order_number) return 1;
                    if (a.order_number < b.order_number) return -1;
                    return 0;
                });
                setShipmentData(shortedArray);
                setShort("descending");
            } else {
                const shaloArray = [...ShipmentData];
                const shortedArray = shaloArray.sort((a, b) => {
                    if (a.order_number > b.order_number) return -1;
                    if (a.order_number < b.order_number) return 1;
                    return 0;
                });
                setShipmentData(shortedArray);
                setShort("ascending");
            }
        }
          
        if (type === "ship_provider") {
            if (Short === "ascending") {
                const shaloArray = [...ShipmentData];
                const shortedArray = shaloArray.sort((a, b) => {
                    if (a.shipping_method > b.shipping_method) return 1;
                    if (a.shipping_method < b.shipping_method) return -1;
                    return 0;
                });
                setShipmentData(shortedArray);
                setShort("descending");
            } else {
                const shaloArray = [...ShipmentData];
                const shortedArray = shaloArray.sort((a, b) => {
                    if (a.shipping_method > b.shipping_method) return -1;
                    if (a.shipping_method < b.shipping_method) return 1;
                    return 0;
                });
                setShipmentData(shortedArray);
                setShort("ascending");
            }
        }

        if (type === "name") {
            if (Short === "ascending") {
              const shaloArray = [...ShipmentData];
              const shortedArray = shaloArray.sort((a, b) => {
                if (a.from_address.name > b.from_address.name) return 1;
                if (a.from_address.name < b.from_address.name) return -1;
                return 0;
              });
              setShipmentData(shortedArray);
              setShort("descending");
            } else {
              const shaloArray = [...ShipmentData];
              const shortedArray = shaloArray.sort((a, b) => {
                if (a.from_address.name > b.from_address.name) return -1;
                if (a.from_address.name < b.from_address.name) return 1;
                return 0;
              });
              setShipmentData(shortedArray);
              setShort("ascending");
            }
          }
    }

    const listData = ShipmentData.length !== 0 ? ShipmentData.map((data, inx) => (
        <tr key={"reports-tbl" + inx}>
            <td className="arabic_left">{data.order_number}</td>
            <td className="arabic_left">{data.shipping_method}</td>
            <td className="arabic_left">{data.order_amount}</td>
            <td className="arabic_left">{data.from_address.name}</td>
            {/* <td className="text-center view_shipment"><Link to={`/dashboard/shipments/view/${data.tracking_number}`}>VIEW</Link></td> */}
            <td className="text-center view_mod" onClick={() => handleShow(data.tracking_number)}>VIEW</td>
            <td className="text-center">{data.createdAt.slice(0, 10)}</td>
            <td className="text-center">
                <Link to={`/dashboard/shipments/track/${data.tracking_number}`} target="_blank">
                    <i
                        data-toggle="tooltip"
                        data-placement="bottom"
                        title="Search"
                        className="fa fa-search iconfa"
                    ></i>
                </Link>
            </td>
        </tr>
    )) : <tr ><td className="no_records" colSpan="8">NO RECORDS FOUND</td></tr>

    const countBar = () => {
        return (
            <Col md={12} className="show_count text-center">
                {listData.length === undefined ?
                    <p>{`showing ${0} - ${ShipmentData.length} of ${0} items in listing`}</p>
                    :
                    <p>{`showing ${pagination + 1} - ${ShipmentData.length} of ${listData.length} items in listing`}</p>
                }
            </Col>
        )
    }

    useEffect(() => {
        const apiCall1 = async () => {
            const res = await getShipmentDropdownList()
            let { provider, status } = res;
            const updateState = { ...SearchHeader };
            updateState.provider = [...provider]
            updateState.status = [...status]
            setSearchHeader({ ...updateState })
        }
        apiCall1()
        apiCall()
    }, [])

    let { provider } = SearchHeader;

    return (
        <>
            <Col lg={12}>
                <PageHeaders title={t("change.CODReports")} />
                <div>
                    <div className="col-md-12">
                        <div
                            className="box_detail"
                            style={{ padding: "15px 0px 10px 0px", marginBottom: "20px" }}
                        >
                            <div className="col-12" style={{ padding: "0px" }}>
                                <div className="head-title1 row no-gutters">
                                    <div className="col-md-12">
                                        <h3 className="page-title subtitile">{t("change.filter_option")}</h3>
                                    </div>
                                    <hr style={{ marginBottom: "0px" }} />
                                </div>
                            </div>
                            <div className="row" style={{ padding: "20px 30px" }}>
                                <div className="col-lg-10 col-md-12">
                                    <div className="row">
                                        <div className="form-group col-lg-2 col-md-4 shipf">
                                            <label className="pwdc">{t("change.s_proder")}</label>
                                            <select
                                                className="form-control"
                                                id="assocom"
                                                name="shipping_method"
                                                onChange={buttonHandleChange}
                                                style={{ padding: "4px 10px", color: "#000" }}
                                            >
                                                {provider.map((data, inx) => {
                                                    return (
                                                        <option key={"SHIP-STATUS" + inx}>{data}</option>
                                                    )
                                                })}
                                            </select>
                                        </div>
                                        <div className="form-group col-lg-2 col-md-4 shipf padrig">
                                            <label className="pwdc">{t("change.s_date")}</label>
                                            <div className="input-container d-flex form-control" id="date_end">
                                                <DatePicker
                                                    placeholderText={t("change.s_date")}
                                                    selected={startDate}
                                                    onChange={(date) => setStartDate(date)}
                                                />
                                            </div>
                                        </div>
                                        <div className="form-group col-lg-2 col-md-4 shipf padrig">
                                            <label className="pwdc">{t("change.e_date")}</label>
                                            <div className="input-container d-flex form-control" id="date_end">
                                                <DatePicker
                                                    placeholderText={t("change.e_date")}
                                                    selected={endDate}
                                                    onChange={(date) => setEndDate(date)}
                                                />
                                            </div>
                                        </div>
                                        <div className="col-lg-1 col-md-12 resmart1">
                                            <label
                                                className="pwdc new_rc"
                                                style={{ color: "transparent" }}
                                            >
                                                Shipment
                                            </label>
                                            <button className="searchs" onClick={onSearch}>
                                                {t("change.search")}
                                            </button>
                                        </div>
                                    </div>
                                </div>
                                <div className="form-group col-lg-2 col-md-4 shipf padrig ship_pad">
                                    <div className="">
                                        <label className="pwdc">{t("change.s_orderserch")}</label>
                                        <input
                                            type="text"
                                            placeholder="Search by OrderID/Name"
                                            onChange={handleChange}
                                            className="form-control"
                                        />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <Col md={12}>
                        <Col md={12} className="text-right backb new_expbtn">
                            <ExcelFile
                                fillename="sheet"
                                element={ShipmentData.length !== 0
                                    ? <button className="export_btn addbce customer_export">{t("change.exp")}</button>
                                    : <button className="export_btn addbce1 customer_export" disabled>{t("change.exp")}</button>}
                            >
                                <ExcelSheet dataSet={DataSet} name="shipment reports" />
                            </ExcelFile>
                        </Col>
                    </Col>
                    {/* <div className="col-md-12 text-right backb new_expbtn">
                        <span><button className="export_btn addbce">EXPORT</button></span>
                    </div> */}
                    <Col md={12}>
                        <hr />
                        <div className="box_detail tableboxdc table_scroll"
                            style={{
                                paddingTop: "0px",
                                paddingBottom: "0px",
                                marginBottom: "0px",
                            }}
                            onScroll={onScrollHandler}
                        >
                            <table className="table table-bordered table-responsive" id="table-to-xls">
                                <thead className="thead-dark">
                                    <tr>
                                        <th className="ohead arabic_left sorting" onClick={()=>sortFun("order_number")}>{t("change.order_sid")}</th>
                                        <th className="nhead arabic_left sorting" onClick={()=>sortFun("ship_provider")}>{t("change.sp_header")}</th>
                                        <th className="nhead arabic_left">{t("change.s_amount")}</th>
                                        <th className="nhead arabic_left sorting" onClick={()=>sortFun("name")}>{t("change.NAME")}</th>
                                        <th className="text-center">{t("change.s_label")}</th>
                                        <th className="text-center">Date</th>
                                        <th className="text-center">{t("change.s_track")}</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {Loading ? <tr><td className="no_records" colSpan="8">{t("change.LOADING")}</td></tr> : [listData]}
                                </tbody>
                            </table>
                        </div>
                    </Col>
                </div>
                {countBar()}
            </Col>
            <ShipmentView show={show} handleClose={handleClose} TrakingData={TrakingData} />
        </>
    )
}

export default Reports