import React from "react";
import { useAuth } from "../../Utils/auth";
import TopBar from "../../Components/NavSection/TopBar";
import brandlogo from "../../Images/brandlogo.png";
import { Navbar, Container } from "react-bootstrap";

const AuthNav = () => {
  let auth = useAuth();
  return auth.user ? (
    <TopBar />
  ) : (
    <div>
      <Navbar className="nav_header" expand="lg">
        <Container>
          <Navbar.Brand>
            <img src={brandlogo} alt="branimage" />
          </Navbar.Brand>
        </Container>
      </Navbar>
    </div>
  );
};

export default AuthNav;
