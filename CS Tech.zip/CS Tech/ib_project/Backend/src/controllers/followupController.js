const { CompanyMasterSchema, followup } = require("../model");

exports.getDropDownValues = async (req, res) => {
  const pipeline = [
    {
      $group: {
        _id: "$f_companyname",
      },
    },
  ];
  try {
    const CompanyGroup = await CompanyMasterSchema.aggregate(pipeline);
    res.json({ CompanyGroup });
  } catch (error) {
    res.json({ message: `Error in Controller`, error: error.message });
  }
};

exports.getSearchFieldDetails = async (req, res) => {
  const { f_companyname } = req.params;
  try {
    const companyData = await CompanyMasterSchema.findOne({ f_companyname });
    res.json({ companyData });
  } catch (error) {
    res.json({ message: `Error in Controller`, error: error.message });
  }
};
