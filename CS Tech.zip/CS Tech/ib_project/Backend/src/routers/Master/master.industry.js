const Industry = require("express").Router();

const {
    addIndustry, getIndustryList, getIndustryDetail, updateIndustryDetail, removeIndustryDetail
} = require("../../controllers/Master/master.industry.controller");

Industry.route("/addindustry").post(addIndustry);
Industry.route("/getindustrylist").get(getIndustryList);
Industry.route("/getindustrydetail/:_id").get(getIndustryDetail);
Industry.route("/updateindustrydetail").post(updateIndustryDetail);
Industry.route("/removeindustrydetail/:_id").get(removeIndustryDetail);


module.exports = Industry;