import React from 'react';
import * as RB from "react-bootstrap";

const ProposalInsertCart = ({ InsertCart, setInsertCart, T_orderid, insertCart, handleChange }) => {

    const closeModal = () => setInsertCart(false);

    return (
        <>
            <RB.Modal show={InsertCart} onHide={closeModal} className="ordermanage_modal send_proposalmail">
                <RB.Modal.Header closeButton>
                    <RB.Modal.Title>Insert Shoping Cart</RB.Modal.Title>
                </RB.Modal.Header>
                <RB.Modal.Body>
                    <RB.Row>
                        <RB.Col lg={12} md={12}>
                            <RB.Row>
                                <RB.Col lg={12} md={12}>
                                    <RB.Form>
                                        <RB.Form.Group as={RB.Row} controlId="formbasicemailo">
                                            <RB.Col lg={3} md={4}>
                                                <RB.Form.Label>Proposal ID :</RB.Form.Label>
                                            </RB.Col>
                                            <RB.Col lg={6} md={7}>
                                                <p>{T_orderid}</p>
                                            </RB.Col>
                                        </RB.Form.Group>
                                        <RB.Form.Group as={RB.Row} controlId="formbasicamount">
                                            <RB.Col lg={3} md={4}>
                                                <RB.Form.Label>Client Email :</RB.Form.Label>
                                            </RB.Col>
                                            <RB.Col lg={6} md={7}>
                                                <RB.Form.Control
                                                    name="email"
                                                    onChange={handleChange}
                                                    type="text"
                                                    placeholder="Enter Email" />
                                            </RB.Col>
                                        </RB.Form.Group>

                                        <RB.Row>
                                            <RB.Col lg={3} md={4}></RB.Col>
                                            <RB.Col lg={6} md={7}>
                                                <RB.Button size="sm" variant="primary"
                                                    onClick={insertCart}
                                                >
                                                    CONFIRM
                                                </RB.Button>
                                            </RB.Col>
                                        </RB.Row>
                                    </RB.Form>
                                </RB.Col>
                            </RB.Row>
                        </RB.Col>
                    </RB.Row>
                </RB.Modal.Body>
            </RB.Modal>
        </>
    )
}

export default ProposalInsertCart
