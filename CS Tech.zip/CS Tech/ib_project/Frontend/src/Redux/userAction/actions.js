import axios from "axios";
import {
  FATCH_USER_REQUEST,
  FATCH_USER_REGISTER,
  FATCH_USER_ORDER,
  FATCH_USER_PROPOSAL,
  FATCH_USER_FOLLOWUP,
  FATCH_USER_FAILED,
} from "./actionType";

const fatchUserRequest = () => {
  return {
    type: FATCH_USER_REQUEST,
  };
};

const fatchUserRegister = (profile) => {
  return {
    type: FATCH_USER_REGISTER,
    payload: profile,
  };
};

const fatchUserOrder = (order) => {
  return {
    type: FATCH_USER_ORDER,
    payload: order,
  };
};

const fatchUserProposal = (proposal) => {
  return {
    type: FATCH_USER_PROPOSAL,
    payload: proposal,
  };
};

const fatchUserFollowup = (followup) => {
  return {
    type: FATCH_USER_FOLLOWUP,
    payload: followup,
  };
};

const fatchUserFailed = (error) => {
  return {
    type: FATCH_USER_FAILED,
    payload: error,
  };
};

export const fatchAction = (_id) => {
  console.log({ _id });
  return (dispatch) => {
    dispatch(fatchUserRequest);
    axios
      .get(`http://localhost:5000/api/admin/profileData/${_id}`)
      .then((res) => {
        const { registrationData, T_orderData, proposal_data, followup_data } =
          res.data;
        dispatch(fatchUserRegister(registrationData));
        dispatch(fatchUserOrder(T_orderData));
        dispatch(fatchUserProposal(proposal_data));
        dispatch(fatchUserFollowup(followup_data));
      })
      .catch((error) => {
        const errorMsg = error.message;
        dispatch(fatchUserFailed(errorMsg));
      });
  };
};
