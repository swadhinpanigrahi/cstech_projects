import React, { useState } from 'react';
import { Form, Row, Col, Button } from 'react-bootstrap';
import { addsubuserForm } from "../../../Components/FormData/FormElements";
import { Register_Subuser } from "../../../Utils/api";
import Model from "../../../Components/Common/Model";
import { useHistory, Link } from 'react-router-dom';
import { authProfiledValidetor } from '../../../Utils/FormValidetor';

const AddSubuser = () => {
    const history = useHistory();

    const [FormData, setFormData] = useState({});
    const [isOpen, setIsOpen] = useState(false);
    const [ModelMsg, setModelMsg] = useState("");
    const [Password, setPassword] = useState("password");
    const [Errors, setErrors] = useState({
        errors: {},
        errMsg: "",
        errClr: "",
    });

    const changePasswordType = () => {
        Password === "password" ? setPassword("text") : setPassword("password")
    }

    const handleChange = (e) => {
        let { name, value } = e.target;
        const data = { ...FormData };
        data[name] = value;
        setFormData(data);
        const updateError = { ...Errors };
        updateError.errors = authProfiledValidetor(data);
        updateError.errMsg = "";
        updateError.errClr = "";
        setErrors({ ...updateError });
    }

    const modelSet = () => {
        setIsOpen(true);
    };

    const onSubmit = async (e) => {
        e.preventDefault();
        if (FormData["firstName"] && FormData["lastName"] && FormData["emailId"] && FormData["mobileNo"] && FormData["companyName"]) {
            const res = await Register_Subuser({ ...FormData, userRole: "sub-admin" });
            let { permissionData, error } = res;
            if (!error) {
                if (permissionData) {
                    setModelMsg("User Created Successfully!!");
                    modelSet();
                    setTimeout(() => { history.push("/dashboard/subuser/get") }, 1000)
                } else {
                    setModelMsg("emailID or mobile number already exist!!");
                    modelSet();
                }
            }
            else {
                setModelMsg("network error!!");
                modelSet();
            }
        } else {
            const updatedError = { ...Errors };
            updatedError.errors = authProfiledValidetor(FormData);
            updatedError.errMsg = "";
            updatedError.errClr = "border-danger";
            setErrors({ ...updatedError });
        }
    }

    let { errors, errMsg, errClr } = Errors;

    return (
        <>
            <main className="">
                <div className="container-fluid">
                    <div className="col-12">
                        <div className="page-header row no-gutters pym-4">
                            <Col lg={6} md={6} xs={7}>
                                <h3 className="page-title">Add Sub User</h3>
                            </Col>
                            <Col lg={6} md={6} xs={5} className="text-right backb">
                                <button className="addcb">
                                    <span><i className="fa fa-arrow-left"></i>
                                        <span style={{ position: "relative", left: "5px" }}>
                                            <Link to="/dashboard/subuser/get">BACK</Link>
                                        </span></span>
                                </button>
                            </Col>
                            <hr />
                        </div>
                    </div>
                    <div className="col-md-12">
                        <div className="box_detail">
                            <div className="row" style={{ padding: "20px 30px" }}>
                                <div className="col-md-12">
                                    <form className="formcon">
                                        {addsubuserForm.map((data, inx) => {

                                            let {
                                                label,
                                                name,
                                                type,
                                                placeholder,
                                                controlId
                                            } = data;
                                            if (name === "password") {
                                                return (
                                                    <Form.Group as={Row} controlId={controlId}>
                                                        <Form.Label column sm="2">
                                                            {label}
                                                        </Form.Label>
                                                        <Col sm="5">
                                                            <Form.Control type={Password} name={name}
                                                                placeholder={placeholder} onChange={handleChange}
                                                                className={errClr ? errClr : ""}
                                                            />
                                                            {errors[name] && (
                                                                <Form.Text className="text-danger">
                                                                    {errors[name]}
                                                                </Form.Text>
                                                            )}
                                                            <Button onClick={changePasswordType} className="see_password"><i className="fa fa-eye"></i></Button>
                                                        </Col>
                                                    </Form.Group>
                                                )
                                            } else {
                                                return (
                                                    <Form.Group as={Row} controlId={controlId}>
                                                        <Form.Label column sm="2">
                                                            {label}
                                                        </Form.Label>
                                                        <Col sm="5">
                                                            <Form.Control type={type} name={name}
                                                                placeholder={placeholder} onChange={handleChange}
                                                                className={errClr ? errClr : ""}
                                                            />
                                                            {errors[name] && (
                                                                <Form.Text className="text-danger">
                                                                    {errors[name]}
                                                                </Form.Text>
                                                            )}
                                                        </Col>
                                                    </Form.Group>
                                                );
                                            }
                                        })}
                                        <div className="row">
                                            <div
                                                className="form-group col-lg-6 col-md-12"
                                                style={{ marginBottom: "0rem" }}
                                            >
                                                <div className="row">
                                                    <div className="col-md-4"></div>
                                                    <div className="col-md-8">
                                                        <button className="submit" type="submit" onClick={onSubmit}>SUBMIT</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
            <Model
                text={ModelMsg}
                open={isOpen}
                onClose={() => setIsOpen(false)}
            />
        </>
    )
}

export default AddSubuser
