import React from 'react';
import { Table, Modal } from "react-bootstrap";
import Moment from "moment";


const SuperImgTableModel = ({ ShowModel, setShowModel, ViewData }) => {
    const closeModel = () => setShowModel(false);
    const { List, Count, email } = ViewData
    return (
        <>
            <Modal
                show={ShowModel}
                onHide={closeModel}
                backdrop="static"
                keyboard={false}
            >
                <Modal.Header closeButton>
                    <Modal.Title>Modal title</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    View High-Res Images Download <br />
                    User Name: {email}<br />
                    Total Download: {Count}<br />
                    <div
                        className="box_detail table_boxdtl manage_order"
                        style={{ marginBottom: "0px" }}
                    >
                        <Table striped bordered hover variant="dark" responsive>
                            <thead>
                                <tr>
                                    <th>Sl No.</th>
                                    <th>Client Name</th>
                                    <th>Image Id</th>
                                    <th>IP Address</th>
                                    <th>Download Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                {List.length > 0 ? List.map((info, inx) => {
                                    let { _id, Client_name, Imageid, ip, download_date } = info;
                                    return (
                                        <tr key={_id}>
                                            <td>{inx + 1}</td>
                                            <td>{Client_name}</td>
                                            <td>{Imageid}</td>
                                            <td>{ip}</td>
                                            <td>{Moment(download_date).format("DD-MM-YYYY")}</td>
                                        </tr>
                                    )
                                }) : <>
                                    <td className="no_records" colSpan="11">
                                        No Records Found
                                    </td>
                                </>}

                            </tbody>
                        </Table>
                    </div>
                </Modal.Body>
            </Modal>
        </>
    )
}

export default SuperImgTableModel

