const { sendEmail } = require("./nodeMailer");
const {
  IBadminForgetPassTemp, IBProposalMailTemp,
  IBPaidProcessEmailTemp, IBOrderConfirmEmailTemp,
  OrderPaymentMailTemp, OrderDetailsCCMailTemp,
  FeedbackEmailTemp
} = require("./template/template");
//Email subject..

const IBresetPassword = ({ name, email, token, endPoint }, callback) => {
  sendEmail(
    {
      mailTo: email,
      subject: "Admin Forgot Password Request on IB-Admin",
      html: IBadminForgetPassTemp(name, token, endPoint),
    },
    callback
  );
};

const IBProposal = ({ email, T_orderid }, callback) => {
  sendEmail(
    {
      mailTo: email,
      subject: "view proposal details",
      html: IBProposalMailTemp(T_orderid),
    }, callback
  );
};

const IBPaidProcess = ({ email }, callback) => {
  sendEmail(
    {
      mailTo: email,
      subject: "Thank you for payment(s)",
      html: IBPaidProcessEmailTemp(email),
    }, callback
  );
};

const IBOrderConfirmation = ({ email, ImageArray, price, tax, NetAmount }, callback) => {
  sendEmail(
    {
      mailTo: email,
      subject: "testing mail",
      html: IBOrderConfirmEmailTemp(ImageArray, price, tax, NetAmount),
    }, callback
  );
};

/**
 * ORDER-LIST --- ACTIONS
*/

const OrderPaymentActionMail = ({ email, paymentPrice, payemntLink, T_orderid, PaymentMD }, callback) => {
  sendEmail(
    {
      mailTo: email,
      subject: "Payment Link Againt  : " + T_orderid + "",
      html: OrderPaymentMailTemp({ email, payemntLink }),
    }, callback
  );
};

const OrderDetailActionCCMail = ({ email, content, orderId }, callback) => {
  sendEmail(
    {
      mailTo: email,
      subject: "order detail CC mail",
      html: OrderDetailsCCMailTemp({ content, orderId }),
    }, callback
  );
};

const FeedbackEmail = ({ CS_username, cs_userid, message }, callback) => {
  sendEmail(
    {
      mailTo: CS_username,
      subject: "replay mail again your feedback",
      html: FeedbackEmailTemp({ cs_userid, message }),
    }, callback
  );
};


module.exports = {
  IBresetPassword,
  IBProposal,
  IBPaidProcess,
  IBOrderConfirmation,

  OrderPaymentActionMail,
  OrderDetailActionCCMail,
  FeedbackEmail
};
