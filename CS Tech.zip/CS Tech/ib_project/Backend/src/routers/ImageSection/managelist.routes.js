const Image = require("express").Router();

const {
    getImageDetails, ImageDetail, ImageDetailEdit, ImageRemove
} = require("../../controllers/ImagesController/managelist.controller");

Image.route("/getimageslist").get(getImageDetails);
Image.route("/getimage/:_id").get(ImageDetail)
Image.route("/editimage").post(ImageDetailEdit)
Image.route("/removeimage/:_id").get(ImageRemove)


module.exports = Image