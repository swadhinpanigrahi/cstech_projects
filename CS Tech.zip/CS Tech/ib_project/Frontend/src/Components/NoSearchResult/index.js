import React from "react";
import { Container, Row, Col, Button } from "react-bootstrap";
import searchr from "../../Images/searchr.png";
import { Link } from "react-router-dom";

const NoSearchResult = ({ test }) => {
  return (
    <main>
      <Container>
        <div className="page-header row no-gutters py-4">
          <div className="col-md-12">
            <h3 className="page-title">
              Search Results -{" "}
              <span style={{ color: "#0081ad" }}>"{test}"</span>
            </h3>
          </div>
        </div>
        <Row>
          <Col lg={3} md={2}></Col>
          <Col lg={6} md={8}>
            <div className="box_detail" style={{ borderRadius: "0px" }}>
              <h3 className="text-center" style={{ fontWeight: "bold" }}>
                <img src={searchr} className="imgm" alt="searchimg" />
              </h3>
              <div className="text-center">
                <h4 className="noresult">No results found</h4>
                <p
                  style={{
                    color: "#666666",
                    fontWeight: "600",
                    fontSize: "16px",
                    marginBottom: "20px",
                  }}
                >
                  We don't have any record on the search string.
                </p>
                <Button
                  size="sm"
                  variant="primary"
                  type="submit"
                >
                  <Link to="/dashboard/createfollowups" >Create New User</Link>
                </Button>

              </div>
            </div>
          </Col>
          <Col lg={3} md={2}></Col>
        </Row>
      </Container>
    </main>
  );
};

export default NoSearchResult;
