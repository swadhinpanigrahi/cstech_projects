const VisibleKey = require("express").Router();

const {
    getVisibleKeyDetails, getAidValues
} = require("../../controllers/KeywordsController/visiblekeywords.controller");

VisibleKey.route(`/getvisiblekeydetails`).get(getVisibleKeyDetails);
VisibleKey.route(`/getaidvalues`).post(getAidValues)

module.exports = VisibleKey;