import React from 'react'
import { Route } from "react-router-dom"

import Shipments from "./Shipments";
import ShipmentTraking from "./ShipmentTraking";

const ShipmentDash = () => {
    return (
        <div>
            <Route path="/dashboard/shipments/get" component={Shipments} />
            <Route path="/dashboard/shipments/track/:tracking_number" component={ShipmentTraking} />
        </div>
    )
}

export default ShipmentDash
