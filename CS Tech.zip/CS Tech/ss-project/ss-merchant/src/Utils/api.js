import Axios from "axios";
import Cookie from "js-cookie";
// Axios.defaults.baseURL = "http://localhost:2222/api";
Axios.defaults.baseURL = "https://apiv2.storagestation.net/api";

export const LoginApi = async (FormData) => {
    try {
        const apicall = await Axios.post("/v1/auth/merchantlogin", FormData);
        let { status, message, id, name } = apicall.data
        if (status === 200) {
            await Cookie.set("_id", id)
            await Cookie.set("name", name)
            return { status, message }
        } else {
            return { message }
        }
    } catch (error) {
        return { error }
    }
}

export const getDataForGraph = async () => {
    try {
        const _id = Cookie.get("_id")
        const apiCall = await Axios.get(`/v3/merchant/get15dayshipmentsrecords/${_id}`);
        let { graph, creditAmount, debitAmount } = apiCall.data;
        return { graph, creditAmount, debitAmount }
    } catch (err) {
        return { err };
    }
}

export const getMerchantProfile = async () => {
    try {
        const _id = Cookie.get("_id")
        const apiCall = await Axios.get(`/v1/auth/merchantgetprofile/${_id}`);
        let { userInfo } = apiCall.data
        return { userInfo }
    } catch (err) {
        return { err };
    }
}

export const updateCustomerDetails = async (FormData) => {
    try {
        const _id = Cookie.get("_id")
        const apiCall = await Axios.post(`/v1/auth/merchanteditprofile/${_id}`, FormData);
        let { status, message, updatedCustomer } = apiCall.data;
        if (status === 200 && updatedCustomer) {
            return { message }
        }
    } catch (err) {
        return { err };
    }
}

export const authChangePassword = async (FormData) => {
    try {
        const _id = Cookie.get("_id")
        const apiCall = await Axios.post(`/v1/auth/merchantchangepassword/${_id}`, FormData);
        let { status, message } = apiCall.data;
        return { status, message }
    } catch (err) {
        return { err };
    }
}

export const forgotPasswordEmail = async (FormData) => {
    try {
        const apiCall = await Axios.post(`/v1/auth/merchantForgotMail`, FormData);
        let { status, message } = apiCall.data;
        return { status, message }
    } catch (err) {
        return { err };
    }
}

export const forgotEmailPasswordChange = async (FormData) => {
    try {
        const apiCall = await Axios.post(`/v1/auth/merchantchangepassfromforgotMail`, FormData);
        let { message } = apiCall.data
        // let { status, message } = apiCall.data;
        return { message }
    } catch (err) {
        return { err };
    }
}

/*---shipments----*/
export const getShipmentDropdownList = async () => {
    try {
        const _id = Cookie.get("_id")
        const apiCall = await Axios.get(`/v3/merchant/searchbardropdown/${_id}`);
        let { provider, status } = apiCall.data;
        return { provider, status }
    } catch (err) {
        return { err };
    }
}

export const getShipmentDetailsList = async (pagecount, searchbyname) => {
    try {
        const _id = Cookie.get("_id")
        const apiCall = await Axios.get("/v3/merchant/getshipment", {
            params: { _id: _id, pagecount: pagecount, searchbyname: searchbyname },
        });
        let { status, trakingDetailsList, shipExportList } = apiCall.data;
        return { status, trakingDetailsList, shipExportList };
    } catch (error) {
        return { error };
    }
};

export const getShipmentDetailsForView = async (tracking_number) => {
    try {
        const apiCall = await Axios.get(`/v3/merchant/trakingdetailsview/${tracking_number}`);
        let { status, trakingData } = apiCall.data;
        return { status, trakingData };
    } catch (error) {
        return { error };
    }
}

export const shipmentButtonFilter = async (ButtonData) => {
    try {
        const _id = Cookie.get("_id")
        const apiCall = await Axios.post(`/v3/merchant/trakingdetailsearchbybutton/${_id}`, ButtonData);
        console.log(apiCall)
        let { filteredData, shipExportList } = apiCall.data;
        return { filteredData, shipExportList };
    } catch (error) {
        return { error };
    }
}
export const shipmentCODButtonFilter = async (ButtonData) => {
    try {
        const _id = Cookie.get("_id")
        const apiCall = await Axios.post(`/v3/merchant/trakingCODdetailsearchbybutton/${_id}`, ButtonData);
        console.log(apiCall)
        let { filteredData, shipExportList } = apiCall.data;
        return { filteredData, shipExportList };
    } catch (error) {
        return { error };
    }
}
/*--shipment(end)--*/

/*--payment(START)--*/
export const getPaymentStalment = async () => {
    try {
        const _id = Cookie.get("_id");
        const apiCall = await Axios.get(`/v3/merchant/getpaymentsatelments/${_id}`);
        let { records, sumCredit, sumDebit, netPayble, netReceiveble } = apiCall.data;
        return { records, sumCredit, sumDebit, netPayble, netReceiveble };
    } catch (error) {
        return { error };
    }
}

export const paymentFilteredData = async (data) => {
    try {
        const _id = Cookie.get("_id");
        console.log(_id)
        const apiCall = await Axios.post(`/v3/merchant/getpaymentdetailsbydatefilter/${_id}`, data);
        let { paymentDetails } = apiCall.data;
        return { paymentDetails };
    } catch (error) {
        return { error };
    }
}
/*--payment(END)--*/

/*--traking(start)*/
export const trakin_details = async (tracking_number) => {
    try {
        const res = await Axios.get("https://app.sky-sa.net/api/track-shipment", {
            params: { tracking_number: tracking_number },
        });
        const { statuses } = res.data;
        return { statuses };
    } catch (error) {
        return { error };
    }
};

export const change_shipstatus = async (tracking_number) => {
    try {
        const apiCall = await Axios.get(`/v4/post_shipment/statuschange/${tracking_number}`);
        let { message } = apiCall.data;
        return { message }
    } catch (error) {
        return { error }
    }
}

export const crownJOBapi = async () => {
    try {
        const _id = Cookie.get("_id");
        const apiCall = await Axios.get(`/v4/post_shipment/getshipmentsforcrownjob/${_id}`);
        let { trakingDetails } = apiCall.data;
        return { trakingDetails }
    } catch (error) {
        return { error }
    }
}
/*--traking(end)*/

/*--count--*/
export const shipCount = async () => {
    try {
        const _id = Cookie.get("_id");
        const apiCall = await Axios.get(`/v3/merchant/getmerchantcounts/${_id}`);
        const { shipmentCount } = apiCall.data
        return { shipmentCount }
    } catch (error) {
        return { error }
    }
}

export const logOutApi = async () => {
    try {
        await Cookie.remove("_id");
        await Cookie.remove("name");
        return { status: 200 };
    } catch (err) {
        return { err };
    }
};