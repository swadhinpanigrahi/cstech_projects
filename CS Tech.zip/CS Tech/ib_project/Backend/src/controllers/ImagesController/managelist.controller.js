const { t_Images } = require("../../model");


exports.getImageDetails = async (req, res) => {
    const { currentPage, itemPerPage, searchData } = req.query;
    const num = parseInt(itemPerPage)
    const start = parseInt(currentPage);
    let pipeline;
    let countline;
    try {
        if (!searchData || searchData === "") {
            pipeline = [
                { $sort: { f_createdate: -1 } },
                { $skip: (start - 1) * num },
                { $limit: num }
            ]
            countline = [
                { $count: "totalcount" }
            ]
        } else {
            pipeline = [
                { $match: { F_imgid: { $regex: searchData, $options: "im" } } },
                { $sort: { f_createdate: -1 } },
                { $skip: (start - 1) * num },
                { $limit: num }
            ]
            countline = [
                { $match: { F_imgid: { $regex: searchData, $options: "im" } } },
                { $count: "totalcount" }
            ]
        }
        const data = await t_Images.aggregate(pipeline)
        const totalrecord = await t_Images.aggregate(countline)
        res.json({ status: 200, data, totalrecord })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

exports.ImageDetail = async (req, res) => {
    const { _id } = req.params;
    try {
        const data = await t_Images.findById({ _id });
        res.json({ status: 200, data })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

exports.ImageDetailEdit = async (req, res) => {
    const {
        _id, F_imgid, f_imgType, F_rank, f_pricing, f_rank1, f_exclusiveonly
    } = req.params;
    try {

    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

exports.ImageRemove = async (req, res) => {
    const { _id } = req.params;
    console.log(_id)
    try {
        const data = await t_Images.findByIdAndRemove({ _id });
        res.json({ status: 200, message: "successfully deleted" })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}