const options = {
  useNewUrlParser: true,
  useUnifiedTopology: true,
  poolSize: 30000, // Maintain up to 10 socket connections
  connectTimeoutMS: 30000, // Keep trying to send operations for 30 seconds, //TCP Connection timeout setting.
  socketTimeoutMS: 360000, // Close sockets after 1 min of inactivity,//TCP Socket timeout setting.
};

// var MongoClient = require('mongodb').MongoClient;
// MongoClient.connect('mongodb+srv://dbUser:dbUser@cluster1.mksip.mongodb.net', { useNewUrlParser: true, useUnifiedTopology: true }, function (err, client) {
//     if (err) throw err;
//     var db = client.db('IBDataSearch');
//     global.db = db
// })


var MongoClient = require('mongodb').MongoClient;
// MongoClient.connect('mongodb://localhost',options, function (err, client) {
//   if (err) throw err;
//   var db = client.db('IBSearchDataLatest');
//   global.db = db
// });
MongoClient.connect('mongodb://localhost', options, function (err, client) {
  if (err) throw err;
  var db1 = client.db('ImagesbazaarDB_MongoDBv2');
  global.db1 = db1
});