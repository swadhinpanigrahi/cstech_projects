import React, { useState } from "react";
import { useHistory, useLocation, Link } from "react-router-dom";
import { Form, Button, Container } from "react-bootstrap";
import { useAuth } from "../../Utils/auth";
import { LoginForm } from "../../Components/Forms/FormElements";
import { logInApi } from "../../Utils/api";
import TopBar from "../../Components/NavSection/TopBar";
import validation from "../../Utils/validation";
import Footer from "../../Components/NavSection/Footer"

const Login = () => {
  let history = useHistory();
  let location = useLocation();
  let auth = useAuth();
  const [Loading, setLoading] = useState("LOGIN");
  const [Login, setLogin] = useState({});
  const [Error, setError] = useState({
    errMsg: "",
    errClr: "",
  });
  const [errors, setErrors] = useState({});

  const handleChange = (e) => {
    let { name, value } = e.target;
    const data = { ...Login };
    data[name] = value;
    setLogin(data);
    setErrors(validation(data));
    const updateError = { ...Error };
    updateError.errCls = "";
    updateError.errMsg = "";
    setError({ ...updateError });
  };

  const changeLoading = () => {
    setLoading("Loading...");
    setTimeout(() => {
      setLoading("LOGIN");
    }, 1000);
  };

  let { from } = location.state || { from: { pathname: "/dashboard/home" } };

  let login = async (e) => {
    e.preventDefault();
    const res = await logInApi(Login);
    let { status, error, message } = res;
    if (Login["username"] && Login["password"]) {
      if (!error) {
        if (status === 200) {
          changeLoading();
          setTimeout(() => {
            auth.signin(() => {
              history.replace(from);
            });
          }, 2000);
        } else {
          changeLoading();
          const updateError = { ...Error };
          updateError.errMsg = message;
          setError({ ...updateError });
        }
      } else {
        changeLoading();
        const updateError = { ...Error };
        updateError.errMsg = "Network Error";
        setError({ ...updateError });
      }
    } else {
      const updateError = { ...Error };
      updateError.errCls = "border-danger";
      updateError.errMsg = "";
      setError({ ...updateError });
      setErrors(validation(Login));
    }
  };

  let { errMsg, errCls } = Error;

  return (
    <div>
      <TopBar isVisible={false} />
      <Container>
        <main>
          <div id="login">
            <div className="loginFrom">
              <h4 className="loginHeader">Login Here</h4>
              <Form.Text className="text-danger error_text">
                {Loading === "Loading..." ? "" : errMsg ? errMsg : ""}
              </Form.Text>
              <Form onSubmit={login}>
                {LoginForm.map((data, inx) => {
                  let { type, controlId, name, placeholder } = data;
                  return (
                    <Form.Group controlId={controlId} key={controlId + inx}>
                      <Form.Control
                        type={type}
                        onChange={handleChange}
                        name={name}
                        value={Login[name]}
                        placeholder={placeholder}
                        className={
                          Loading === "Loading..." ? "" : errCls ? errCls : ""
                        }
                      />
                      {Loading === "Loading..."
                        ? ""
                        : errors[name] && (
                          <Form.Text className="text-danger">
                            {errors[name]}
                          </Form.Text>
                        )}
                    </Form.Group>
                  );
                })}
                <Button block type="submit" className="loginBtn">
                  {Loading}
                </Button>
              </Form>
              <h5 className="loginBack">
                <Link to="/forgotpage">Forgot Password?</Link>
              </h5>
            </div>
          </div>
        </main>
      </Container>
      <Footer />
    </div>
  );
};

export default Login;
