import React, { useState, useEffect } from "react";
import Moment from "moment";
import * as RB from "react-bootstrap";
import "react-toastify/dist/ReactToastify.css";
import { BiMailSend } from "react-icons/bi";
import { AiOutlineEye } from "react-icons/ai";
import { RiDeleteBin6Line } from "react-icons/ri";
import PaginationComponent from "../../../Components/Common/PaginationComponent";
import ProposalViewModal from "../../../Components/Models/ProposalModals/ProposalViewModal";
import ProposalEmailModal from "../../../Components/Models/ProposalModals/ProposalEmailModal";
import { getProposalList, deleteProposalDetail } from "../../../Utils/api";
import Modal from "../../../Components/Common/Modal";
import { Link } from "react-router-dom";
import { MdAddCircleOutline } from "react-icons/md";

const Table = ({
  Data,
  PROPOSAL_EMAIL_SHOW,
  PROPOSAL_VIEW_SHOW,
  PROPOSAL_DELETE_FUNCTION,
}) => {
  return Data.length !== 0 ? (
    Data.map((data, inx) => {
      return (
        <tr key={"PROPOSAL_NAV_TBL" + inx}>
          <td>{data.T_orderid}</td>
          <td>{data.T_username}</td>
          <td>{data.f_heading}</td>
          <td>{Moment(data.T_orderdate).format("DD-MM-YYYY")}</td>
          <td>{data.f_totimg}</td>
          <td>{data.f_amt}</td>
          <td>{data.f_discount}</td>
          <td>{data.f_sertax}</td>
          <td>{data.f_finalamt}</td>
          <td className="td_comments text-center">
            <BiMailSend
              title="Send Mail"
              onClick={() => PROPOSAL_EMAIL_SHOW(data.T_orderid)}
            />
            <AiOutlineEye
              title="Proposal View"
              onClick={() => PROPOSAL_VIEW_SHOW(data.T_orderid)}
            />
            <RiDeleteBin6Line
              className="text-danger1"
              title="Proposal Delete"
              onClick={() => {
                PROPOSAL_DELETE_FUNCTION(data.T_orderid);
              }}
            />
          </td>
        </tr>
      );
    })
  ) : (
    <tr>
      <td class="no_records" colspan="11">
        No Records Found
      </td>
    </tr>
  );
};

export const ProposalList = () => {
  const [Data, setData] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [itemPerPage, setItemPerPage] = useState(20);
  let [searchData, setSearchData] = useState("");
  const [Count, setCount] = useState(0);
  const [Loading, setLoading] = useState(false);
  const [gotoPage, setGoToPage] = useState("");

  const [ModealData, setModelData] = useState({
    T_orderid: "",
    f_proposal_email: "",
  });

  // MODALS
  const [ProposalEmail, setProposalEmail] = useState(false);
  const [ProposalView, setProposalView] = useState(false);

  const [isOpen, setIsOpen] = useState(false);
  const [ModelMsg, setModelMsg] = useState("");

  const GET_API = async () => {
    const res = await getProposalList(currentPage, itemPerPage, searchData);
    let { proposalCount, proposalData } = res;
    setData(proposalData);
    proposalCount.length === 1
      ? setCount(proposalCount[0].totalCount)
      : setCount(0);
    setLoading(false);
  };

  const PROPOSAL_EMAIL_SHOW = (T_orderid) => {
    setModelData({ ...ModealData, T_orderid });
    setProposalEmail(true);
  };
  const PROPOSAL_VIEW_SHOW = (T_orderid) => {
    setModelData({ ...ModealData, T_orderid });
    setProposalView(true);
  };
  // MODALS

  const PROPOSAL_DELETE_FUNCTION = async (T_orderid) => {
    const res = await deleteProposalDetail(T_orderid);
    let { status, message } = res;
    if (status === 200) {
      await GET_API();
      setModelMsg(message);
      modelSet();
    } else {
      setModelMsg(message);
      modelSet();
    }
  };

  const gotToPage = async () => {
    //console.log(gotoPage)
    setCurrentPage(gotoPage)
    setLoading(true);
    await GET_API();
    window.scroll(0, 0);
    setLoading(false);
  }

  const handleChange = async (e) => {
    setSearchData(e.target.value);
    setLoading(true);
    const res = await getProposalList(
      currentPage,
      itemPerPage,
      (searchData = e.target.value)
    );
    let { proposalCount, proposalData } = res;
    setData(proposalData);
    proposalCount.length === 1
      ? setCount(proposalCount[0].totalCount)
      : setCount(0);
    setLoading(false);
  };

  useEffect(() => {
    setLoading(true);
    GET_API();
  }, [currentPage, itemPerPage]);

  const modelSet = () => {
    setIsOpen(true);
  };

  let { T_orderid } = ModealData;

  return (
    <>

      <RB.Row className="rownew1">
        <RB.Col lg={12}>
          <RB.Row className="rownew1" style={{ paddingTop: "25px" }}>
            <div className="tableHeader tableHeader1 order_btntable">
              <RB.Col md={6} xs={12} className="table_span">
                <h3 className="page-title d-flex userv">
                  <span>Search Results</span>
                </h3>
              </RB.Col>
              <RB.Col md={6} xs={12} className="table_span">
                <div className="float-right responsive_floatbtn">
                  <RB.Button size="sm" variant="primary" className="btn_svg"
                  >
                    <Link to="/dashboard/Proposal/create">
                      <MdAddCircleOutline style={{ marginRight: "3px" }} />
                      CREATE PROPOSAL
                    </Link>
                  </RB.Button>
                </div>
              </RB.Col>
            </div>
          </RB.Row>
        </RB.Col>

        <RB.Col lg={12}>
          <div className="box_detail" style={{ borderRadius: "4px" }}>
            <div className="page-header row">
              <RB.Col md={12}>
                <RB.Form className="manage_searchorder">
                  <RB.Row className="mg_row0">
                    <RB.Col lg={3} md={5}>
                      <RB.Row className="mg_row0">
                        <RB.Col lg={12} className="">
                          <RB.Form.Group>
                            <RB.Form.Control
                              onChange={handleChange}
                              type="text"
                              placeholder="Search by Text/Proposal ID"
                            />
                          </RB.Form.Group>
                        </RB.Col>
                      </RB.Row>
                    </RB.Col>
                  </RB.Row>
                </RB.Form>
              </RB.Col>
            </div>
          </div>
        </RB.Col>

        <RB.Col lg={12}>
          <RB.Row className="rownew1">
            <div className="tableHeader tableHeader1 search_new">
              <RB.Col lg={6} md={6} className="table_span">
                <h3 className="page-title d-flex userv">
                  <span>Proposal List</span>
                </h3>
              </RB.Col>
            </div>
          </RB.Row>
          <div
            className="box_detail table_boxdtl manage_order"
            style={{ marginBottom: "0px" }}
          >
            <RB.Table striped bordered hover variant="dark" responsive>
              <thead>
                <tr class="vtable">
                  <th>Proposal ID</th>
                  <th>User Name</th>
                  <th>Heading</th>
                  <th className="createdate_tablet">Create Date</th>
                  <th className="text-center">No. of images</th>
                  <th>Amount INR</th>
                  <th>Discount INR</th>
                  <th>Tax INR</th>
                  <th>Total Amount INR</th>
                  <th className="text-center action_align">Action</th>
                </tr>
              </thead>
              <tbody>
                {Loading ? (
                  <tr>
                    <td class="loadingd" colspan="10">
                      Loading....
                    </td>
                  </tr>
                ) : (
                  <Table
                    Data={Data}
                    PROPOSAL_EMAIL_SHOW={PROPOSAL_EMAIL_SHOW}
                    PROPOSAL_VIEW_SHOW={PROPOSAL_VIEW_SHOW}
                    PROPOSAL_DELETE_FUNCTION={PROPOSAL_DELETE_FUNCTION}
                  />
                )}
              </tbody>
            </RB.Table>
          </div>

          <PaginationComponent
            MOCK_DATA={Count}
            currentPage={currentPage}
            setCurrentPage={setCurrentPage}
            itemPerPage={itemPerPage}
            setItemPerPage={setItemPerPage}
          />
        </RB.Col>

        <ProposalViewModal
          ProposalView={ProposalView}
          setProposalView={setProposalView}
          T_orderid={T_orderid}
        />

        <ProposalEmailModal
          ProposalEmail={ProposalEmail}
          setProposalEmail={setProposalEmail}
          T_orderid={T_orderid}
        />
        
      </RB.Row>
      <Modal text={ModelMsg} open={isOpen} onClose={() => setIsOpen(false)} />
    </>
  );
};

export default ProposalList;
