const customerRoute = require("express").Router();

const {
    getCustomerData, getUnregisteredCustomerList, getShortAndGroupName,
    updateCustomerShortAndGroupName, DeleteUserRecord, getExportCustomerData,
    UnpaidUser, superImageUser, superImageUserViewList, feedbackUser, BannerImageUser,
    deleteFeedback, ReplayEmail
} = require("../controllers/customerController")

customerRoute.route("/getunregisteredcustomerlist").get(getUnregisteredCustomerList);
customerRoute.route("/getShortAndGroupName").post(getShortAndGroupName);
customerRoute.route("/updatecustomershortandgroupname").post(updateCustomerShortAndGroupName);
customerRoute.route("/getcustomerdata").get(getCustomerData);
customerRoute.route("/DeleteUserRecord/:userId").get(DeleteUserRecord);
customerRoute.route("/customerexportdetails").get(getExportCustomerData);

customerRoute.route("/getunpaidcustomerdata").get(UnpaidUser);
customerRoute.route("/getsuperImageUsercustomerdata").get(superImageUser);
customerRoute.route("/getsuperImageUserViewListcustomerdata/:f_email").get(superImageUserViewList);
customerRoute.route("/getfeedbackUsercustomerdata").get(feedbackUser);
customerRoute.route("/deletefeedbackUsercustomerdata/:_id").get(deleteFeedback);
customerRoute.route("/feedbackreplayemail").post(ReplayEmail);
customerRoute.route("/getBannerImageUsercustomerdata").get(BannerImageUser);


module.exports = customerRoute;