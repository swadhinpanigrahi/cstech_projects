module.exports = {
    dir:"public//profiles"
}