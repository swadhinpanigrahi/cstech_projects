const mongoose = require("mongoose");

const T_allkeyword_MongoDBSchema = mongoose.Schema(
    {
        aid: { type: Number },
        Akeyword: { type: String },
        deletedrow: { type: Boolean }
    },
    { collection: "T_allkeyword_MongoDB" }
)

module.exports = T_allkeyword_MongoDB = mongoose.model(
    "T_allkeyword_MongoDB",
    T_allkeyword_MongoDBSchema
)