const { createLogger, format, transports } = require("winston")

const { combine, printf, colorize, timestamp } = format;

const logger = createLogger({
  transports: [
    new transports.File({
      level: "info",
      format: combine(
        colorize(),
        timestamp({ format: "YYYY-MM-DD HH:mm:ss" }),
        printf((info) => `${info.timestamp} ${info.level} : ${info.message}`)
      ),
      filename: "log/info.log",
    }),
    new transports.File({
      level: "error",
      format: combine(
        colorize(),
        timestamp({ format: "YYYY-MM-DD HH:mm:ss" }),
        printf((info) => `${info.timestamp} ${info.level} : ${info.message}`)
      ),
      filename: "log/error.log",
    }),
  ],
  exitOnError: false,
});

if (process.env.ENVIRONMENT !== "production") {
  logger.add(
    new transports.Console({
      format: combine(
        colorize(),
        timestamp({
          format: "YYYY-MM-DD HH:mm:ss",
        }),
        printf((info) => `${info.timestamp} ${info.level}: ${info.message}`)
      ),
    })
  );
}

module.exports = logger;
