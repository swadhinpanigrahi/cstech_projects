import React, { useState, useEffect } from "react";
import Cookie from "js-cookie";
import { Link } from "react-router-dom";
import $ from "jquery";

const Topbar = () => {
  const [ViewAuth, setViewAuth] = useState({
    customers_viewlist: "",
    shipments_viewlist: "",
    codreports_viewlist: "",
    outstanding_viewlist: ""
  })

  let { customers_viewlist, shipments_viewlist, codreports_viewlist, outstanding_viewlist } = ViewAuth
  const openNav = () => {
    $("#menu").addClass("resmenu");
    $(".resmenu").css("display", "block");
    $(".resmenu").css("width", "250px");
    $("#resmenun").css("display", "block");
    $(".closebtn").css("display", "block");
    $("#resmenun").addClass("mm-listview");
    $("#navm").css("margin-left", "0px");
  };

  const closeNav = () => {
    $("#menu").removeClass("resmenu");
    $("#menu").css("width", "auto");
    $("#resmenun").css("display", "npne");
    $(".mm-listview").css("display", "none");
    $(".closebtn").css("display", "none");
    $("#resmenun").removeClass("mm-listview");
    $("#navm").css("margin-left", "0px");
  };

  $("#resmenun li span a").click(function () {
    setTimeout(function () {
      $("#menu").removeClass("resmenu");
      $("#menu").css("width", "auto");
      $("#resmenun").css("display", "npne");
      $(".mm-listview").css("display", "none");
      $(".closebtn").css("display", "none");
      $("#resmenun").removeClass("mm-listview");
      $("#navm").css("margin-left", "0px");
    }, 1000);
  });
  const NAME_SECTIONS = [
    {
      name: "Dashboard",
      route: "/dashboard/analytical",
      status: "true"
    },
    {
      name: "Customers",
      route: "/dashboard/customer/get",
      status: customers_viewlist
      // name: customers_viewlist === "true" ? "Customers" : "",
      // route: customers_viewlist === "true" ? "/dashboard/customer/get" : "",
    },
    {
      name: "Shipments",
      route: "/dashboard/shipments/get",
      status: shipments_viewlist
      // name: shipments_viewlist === "true" ? "Shipments" : "",
      // route: shipments_viewlist === "true" ? "/dashboard/shipments/get" : "",
    },
    {
      name: "COD Reports",
      route: "/dashboard/CODReports/get",
      status: codreports_viewlist
      // name: codreports_viewlist === "true" ? "COD Reports" : "",
      // route: codreports_viewlist === "true" ? "/dashboard/CODReports/get" : "",
    },
    {
      name: "COD Reports New",
      route: "/dashboard/CODReports/Allget",
      status: codreports_viewlist
    },
    {
      name: "OutStanding",
      route: "/dashboard/outstandingreport/get",
      status: outstanding_viewlist
      // name: outstanding_viewlist === "true" ? "OutStanding" : "",
      // route: outstanding_viewlist === "true" ? "/dashboard/outstandingreport/get" : "",
    },
    {
      name: "OutStanding New",
      route: "/dashboard/outstandingreport/getnew",
      status: outstanding_viewlist
      // name: outstanding_viewlist === "true" ? "OutStanding" : "",
      // route: outstanding_viewlist === "true" ? "/dashboard/outstandingreport/get" : "",
    },
  ];

  useEffect(() => {
    const fun = async () => {
      const customers_viewlist = await Cookie.get("customers_viewlist")
      const shipments_viewlist = await Cookie.get("shipments_viewlist")
      const codreports_viewlist = await Cookie.get("codreports_viewlist")
      const outstanding_viewlist = await Cookie.get("outstanding_viewlist");

      const updateState = { ...ViewAuth }
      updateState.customers_viewlist = customers_viewlist
      updateState.shipments_viewlist = shipments_viewlist
      updateState.codreports_viewlist = codreports_viewlist
      updateState.outstanding_viewlist = outstanding_viewlist
      setViewAuth({ ...updateState })

      // console.log("TopBar", customers_viewlist, shipments_viewlist, codreports_viewlist, outstanding_viewlist)
    }
    fun()
  }, [])

  return (
    <header className="header_in">
      <div className="container-fluid">
        <div className="row">
          <div className="col-lg-12 col-12">
            <ul id="top_menu">
              <li>
                <span>{/* <a className="helpbtn">HELP</a> */}</span>
              </li>
            </ul>

            <span className="hamber" onClick={openNav}>
              &#9776;
            </span>

            <nav id="menu" className="main-menu">
              <a
                href="javascript:void(0)"
                className="closebtn"
                onClick={closeNav}
              >
                &times;
              </a>

              <ul id="resmenun">
                {NAME_SECTIONS.filter((data) => data.status === "true").map((data, inx) => {
                  let { name, route } = data;
                  return (
                    <li key={inx}>
                      <span>
                        <Link to={route}>{name}</Link>
                      </span>
                    </li>
                  );
                })}
              </ul>

              <ul id="resmenun1">
                {NAME_SECTIONS.filter((data) => data.status === "true").map((data, inx) => {
                  let { name, route } = data;
                  return (
                    <li key={inx}>
                      <span>
                        <Link to={route}>{name}</Link>
                      </span>
                    </li>
                  );
                })}
              </ul>

            </nav>
          </div>
        </div>
      </div>
      <div className="layer"></div>
    </header>
  );
};

export default Topbar;
