const {
    AdminLogin,
    registration,
    order,
    proposal,
    followup,
    forgetPassTkn,
    T_Orders_IB_MongoDB,
    invoiceSchema,
    t_invoice_IB_MongoDB,
    orderDetailSchema,
    CountrySchema,
    StateSchema,
    t_LUS104576_IB_MongoDB,
    t_TUR0615518_IB_MongoDB,
    t_orderproposal_IB_MongoDB,
    FollowupSchemaV2
} = require("../model");
const companyMasterSchema = require("../model/companyMasterSchema");
const {
    generateToken,
    checkAuthorization,
    veridyEmailPassword,
} = require("../utils/jwt");
const { IBresetPassword } = require("../utils/nodeMailer/sendMail");


module.exports = {
    updateUserDetailsSqlToMongo: async (req, res) => {
        const data = req.body;
        console.log(data);
        // res.send(req.params)
        // return
        const { f_userid } = req.params;
        const { _id, CS_username, CS_password, CS_email, CS_firstname, CS_lastname, CS_IPAddress,
            cs_active, CS_active, cs_refid, cs_ecashamt, f_EcashSetUp, CS_companynames, CS_mobile, cs_followups_status,
            f_GSTIN, f_ISDNo, f_userAttempt, f_attemptTime, f_sno, CS_jobdesc, CS_businesstype, CS_country, CS_address,
            CS_state, CS_pin, CS_phone, CS_subscribe, CS_lightboxname, CS_comment, f_Identify_User,
            cs_info, CS_status, cs_gold, cs_ccmail, cs_proposal, cs_performaUser, cs_Commission, cs_subscriptionccmail,
            cs_SubscriptionDiscount, f_Subscriptionconnectedto, sortcmp_name, Identify_User, group_cmpname,
            Identify_date, f_exclude, act_highres, ip_address, limit_img, f_addcmpname, f_pan, ivs_download,
            cs_discount
        } = data
        try {

            const registrationData = await registration.findOne({ f_userid });
            const t_LUS = await t_LUS104576_IB_MongoDB.findOne({ CS_userid: registrationData.f_userid });
            const t_TUR = await t_TUR0615518_IB_MongoDB.findOne({ CS_userid: registrationData.f_userid });
            // console.log(registrationData, t_LUS, t_TUR)
            if (registrationData && t_LUS && t_TUR) {
                await registration.updateOne({ f_userid }, {
                    $set: {
                        f_fullname: `${CS_firstname} ${CS_lastname}`, f_email: CS_email,
                        f_mobileno: CS_mobile, f_companyname: CS_companynames, f_Shortname: sortcmp_name,
                        f_groupname: group_cmpname, f_Identify_User: f_Identify_User, CS_phone: CS_phone,
                        f_address: CS_address, f_state: CS_state, f_country: CS_country, f_commissionpolicy: cs_Commission
                    }
                })
                await t_LUS104576_IB_MongoDB.updateOne({ CS_userid: t_LUS.CS_userid }, {
                    $set: {
                        CS_username, CS_email, CS_firstname, CS_lastname, CS_status, CS_IPAddress, cs_active,
                        cs_refid, cs_ecashamt, f_EcashSetUp, CS_companynames, CS_mobile, cs_followups_status,
                        f_GSTIN, f_ISDNo, f_userAttempt
                    }
                })
                await t_TUR0615518_IB_MongoDB.updateOne({ CS_userid: t_TUR.CS_userid }, {
                    $set: {
                        CS_firstname, CS_lastname, CS_companynames, cs_ecashamt, CS_businesstype, CS_country, CS_address,
                        CS_state, CS_state, CS_pin, CS_mobile, CS_comment, sortcmp_name, Identify_User, ip_address,
                        f_GSTIN, f_userAttempt, group_cmpname, CS_jobdesc, CS_phone, CS_lightboxname,
                        cs_ccmail, f_pan, f_Subscriptionconnectedto, cs_discount, limit_img, f_addcmpname,
                        cs_subscriptionccmail, cs_proposal, cs_performaUser, cs_Commission, cs_SubscriptionDiscount, f_exclude,
                        ivs_download, act_highres, CS_active
                    }
                })

                res.json({ status: 200, message: "user updated successfully!!" });

            } else {
                res.json({ status: 400, message: "Data missmacthed while fatching from DB" })
            }

        } catch (error) {
            res.json({ status: 500, error: error.message, message: "internal server error" })
        }
    },
    removeUserSqlToMongo: async (req, res) => {
        var { userId } = req.body
        res.send(req.body)
        return
        const REG_DATA = await registration.deleteOne({ f_userid: userId })
        const TUR_DATA = await t_TUR0615518_IB_MongoDB.deleteOne({ CS_userid: userId })
        const LUS_DATA = await t_LUS104576_IB_MongoDB.deleteOne({ CS_userid: userId });
        res.json({
            data: req.body
        })
    },
    RemoveOrderSqlToMongo: async (req, res) => {
        const { T_orderid } = req.params;
        console.log(req.body);
        try {
            const orderDetail = await T_Orders_IB_MongoDB.findOne({ T_orderid });
            const orderDetails = await orderDetailSchema.find({ t_orderid: T_orderid });
            if (orderDetail && orderDetails) {
                await T_Orders_IB_MongoDB.deleteOne({ _id: orderDetail._id })
                orderDetails.forEach(async info => {
                    await orderDetailSchema.deleteOne({ _id: info._id })
                })
            }
            res.json({ status: 200, message: `Order Deleted Successfully..`, data: req.params });
        } catch (error) {
            res.json({ status: 500, message: `Error in Controller`, error: error.message });
        }
    },
    RejectOrderSqlToMongo: async (req, res) => {
        const { T_orderid } = req.params;
        try {
            const orderDetail = await T_Orders_IB_MongoDB.findOne({ T_orderid });
            if (orderDetail) {
                await T_Orders_IB_MongoDB.updateOne({ _id: orderDetail._id }, { $set: { T_status: "R" } });
            }
            res.json({ status: 200, message: `Order Rejected Successfully..`, data: req.params });
        } catch (error) {
            res.json({ status: 500, message: `Error in Controller`, error: error.message });
        }
    },
    confirmOrderSqlToMongo: async (req, res) => {
        console.log("coming in order section");
        //    console.log(req);
        const { orderid, invoiceid } = req.body
        // console.log(req.body)
        // return
        try {
            // var invoiceId = Math.floor(Math.random() * 98900000999999 + 91009000000099);
            var OrderInfo = await T_Orders_IB_MongoDB.findOne({
                T_orderid: orderid,
            });
            var OrderDetails = await orderDetailSchema.find({
                t_orderid: orderid,
            });
            // console.log(OrderInfo, OrderDetails)
            // var userInfo = await RegistrationSchema.findOne({
            //     f_email: req.body.f_email,
            // });
            // return

            db1.collection("T_Orders_IB_MongoDB").updateOne(
                { T_orderid: orderid },
                {
                    $set: {
                        T_status: "C",
                        t_paymentdate: new Date(),
                        f_invoiceID: invoiceid,//Resbody.recordset[0].invoiceId,
                        t_comment: req.body.t_comment
                    },
                },
                function (err1, updated) {
                    console.log(err1);
                    // console.log(updated);
                }
            );
            db1.collection("t_registration_mongoDB").updateOne(
                { f_email: req.body.f_email },
                {
                    $set: {
                        f_companyname: req.body.f_companyname,
                        CS_address: req.body.CS_address,
                        f_state: req.body.f_state,
                    },
                }
            );

            db1.collection("t_invoice_IB_MongoDB", function (err, collection) {
                collection.insertOne({
                    invoice_id: invoiceid,//Resbody.recordset[0].invoiceId,
                    orderid: orderid,//req.body.orderid,
                    invoice_date: new Date(),
                    total_amt: OrderInfo.f_orderAmt,
                    discount: 0,
                    tax_amt: parseInt((OrderInfo.f_orderAmt * 18) / 100),
                    final_amt:
                        parseInt(OrderInfo.f_orderAmt) +
                        parseInt((OrderInfo.f_orderAmt * 18) / 100),
                    f_username: OrderInfo.T_username,
                    f_paymode: OrderInfo.T_paymode,
                    f_client: OrderInfo.t_client,
                    f_purchaseorderno: null,
                    t_paymentstatus: OrderInfo.t_paymentstatus,
                    f_orderdate: OrderInfo.T_orderdate,
                    f_paymentdate: OrderInfo.T_orderdate,
                    Name: req.body.f_fullname,
                    Companyname: req.body.f_companyname,
                    address: req.body.CS_address,
                    invoicereject: false,
                    orderby: OrderInfo.t_client,
                    t_followup_status: 0,
                    T_status: "C",
                    f_county: "India",
                    f_statecrm: req.body.f_state,
                    f_companyCrm: req.body.f_companyname,
                    t_commissionamount: null,
                    t_commdiscount: null,
                    t_commShow: "0",
                    f_comm_status: "Unpaid",
                    f_comm_detail: null,
                    f_discountOnInvoice: 0,
                    f_clientGSTIN_no: req.body.f_GSTIN,
                    t_invoiceText: null,
                });
            });

            OrderDetails.forEach((item) => {
                db1.collection(
                    "t_invoice_details_IB_MongoDB",
                    function (err, collection) {
                        collection.insertOne({
                            f_orderid: orderid,//req.body.orderid,
                            f_HSN_ACS: "",
                            f_imgname: item.f_image_type,
                            cratedate: new Date(),
                            f_quality: item.t_quality,
                            f_qty: 1,
                            f_price: item.t_price,
                            f_totalprice: item.t_price,
                            f_discount: 0,
                            f_tax: 18,
                            f_SGST: 0,
                            f_CGST: 0,
                            f_IGST: parseInt((item.t_price * 18) / 100),
                            f_FinalePrice:
                                parseInt(item.t_price) + parseInt((item.t_price * 18) / 100),
                            f_imagetype: item.f_image_type,
                            CS_ImgType_up: item.CS_ImgType_up,
                            f_mydimension: item.f_mydimension,
                            f_groupid: item.f_groupid,
                            f_rank: item.f_rank,
                        });
                    }
                );
            });
            // res.json({ status: 200, message: "Invoice Rejected" })
            res.json({
                updated: "updated"
            });

        } catch (error) {
            console.log("coming in else");
            console.log(error);
        }
    },
    updateInvoiceSqlToMongo: async (req, res) => {
        // const { f_orderid } = req.params;
        console.log("coming in order edit section,km   ");
        console.log(req.body);
        const {
            Companyname, f_client, CS_comment, address, orderby, f_statecrm, f_clientGSTIN_no,
            find_info_mail, CS_companynames, group_cmpname, cs_discount,
            f_discountType, f_CreaditPeriod, f_orderid
        } = req.body;
        try {
            // if (!find_info_mail) {
            //     const invoiceDetail = await t_invoice_IB_MongoDB.findOne({ orderid: f_orderid });
            //     await t_invoice_IB_MongoDB.updateOne(
            //         { s_id: invoiceDetail._id },
            //         {
            //             $set: {
            //                 Companyname, f_client, address, orderby, f_statecrm, f_clientGSTIN_no
            //             }
            //         }
            //     )
            // }

            // if (find_info_mail) {
            console.log("m i calling", CS_comment, CS_companynames, group_cmpname)
            const invoiceDetail = await t_invoice_IB_MongoDB.findOne({ orderid: f_orderid });
            const T_orderDetails = await T_Orders_IB_MongoDB.findOne({ T_orderid: invoiceDetail.orderid });
            const LUS = await t_LUS104576_IB_MongoDB.findOne({ CS_username: T_orderDetails.T_username });
            const TUR = await t_TUR0615518_IB_MongoDB.findOne({ CS_userid: LUS.CS_userid });


            await t_invoice_IB_MongoDB.updateOne(
                { _id: invoiceDetail._id },
                {
                    $set: {
                        Companyname, f_client, address, orderby, f_statecrm, f_clientGSTIN_no
                    }
                }
            )

            await t_TUR0615518_IB_MongoDB.updateOne(
                { _id: TUR._id },
                {
                    $set: {
                        CS_comment, cs_discount, CS_companynames, group_cmpname
                    }
                }
            )

            await T_Orders_IB_MongoDB.updateOne(
                { _id: T_orderDetails._id },
                {
                    $set: {
                        f_discountType, f_CreaditPeriod
                    }
                }
            )
            // }

            res.json({ status: 200, message: "invoice update successfully!" })

        } catch (error) {
            console.log("coming in catch");
            console.log(error);
            res.json({ message: `Error in Controller`, error: error.message });
        }
    },
    updateCompanySqlToMongo: async (req, res) => {
        console.log("Cooming in Comany Update");
        console.log(req.body);
        const { f_Shortname, f_groupname, selectedEmails } = req.body;
        try {
            var emailBulk = selectedEmails.split(',');
            console.log(emailBulk);
            emailBulk.forEach(async (email) => {
                const CustomerDetails = await registration.findOne({ f_email: email });
                const t_TUR_Data = await t_TUR0615518_IB_MongoDB.findOne({ CS_userid: CustomerDetails.f_userid })
                console.log(CustomerDetails, t_TUR_Data)

                await registration.updateOne({ _id: CustomerDetails._id }, {
                    $set: {

                        f_Shortname,
                        f_groupname
                    }
                })
                await t_TUR0615518_IB_MongoDB.updateOne({ _id: t_TUR_Data._id }, {
                    $set: {
                        sortcmp_name: f_Shortname,
                        group_cmpname: f_groupname
                    }
                })
            })

            // res.json({ status: 200, message: "user updated successfully!!" });

        } catch (error) {
            console.log(error);
            res.json({ message: `Error in Controller`, error: error.message });
        }
    },
    RemoveProposalSqlToMongo: async (req, res) => {
        console.log(req.body);
        const { T_orderid } = req.body;
        try {

            const t_proposal = await t_orderproposal_IB_MongoDB.findOne({ T_orderid });
            const t_proposalDetails = await t_ordproposal_details_IB_MongoDB.findOne({
                t_orderid: T_orderid,
            });
            if (t_proposal && t_proposalDetails) {
                await t_orderproposal_IB_MongoDB.deleteOne({ _id: t_proposal._id });
                await t_ordproposal_details_IB_MongoDB.deleteOne({
                    _id: t_proposalDetails._id,
                });
                res.json({ status: 200, message: "successfully deleted proposal" });
            } else {
                res.json({ status: 400, message: "error while deleting proposal" });
            }



        } catch (error) {
            res.json({ message: `Error in Controller`, error: error.message });
        }
    },
    CreateFollowUpSqlToMongo: async (req, res) => {
        console.log(req.body);

        try {
            // var obj = {
            var ats = Math.floor(Math.random() * Date.now());
            // var ats = Math.random(a)
            folowData = new FollowupSchemaV2({
                f_sno: ats,
                f_email: req.body.cs_ccmail,
                f_AlternateEmail: req.body.f_AlternateEmail,
                f_fullname: req.body.CS_firstname + ' ' + req.body.CS_lastname,
                f_CompanyName: req.body.CS_companynames,
                f_PhoneNumber: req.body.CS_phone,
                f_MobileNo: req.body.CS_mobile,
                f_state: req.body.CS_state,
                f_country: 'India', //req.body.country,
                f_usertype: req.body.userType,
                f_RequirementType: req.body.reqType,
                f_followups_status: "Open",
                f_createdby: "",
                f_creationdate: Date.now(),
                f_DescriptionType: req.body.aboutIB,
                f_DiscountTerms: req.body.discountTerm,
                f_CreditPeriod: req.body.credetPeriod,
                f_OrderId: req.body.orderID,
                f_followUpType1: req.body.followUpType,
                f_followUpType2: req.body.followUpType2,
                f_followUpDescriptionType: req.body.followUpDescriptionType,
                f_followUpDescriptionType2: req.body.followUpDescriptionType2,
                f_followupDate: req.body.followupDate,
                f_followupDate2: req.body.followupDate2,
                f_followupDescription: req.body.followupDescription,
                f_followupDescription2: req.body.followupDescription2,
                f_followupOrderID: req.body.followupOrderID,
                f_followupOrderID2: req.body.followupOrderID2,
                f_AdditionalInfo: {
                    add_userType: req.body.add_userType,
                    add_name: req.body.add_name,
                    add_email: req.body.add_email,//'superadmin@cstech.in',
                    add_contact: req.body.add_contact,// '09876543210',
                    add_designation: req.body.add_designation,// 'gfdgdfgdfg',
                    add_imp: req.body.add_imp//'important'
                }
            })

            followupData = new followup({
                f_sno: ats,
                f_email: req.body.cs_ccmail,
                f_AlternateEmail: req.body.f_AlternateEmail,
                f_fullname: req.body.CS_firstname + ' ' + req.body.CS_lastname,
                f_CompanyName: req.body.CS_companynames,
                f_PhoneNumber: req.body.CS_phone,
                f_MobileNo: req.body.CS_mobile,
                f_state: req.body.CS_state,
                f_country: 'India', //req.body.country,
                f_usertype: "Existing",//req.body.userType,
                f_RequirementType: req.body.reqType,
                f_followups_status: "Open",
                f_createdby: "",
                f_creationdate: Date.now(),
                f_DescriptionType: req.body.aboutIB,
                f_DiscountTerms: req.body.f_DiscountTerms,
                f_CreditPeriod: req.body.credetPeriod,
                f_OrderId: req.body.orderID,
                f_followUpType1: req.body.followUpType,
                f_followUpType2: req.body.followUpType2,
                f_followUpDescriptionType: req.body.followUpDescriptionType,
                f_followUpDescriptionType2: req.body.followUpDescriptionType2,
                f_followupDate: req.body.followupDate,
                f_followupDate2: req.body.followupDate2,
                f_followupDescription: req.body.followupDescription,
                f_followupDescription2: req.body.followupDescription2,
                f_followupOrderID: req.body.followupOrderID,
                f_followupOrderID2: req.body.followupOrderID2,
                f_AdditionalInfo: {
                    add_userType: req.body.add_userType,
                    add_name: req.body.add_name,
                    add_email: req.body.add_email,//'superadmin@cstech.in',
                    add_contact: req.body.add_contact,// '09876543210',
                    add_designation: req.body.add_designation,// 'gfdgdfgdfg',
                    add_imp: req.body.add_imp//'important'
                }
            })
            const result = await folowData.save();
            const result1 = await followupData.save();
            res.json({
                status: true,
                data: result,
                msg: "Followup data created successfully.."
            })
        } catch (error) {
            console.log(error);
            res.json({
                status: false,
                data: "",
                msg: error
            })
        }
    },

}