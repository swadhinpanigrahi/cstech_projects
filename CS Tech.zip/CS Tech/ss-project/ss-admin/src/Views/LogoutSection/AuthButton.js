import React from "react";
import { useAuth } from "../../Utils/auth";
import Topbar from "../../Components/Headers/Topbar";
import Profilebar from "../../Components/Headers/Profilebar";

const AuthButton = () => {
  let auth = useAuth();
  return auth.user ? (
    <div>
      <Profilebar /> <Topbar />
    </div>
  ) : (
    ""
  );
};

export default AuthButton;
