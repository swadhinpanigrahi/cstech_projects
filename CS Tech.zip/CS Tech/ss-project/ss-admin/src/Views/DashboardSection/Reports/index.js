import React from 'react'
import { Route } from "react-router-dom"

import Reports from "./Reports";
import AllReports from "./AllReports";

const ReportsDash = () => {
    return (
        <>
            <main className="pd-b-25">
                <Route path="/dashboard/CODReports/get" component={Reports} />
                <Route path="/dashboard/CODReports/Allget" component={AllReports} />
            </main>
        </>
    )
}

export default ReportsDash
