const proposalRoute = require("express").Router();

const {
    sendProposalMail, getProposalData, getProposalDetails, deleteProposalDetail, getImageById,
    getImageSizeDrop, getFromCartArray, addTocart, deleteFromCart,
    FinalizeProposal, getOrderUserDetails
} = require("../controllers/proposalController")

proposalRoute.route("/getproposaldata").get(getProposalData);
proposalRoute.route("/getproposaldetails/:T_orderid").get(getProposalDetails);
proposalRoute.route("/deleteproposaldetail/:T_orderid").get(deleteProposalDetail);

proposalRoute.route("/sendproposalviewemail").post(sendProposalMail)

proposalRoute.route("/getimagebyidsearch").post(getImageById);
proposalRoute.route("/getsizeforimages/:f_pricing").get(getImageSizeDrop);

proposalRoute.route("/getexistingcartdetails/:CS_username").get(getFromCartArray);
proposalRoute.route("/addtocartimage").post(addTocart);
proposalRoute.route("/removefromcart").post(deleteFromCart);

proposalRoute.route("/finalizeproposalentry").post(FinalizeProposal);

proposalRoute.route("/getOrderUserDetails/:CS_username").get(getOrderUserDetails);



module.exports = proposalRoute;