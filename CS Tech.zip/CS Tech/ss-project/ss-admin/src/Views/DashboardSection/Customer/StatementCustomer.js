import React, { useState, useEffect } from "react";
import { getPaymentStalment, paymentFilteredData } from '../../../Utils/api';
import { Link, useParams } from "react-router-dom";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";


const StatementCustomer = () => {
  const { _id } = useParams();
  const [Loading, setLoading] = useState(false)
  const [StatelmentData, setSetelmentData] = useState({
    satelmentArray: [],
    credit: 0,
    debit: 0,
    netPayble: 0,
    netRecevible: 0
  });
  let [startDate, setStartDate] = useState(0);
  let [endDate, setEndDate] = useState(0);

  const onsubmit = async () => {
    const res = await paymentFilteredData({ startDate, endDate }, _id)
    let { error, paymentDetails, sumCredit, sumDebit, netPayble, netReceiveble } = res
    if (!error) {
      const updateState = { ...StatelmentData }
      updateState.satelmentArray = paymentDetails;
      updateState.credit = sumCredit;
      updateState.debit = sumDebit;
      updateState.netPayble = netPayble;
      updateState.netRecevible = netReceiveble;
      setSetelmentData({ ...updateState })
    }
  }

  let { satelmentArray, credit, debit, netPayble, netRecevible } = StatelmentData

  const listData = satelmentArray.length !== 0 ? satelmentArray.map((data, inx) => {
    let {
      createdAt,
      seller_entry_name,
      comment,
      payment_type,
    } = data;
    return (
      <tr key={"table" + inx}>
        <td className="text-center">
          {inx + 1}
        </td>
        <td className="text-center">
          {createdAt.slice(0, 10)}
        </td>
        <td>{`${seller_entry_name}  [${data.userId}]`}</td>
        <td>{comment}</td>
        <td className="text-right">
          {payment_type === "Credit" ? data.payed_amount : 0}
        </td>
        <td className="text-right">
          {payment_type === "Debit" ? data.payed_amount : 0}
        </td>
      </tr>
    );
  }) : <tr ><td className="no_records" colSpan="8">NO RECORDS FOUND</td></tr>

  useEffect(() => {
    setLoading(true)
    const apiCall = async () => {
      const res = await getPaymentStalment(_id);
      let { records, sumCredit, sumDebit, netPayble, netReceiveble } = res
      const updateState = { ...StatelmentData }
      updateState.satelmentArray = records;
      updateState.credit = sumCredit;
      updateState.debit = sumDebit;
      updateState.netPayble = netPayble;
      updateState.netRecevible = netReceiveble;
      setSetelmentData({ ...updateState })
      setLoading(false)
    }
    apiCall()
  }, [_id]);

  return (
    <>
      <div className="container-fluid">
        <div className="col-12">
          <div
            className="page-header row no-gutters pym-4"
            style={{ paddingBottom: ".5rem!important" }}
          >
            <div className="col-md-6">
              <h3 className="page-title">Statement Of Report</h3>
            </div>
            <div className="col-md-6 text-right backb">
              <button className="addcb">
                <span>
                  <i className="fa fa-arrow-left"></i>
                  <span style={{ position: "relative", left: "5px" }}>
                    <Link to="/dashboard/customer/get">BACK</Link>
                  </span>
                </span>
              </button>
            </div>
            <hr />
          </div>
        </div>

        <div className="col-md-12">
          <div
            className="box_detail"
            style={{ padding: "15px 0px 0px 0px", marginBottom: "20px" }}
          >
            <div className="col-12" style={{ padding: "0px" }}>
              <div className="page-header row no-gutters">
                <div className="col-md-12">
                  <h3 className="page-title subtitile">
                    ACCOUNT STATEMENT
                  </h3>
                </div>
                <hr style={{ marginBottom: "0px" }} />
              </div>
            </div>
            <div className="row" style={{ padding: "10px 30px 20px 30px" }}>
              <div className="col-lg-3 col-md-3 col-12">
                <div className="form-group mgb-0">
                  <label className="pwdc">
                    From Date <span className="text-danger">*</span>
                  </label>
                  <div
                    className="input-container form-control"
                    id="date_end"
                  >
                    <DatePicker
                      placeholderText="Start Date"
                      selected={startDate}
                      onChange={(date) => setStartDate(date)}
                    />
                  </div>
                </div>
              </div>
              <div className="col-lg-3 col-md-3 col-12">
                <div className="form-group mgb-0">
                  <label className="pwdc">
                    To Date <span className="text-danger">*</span>
                  </label>
                  <div
                    className="input-container form-control"
                    id="date_end"
                  >
                    <DatePicker
                      placeholderText="End Date"
                      selected={endDate}
                      onChange={(date) => setEndDate(date)}
                    />
                  </div>
                </div>
              </div>
              <div className="col-lg-1 col-md-3 col-12 pay_mer1">
                <label
                  className="pwdc newt_c"
                  style={{ color: "transparent" }}
                >
                  Shipment
                </label>
                <button className="subpay" onClick={onsubmit}>
                  SUBMIT
                </button>
              </div>
            </div>
          </div>
        </div>
        <div className="col-12">
          <div
            className="box_detail tableboxdc"
            style={{
              paddingTop: "0px",
              paddingBottom: "0px",
              marginBottom: "0px",
            }}
          >
            <table
              className="table table-bordered table-responsive"
              id="table-to-xls"
            >
              <thead className="thead-dark">
                <tr>
                  <th className="ohead text-center">S NO.</th>
                  <th className="ohead text-center">DATE</th>
                  <th className="nhead text-left">MERCHANT</th>
                  <th className="deshead text-left">DESCRIPTION</th>
                  <th className="nhead text-right">CREDIT</th>
                  <th className="nhead text-right">DEBIT</th>
                </tr>
              </thead>
              <tbody>
                {Loading ? <tr><td className="no_records" colSpan="8">LOADING...</td></tr> : [listData]}
              </tbody>
              <tbody className={satelmentArray.length !== 0 ? null : "display"}>
                <tr>
                  <td className="border_nonet"></td>
                  <td className="border_nonet"></td>
                  <td className="border_nonet text-right strongt">
                    Sub Total :
                  </td>
                  <td className="border_nonet text-right strongt">
                    {credit.toFixed(2)}
                  </td>
                  <td className="border_nonet text-right strongt">
                    {debit.toFixed(2)}
                  </td>
                </tr>
                <tr>
                  <td className="border_nonet"></td>
                  <td className="border_nonet"></td>
                  <td className="border_nonet text-right strongt">
                    Net Payble :
                  </td>
                  <td className="border_nonet text-right strongt">0.00</td>
                  <td className="border_nonet text-right strongt">
                    {netPayble.toFixed(2)}
                  </td>
                </tr>
                <tr>
                  <td className="border_nonet"></td>
                  <td className="border_nonet"></td>
                  <td className="border_nonet text-right strongt">
                    Net Receivable :
                  </td>
                  <td className="border_nonet text-right strongt">
                    {netRecevible.toFixed(2)}
                  </td>
                  <td className="border_nonet text-right strongt">0.00</td>
                </tr>
                <tr>
                  <td className="border_nonet"></td>
                  <td className="border_nonet"></td>
                  <td className="border_nonet text-right strongt">
                    Total :
                  </td>
                  <td className="border_nonet text-right strongt">
                    {(credit + netRecevible).toFixed(2)}
                  </td>
                  <td className="border_nonet text-right strongt">
                    {(debit + netPayble).toFixed(2)}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </>
  );
};

export default StatementCustomer;
