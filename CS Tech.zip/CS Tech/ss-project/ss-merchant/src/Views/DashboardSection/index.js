import React from 'react'
import { Route } from "react-router-dom"

// NAVPAGES
import Analytical from "./Analytical/Analytical";
import ShipmentDash from "./Shipments";
import ReportsDash from "./Reports";
import Statements from "./Statements";

import Profilebar from "../../Components/Headers/Profilebar"
import Topbar from "../../Components/Headers/Topbar";

import ManageProfile from "./ManageProfile";
import ChangePassword from "./ChangePassword";


const DashSection = () => {
    return (
        <>
            <Profilebar />
            <Topbar />
            <main className="pd-b-25">
                <Route path="/dashboard/analytical" component={Analytical} />
                <Route path="/dashboard/shipments" component={ShipmentDash} />
                <Route path="/dashboard/CODReports" component={ReportsDash} />
                <Route path="/dashboard/statements" component={Statements} />
                <Route path="/dashboard/editprofile" component={ManageProfile} />
                <Route path="/dashboard/changepassword" component={ChangePassword} />
            </main>
        </>
    )
}

export default DashSection
