import React, { useState, useEffect } from 'react';
import * as RB from 'react-bootstrap';
import { Form, Button, Row } from "react-bootstrap";
import { getOrderDetialsForConfirm, fetchCompanyDataByKeyPress, confirmOrderAndGenerateInvoice } from "../../../Utils/api";
import { useHistory, useParams, Link } from "react-router-dom";
import DatePicker from "react-datepicker";
import { IoIosArrowBack } from "react-icons/io";
import "react-datepicker/dist/react-datepicker.css";
import Moment from 'moment';
import { state } from "../../../Utils/state";
import Modal from "../../../Components/Common/Modal";


export const OrderDetail = () => {
    const history = useHistory();
    const { orderid } = useParams();
    const [OrderEditData, setOrderEditData] = useState({
        USER_INFO: {},
        ORDER_INFO: {},
        STATE_LIST: [],
        ORDER_LIST: []
    })
    const [isTrue, setisTrue] = useState(false);
    const [CompanyInfo, setCompanyInfo] = useState([]);
    const [company, setCompanyData] = useState("");
    const [usrInfo, setUserInfo] = useState(OrderEditData.USER_INFO);
    const [ordInfo, setOrderInfo] = useState(OrderEditData.ORDER_INFO);
    const [Discount, setDiscount] = useState(0);
    const [Less, setLess] = useState(0);
    const [startDate, setStartDate] = useState(new Date());

    const [isOpen, setIsOpen] = useState(false);
    const [ModelMsg, setModelMsg] = useState("");

    const modelSet = () => {
        setIsOpen(true);
    };

    const apiCall = async () => {
        const res = await getOrderDetialsForConfirm(orderid);
        let { OrderInfo, OrderDetails, userInfo, stateList } = res;
        const updateState = { ...OrderEditData }
        updateState.USER_INFO = userInfo
        updateState.ORDER_INFO = OrderInfo
        updateState.ORDER_LIST = OrderDetails
        updateState.STATE_LIST = stateList;
        let discount_price = 0;
        ORDER_LIST.forEach(element => discount_price += element.t_disc_price)
        setOrderEditData(updateState);
        setUserInfo(userInfo)
        setDiscount(discount_price);


    }


    useEffect(() => {
        setTimeout(() => {
            apiCall();
        }, 500);
    }, [orderid]);

    let { USER_INFO, ORDER_INFO, STATE_LIST, ORDER_LIST } = OrderEditData;
    console.log(OrderEditData);
    const DiscountHandler = (e) => {
        let { name, value } = e.target;
        console.log(name, value, USER_INFO)
        const data = { ...USER_INFO }
        data[name] = value;
        const updateState = { ...OrderEditData }
        updateState.USER_INFO = data;
        setOrderEditData(updateState);
    }

    const onInputChange = (e) => {
        setUserInfo({ ...usrInfo, [e.target.name]: e.target.value });
    };

    const onInputChange1 = (e) => {
        setOrderInfo({ ...ordInfo, [e.target.name]: e.target.value });
    };

    const onCompanySelect = async (id) => {
        const compInfo = CompanyInfo.filter(i => i._id === id)[0];
        setisTrue(false)
        setCompanyData(compInfo.f_companyname)
    }

    var total = 0;
    var discount = 0;
    var tax = 0;
    var netPayable = 0
    var less = 0
    var userDiscount = 0
    const listOrderDetails = ORDER_LIST.length !== 0 ? ORDER_LIST.map((info, inx) => {
        total += info.t_price;

        if (ORDER_INFO.f_orderType === "Plan" || ORDER_INFO.f_orderType === "IV") {
            return (
                <tr className="border_btm">
                    <td className="td_first text-center">
                        {info.t_quality === 'Large Size' ? <img src="https://old.imagesbazaar.com/imagesvideoimg/images/CheckoutLARGE.png" alt="invoiceimg" /> : ""}
                        {info.t_quality === 'Web-Size' ? <img src="https://old.imagesbazaar.com/imagesvideoimg/images/CheckoutSMALL.png" alt="invoiceimg" /> : ""}
                        {info.t_quality === 'Medium-Size' ? <img src="https://old.imagesbazaar.com/imagesvideoimg/images/CheckoutMEDIUM.png" alt="invoiceimg" /> : ""}
                        {info.t_quality === 'Small-Size' ? <img src="https://old.imagesbazaar.com/imagesvideoimg/images/CheckoutSMALL.png" alt="invoiceimg" /> : ""}
                        {info.t_quality === 'XL-Size' ? <img src="https://old.imagesbazaar.com/imagesvideoimg/images/CheckoutXL.png" alt="invoiceimg" /> : ""}
                        {info.t_quality === 'XXL-Size' ? <img src="https://old.imagesbazaar.com/imagesvideoimg/images/CheckoutXXL.png" alt="invoiceimg" /> : ""}
                    </td>
                    <td className="td_first text-center">
                        <p class="mg-b-0">{info.t_quality}</p>
                    </td>
                    <td className="td_first text-center">
                        <p class="mg-b-0">{info.t_imageid}</p>
                    </td>
                    <td className="td_first text-center">
                        <p class="mg-b-0">{info.f_duration} days</p>
                    </td>
                    <td className="td_second text-right">
                        <p class="mg-b-0">{info.t_price}</p>
                    </td>
                </tr>
            )

        } else {
            return (
                <tr className="border_btm">
                    <td className="td_first text-center">
                        <img src={`https://ibcdn.imagesbazaar.com/img170/${info.f_rank}-${info.t_imageid}.jpg`} alt="invoiceimg" />
                    </td>
                    <td className="td_first text-center">
                        <p class="mg-b-0">{info.t_imageid}</p>
                    </td>
                    <td className="td_first text-center">
                        <p class="mg-b-0">{info.f_image_type}</p>
                    </td>
                    <td className="td_first text-center">
                        <p class="mg-b-0">Non Exclusive </p>
                    </td>
                    <td className="td_first text-center">
                        <p class="mg-b-0">{info.f_mydimension}</p>
                    </td>
                    <td className="td_second text-right">
                        <p class="mg-b-0">{info.t_price}</p>
                    </td>
                </tr>
            )

        }
    }) : <tr><td class="no_records" colspan="11">No Records Found</td></tr>

    discount = total * parseInt(USER_INFO.f_discount) / 100;
    if (USER_INFO.cs_discount != undefined) {
        less = total * parseInt(USER_INFO.cs_discount) / 100;
    }

    var newToal = total - less
    tax = newToal * 18 / 100;
    console.log("total: ", total);
    console.log("USER_INFO.cs_discount: ", USER_INFO.cs_discount);
    console.log("Less: ", less);
    console.log("discount: ", Discount);
    console.log(total + '--' + USER_INFO.cs_discount + '--' + 100)

    // netPayable = total - discount + tax
    // alert(Less)
    const onInputChangeCompany = async (e) => {
        var compName = e.target.value
        setCompanyData(compName)
        if (compName !== "" && compName.length >= 1) {
            const companyDate = await fetchCompanyDataByKeyPress(compName);
            setCompanyInfo(companyDate.res.data.companyData)
            setisTrue(true)
        }
    }

    const onSubmit = async (e) => {
        e.preventDefault();
        const data1 = await confirmOrderAndGenerateInvoice({ ...usrInfo, ...ordInfo, orderid });
        setModelMsg("Order Confirmed! Invoice created successfully...");
        modelSet();
        setTimeout(() => {
            history.push("/dashboard/order/get")
        }, 1000)
    }

    return (
        <RB.Row className="rownew1">
            <RB.Col lg={12}>
                <RB.Row className="page_header1 rownew1">
                    <div className="tableHeader tableHeader1 search_new">
                        <RB.Col md={12} className="table_span">
                            <h3 className="page-title d-flex userv">
                                <span>Order Details</span>
                            </h3>
                        </RB.Col>
                    </div>
                </RB.Row>
            </RB.Col>
            <RB.Col lg={12}>
                <div className="box_detail" style={{ borderRadius: "4px", paddingTop: "25px", marginTop: "5px" }}>
                    <RB.Row style={{ paddingLeft: "25px", paddingRight: "25px" }}>
                        <RB.Col lg={12}>
                            <form>
                                <RB.Row>
                                    <RB.Col lg={6}>
                                        <RB.Container>
                                            <div className="main_orders">
                                                <div className="headinv" id="invoicem" style={{ borderBottom: "0px" }}>
                                                    <RB.Col lg={12} className=" pd_0">
                                                        <RB.Table responsive>
                                                            <tbody>
                                                                <tr className="border_btm">
                                                                    <td className="td_first text-left">
                                                                        <p class="mg-b-0">
                                                                            <strong>Order Status:</strong> {ORDER_INFO.T_status}
                                                                        </p>
                                                                    </td>
                                                                    <td className="td_second2 text-left">
                                                                        <tr>
                                                                            <td className="td_first text-left">
                                                                                <p class="mg-b-0">
                                                                                    <strong>Order Confirmation No.:</strong>{ORDER_INFO.T_orderid}
                                                                                </p>
                                                                            </td>
                                                                            <td className="text-left">
                                                                                <p class="mg-b-0">
                                                                                    <strong>Date:</strong> {Moment(ORDER_INFO.T_orderdate).format('DD-MM-YYYY')} <br />

                                                                                    {Moment(ORDER_INFO.T_orderdate).format('hh:mm A')}
                                                                                </p>
                                                                            </td>
                                                                        </tr>
                                                                    </td>
                                                                </tr>
                                                                <tr className="border_btm">
                                                                    <td className="td_first">
                                                                        <p class="mg-b-0">
                                                                            <strong>Mode of Payment:</strong> <br />{ORDER_INFO.T_paymode}
                                                                        </p>
                                                                    </td>
                                                                    <td className="td_second text-left">
                                                                        <p class="mg-b-0">
                                                                            <strong>Name:</strong> <br /> {usrInfo.f_fullname}
                                                                        </p>
                                                                    </td>
                                                                </tr>
                                                                <tr className="border_btm">
                                                                    <td className="td_first">
                                                                        <p class="mg-b-0">
                                                                            <Form.Group className="mb-0" >
                                                                                <Form.Label><strong>Company Name: </strong></Form.Label>
                                                                                <Form.Control type="text" onChange={onInputChange} name="f_companyname" value={usrInfo.f_companyname} />
                                                                            </Form.Group>
                                                                        </p>
                                                                    </td>
                                                                    <td className="td_second text-left vertical_middle">
                                                                        <p class="mg-b-0">
                                                                            <Form.Group className="mb-0" >
                                                                                <Form.Label><strong>Client:</strong></Form.Label>
                                                                                <Form.Control type="text" value={ORDER_INFO.t_client} />
                                                                            </Form.Group>
                                                                        </p>
                                                                    </td>
                                                                </tr>
                                                                <tr className="border_btm">
                                                                    <td className="td_first text-left">
                                                                        <p class="mg-b-0">
                                                                            <strong>Telephone:</strong> {usrInfo.CS_phone}
                                                                        </p>
                                                                    </td>
                                                                    <td className="td_second text-left">
                                                                        <p class="mg-b-0">
                                                                            <strong>Mobile:</strong> {usrInfo.f_mobileno}
                                                                        </p>
                                                                    </td>
                                                                </tr>
                                                                <tr className="border_btm">
                                                                    <td className="td_first text-left">
                                                                        <p class="mg-b-0">
                                                                            <strong>Agency:</strong> <br />Agent
                                                                        </p>
                                                                    </td>
                                                                    <td className="td_second text-left">
                                                                        <p class="mg-b-0">
                                                                            <strong>Email:</strong> <br />{usrInfo.f_email}
                                                                        </p>
                                                                    </td>
                                                                </tr>
                                                                <tr className="border_btm">
                                                                    <td className="td_first">
                                                                        <p class="mg-b-0">
                                                                            <Form.Group className="mb-0" >
                                                                                <Form.Label><strong>Address:</strong></Form.Label>
                                                                                <Form.Control type="text" as="textarea" onChange={onInputChange} name="CS_address" value={usrInfo.CS_address} />
                                                                            </Form.Group>
                                                                        </p>
                                                                    </td>
                                                                    <td className="td_second text-left">
                                                                        <p class="mg-b-0">
                                                                            <Form.Group className="mb-0" >
                                                                                <Form.Label><strong>Paid By:<br />Subscription Converted By:</strong></Form.Label>
                                                                                <Form.Control type="text" placeholder="admin" value="admin" />
                                                                            </Form.Group>
                                                                        </p>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </RB.Table>
                                                    </RB.Col>
                                                </div>

                                                <div className="headinv" id="invoicem" style={{ borderBottom: "0px" }}>
                                                    <RB.Col lg={12} className="pd_0 table_leftord">
                                                        <RB.Table responsive className="top_modaltable">
                                                            <thead>
                                                                {ORDER_INFO.f_orderType === "Plan" ? <tr>
                                                                    <th className="td_first text-center">Image</th>
                                                                    <th className="td_first text-center">Plan Name</th>
                                                                    <th className="td_first text-center">No of Videos</th>
                                                                    <th className="td_first text-center">Validity of Package</th>
                                                                    {/* <th className="td_first text-center">Dimensions (Px)</th> */}
                                                                    <th className="text-right">Amount (Rs.)</th>
                                                                </tr> : <tr>
                                                                    <th className="td_first text-center">Image</th>
                                                                    <th className="td_first text-center">Item ID</th>
                                                                    <th className="td_first text-center">Image Type</th>
                                                                    <th className="td_first text-center">Rights</th>
                                                                    <th className="td_first text-center">Dimensions (Px)</th>
                                                                    <th className="text-right">Amount (Rs.)</th>
                                                                </tr>}

                                                            </thead>
                                                            <tbody className="order_modaltable">
                                                                {listOrderDetails}
                                                                {/*                                                                 
                                                                {ORDER_LIST.map((info, inx) => {
                                                                       })}                                                            */}
                                                            </tbody>
                                                        </RB.Table>
                                                        <RB.Table responsive>
                                                            <tbody className="amount_modalt">
                                                                <tr className="border_btm">
                                                                    <td className="text-right td_first" colSpan="">
                                                                        <p className="mg-b-0 resblock">
                                                                            <strong>Total Value (INR)</strong>
                                                                        </p>
                                                                    </td>
                                                                    <td className="text-right">
                                                                        <p class="mg-b-0"><strong>{total}</strong></p>
                                                                    </td>
                                                                </tr>
                                                                {/* {
                                                                    usrInfo.f_state === "Delhi" ?
                                                                        <>

                                                                            {less !== 0 ? <tr className="border_btm">
                                                                                <td className="text-right td_first" colSpan="" >
                                                                                    <p className="mg-b-0 resblock">
                                                                                        <strong>Less  (INR) :</strong>
                                                                                    </p>
                                                                                </td>
                                                                                <td className="text-right">
                                                                                    <p class="mg-b-0"><strong>{less}</strong></p>
                                                                                </td>
                                                                            </tr> : ""}

                                                                            {Discount !== 0 ? <tr className="border_btm">
                                                                                <td className="text-right td_first" colSpan="" >
                                                                                    <p className="mg-b-0 resblock">
                                                                                        <strong>Discount  (INR) :</strong>
                                                                                    </p>
                                                                                </td>
                                                                                <td className="text-right">
                                                                                    <p class="mg-b-0"><strong>{Discount}</strong></p>
                                                                                </td>
                                                                            </tr> : ""}


                                                                            <tr>
                                                                                <td className="text-right td_first" colSpan="">
                                                                                    <p className="mg-b-0 resblock">
                                                                                        <strong>IGST 9% :</strong>
                                                                                    </p>
                                                                                </td>
                                                                                <td className="text-right">
                                                                                    <p class="mg-b-0"><strong>{tax / 2}</strong></p>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td className="text-right td_first" colSpan="">
                                                                                    <p className="mg-b-0 resblock">
                                                                                        <strong>IGST 9% :</strong>
                                                                                    </p>
                                                                                </td>
                                                                                <td className="text-right">
                                                                                    <p class="mg-b-0"><strong>{tax / 2}</strong></p>
                                                                                </td>
                                                                            </tr>
                                                                        </>
                                                                        :
                                                                        <> */}
                                                                {less !== 0 ? <tr className="border_btm">
                                                                    <td className="text-right td_first" colSpan="" >
                                                                        <p className="mg-b-0 resblock">
                                                                            <strong>Less @  (INR) :</strong>
                                                                        </p>
                                                                    </td>
                                                                    <td className="text-right">
                                                                        <p class="mg-b-0"><strong>{less}</strong></p>
                                                                    </td>
                                                                </tr> : ""}
                                                                {Discount !== 0 ? <tr className="border_btm">
                                                                    <td className="text-right td_first" colSpan="" >
                                                                        <p className="mg-b-0 resblock">
                                                                            <strong>Discount  (INR) :</strong>
                                                                        </p>
                                                                    </td>
                                                                    <td className="text-right">
                                                                        <p class="mg-b-0"><strong>{Discount}</strong></p>
                                                                    </td>
                                                                </tr> : ""}
                                                                <tr className="border_btm">
                                                                    <td className="text-right td_first" colSpan="" >
                                                                        <p className="mg-b-0 resblock">
                                                                            <strong>Service Tax @ 18% :</strong>
                                                                        </p>
                                                                    </td>
                                                                    <td className="text-right">
                                                                        <p class="mg-b-0"><strong>{tax}</strong></p>
                                                                    </td>
                                                                </tr>
                                                                {/* </> */}
                                                                {/* } */}


                                                                <tr className="border_btm" style={{ borderBottom: "0px solid #707070" }}>
                                                                    <td className="text-right td_first" colSpan="" >
                                                                        <p className="mg-b-0 resblock">
                                                                            <strong>Net Payable Amount  (INR)</strong>
                                                                        </p>
                                                                    </td>
                                                                    <td className="text-right">
                                                                        {/* <p class="mg-b-0"><strong>{(total + tax) - Discount || 0}</strong></p> */}
                                                                        <p class="mg-b-0"><strong>{total + tax + less}</strong></p>
                                                                    </td>
                                                                </tr>
                                                            </tbody>

                                                        </RB.Table>

                                                    </RB.Col>
                                                </div>
                                            </div>
                                        </RB.Container>
                                    </RB.Col>
                                    <RB.Col lg={6}>
                                        <RB.Container>
                                            <div className="main_orders right_half">
                                                <div className="headinv" id="invoicem" style={{ borderBottom: "0px" }}>
                                                    <RB.Col lg={12} className=" pd_0">
                                                        <RB.Table responsive>
                                                            <tbody className="right_table">
                                                                <tr className="border_btm">
                                                                    <td className="td_first">
                                                                        <p class="mg-b-0">
                                                                            <Form.Group as={Row} className="mb-0 mglr-0" >
                                                                                <Form.Label className="col-lg-3 col-md-4"><strong>State:</strong></Form.Label>
                                                                                <Form.Control className="col-lg-9 col-md-8" type="text" value={usrInfo.f_state} placeholder="State" />
                                                                            </Form.Group>
                                                                        </p>
                                                                    </td>
                                                                    <td className="td_second text-left">
                                                                        <p class="mg-b-0">
                                                                            <Form.Group as={Row} className="mb-0 mglr-0" >
                                                                                <RB.Form.Control as="select" name="f_state" onChange={onInputChange}>
                                                                                    <option>{usrInfo.f_state}</option>
                                                                                    {state.map((data, inx) => <option value={data.name} key={`ORDER_DTL${inx}`}>{data.name}</option>)}
                                                                                </RB.Form.Control>
                                                                            </Form.Group>
                                                                        </p>
                                                                    </td>
                                                                </tr>
                                                                <tr className="border_btm">
                                                                    <td className="td_first">
                                                                        <p class="mg-b-0">
                                                                            <Form.Group className="mb-0" >
                                                                                <Form.Label><strong>Search Company: </strong></Form.Label>
                                                                                <Form.Control type="text" autoComplete="off" value={company} onChange={(e) => onInputChangeCompany(e)} />
                                                                                {isTrue === true ? <div class="auto_searchdata">
                                                                                    {CompanyInfo.slice(0, 20).map((data, inx) => {
                                                                                        return (
                                                                                            <p style={{ cursor: "pointer" }} onClick={(e) => onCompanySelect(data._id)} >{data.f_companyname}</p>
                                                                                        );
                                                                                    })}
                                                                                </div> : ""}
                                                                            </Form.Group>
                                                                        </p>
                                                                    </td>
                                                                    <td className="td_second text-left vertical_middle">
                                                                        <p class="mg-b-0">
                                                                            <Form.Group as={Row} className="mb-0 mglr-0" >
                                                                                <Form.Label className="col-lg-12 col-md-12 col-12"><strong>Find Information By Email:</strong></Form.Label>
                                                                                <Form.Check className="col-lg-12 col-md-12 col-12" type="checkbox" />
                                                                            </Form.Group>
                                                                        </p>
                                                                    </td>
                                                                </tr>
                                                                <tr className="border_btm">
                                                                    <td className="td_first text-left vertical_middle">
                                                                        <p class="mg-b-0">
                                                                            <strong>Company Group</strong>
                                                                        </p>
                                                                    </td>
                                                                    <td className="td_second text-left">
                                                                        <p class="mg-b-0">
                                                                            <Form.Group as={Row} className="mb-0 mglr-0" >
                                                                                <Form.Control className="col-lg-12 col-md-12" type="text" />
                                                                            </Form.Group>
                                                                        </p>
                                                                    </td>
                                                                </tr>
                                                                <tr className="border_btm">
                                                                    <td className="td_first vertical_middle">
                                                                        <p class="mg-b-0">
                                                                            <Form.Group as={Row} className="mb-0 mglr-0" >
                                                                                <Form.Label className="col-lg-8 col-md-8"><strong>Invoice Discount</strong></Form.Label>
                                                                                <Form.Control className="col-lg-3 col-md-3"
                                                                                    type="text"
                                                                                    name="cs_discount"
                                                                                    value={USER_INFO.cs_discount}
                                                                                    onChange={DiscountHandler}
                                                                                />
                                                                                <span className="after_formt">%</span>
                                                                            </Form.Group>
                                                                        </p>
                                                                    </td>
                                                                    <td className="td_second text-left vertical_middle">
                                                                        <p class="mg-b-0">
                                                                            <Form.Group as={Row} className="mb-0 mglr-0 radio_btnc"  >
                                                                                <Form.Check inline label="All orders" name="group21" type="radio" />
                                                                                <Form.Check inline label="Only this order" type="radio" name="group21" checked />
                                                                            </Form.Group>
                                                                        </p>
                                                                    </td>
                                                                </tr>
                                                                <tr className="border_btm">
                                                                    <td className="td_first text-left vertical_middle">
                                                                        <p class="mg-b-0">
                                                                            <strong>Discount Type</strong>
                                                                        </p>
                                                                    </td>
                                                                    <td className="td_second text-left">
                                                                        <p class="mg-b-0">
                                                                            <Form.Group as={Row} className="mb-0 mglr-0" >
                                                                                <RB.Form.Control as="select">
                                                                                    <option value="Select Discount Type">Select Discount Type</option>
                                                                                    <option value="Commision">Commision</option>
                                                                                    <option value="Corporate Deal">Corporate Deal</option>
                                                                                    <option value="NO Discount">NO Discount</option>
                                                                                    <option value="Performa">Performa</option>
                                                                                    <option value="Publication Pckg">Publication Pckg</option>
                                                                                    <option value="Publicis Group Discount">Publicis Group Discount</option>
                                                                                    <option value="UpFront">UpFront</option>
                                                                                    <option value="WPP Discount">WPP Discount</option>
                                                                                </RB.Form.Control>
                                                                            </Form.Group>
                                                                        </p>
                                                                    </td>
                                                                </tr>
                                                                <tr className="border_btm">
                                                                    <td className="td_first text-left vertical_middle">
                                                                        <p class="mg-b-0">
                                                                            <strong>User Type</strong>
                                                                        </p>
                                                                    </td>
                                                                    <td className="td_second text-left">
                                                                        <p class="mg-b-0">
                                                                            <Form.Group as={Row} className="mb-0 mglr-0 radio_btnc"  >
                                                                                <Form.Check inline label="New" name="group3" type="radio" />
                                                                                <Form.Check inline label="Existing" type="radio" checked name="group3" />
                                                                            </Form.Group>
                                                                        </p>
                                                                    </td>
                                                                </tr>
                                                                <tr className="border_btm">
                                                                    <td className="td_first text-left vertical_middle">
                                                                        <p class="mg-b-0">
                                                                            <strong>Credit Period</strong>
                                                                        </p>
                                                                    </td>
                                                                    <td className="td_second text-left">
                                                                        <p class="mg-b-0">
                                                                            <Form.Group as={Row} className="mb-0 mglr-0" >
                                                                                <RB.Form.Control as="select">
                                                                                    <option value="Select Credit Period">Select Credit Period</option>
                                                                                    <option value="0">0 day</option>
                                                                                    <option value="15">15 days</option>
                                                                                    <option value="30">30 days</option>
                                                                                    <option value="45">45 days</option>
                                                                                    <option value="60">60 days</option>
                                                                                    <option value="7">7 days</option>
                                                                                    <option value="90">90 days</option>
                                                                                </RB.Form.Control>
                                                                            </Form.Group>
                                                                        </p>
                                                                    </td>
                                                                </tr>
                                                                <tr className="border_btm">
                                                                    <td className="td_first text-left vertical_middle">
                                                                        <p class="mg-b-0">
                                                                            <strong>Approval Mode</strong>
                                                                        </p>
                                                                    </td>
                                                                    <td className="td_second text-left">
                                                                        <p class="mg-b-0">
                                                                            <Form.Group as={Row} className="mb-0 mglr-0" >
                                                                                <RB.Form.Control as="select">
                                                                                    <option selected="selected" value="Select Approval Mode">Select Approval Mode</option>
                                                                                    <option value="Cheque copy/deposit slip">Cheque copy/deposit slip</option>
                                                                                    <option value="PO">PO</option>
                                                                                    <option value="Quotation approval">Quotation approval</option>
                                                                                    <option value="Mail approval">Mail approval</option>
                                                                                    <option value="PDC">PDC</option>
                                                                                    <option value="Upfront">Upfront</option>
                                                                                    <option value="NEFT/SWIFT">NEFT/SWIFT</option>
                                                                                </RB.Form.Control>
                                                                            </Form.Group>
                                                                        </p>
                                                                    </td>
                                                                </tr>
                                                                <tr className="border_btm">
                                                                    <td className="td_first text-left vertical_middle">
                                                                        <p class="mg-b-0">
                                                                            <strong>Special Comments</strong>
                                                                        </p>
                                                                    </td>
                                                                    <td className="td_second text-left">
                                                                        <p class="mg-b-0">
                                                                            <Form.Group as={Row} className="mb-0 mglr-0" >
                                                                                <Form.Control type="text" onChange={onInputChange1} name="t_comment" as="textarea" value={ordInfo.t_comment} />
                                                                            </Form.Group>
                                                                        </p>
                                                                    </td>
                                                                </tr>
                                                                <tr className="border_btm">
                                                                    <td className="td_first text-left vertical_middle">
                                                                        <p class="mg-b-0">
                                                                            <strong>Order By</strong>
                                                                        </p>
                                                                    </td>
                                                                    <td className="td_second text-left">
                                                                        <p class="mg-b-0">
                                                                            <Form.Group as={Row} className="mb-0 mglr-0" >
                                                                                <Form.Control className="col-lg-12 col-md-12" type="text" value={usrInfo.f_fullname} />
                                                                            </Form.Group>
                                                                        </p>
                                                                    </td>
                                                                </tr>
                                                                <tr className="border_btm">
                                                                    <td className="td_first text-left vertical_middle">
                                                                        <p class="mg-b-0">
                                                                            <strong>Additional Email</strong>
                                                                        </p>
                                                                    </td>
                                                                    <td className="td_second text-left">
                                                                        <p class="mg-b-0">
                                                                            <Form.Group as={Row} className="mb-0 mglr-0" >
                                                                                <Form.Control className="col-lg-12 col-md-12" type="text" />
                                                                            </Form.Group>
                                                                        </p>
                                                                    </td>
                                                                </tr>
                                                                <tr className="border_btm">
                                                                    <td className="td_first text-left vertical_middle">
                                                                        <p class="mg-b-0">
                                                                            <strong>Closed by</strong>
                                                                        </p>
                                                                    </td>
                                                                    <td className="td_second text-left">
                                                                        <p class="mg-b-0">
                                                                            <Form.Group as={Row} className="mb-0 mglr-0"  >
                                                                                <RB.Form.Control as="select">
                                                                                    <option selected="selected" value="CS">CS</option>
                                                                                    <option value="Sales">Sales</option>
                                                                                    <option value="Exclude">Exclude</option>
                                                                                    <option value="Special package">Special package</option>
                                                                                    <option value="Renew">Renew</option>
                                                                                    <option value="Sales-Renew">Sales-Renew</option>
                                                                                    <option value="Legal">Legal</option>
                                                                                </RB.Form.Control>
                                                                            </Form.Group>
                                                                        </p>
                                                                    </td>
                                                                </tr>
                                                                <tr className="border_btm">
                                                                    <td className="td_first text-left vertical_middle">
                                                                        <p class="mg-b-0">
                                                                            <strong>Status</strong>
                                                                        </p>
                                                                    </td>
                                                                    <td className="td_second text-left">
                                                                        <p class="mg-b-0">
                                                                            <Form.Group as={Row} className="mb-0 mglr-0" >
                                                                                <RB.Form.Control as="select">
                                                                                    <option>Confirmed</option>
                                                                                </RB.Form.Control>
                                                                            </Form.Group>
                                                                        </p>
                                                                    </td>
                                                                </tr>
                                                                <tr className="border_btm">
                                                                    <td className="td_first text-left vertical_middle">
                                                                        <p class="mg-b-0">
                                                                            <strong>Payment Date</strong>
                                                                        </p>
                                                                    </td>
                                                                    <td className="td_second text-left">
                                                                        <p class="mg-b-0">
                                                                            {/* <Form.Group as={Row} className="mb-0 mglr-0" >
                                                                                <Form.Control className="col-lg-12 col-md-12" type="date"   />
                                                                            </Form.Group>
                                                                             */}
                                                                            <DatePicker className="startdate"
                                                                                placeholderText="Start Date"
                                                                                selected={startDate}
                                                                                onChange={(date) => setStartDate(date)}
                                                                                dateFormat="dd-MM-yyyy"
                                                                            />
                                                                        </p>
                                                                    </td>
                                                                </tr>
                                                                <tr className="border_btm">
                                                                    <td className="td_first text-left vertical_middle">
                                                                        <p class="mg-b-0">
                                                                            <strong>Purchase Order	</strong>
                                                                        </p>
                                                                    </td>
                                                                    <td className="td_second text-left">
                                                                        <p class="mg-b-0">
                                                                            <Form.Group as={Row} className="mb-0 mglr-0">
                                                                                <Form.Control className="col-lg-12 col-md-12" type="text" placeholder="" />
                                                                            </Form.Group>
                                                                        </p>
                                                                    </td>
                                                                </tr>
                                                                <tr className="border_btm">
                                                                    <td className="td_first text-left vertical_middle">
                                                                        <p class="mg-b-0">
                                                                            <strong>Comments</strong>
                                                                        </p>
                                                                    </td>
                                                                    <td className="td_second text-left">
                                                                        <p class="mg-b-0">
                                                                            <Form.Group as={Row} className="mb-0 mglr-0" >
                                                                                <Form.Control type="text" as="textarea" onChange={onInputChange1} name="t_comment" value={ordInfo.t_comment} />
                                                                            </Form.Group>
                                                                        </p>
                                                                    </td>
                                                                </tr>
                                                                <tr className="border_btm">
                                                                    <td className="td_first text-left vertical_middle">
                                                                        <p class="mg-b-0">
                                                                            <strong>DownLoad Link</strong>
                                                                        </p>
                                                                    </td>
                                                                    <td className="td_second text-left">
                                                                        <p class="mg-b-0">
                                                                            <Form.Group as={Row} className="mb-0 mglr-0" >
                                                                                <Form.Control className="col-lg-12 col-md-12" type="text" />
                                                                            </Form.Group>
                                                                        </p>
                                                                    </td>
                                                                </tr>
                                                                {ORDER_INFO.T_status === "P" ?
                                                                    <tr className="border_btm" style={{ borderBottom: "0px" }}>
                                                                        <td colspan="2">
                                                                            <p className="mg-b-0 resblock">
                                                                                <RB.Button size="sm" variant="primary" className="btn_svg   mr-2" onClick={onSubmit}>
                                                                                    Order Confirm
                                                                                </RB.Button>
                                                                                <RB.Button size="sm" variant="primary" className="btn_svg btn-backconf">
                                                                                    <Link to="/dashboard/order/get">
                                                                                        <IoIosArrowBack />Back
                                                                                    </Link>
                                                                                </RB.Button>
                                                                            </p>
                                                                        </td>
                                                                    </tr> :
                                                                    <tr className="border_btm" style={{ borderBottom: "0px" }}>
                                                                        <td colspan="2">
                                                                            <p className="mg-b-0 resblock"></p>
                                                                            <RB.Button size="sm" variant="primary" className="btn_svg btn-backconf">
                                                                                <Link to="/dashboard/order/get">
                                                                                    <IoIosArrowBack />Back
                                                                                </Link>
                                                                            </RB.Button>
                                                                        </td>
                                                                    </tr>

                                                                }

                                                            </tbody>
                                                        </RB.Table>
                                                    </RB.Col>
                                                </div>

                                            </div>
                                        </RB.Container>
                                    </RB.Col>
                                </RB.Row>
                            </form>
                        </RB.Col>
                    </RB.Row>
                </div>
            </RB.Col>

            <Modal text={ModelMsg} open={isOpen} onClose={() => setIsOpen(false)} />

        </RB.Row>
    )
}

export default OrderDetail