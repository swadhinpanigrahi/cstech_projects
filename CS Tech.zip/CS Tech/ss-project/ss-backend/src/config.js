const dotenv = require("dotenv")
dotenv.config();

exports.PORT = process.env.PORT;
// exports.DB_URL = process.env.DB_URL || "mongodb+srv://user:T3inqbvLU9rZG6uE@bolesa.c8k7x.mongodb.net/bolesa?retryWrites=true&w=majority";
exports.DB_URL = process.env.DB_URL || "mongodb://localhost:27017/storagestation";
exports.ENV = process.env.ENVIRONMENT;
exports.JWT_TOKEN = process.env.JWT_TOKEN || "TOKEN_SECRET_ACC_KEY";
exports.SMTP_HOST = process.env.SMTP_HOST || "smtp.sparkpostmail.com";
exports.SMTP_EMAIL = process.env.SMTP_EMAIL || "Salem@bolesa.net";
exports.SMTP_PASSWORD = process.env.SMTP_PASSWORD || "fc9bb365f46c6dc67bbc0e88f241a0e0aa8cf44a";

exports.BASE_URL = () => (ENV === "production" ? productionUrl : localUrl);
