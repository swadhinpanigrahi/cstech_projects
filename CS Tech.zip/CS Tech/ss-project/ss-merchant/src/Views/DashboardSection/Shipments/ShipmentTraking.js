import React, { useState, useEffect } from 'react'
import { useParams } from 'react-router-dom'
import { trakin_details, getShipmentDetailsForView, change_shipstatus } from "../../../Utils/api";
import { useTranslation } from "react-i18next";

// let ARAMEX_COD_DELIVERED_STATUS_COSE = "SH005" || "NTC07" || "COMPLETED"

const ShipmentTraking = () => {
    const { t } = useTranslation();
    const { tracking_number } = useParams();

    const [PageData, setPageData] = useState({
        trakingObject: {},
        trakingArray: []
    });

    let { trakingObject, trakingArray } = PageData;

    // const changeStatus = async (statuses) => {
    //     let filterData = statuses.filter((data) => data.code === "SH005")
    //     if (filterData.length > 0) {
    //         const res = await change_shipstatus(tracking_number);
    //         console.log(res)
    //     } else {
    //         console.log("failed")
    //     }
    // }

    useEffect(() => {
        const apiCall = async () => {
            const res = await getShipmentDetailsForView(tracking_number)
            const res1 = await trakin_details(tracking_number)
            let { statuses } = res1
            let { trakingData, error } = res
            if (!error) {
                const updateData = { ...PageData }
                updateData.trakingObject = trakingData;
                if (statuses !== undefined) {
                    updateData.trakingArray = statuses;
                    setPageData({ ...updateData });
                } else {
                    updateData.trakingArray = [];
                    setPageData({ ...updateData });
                }
                // changeStatus(statuses)
            } else {
                window.alert("network error!")
            }
        }
        apiCall();
    }, [])

    return (
        <>
            <div className="container-fluid">
                <div className="col-12">
                    <div
                        className="page-header row no-gutters pym-4"
                        style={{ paddingBottom: ".5rem!important" }}
                    >
                        <div className="col-md-6">
                            <h3 className="page-title">{t("change.t_shipment_sub1")}</h3>
                        </div>
                        <div className="col-md-6 text-right backb">
                        </div>
                        <hr />
                    </div>
                </div>
                <div className="col-md-12">
                    <div
                        className="box_detail tableboxdc"
                        style={{
                            paddingTop: "0px",
                            paddingBottom: "0px",
                            marginBottom: "0px",
                            borderRadius: "13px",
                        }}
                    >
                        <table
                            className="table table-bordered table-responsive"
                            id="table-to-xls"
                        >
                            <thead className="thead-dark">
                                <tr>
                                    <th className="nhead ohead text-center">{t("change.date")}</th>
                                    <th className="ohead"> {t("change.order_id")} </th>
                                    <th className="nhead"> {t("change.o_no")} </th>
                                    <th className="deshead">{t("change.status")}</th>
                                    <th className="deshead nhead "> {t("change.t_sname")} </th>
                                    <th className="nhead text-center"> {t("change.s_trakingnum")} </th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td className="nhead ohead text-center">{trakingObject.createdAt}</td>
                                    <td className="ohead"> {trakingObject.order_id} </td>
                                    <td className="nhead"> {trakingObject.order_number} </td>
                                    <td className="deshead">{trakingObject.fulfillment_status}</td>
                                    <td className="deshead nhead "> {trakingObject.shop_name}</td>
                                    <td className="nhead text-center">
                                        {trakingObject.tracking_number}
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div className="container-fluid">
                <div className="col-12">
                    <div
                        className="page-header row no-gutters pym-4"
                        style={{ paddingBottom: ".5rem!important" }}
                    >
                        <div className="col-md-6">
                            <h3 className="page-title">
                                {t("change.t_shipment_sub2")}
                            </h3>
                        </div>
                        <div className="col-md-6 text-right backb">
                            {/* <ReactToExcel
                  table="table-to-xls"
                  filename="excelFile"
                  sheet="sheet 1"
                  className="addbce"
                  buttonText="EXPORT"
                /> */}
                        </div>
                        <hr />
                    </div>
                </div>
                <div className="col-md-12">
                    <div
                        className="box_detail tableboxdc"
                        style={{
                            paddingTop: "0px",
                            paddingBottom: "0px",
                            marginBottom: "0px",
                            borderRadius: "13px",
                        }}
                    >
                        <table
                            className="table table-bordered table-responsive"
                            id="table-to-xls"
                        >
                            <thead className="thead-dark">
                                <tr>
                                    <th className="ohead"> {t("change.t_waybill")} </th>
                                    <th className="nhead"> {t("change.t_code")} </th>
                                    <th className="deshead">{t("change.t_description")}</th>
                                    <th className="deshead nhead "> {t("change.t_time")} </th>
                                    <th className="nhead ohead">{t("change.t_location")}</th>
                                    <th className="nhead"> {t("change.t_comment")} </th>
                                </tr>
                            </thead>
                            <tbody>
                                {trakingArray.map((val, inx) => {
                                    return (
                                        <tr key={inx + "taking_id"}>
                                            <td>{val.waybill}</td>
                                            <td>{val.code}</td>
                                            <td>{val.description}</td>
                                            <td>{val.time}</td>
                                            <td>{val.location}</td>
                                            <td>{val.comment}</td>
                                        </tr>
                                    );
                                })}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </>
    )
}

export default ShipmentTraking