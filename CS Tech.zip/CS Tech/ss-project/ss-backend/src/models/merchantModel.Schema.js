// import Mongoose from "mongoose"
const Mongoose = require("mongoose")

const merchantModelSchema = new Mongoose.Schema(
  {
    name: { type: String },
    email: {
      type: String,
      trim: true,
      lowercase: true,
      unique: true,
    },
    phone: { type: String, unique: true, },
    activate: { type: String, default: "active" },
    password: { type: String },
    companyName: { type: String },
    address: { type: String },
    pincode: { type: String },
    city: { type: String },
    state: { type: String },
    country: { type: String },
    isUpdate: { type: Boolean, default: false },
    beneficiary_name: { type: String, default: "" },
    bank_name: { type: String, default: "", uppercase: true },
    account_number: { type: String, default: "" },
    ifsc_code: { type: String, default: "", uppercase: true },
    bank_branch: { type: String, default: "" },
  },
  { timestamps: true },
  { collection: "customerdetails_tbls" }
);

module.exports = merchantModelSchema;