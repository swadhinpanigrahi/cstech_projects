import React, { useState } from 'react';
import * as RB from "react-bootstrap";
import { Row } from "react-bootstrap";
import { ADD_IMAGEVEDIODETAIL } from "../../../Utils/api"

const AddImageVedioSubscriptionPlan = ({
    show_addimagevediosubscription, setShow, apiCall, setModelMsg, modelSet
}) => {
    const [FormData, setFormData] = useState({});
    const [ErrorMsg, setErrorMsg] = useState("")

    const closeModel = () => {
        setFormData({});
        setErrorMsg("")
        setShow(false)
    }

    const handleChange = (e) => {
        setErrorMsg("")
        let { name, value } = e.target;
        const data = { ...FormData };
        data[name] = value;
        setFormData(data)
    }

    const AddImageAndVedioSubScription = async () => {
        let {
            f_planname, f_maxallowed, f_periodindays, f_amount, f_totimg,
            f_imageType, f_save, f_upgradamt, f_couponAmt, f_desc, f_status
        } = FormData
        if (
            !f_planname || !f_maxallowed || !f_periodindays || !f_amount || !f_totimg ||
            !f_imageType || !f_save || !f_upgradamt || !f_couponAmt || !f_desc || !f_status
        ) {
            setErrorMsg("please fill requirment text-boxes!")
        } else {
            const res = await ADD_IMAGEVEDIODETAIL(FormData);
            let { status, message } = res
            if (status === 200) {
                apiCall();
                setFormData({});
                setErrorMsg("")
                setShow(false);
                setModelMsg(message);
                modelSet()
            } else {
                setErrorMsg(message)
            }
        }
    }

    return (
        <div>
            <RB.Modal show={show_addimagevediosubscription} onHide={closeModel} className="ordermanage_modal">
                <RB.Modal.Header closeButton>
                    <RB.Modal.Title>Add Image And Vedio Sunscription</RB.Modal.Title>
                </RB.Modal.Header>
                <RB.Modal.Body>
                    <RB.Row>
                        <RB.Col lg={12} md={12}>
                            <RB.Row>
                                <RB.Col lg={12} md={12}>
                                    {ErrorMsg !== "" ? ErrorMsg : ""}
                                    <RB.Form>
                                        <RB.Form.Group as={Row} controlId="image_pricet">
                                            <RB.Col lg={5} md={5}>
                                                <RB.Form.Label>Subscription Plan Name :</RB.Form.Label>
                                            </RB.Col>
                                            <RB.Col lg={7} md={7}>
                                                <RB.Form.Control
                                                    type="text"
                                                    name="f_planname"
                                                    onChange={handleChange}
                                                />
                                            </RB.Col>
                                        </RB.Form.Group>
                                        <RB.Form.Group as={Row} controlId="image_pricet">
                                            <RB.Col lg={5} md={5}>
                                                <RB.Form.Label>Max Allowed :</RB.Form.Label>
                                            </RB.Col>
                                            <RB.Col lg={7} md={7}>
                                                <RB.Form.Control
                                                    type="number"
                                                    name="f_maxallowed"
                                                    onChange={handleChange}
                                                />
                                            </RB.Col>
                                        </RB.Form.Group>
                                        <RB.Form.Group as={Row} controlId="image_pricet">
                                            <RB.Col lg={5} md={5}>
                                                <RB.Form.Label>Period in Days :</RB.Form.Label>
                                            </RB.Col>
                                            <RB.Col lg={7} md={7}>
                                                <RB.Form.Control
                                                    type="number"
                                                    name="f_periodindays"
                                                    onChange={handleChange}
                                                />
                                            </RB.Col>
                                        </RB.Form.Group>
                                        <RB.Form.Group as={Row} controlId="image_pricet">
                                            <RB.Col lg={5} md={5}>
                                                <RB.Form.Label>Amount :</RB.Form.Label>
                                            </RB.Col>
                                            <RB.Col lg={7} md={7}>
                                                <RB.Form.Control
                                                    type="number"
                                                    name="f_amount"
                                                    onChange={handleChange}
                                                />
                                            </RB.Col>
                                        </RB.Form.Group>
                                        <RB.Form.Group as={Row} controlId="image_pricet">
                                            <RB.Col lg={5} md={5}>
                                                <RB.Form.Label>Total No.Images :</RB.Form.Label>
                                            </RB.Col>
                                            <RB.Col lg={7} md={7}>
                                                <RB.Form.Control
                                                    type="number"
                                                    name="f_totimg"
                                                    onChange={handleChange}
                                                />
                                            </RB.Col>
                                        </RB.Form.Group>
                                        <RB.Form.Group as={Row} controlId="image_pricet">
                                            <RB.Col lg={5} md={5}>
                                                <RB.Form.Label>Image Type :</RB.Form.Label>
                                            </RB.Col>
                                            <RB.Col lg={7} md={7}>
                                                <select className="select_customerd" name="f_imageType" onChange={handleChange}>
                                                    <option value="1">One</option>
                                                    <option value="2">Two</option>
                                                    <option value="3">Three</option>
                                                </select>
                                            </RB.Col>
                                        </RB.Form.Group>
                                        <RB.Form.Group as={Row} controlId="image_pricet">
                                            <RB.Col lg={5} md={5}>
                                                <RB.Form.Label>Savings :</RB.Form.Label>
                                            </RB.Col>
                                            <RB.Col lg={7} md={7}>
                                                <RB.Form.Control
                                                    type="text"
                                                    name="f_save"
                                                    onChange={handleChange}
                                                />
                                            </RB.Col>
                                        </RB.Form.Group>
                                        <RB.Form.Group as={Row} controlId="image_pricet">
                                            <RB.Col lg={5} md={5}>
                                                <RB.Form.Label>Upgrade Worth :</RB.Form.Label>
                                            </RB.Col>
                                            <RB.Col lg={7} md={7}>
                                                <RB.Form.Control
                                                    type="number"
                                                    name="f_upgradamt"
                                                    onChange={handleChange}
                                                />
                                            </RB.Col>
                                        </RB.Form.Group>
                                        <RB.Form.Group as={Row} controlId="image_pricet">
                                            <RB.Col lg={5} md={5}>
                                                <RB.Form.Label>Coupon Amount :</RB.Form.Label>
                                            </RB.Col>
                                            <RB.Col lg={7} md={7}>
                                                <RB.Form.Control
                                                    type="number"
                                                    name="f_couponAmt"
                                                    onChange={handleChange}
                                                />
                                            </RB.Col>
                                        </RB.Form.Group>
                                        <RB.Form.Group as={Row} controlId="image_pricet">
                                            <RB.Col lg={5} md={5}>
                                                <RB.Form.Label>Description:</RB.Form.Label>
                                            </RB.Col>
                                            <RB.Col lg={7} md={7}>
                                                <RB.Form.Control
                                                    type="text"
                                                    name="f_desc"
                                                    onChange={handleChange}

                                                />
                                            </RB.Col>
                                        </RB.Form.Group>
                                        <RB.Form.Group as={Row} controlId="image_pricet">
                                            <RB.Col lg={5} md={5}>
                                                <RB.Form.Label>Status :</RB.Form.Label>
                                            </RB.Col>
                                            <RB.Col lg={7} md={7}>
                                                <RB.Form.Check
                                                    name="f_status"
                                                    onChange={handleChange}
                                                />
                                            </RB.Col>
                                        </RB.Form.Group>
                                        <RB.Row>
                                            <RB.Col lg={5} md={5}></RB.Col>
                                            <RB.Col lg={7} md={7}>
                                                <RB.Button
                                                    size="sm" variant="primary"
                                                    onClick={AddImageAndVedioSubScription}
                                                >
                                                    ADD
                                                </RB.Button>
                                            </RB.Col>
                                        </RB.Row>
                                    </RB.Form>
                                </RB.Col>
                            </RB.Row>
                        </RB.Col>
                    </RB.Row>
                </RB.Modal.Body>
            </RB.Modal>
        </div>
    )
}

export default AddImageVedioSubscriptionPlan
