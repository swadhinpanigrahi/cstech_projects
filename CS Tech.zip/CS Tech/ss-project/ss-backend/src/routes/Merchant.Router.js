const express = require("express")
const { createValidator } = require("express-joi-validation")

// Merchant.Controller
const {
    get15daysShipmentData,
    getShipmentDropSearch, getTrakingDetails, getTrakingDetailsView, getTrakingDetailsByButtonSearch, CODbuttonSearch,
    getPaymentSatelments, paymentDateFilter,
    totalCounts
} = require("../controllers/Merchant.Controller");

const validator = createValidator({ passError: true });
const merchantRouter = express.Router();

merchantRouter.route("/get15dayshipmentsrecords/:_id").get(get15daysShipmentData);

merchantRouter.route("/searchbardropdown/:_id").get(getShipmentDropSearch);
merchantRouter.route("/getshipment").get(getTrakingDetails);
merchantRouter.route('/trakingdetailsview/:tracking_number').get(getTrakingDetailsView);
merchantRouter.route('/trakingdetailsearchbybutton/:_id').post(getTrakingDetailsByButtonSearch);
merchantRouter.route('/trakingCODdetailsearchbybutton/:_id').post(CODbuttonSearch);

merchantRouter.route('/getpaymentsatelments/:_id').get(getPaymentSatelments);
merchantRouter.route('/getpaymentdetailsbydatefilter/:_id').post(paymentDateFilter);

merchantRouter.route('/getmerchantcounts/:_id').get(totalCounts);

module.exports = merchantRouter