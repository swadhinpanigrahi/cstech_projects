import React from "react";
import { useAuth } from "../../Utils/auth";
import Navigation from "../../Components/NavSection/Navigation";

const AuthButton = () => {
  let auth = useAuth();
  return auth.user ? <Navigation /> : "";
};

export default AuthButton;
