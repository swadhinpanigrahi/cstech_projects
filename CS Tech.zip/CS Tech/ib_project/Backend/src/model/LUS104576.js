const mongoose = require("mongoose");

const LUS104576Schema = mongoose.Schema({
    
})