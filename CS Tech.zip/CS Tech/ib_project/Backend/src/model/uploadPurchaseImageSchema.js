const mongoose = require("mongoose");

const purchaseSchema = mongoose.Schema(
  {
    OrderId: { type: String },
    PoName: { type: String } 
  },
  { collection: "t_Podata_Mongodb" }
);

module.exports = PurchaseImageSchema = mongoose.model(
  "t_Podata_Mongodb",
  purchaseSchema
);
