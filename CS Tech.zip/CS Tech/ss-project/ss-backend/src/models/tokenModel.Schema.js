// import  Mongoose  from "mongoose";
const Mongoose = require("mongoose")

const tokenModelSchema = new Mongoose.Schema(
  {
    token: { type: String, required: true },
    expireAt: { type: Date, default: Date.now(), index: { expires: "5m" } },
  },
  { timestamps: true },
  { collection: "tbl_forgetpass_jwt_tokens" }
);

module.exports = tokenModelSchema

