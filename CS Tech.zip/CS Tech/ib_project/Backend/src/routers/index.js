const apiRouter = require("express").Router();
const userRoute = require("./userRoute");
const profileDataRoute = require("./profileDataRoute");
const customerRoute = require("./customerRoute");
const orderRoute = require("./orderRoute");
const proposalRoute = require("./proposalRoute");
const followupRoute = require("./followupRoutes");
const invoiceRoute = require("./invoiceRoute")
const testRoute = require("../test");
const apiforSQL = require("./apiforsql.routes");
const apiforMongo = require("./apiformongo.routes");

const MasterRoute = require("./Master");
const ImageRoute = require("./ImageSection");
const KeywordRoute = require("./Keyword")

apiRouter.use("/admin", userRoute);
apiRouter.use("/admin", profileDataRoute);
apiRouter.use("/admin", customerRoute);
apiRouter.use("/admin", orderRoute);
apiRouter.use("/admin", proposalRoute);
apiRouter.use("/admin", followupRoute);
apiRouter.use("/admin", invoiceRoute);
apiRouter.use('/admin', apiforMongo);
apiRouter.use('/admin', apiforSQL);
apiRouter.use("/admin", MasterRoute);
apiRouter.use("/admin", ImageRoute);
apiRouter.use("/admin", KeywordRoute);

apiRouter.use("/test", testRoute);

module.exports = apiRouter;
