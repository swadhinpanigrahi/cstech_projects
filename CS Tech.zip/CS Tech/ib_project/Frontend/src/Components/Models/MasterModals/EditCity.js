import React, { useState, useEffect } from 'react';
import * as RB from "react-bootstrap";
import { Row } from "react-bootstrap";
import { UPDATE_CITYDETAIL } from "../../../Utils/api";

const EditCity = (
    { show_editcity, setShowEdit, StateData, CountryData, City, apiCall }
) => {
    const [FormData, setFormData] = useState({});

    const handleChange = (e) => {
        let { name, value } = e.target;
        const data = { ...FormData }
        data[name] = value
        setFormData(data)
    }

    const closeModal = () => {
        setShowEdit(false)
    }

    const onSubmit = async (e) => {
        e.preventDefault();
        const res = await UPDATE_CITYDETAIL(FormData);
        let { message } = res
        if (message) {
            apiCall()
            closeModal();
        }
    }

    useEffect(() => {
        let countryCode;
        let countryName;
        CountryData.forEach(element => {
            if (element.f_countryid === City.f_countryid) {
                countryCode = element.f_countryid
                countryName = element.f_country
            }
        })
        let stateCode;
        let stateName;
        StateData.forEach(element => {
            if (element.f_stateid === City.f_stateid) {
                stateCode = element.f_stateid
                stateName = element.f_state
            }
        })
        setFormData({ ...City, f_countryid: countryCode, f_country: countryName, f_stateid: stateCode, f_state: stateName });
    }, [City]);

    return (
        <div>
            <RB.Modal show={show_editcity} onHide={closeModal} className="ordermanage_modal">
                <RB.Modal.Header closeButton>
                    <RB.Modal.Title>Edit City</RB.Modal.Title>
                </RB.Modal.Header>
                <RB.Modal.Body>
                    <RB.Row>
                        <RB.Col lg={12} md={12}>
                            <RB.Row>
                                <RB.Col lg={12} md={12}>
                                    <RB.Form>
                                        <RB.Form.Group as={Row} controlId="Country_id">
                                            <RB.Col lg={4} md={4}>
                                                <RB.Form.Label>Select Country :</RB.Form.Label>
                                            </RB.Col>
                                            <RB.Col lg={7} md={8}>
                                                <select className="select_customerd" name="f_countryid" onChange={handleChange}
                                                    value={FormData.f_country}>
                                                    <option value="1">INDIA</option>
                                                </select>
                                            </RB.Col>
                                        </RB.Form.Group>
                                        <RB.Form.Group as={Row} controlId="Country_id">
                                            <RB.Col lg={4} md={4}>
                                                <RB.Form.Label>State Name :</RB.Form.Label>
                                            </RB.Col>
                                            <RB.Col lg={7} md={8}>
                                                <select className="select_customerd" name="f_stateid" onChange={handleChange}>
                                                    <option value={FormData.f_stateid}>{FormData.f_state}</option>
                                                    {StateData.map((info, inx) => {
                                                        return (
                                                            <option value={info.f_stateid} key={`STATE_DROPDOWN_IN_CITY${inx}`}>
                                                                {info.f_state}
                                                            </option>
                                                        )
                                                    })}
                                                </select>
                                            </RB.Col>
                                        </RB.Form.Group>
                                        <RB.Form.Group as={Row} controlId="Country_id">
                                            <RB.Col lg={4} md={4}>
                                                <RB.Form.Label>City Name :</RB.Form.Label>
                                            </RB.Col>
                                            <RB.Col lg={7} md={8}>
                                                <RB.Form.Control type="text" name="f_cityname" value={FormData.f_cityname} onChange={handleChange} />
                                            </RB.Col>
                                        </RB.Form.Group>
                                        <RB.Row>
                                            <RB.Col lg={4} md={4}></RB.Col>
                                            <RB.Col lg={6} md={7}>
                                                <RB.Button
                                                    size="sm" variant="primary"
                                                    onClick={onSubmit}
                                                >
                                                    SUBMIT
                                                </RB.Button>
                                            </RB.Col>
                                        </RB.Row>
                                    </RB.Form>
                                </RB.Col>
                            </RB.Row>
                        </RB.Col>
                    </RB.Row>
                </RB.Modal.Body>
            </RB.Modal>
        </div>
    )
}

export default EditCity