import React, { useState, useEffect } from 'react';
import * as RB from "react-bootstrap";
import { Row } from "react-bootstrap";

import { UPDATE_IMAGEVEDIODETAIL } from "../../../../Utils/api";

const EditImageVedioSubscriptionPlan = ({
    show_editimagevediosubscription, setEdit, useData, apiCall
}) => {
    const [FormData, setFormData] = useState({});

    const closeModel = () => {
        setEdit(false)
    }

    const handleChange = (e) => {
        let { name, value } = e.target;
        const data = { ...FormData };
        data[name] = value;
        setFormData(data)
    }

    const EditImageAndVedioSubScription = async () => {
        const res = await UPDATE_IMAGEVEDIODETAIL(FormData);
        apiCall()
        closeModel()
        console.log(FormData)
    }

    useEffect(() => {
        setFormData(useData)
    }, [useData])

    return (
        <div>
            <RB.Modal show={show_editimagevediosubscription} onHide={closeModel} className="ordermanage_modal">
                <RB.Modal.Header closeButton>
                    <RB.Modal.Title>Edit Image And Vedio Sunscription</RB.Modal.Title>
                </RB.Modal.Header>
                <RB.Modal.Body>
                    <RB.Row>
                        <RB.Col lg={12} md={12}>
                            <RB.Row>
                                <RB.Col lg={12} md={12}>
                                    <RB.Form>
                                        <RB.Form.Group as={Row} controlId="image_pricet">
                                            <RB.Col lg={5} md={5}>
                                                <RB.Form.Label>Subscription Plan Name :</RB.Form.Label>
                                            </RB.Col>
                                            <RB.Col lg={7} md={7}>
                                                <RB.Form.Control
                                                    type="text"
                                                    name="f_planname"
                                                    onChange={handleChange}
                                                    value={FormData.f_planname}
                                                />
                                            </RB.Col>
                                        </RB.Form.Group>
                                        <RB.Form.Group as={Row} controlId="image_pricet">
                                            <RB.Col lg={5} md={5}>
                                                <RB.Form.Label>Max Allowed :</RB.Form.Label>
                                            </RB.Col>
                                            <RB.Col lg={7} md={7}>
                                                <RB.Form.Control
                                                    type="number"
                                                    name="f_maxallowed"
                                                    onChange={handleChange}
                                                    value={FormData.f_maxallowed}
                                                />
                                            </RB.Col>
                                        </RB.Form.Group>
                                        <RB.Form.Group as={Row} controlId="image_pricet">
                                            <RB.Col lg={5} md={5}>
                                                <RB.Form.Label>Period in Days :</RB.Form.Label>
                                            </RB.Col>
                                            <RB.Col lg={7} md={7}>
                                                <RB.Form.Control
                                                    type="number"
                                                    name="f_periodindays"
                                                    onChange={handleChange}
                                                    value={FormData.f_periodindays}
                                                />
                                            </RB.Col>
                                        </RB.Form.Group>
                                        <RB.Form.Group as={Row} controlId="image_pricet">
                                            <RB.Col lg={5} md={5}>
                                                <RB.Form.Label>Amount :</RB.Form.Label>
                                            </RB.Col>
                                            <RB.Col lg={7} md={7}>
                                                <RB.Form.Control
                                                    type="number"
                                                    name="f_amount"
                                                    onChange={handleChange}
                                                    value={FormData.f_amount}
                                                />
                                            </RB.Col>
                                        </RB.Form.Group>
                                        <RB.Form.Group as={Row} controlId="image_pricet">
                                            <RB.Col lg={5} md={5}>
                                                <RB.Form.Label>Total No.Images :</RB.Form.Label>
                                            </RB.Col>
                                            <RB.Col lg={7} md={7}>
                                                <RB.Form.Control
                                                    type="number"
                                                    name="f_totimg"
                                                    onChange={handleChange}
                                                    value={FormData.f_totimg}
                                                />
                                            </RB.Col>
                                        </RB.Form.Group>
                                        <RB.Form.Group as={Row} controlId="image_pricet">
                                            <RB.Col lg={5} md={5}>
                                                <RB.Form.Label>Image Type :</RB.Form.Label>
                                            </RB.Col>
                                            <RB.Col lg={7} md={7}>
                                                <select className="select_customerd" name="f_imageType">
                                                    <option value={FormData.f_imageType}>{FormData.f_imageType}</option>
                                                    <option value="1">One</option>
                                                    <option value="2">Two</option>
                                                    <option value="3">Three</option>
                                                </select>
                                            </RB.Col>
                                        </RB.Form.Group>
                                        <RB.Form.Group as={Row} controlId="image_pricet">
                                            <RB.Col lg={5} md={5}>
                                                <RB.Form.Label>Savings :</RB.Form.Label>
                                            </RB.Col>
                                            <RB.Col lg={7} md={7}>
                                                <RB.Form.Control
                                                    type="text"
                                                    name="f_save"
                                                    onChange={handleChange}
                                                    value={FormData.f_save}
                                                />
                                            </RB.Col>
                                        </RB.Form.Group>
                                        <RB.Form.Group as={Row} controlId="image_pricet">
                                            <RB.Col lg={5} md={5}>
                                                <RB.Form.Label>Upgrade Worth :</RB.Form.Label>
                                            </RB.Col>
                                            <RB.Col lg={7} md={7}>
                                                <RB.Form.Control
                                                    type="number"
                                                    name="f_upgradamt"
                                                    onChange={handleChange}
                                                    value={FormData.f_upgradamt}
                                                />
                                            </RB.Col>
                                        </RB.Form.Group>
                                        <RB.Form.Group as={Row} controlId="image_pricet">
                                            <RB.Col lg={5} md={5}>
                                                <RB.Form.Label>Coupon Amount :</RB.Form.Label>
                                            </RB.Col>
                                            <RB.Col lg={7} md={7}>
                                                <RB.Form.Control
                                                    type="number"
                                                    name="f_couponAmt"
                                                    onChange={handleChange}
                                                    value={FormData.f_couponAmt}
                                                />
                                            </RB.Col>
                                        </RB.Form.Group>
                                        <RB.Form.Group as={Row} controlId="image_pricet">
                                            <RB.Col lg={5} md={5}>
                                                <RB.Form.Label>Description:</RB.Form.Label>
                                            </RB.Col>
                                            <RB.Col lg={7} md={7}>
                                                <RB.Form.Control
                                                    type="text"
                                                    name="f_desc"
                                                    onChange={handleChange}
                                                    value={FormData.f_desc}
                                                />
                                            </RB.Col>
                                        </RB.Form.Group>
                                        <RB.Form.Group as={Row} controlId="image_pricet">
                                            <RB.Col lg={5} md={5}>
                                                <RB.Form.Label>Status :</RB.Form.Label>
                                            </RB.Col>
                                            <RB.Col lg={7} md={7}>
                                                <RB.Form.Check
                                                    name="f_status"
                                                    onChange={handleChange}
                                                />
                                            </RB.Col>
                                        </RB.Form.Group>
                                        <RB.Row>
                                            <RB.Col lg={5} md={5}></RB.Col>
                                            <RB.Col lg={7} md={7}>
                                                <RB.Button
                                                    size="sm" variant="primary"
                                                    onClick={EditImageAndVedioSubScription}
                                                >
                                                    UPDATE
                                                </RB.Button>
                                            </RB.Col>
                                        </RB.Row>
                                    </RB.Form>
                                </RB.Col>
                            </RB.Row>
                        </RB.Col>
                    </RB.Row>
                </RB.Modal.Body>
            </RB.Modal>
        </div>
    )
}

export default EditImageVedioSubscriptionPlan
