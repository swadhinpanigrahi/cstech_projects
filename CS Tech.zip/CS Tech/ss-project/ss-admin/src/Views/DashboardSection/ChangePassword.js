import React, { useState } from "react";
import { changePasswordForm } from "../../Components/FormData/FormElements";
import { authChangePassword, logOutApi } from "../../Utils/api";
import { authChangePasswordValidetor } from "../../Utils/FormValidetor";
import { Form, Row, Col } from "react-bootstrap"
import Model from "../../Components/Common/Model";
import { useHistory } from "react-router-dom"

const ChangePassword = () => {
    const history = useHistory()
    const [FormData, setFormData] = useState({});
    const [isOpen, setIsOpen] = useState(false);
    const [ErrModel, setErrModel] = useState("");
    const [Errors, setErrors] = useState({
        errors: {},
        errMsg: "",
        errClr: "",
    });


    const handleChange = (e) => {
        let { name, value } = e.target;
        let data = { ...FormData };
        data[name] = value;
        setFormData(data);
        const updateError = { ...Errors };
        updateError.errors = authChangePasswordValidetor(data);
        updateError.errMsg = "";
        updateError.errClr = "";
        setErrors({ ...updateError });
    };

    const submit = async (e) => {
        e.preventDefault();
        if (FormData["oldpassword"] && FormData["newpassword"] && FormData["confirmpassword"]) {
            const res = await authChangePassword(FormData);
            let { message, updatePassword, error } = res
            if (!error) {
                if (updatePassword) {
                    await logOutApi();
                    history.push("/")
                } else {
                    const updateError = { ...Errors };
                    updateError.errors = "";
                    updateError.errMsg = message;
                    updateError.errClr = "";
                    setErrors({ ...updateError });
                }
            } else {
                window.alert("network error!!")
            }
        } else {
            const updatedError = { ...Errors };
            updatedError.errors = authChangePasswordValidetor(FormData);
            updatedError.errMsg = "";
            updatedError.errClr = "border-danger";
            setErrors({ ...updatedError });
        }
    };
    const modelSet = () => {
        setIsOpen(true);
    };

    let { errors, errMsg, errClr } = Errors;

    return (
        <div>
            <main className="">
                <div className="container-fluid">
                    <div className="col-12">
                        <div
                            className="page-header row no-gutters pym-4"
                            style={{ paddingBottom: ".5rem!important" }}
                        >
                            <div className="col-md-12">
                                <h3 className="page-title">Change Password</h3>
                            </div>
                            <hr />
                        </div>
                    </div>
                    <div className="col-md-12">
                        <div className="box_detail">
                            <div className="row changep" style={{ padding: "20px 30px" }}>
                                <div className="col-md-12">
                                    <Form.Text className="text-danger">{errMsg ? errMsg : ""}</Form.Text>
                                    <form className="formcon" action="customer.html">
                                        {changePasswordForm.map((data, inx) => {
                                            let {
                                                label,
                                                name,
                                                type,
                                                placeholder,
                                                controlId
                                            } = data;
                                            return (
                                                <Form.Group as={Row} controlId={controlId} key={"AUTHCHANGEPASS" + inx}>
                                                    <Form.Label column sm="2">
                                                        {label}
                                                    </Form.Label>
                                                    <Col sm="5">
                                                        <Form.Control type={type} name={name}
                                                            placeholder={placeholder} onChange={handleChange}
                                                            className={errClr ? errClr : ""}
                                                        />
                                                        {errors[name] && (
                                                            <Form.Text className="text-danger">
                                                                {errors[name]}
                                                            </Form.Text>
                                                        )}
                                                    </Col>
                                                </Form.Group>
                                            );
                                        })}
                                        <div className="row">
                                            <div
                                                className="form-group col-lg-6 col-md-12"
                                                style={{ marginBottom: "0rem" }}
                                            >
                                                <div className="row">
                                                    <div className="col-md-4"></div>
                                                    <div className="col-md-8">
                                                        <button className="submit" onClick={submit} >
                                                            SUBMIT
                                                        </button>
                                                        <Model
                                                            text={ErrModel}
                                                            open={isOpen}
                                                            onClose={() => setIsOpen(false)}
                                                        />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    );
};

export default ChangePassword;

