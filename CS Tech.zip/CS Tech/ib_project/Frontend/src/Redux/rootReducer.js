import { combineReducers } from "redux";
import userActionReducer from "./userAction/actionReducer";

const rootReducer = combineReducers({
  userAction: userActionReducer,
});

export default rootReducer;
