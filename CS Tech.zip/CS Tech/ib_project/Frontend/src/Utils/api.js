import axios from "axios";
import Cookie from "js-cookie";
import { BASE_URL } from "./baseURL";
axios.defaults.baseURL = BASE_URL;

axios.interceptors.request.use(
  (config) => {
    const token = Cookie.get("AAToken");
    config.headers.authorization = `Bearer ${token}`;
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

//AUTH---------(START)
export const logInApi = async (Login) => {
  try {
    const res = await axios.post(`/admin/adminlogin`, Login);
    let { status, message, token } = res.data;
    if (status === 200 && token) {
      await Cookie.set("AAToken", token, { expires: 3 });
      return { status };
    } else {
      return { message };
    }
  } catch (error) {
    return { error };
  }
};

export const verifyProfile = async () => {
  try {
    const res = await axios.get("/admin/verifytoken");
    const { tokenData } = res.data;
    if (tokenData) {
      await Cookie.set("id", tokenData.id, { expires: 3 });
      await Cookie.set("email", tokenData.email, { expires: 3 });
      await Cookie.set("userid", tokenData.userid, { expires: 3 });
      await Cookie.set("username", tokenData.username, { expires: 3 });
      return { message: "verifyed", tokenData };
    } else {
      return { message: "varification Error!!" };
    }
  } catch (error) {
    return { error };
  }
};

export const changepasswordApi = async (FormData) => {
  try {
    const res = await axios.post("/admin/changepassword", FormData);
    const { status, message, updateUser } = res.data;
    if (status === 200) {
      return { updateUser };
    } else {
      return { message };
    }
  } catch (error) {
    return { error };
  }
};

export const getAdminInfo = async (userId) => {
  try {
    const res = await axios.post("/admin/getAdminInfo?userId=" + userId);
    // const { status, message, updateUser } = res.data;
    return res
  } catch (error) {
    return { error };
  }
};

export const forgetEmailSendApi = async (email) => {
  try {
    const res = await axios.post("/admin/forgetpassword", email);
    const { status, message } = res.data;
    if (status === 200) {
      return { status, message };
    } else {
      return { message };
    }
  } catch (error) {
    return { error };
  }
};

export const forgetEmailPasswordChange = async (obj) => {
  try {
    const res = await axios.post("admin/changepasswordfrommail", obj);
    let { status, message } = res.data;
    if (status === 200) {
      return { message };
    } else {
      return { message };
    }
  } catch (error) {
    return { error };
  }
};


/**
 * 
*/
export const countApi = async () => {
  try {
    const res = await axios.get("admin/cardcount");
    let { arr } = res.data;
    return { arr };
  } catch (error) {
    return { error };
  }
};

/**
 * CUSTOMER---START
*/
export const customerTable = async (currentPage, itemPerPage, startDate, endDate, selectData, searchData, regtype) => {
  try {
    const res = await axios.get(`admin/getcustomerdata`, {
      params: { currentPage, itemPerPage, startDate, endDate, selectData, searchData, regtype },
    });
    let { customerCount, customerData } = res.data;
    return { customerCount, customerData }
  } catch (error) {
    return { error };
  }
};

export const UnpaidUserAPI = async (currentPage, itemPerPage, searchData, startDate, endDate) => {
  try {
    const res = await axios.get(`admin/getunpaidcustomerdata`, {
      params: { currentPage, itemPerPage, startDate, endDate, searchData },
    });
    let { customerCount, customerData } = res.data;
    return { customerCount, customerData }
  } catch (error) {
    return { error };
  }
};

export const SuperImageUserAPI = async (currentPage, itemPerPage, searchData) => {
  try {
    const res = await axios.get(`admin/getsuperImageUsercustomerdata`, {
      params: { currentPage, itemPerPage, searchData },
    });
    let { customerCount, customerData } = res.data;
    return { customerCount, customerData }
  } catch (error) {
    return { error };
  }
};

export const SuperImageUserDetailsAPI = async (f_email) => {
  try {
    const res = await axios.get(`admin/getsuperImageUserViewListcustomerdata/${f_email}`);
    let { customerCount, customerData, email } = res.data;
    return { customerCount, customerData, email }
  } catch (error) {
    return { error };
  }
};

export const UserFeedbackAPI = async (currentPage, itemPerPage, searchData, searchSelect) => {
  try {
    const res = await axios.get(`admin/getfeedbackUsercustomerdata`, {
      params: { currentPage, itemPerPage, searchData, searchSelect },
    });
    console.log(res)
    let { customerCount, customerData } = res.data;
    return { customerCount, customerData }
  } catch (error) {
    return { error };
  }
};

export const RemoveFeedbackAPI = async (_id) => {
  try {
    const res = await axios.get(`admin/deletefeedbackUsercustomerdata/${_id}`);
    let { status } = res.data;
    return { status }
  } catch (error) {
    return { error };
  }
};

export const EmailFeedbackAPI = async (FormData) => {
  try {
    const res = await axios.post(`admin/feedbackreplayemail`, FormData);
    let { status, message } = res.data;
    if (status === 200) {
      return { message }
    } else {
      console.log(res)
    }
  } catch (error) {
    return { error };
  }
};


export const BannerImageAPI = async (currentPage, itemPerPage, searchData) => {
  try {
    const res = await axios.get(`admin/getBannerImageUsercustomerdata`, {
      params: { currentPage, itemPerPage, searchData },
    });
    let { customerCount, customerData } = res.data;
    return { customerCount, customerData }
  } catch (error) {
    return { error };
  }
};

export const customerFilter = async (search) => {
  try {
    const res = await axios.post("admin/onSearchBarCustomerDetails", search);
    let { status, message, userData } = res.data;
    if (status === 200) {
      return { userData };
    } else {
      return { message };
    }
  } catch (error) {
    return { error };
  }
};

export const getUnregisteredShortAndCompanyName = async (FormData) => {
  try {
    const res = await axios.post("admin/getShortAndGroupName", FormData);
    console.log(res)
    let { status, CustomerDetails } = res.data;
    return { status, CustomerDetails }
  } catch (error) {
    return { error };
  }
}

export const unregisterCustomerList = async (currentPage, itemPerPage, searchData) => {
  try {
    const res = await axios.get(`admin/getunregisteredcustomerlist`, {
      params: { currentPage, itemPerPage, searchData },
    });
    let { customerCount, customerData } = res.data;
    return { customerCount, customerData }
  } catch (error) {
    return { error }
  }
}

export const updateUnregisteredCustomerList = async (FormData) => {
  try {
    const res = await axios.post("admin/updatecustomershortandgroupname", FormData);
    console.log(res)
    let { status, message } = res.data;
    return { status, message }
  } catch (error) {
    return { error };
  }
}

export const getCustomerExport = async (startDate, endDate, selectData, searchData) => {
  try {
    const res = await axios.get("admin/customerexportdetails", {
      params: { startDate, endDate, selectData, searchData },
    });
    let { customerData } = res.data
    return { customerData }
  } catch (error) {
    return { error };
  }
}

/**
 * CUSTOMER---END
*/

/**
 * ORDER---START
*/

export const OrderSearchByMail = async (T_username) => {
  try {
    const res = await axios.get(`admin/getorderbyemaildata/${T_username}`);
    let { data } = res.data;
    return { data }
  } catch (error) {
    return { error };
  }
}

export const orderTable = async (currentPage, itemPerPage, startDate, endDate, searchData) => {
  try {
    const res = await axios.get(`admin/getorderdata`, {
      params: { currentPage, itemPerPage, startDate, endDate, searchData },
    });
    let { orderCount, orderData } = res.data;
    return { orderCount, orderData }
  } catch (error) {
    return { error };
  }
};

export const PorderTable = async (currentPage, itemPerPage, startDate, endDate, searchData) => {
  try {
    const res = await axios.get(`admin/getpendingorderdata`, {
      params: { currentPage, itemPerPage, startDate, endDate, searchData },
    });
    let { orderCount, orderData } = res.data;
    return { orderCount, orderData }
  } catch (error) {
    return { error };
  }
};

export const getOrderDetailAPI = async (T_orderid) => {
  try {
    const res = await axios.get(`admin/getorderdetail/${T_orderid}`);
    let { status, T_OrderData } = res.data;
    if (status === 200) {
      return { T_OrderData }
    } else {
      return { message: "API ERROR" }
    }
  } catch (error) {
    return { error };
  }
}

export const SendPaymenrMail = async (FormData) => {
  try {
    const res = await axios.post(`admin/sendpaymentmail`, FormData);
    let { status, message } = res.data;
    return { status, message }
  } catch (error) {
    return { error }
  }
}

export const SendDetailMail = async (FormData) => {
  try {
    const res = await axios.post(`admin/sendorderccmail`, FormData);
    let { status, message } = res.data;
    return { status, message }
  } catch (error) {
    return { error }
  }
}


export const bounceChequeAPI = async (FormData) => {
  try {
    const res = await axios.post(`admin/updatebouncecheque`, FormData);
    let { status, message } = res.data;
    if (status === 200) {
      return { status, message }
    } else {
      return { message }
    }
  } catch (error) {
    return { error };
  }
}

export const paidProccess = async (FormData) => {
  try {
    const res = await axios.post(`admin/updatepaidproccessstatusupdate`, FormData);
    let { status, message } = res.data;
    if (status === 200) {
      return { status, message }
    } else {
      return { message }
    }
  } catch (error) {
    return { error };
  }
}

export const rejectInvoice = async (T_orderid) => {
  try {
    const res = await axios.get(`admin/invoicechangingtoreject/${T_orderid}`);
    let { status, message } = res.data;
    return { status, message }
  } catch (error) {
    return { error };
  }
}

export const removeOrder = async (T_orderid) => {
  try {
    const res = await axios.get(`admin/deleteorderdetail/${T_orderid}`);
    let { status, message } = res.data;
    return { status, message }
  } catch (error) {
    return { error };
  }
}


/**
 * ORDER---END
*/

export const orderFilter = async (search) => {
  try {
    const res = await axios.post("admin/onSearchBarOrderDetails", search);
    let { status, message, userData, countArr } = res.data;
    if (status === 200) {
      return { userData, countArr };
    } else {
      return { message };
    }
  } catch (error) {
    return { error };
  }
};

export const proposalFilter = async (search) => {
  try {
    const res = await axios.post("admin/onSearchBarProposalDetails", search);
    let { status, message, userData } = res.data;
    if (status === 200) {
      return { userData };
    } else {
      return { message };
    }
  } catch (error) {
    return { error };
  }
};

export const followerFilter = async (search) => {
  try {
    const res = await axios.post("admin/onSearchBarFollowupsDetails", search);
    let { status, message, userData, spanArray } = res.data;
    if (status === 200) {
      return { userData, spanArray };
    } else {
      return { message };
    }
  } catch (error) {
    return { error };
  }
};

export const onBtnClickData = async (btn_data, search) => {
  try {
    const res = await axios.post(`admin/buttonsearch/${btn_data}`, search);
    let { status, userData, message } = res.data;
    if (status === 200) {
      return { userData };
    } else {
      return { message };
    }
  } catch (error) {
    return { error };
  }
};

export const userActionApi = async (f_userid) => {
  try {
    const res = await axios.get(`admin/profileData/${f_userid}`);
    let {
      status,
      T_orderData,
      orderArr,
      proposal_data,
      followupsArr,
      followup_data,
      message,
    } = res.data;
    if (status === 200) {
      return { T_orderData, proposal_data, followup_data, orderArr, followupsArr, };
    } else {
      return { message };
    }
  } catch (error) {
    return { error };
  }
};

export const companyAction = async (f_userid) => {
  try {
    const res = await axios.get(`admin/companygroupdata/${f_userid}`);
    let {
      status,
      userData,
      groupData,
      T_orderData,
      proposal_data,
      followup_data,
    } = res.data;
    console.log(res);
    if (status === 200) {
      return { userData, groupData, T_orderData, proposal_data, followup_data };
    }
  } catch (error) {
    return { error };
  }
};

export const proposalViewAction = async (_id) => {
  try {
    const res = await axios.get(`admin/proposalactionview/${_id}`);
    let { status, proposalData, tblProposalData } = res.data;
    if (status === 200) {
      return { proposalData, tblProposalData };
    }
  } catch (error) {
    return { error };
  }
};

export const proposalDeleteAction = async (_id) => {
  try {
    const res = await axios.get(`admin/proposalactiondelete/${_id}`);
    console.log(res.data);
    let { status, deleted } = res.data;
    if (status === 200) {
      return { deleted };
    }
  } catch (error) {
    return { error };
  }
};

export const profileData = async (_id) => {
  try {
    const res = await axios.get(`admin/getProfile/${_id}`);
    let { status, data1, data2, registrationData } = res.data;
    console.log(data1, data2);
    if (status === 200) {
      return { data1, data2, registrationData };
    }
  } catch (error) {
    return { error };
  }
};

export const customerProfile = async (f_userid) => {
  try {
    const res = await axios.get(`/admin/getcustomerprofile/${f_userid}`);
    let { status, registrationData, t_LUS, t_TUR, message } = res.data;
    console.log(res)
    if (status) {
      return { registrationData, t_LUS, t_TUR }
    } else {
      return { message }
    }
  } catch (error) {
    return { error };
  }
};

export const updateUserActionEdit = async (FormData, f_userid) => {
  try {
    const res = await axios.post(`admin/editcustomerprofile/${f_userid}`, FormData);
    const { status, message } = res.data;
    console.log(res.data)
    if (status === 200) {
      return { message }
    } else {
      return { message: "something went wrong!!" }
    }
  } catch (error) {
    return { error };
  }
};

/**
 * ORDER---START
*/

export const getOrderDeatils = async (orderId) => {
  console.log(orderId)
  try {
    const res = await axios.get(`admin/getOrderbyOrderId/${orderId}`);
    console.log(res)
    let { OrderDetail, OrderDetailsList, userDetails } = res.data;
    return { OrderDetail, OrderDetailsList, userDetails };
  } catch (error) {
    return { error };
  }
};

export const getOrderInvoice = async (orderId) => {
  try {
    const res = await axios.get(`admin/getinvoicedetails/${orderId}`);
    console.log(res.data)
    let { status, OrderInvoice, OrderInvoiceList, message } = res.data;
    if (status === 200) {
      return { OrderInvoice, OrderInvoiceList };
    } else {
      return { message };
    }
  } catch (error) {
    return { error };
  }
}

export const InserOrderAPI = async (FormData) => {
  try {
    const res = await axios.post(`admin/placeorderdetails`, FormData);
    console.log(res.data);
    let { status, message } = res.data;
    return { status, message }
  } catch (error) {
    return { error }
  }
}

/**
 * ORDER---END
*/

export const getUserDeatilsByUsername = async (username) => {
  try {
    const res = await axios.get(`admin/getUserDeatilsByUsername/${username}`);
    let { status, data, msg } = res.data;
    if (status === true) {
      return { data };
    } else {
      return { msg };
    }
  } catch (error) {
    return { error };
  }
};

export const getFollowupsDetails = async (f_sno) => {
  // alert(f_sno)
  try {
    const res = await axios.get(`admin/getFollowupsDetail/${f_sno}`);
    let { status, followupsData } = res.data;
    if (status === 200) {
      return { followupsData };
    }
  } catch (error) {
    return { error };
  }
};


export const getCountryList = async () => {
  try {
    const res = await axios.get(`admin/getCountryList`);
    // console.log(res);
    return { res }
  } catch (error) {
    return { error };
  }
};

export const getStateList = async (countryID) => {
  try {
    const res = await axios.get(`admin/getStateByID/${countryID}`);
    // console.log(res);
    return { res }
  } catch (error) {
    return { error };
  }
};

export const getCompanyMaster = async (countryID) => {
  try {
    const res = await axios.get(`admin/getCompanyMaster`);
    // console.log(res);
    return { res }
  } catch (error) {
    return { error };
  }
};
export const fetchCompanyDataByKeyPress = async (compName) => {
  try {
    var obj = {
      compName: compName
    }
    const res = await axios.post(`admin/fetchCompanyDataByKeyPress`, obj);
    return { res }
  } catch (error) {
    return { error };
  }
};
export const fetchEmailByKeyPress = async (emailId) => {
  try {
    var obj = {
      emailId: emailId
    }
    const res = await axios.post(`admin/fetchEmailDataByKeyPress`, obj);
    return { res }
  } catch (error) {
    return { error };
  }
};

export const SubMitFollowUpRecord = async (followupInfo) => {
  try {
    const res = await axios.post(`admin/SubMitFollowUpRecord`, followupInfo);
    return { res }
  } catch (error) {
    return { error };
  }
};

export const postNextFollowup = async (FormData) => {
  try {
    const res = await axios.post(`admin/saveingnextfollowups`, FormData);
    let { message, status } = res.data;
    if (message && status === 200) {
      return { message };
    }
  } catch (error) {
    return { error };
  }
};
// export const getFollowupsDetails = async (f_sno) => {
//   try {
//     const res = await axios.get(`admin/getFollowupsDetail/${f_sno}`);
//     let { status, followupsData } = res.data;
//     if (status === 200) {
//       return { followupsData };
//     }
//   } catch (error) {
//     return { error };
//   }
// };

export const getFollowupsDetailsTable = async (f_sno) => {
  try {
    const res = await axios.get(`admin/getFollowupsDetailTable/${f_sno}`);
    let { status, followupsData } = res.data;
    if (status === 200) {
      return { followupsData };
    }
  } catch (error) {
    return { error };
  }
};


export const logOutApi = async () => {
  try {
    Cookie.remove("AAToken");
    Cookie.remove("id");
    Cookie.remove("email");
    Cookie.remove("userid");
    Cookie.remove("username");
    return { status: 200 };
  } catch (err) {
    return { err };
  }
};

export const orderTableDataByBtnSearch = async (FormData) => {
  try {
    const res = await axios.post(`admin/getorderdatabybtnsearchfilter`, FormData);
    console.log(res)
    let { orderData, orderCount } = res.data;
    return { orderData, orderCount }
  } catch (error) {
    return { error };
  }
};


export const DeletedUserRecord = async (userId) => {
  try {
    const res = await axios.get(`admin/DeleteUserRecord/${userId}`);
    let { message } = res.data;
    return { message }
  } catch (error) {
    return { error };
  }
};

export const getOrderDetialsForConfirm = async (orderid) => {
  try {
    var obj = {
      orderid: orderid
    }
    const res = await axios.post(`admin/getOrderDetialsForConfirm`, obj);
    let { OrderInfo, OrderDetails, userInfo, stateList } = res.data;

    return {
      OrderInfo,
      OrderDetails,
      userInfo,
      stateList
    }
    // return res
  } catch (error) {
    return { error };
  }
};

export const confirmOrderAndGenerateInvoice = async (usrInfo) => {
  try {
    const res = await axios.post(`admin/confirmOrderAndGenerateInvoice`, usrInfo);
    let { OrderInfo, OrderDetails, userInfo, stateList } = res.data;
    return {
      OrderInfo,
      OrderDetails,
      userInfo,
      stateList
    }
  } catch (error) {
    return { error };
  }
};
export const fetchInvoiceDataByOrderId = async (orderId) => {
  //alert(orderId)
  try {
    const res = await axios.post(`admin/fetchInvoiceDataByOrderId?orderid=${orderId}`);
    let { OrderInfo,
      OrderDetails,
      userInfo } = res.data;
    return {
      OrderInfo,
      OrderDetails,
      userInfo
    }
    // return res
  } catch (error) {
    return { error };
  }
};

export const fetchPaymentDetailsByOrderId = async (orderId) => {
  try {
    const res = await axios.get(`admin/fetchPaymentDetailsByOrderId/${orderId}`);
    const { paymentInfo } = res.data
    return { paymentInfo }
  } catch (error) {
    return { error };
  }
};
export const uploadPurchaseImage = async (formData) => {
  try {
    const res = await axios.post(`admin/uploadPurchaseImage`, formData);
    let { returnMsg } = res.data;
    return {
      returnMsg
    }
    // return res
  } catch (error) {
    return { error };
  }
};

/**
 * PROPOSAL---STATE
*/
export const getProposalList = async (currentPage, itemPerPage, searchData) => {
  try {
    const res = await axios.get(`admin/getproposaldata`, {
      params: { currentPage, itemPerPage, searchData },
    });
    let { proposalCount, proposalData } = res.data;
    return { proposalCount, proposalData }
  } catch (error) {
    return { error }
  }
}

export const getProposalDetails = async (T_orderid) => {
  try {
    console.log(T_orderid)
    const res = await axios.get(`admin/getproposaldetails/${T_orderid}`);
    let { status, proposalDetails, proposalDetail, userDetails } = res.data;
    return { status, proposalDetails, proposalDetail, userDetails }
  } catch (error) {
    return { error }
  }
}

export const sendProposalViewEmail = async (FormData) => {
  try {
    const res = await axios.post(`admin/sendproposalviewemail`, FormData);
    const { message } = res.data;
    return { message }
  } catch (error) {
    return { error }
  }
}

export const deleteProposalDetail = async (T_orderid) => {
  try {
    const res = await axios.get(`admin/deleteproposaldetail/${T_orderid}`);
    let { status, message } = res.data;
    return { status, message }
  } catch (error) {
    return { error }
  }
}

export const getImageDetailsForProposal = async (FormData) => {
  try {
    const res = await axios.post(`admin/getimagebyidsearch`, FormData);
    let { status, imageData } = res.data;
    return { status, imageData }
  } catch (error) {
    return { error }
  }
}

export const getSizingDropData = async (f_pricing) => {
  try {
    const res = await axios.get(`admin/getsizeforimages/${f_pricing}`);
    let { status, imageSize } = res.data;
    return { status, imageSize }
  } catch (error) {
    return { error }
  }
}

export const getCartDetails_FATCH = async (CS_username) => {
  try {
    const res = await axios.get(`admin/getexistingcartdetails/${CS_username}`);
    let { status, ImageDetails } = res.data;
    return { status, ImageDetails }
  } catch (error) {
    return { error }
  }
}

export const AddtoCartAPI_FATCH = async (FormData) => {
  try {
    const res = await axios.post(`admin/addtocartimage`, FormData);
    let { status, message } = res.data;
    return { status, message }
  } catch (error) {
    return { error }
  }
}

export const DeleteFromCart = async (FormData) => {
  try {
    const res = await axios.post(`admin/removefromcart`, FormData);
    let { status, message } = res.data;
    return { status, message }
  } catch (error) {
    return { error }
  }
}

export const FinalizeProposalAPI = async (FormData) => {
  try {
    const res = await axios.post(`admin/finalizeproposalentry`, FormData);
    let { status, message } = res.data;
    console.log(res)
    return { status, message }
  } catch (error) {
    return { error }
  }
}

export const GetUserDetailsForOrder = async (CS_username) => {
  try {
    const res = await axios.get(`admin//getOrderUserDetails/${CS_username}`);
    let { status, userData } = res.data;
    return { status, userData }
  } catch (error) {
    return { error }
  }
}

/**
 * PROPOSAL---END
*/

/**
 * Followups---START
*/

export const getCompanyNames = async () => {
  try {
    const res = await axios.get(`admin/getcompanynames`);
    let { CompanyGroup } = res.data;
    return { CompanyGroup }
  } catch (error) {
    return { error }
  }
}

export const getCompanyDataByName = async (f_companyname) => {
  try {
    const res = await axios.get(`admin/getfollowupquerysearch/${f_companyname}`);
    let { companyData } = res.data;
    return { companyData }
  } catch (error) {
    return { error }
  }
}


/**
 * INVOICE -- START
*/
export const InvoicedropData = async () => {
  try {
    const res = await axios.get(`admin/invoicedropdata`);
    let { dropData } = res.data;
    return { dropData }
  } catch (error) {
    return { error }
  }
}

export const InvoiceGroupData = async (CS_companynames) => {
  try {
    const res = await axios.post(`admin/getCompanyGroupName`, CS_companynames);
    let { GroupData } = res.data;
    return { GroupData }
  } catch (error) {
    return { error }
  }
}

export const getInvoiceDetail = async (f_orderid) => {
  try {
    const res = await axios.get(`admin/getinvoicedetail/${f_orderid}`);
    console.log(res)
    let { invoiceDetail, invoiceDetails, T_orderDetails, LUS, TUR } = res.data;
    return { invoiceDetail, invoiceDetails, T_orderDetails, LUS, TUR }
  } catch (error) {
    return { error }
  }
}

export const InvoiceEditAPI = async (f_orderid, Invoice) => {
  try {
    const res = await axios.post(`admin/invoiceupdate/${f_orderid}`, Invoice);
    let { status, message } = res.data;
    return { status, message }
  } catch (error) {
    return { error }
  }
}

/**
 * INVOICE -- END
*/

export const getDailySalesEntryLists = async (currentPage, itemPerPage, searchData) => {
  try {
    // alert(curr)
    const res = await axios.get(`admin/getDailySalesEntryLists`, {
      params: { currentPage, itemPerPage, searchData },
    });
    let { proposalCount, proposalData } = res.data;
    return { proposalCount, proposalData }
  } catch (error) {
    return { error }
  }
}

export const getFollowupsDetailsById = async (id) => {
  try {
    const res = await axios.post(`admin/getFollowupsDetailsByIds?f_sno=${id}`);
    let { status, followupsData } = res.data;
    if (status === 200) {
      return { followupsData };
    }
  } catch (error) {
    return { error };
  }
};

export const getFollowupsDetailsTableByID = async (id) => {
  try {
    const res = await axios.post(`admin/getFollowupsDetailsTableByIDs?f_sno=${id}`);
    let { status, followupsData } = res.data;
    if (status === 200) {
      return { followupsData };
    }
  } catch (error) {
    return { error };

  }
};



export const insertDataIntoCart = async (data) => {
  try {
    const res = await axios.post(`admin/insertDataIntoCart`, data);
    let { status, returnData } = res.data;
    if (status === 200) {
      return { returnData };
    }
  } catch (error) {
    return { error };
  }
};

export const custom_states = async () => {
  try {
    const res = await axios.get(`admin/getmasterstatecustom`);
    let { status, data } = res.data;
    if (status === 200) {
      return { data };
    }
  } catch (error) {
    return { error };
  }
}


/**
 * MASTER-SECTION
*/

//------Country-------//
export const CREATE_COUNTRYS = async (FormData) => {
  try {
    const res = await axios.post(`admin/master/addcountrydetail`, FormData);
    let { status, saveData, message } = res.data;
    return { status, saveData, message };
  } catch (error) {
    return { error };
  }
}

export const GET_COUNTRYS = async () => {
  try {
    const res = await axios.get(`admin/master/getcountrys`);
    let { status, data } = res.data;
    if (status === 200) {
      return { data };
    }
  } catch (error) {
    return { error };
  }
}

export const GET_COUNTRYLIST = async (currentPage, itemPerPage, searchData, Name, Short) => {
  try {
    const res = await axios.get(`admin/master/getcountrylist`, {
      params: {
        currentPage, itemPerPage, searchData, Name, Short
      }
    });
    let { status, data, totalrecord } = res.data;

    if (status === 200) {
      return { data, totalrecord };
    }
  } catch (error) {
    return { error };
  }
}

export const GET_COUNTRYDETAIL = async (_id) => {
  try {
    const res = await axios.get(`admin/master/getcountrydetail/${_id}`);
    let { status, data } = res.data;
    if (status === 200) {
      return { data };
    }
  } catch (error) {
    return { error };
  }
}

export const UPDATE_COUNTRYDETAIL = async (FormData) => {
  try {
    const res = await axios.post(`admin/master/editcountrydetail`, FormData);
    let { status, message } = res.data;
    if (status === 200) {
      return { message };
    }
  } catch (error) {
    return { error };
  }
}

export const REMOVE_COUNTRYDETAIL = async (_id) => {
  try {
    const res = await axios.get(`admin/master/deletecountrydetail/${_id}`);
    let { status, message } = res.data;
    if (status === 200) {
      return { message };
    }
  } catch (error) {
    return { error };
  }
}

//---------STATE--------//

export const GET_SList = async () => {
  try {
    const res = await axios.get(`admin/master/ststelistforcity`);
    // console.log(res)
    let { data } = res.data;
    return { data };
  } catch (error) {
    return { error };
  }
}

export const CREATE_STATE = async (FormData) => {
  try {
    const res = await axios.post(`admin/master/addstate`, FormData);
    let { status, saveData, message } = res.data;
    return { status, saveData, message };
  } catch (error) {
    return { error };
  }
}

export const GET_STATELIST = async (currentPage, itemPerPage, searchData) => {
  try {
    const res = await axios.get(`admin/master/getstatelist`, { params: { currentPage, itemPerPage, searchData } });
    let { status, data, totalrecord } = res.data;

    if (status === 200) {
      return { data, totalrecord };
    }
  } catch (error) {
    return { error };
  }
}

export const GET_STATEDETAIL = async (_id) => {
  try {
    const res = await axios.get(`admin/master/getstatedetails/${_id}`);
    let { status, stateDetail } = res.data;
    if (status === 200) {
      return { stateDetail };
    }
  } catch (error) {
    return { error };
  }
}

export const UPDATE_STATEDETAIL = async (FormData) => {
  try {
    const res = await axios.post(`admin/master/editstatedetails`, FormData);
    let { status, message } = res.data;
    if (status === 200) {
      return { message };
    }
  } catch (error) {
    return { error };
  }
}

export const REMOVE_STATEDETAIL = async (_id) => {
  try {
    const res = await axios.get(`admin/master/deletestatedetails/${_id}`);
    let { status, message } = res.data;
    if (status === 200) {
      return { message };
    }
  } catch (error) {
    return { error };
  }
}

//---------CITY--------//
export const CREATE_CITY = async (FormData) => {
  try {
    const res = await axios.post(`admin/master/addcity`, FormData);
    let { status, saveData, message } = res.data;
    return { status, saveData, message };
  } catch (error) {
    return { error };
  }
}

export const LIST = async () => {
  try {
    const res = await axios.get(`admin/master/getstatelistnormal`);
    let { status, data } = res.data;
    if (status === 200) {
      return { data };
    }
  } catch (error) {
    return { error };
  }
}

export const GET_CITYLIST = async (currentPage, itemPerPage, searchData) => {
  try {
    const res = await axios.get(`admin/master/getcitylist`, { params: { currentPage, itemPerPage, searchData } });
    let { status, data, totalrecord } = res.data;
    if (status === 200) {
      return { data, totalrecord };
    }
  } catch (error) {
    return { error };
  }
}

export const GET_CITYDETAIL = async (_id) => {
  try {
    const res = await axios.get(`admin/master/getcitydetail/${_id}`);
    let { status, cityDetail } = res.data;
    if (status === 200) {
      return { cityDetail };
    }
  } catch (error) {
    return { error };
  }
}

export const UPDATE_CITYDETAIL = async (FormData) => {
  try {
    const res = await axios.post(`admin/master/editcitydetails`, FormData);
    let { status, message } = res.data;
    if (status === 200) {
      return { message };
    }
  } catch (error) {
    return { error };
  }
}

export const DELETE_CITYDETAIL = async (_id) => {
  try {
    const res = await axios.get(`admin/master/deletecitydetails/${_id}`);
    let { status, message } = res.data;
    if (status === 200) {
      return { message };
    }
  } catch (error) {
    return { error };
  }
}

//---------COMPANY--------//

export const CREATE_COMPANY = async (FormData) => {
  try {
    const res = await axios.post(`admin/master/addcompany`, FormData);
    let { status, saveData, message } = res.data;
    return { status, saveData, message };
  } catch (error) {
    return { error };
  }
}

export const GET_COMPANYIST = async (currentPage, itemPerPage, searchData) => {
  try {
    const res = await axios.get(`admin/master/getcompanylist`, { params: { currentPage, itemPerPage, searchData } });
    let { status, data, totalrecord } = res.data;
    if (status === 200) {
      return { data, totalrecord };
    }
  } catch (error) {
    return { error };
  }
}

export const GET_COMPANYDETAIL = async (_id) => {
  try {
    const res = await axios.get(`admin/master/getcompanydetail/${_id}`);
    let { status, companyData } = res.data;
    if (status === 200) {
      return { companyData };
    }
  } catch (error) {
    return { error };
  }
}

export const UPDATE_COMPANYDETAIL = async (FormData) => {
  try {
    const res = await axios.post(`admin/master/updatecompanydetail`, FormData);

    let { status, message } = res.data;
    if (status === 200) {
      return { message };
    }
  } catch (error) {
    return { error };
  }
}

export const REMOVE_COMPANYDETAIL = async (_id) => {
  try {
    const res = await axios.get(`admin/master/removecompanydetail/${_id}`);
    let { status, message } = res.data;
    if (status === 200) {
      return { message };
    }
  } catch (error) {
    return { error };
  }
}

//---------INDUSTRY--------//

export const CREATE_INDUSTRY = async (FormData) => {
  try {
    const res = await axios.post(`admin/master/addindustry`, FormData);
    console.log(res)
    let { status, saveData } = res.data;
    return { status, saveData };
  } catch (error) {
    return { error };
  }
}

export const GET_INDUSTRYLIST = async (currentPage, itemPerPage, searchData) => {
  try {
    const res = await axios.get(`admin/master/getindustrylist`, { params: { currentPage, itemPerPage, searchData } });

    let { status, data, totalrecord } = res.data;
    if (status === 200) {
      return { data, totalrecord };
    }
  } catch (error) {
    return { error };
  }
}

export const GET_INDUSTRYDETAIL = async (_id) => {
  try {
    const res = await axios.get(`admin/master/getindustrydetail/${_id}`);
    let { status, industryData } = res.data;
    if (status === 200) {
      return { industryData };
    }
  } catch (error) {
    return { error };
  }
}

export const UPDATE_INDUSTRYDETAIL = async (FormData) => {
  try {
    const res = await axios.post(`admin/master/updateindustrydetail`, FormData);
    let { status, message } = res.data;
    if (status === 200) {
      return { message };
    }
  } catch (error) {
    return { error };
  }
}

export const REMOVE_INDUSTRYDETAIL = async (_id) => {
  try {
    const res = await axios.get(`admin/master/removeindustrydetail/${_id}`);
    let { status, message } = res.data;
    if (status === 200) {
      return { message };
    }
  } catch (error) {
    return { error };
  }
}

//---------STARSIZE--------//
export const ADD_STARSIZEDETAIL = async (FormData) => {
  try {
    const res = await axios.post(`admin/master/addstarsize`, FormData);
    let { status, message } = res.data;
    return { status, message };
  } catch (error) {
    return { error };
  }
}

export const GET_STARSIZELIST = async (currentPage, itemPerPage, searchData) => {
  try {
    const res = await axios.get(`admin/master/getstarsizelist`, { params: { currentPage, itemPerPage, searchData } });

    let { status, data, totalrecord } = res.data;
    if (status === 200) {
      return { data, totalrecord };
    }
  } catch (error) {
    return { error };
  }
}

export const GET_STARSIZEDETAIL = async (_id) => {
  try {
    const res = await axios.get(`admin/master/getstarsizedetail/${_id}`);
    let { status, starDetails } = res.data;
    if (status === 200) {
      return { starDetails };
    }
  } catch (error) {
    return { error };
  }
}

export const UPDATE_STARSIZEDETAIL = async (FormData) => {
  try {
    const res = await axios.post(`admin/master/editstarsizedetail`, FormData);

    let { status, message } = res.data;
    if (status === 200) {
      return { message };
    }
  } catch (error) {
    return { error };
  }
}

export const REMOVE_STARSIZEDETAIL = async (_id) => {
  try {
    const res = await axios.get(`admin/master/deletestarsizedetail/${_id}`);
    let { status, message } = res.data;
    if (status === 200) {
      return { message };
    }
  } catch (error) {
    return { error };
  }
}

//---------STARPERIOD--------//
export const ADD_STARPERIODDETAIL = async (FormData) => {
  try {
    const res = await axios.post(`admin/master/addstarperiod`, FormData);
    let { status, message } = res.data;
    return { status, message };
  } catch (error) {
    return { error };
  }
}

export const GET_STARPERIODLIST = async (currentPage, itemPerPage, searchData) => {
  try {
    const res = await axios.get(`admin/master/getstarperiodlist`, { params: { currentPage, itemPerPage, searchData } });

    let { status, data, totalrecord } = res.data;
    if (status === 200) {
      return { data, totalrecord };
    }
  } catch (error) {
    return { error };
  }
}

export const GET_STARPERIODDETAIL = async (_id) => {
  try {
    const res = await axios.get(`admin/master/getstarperioddetail/${_id}`);
    let { status, starPeriodDetail } = res.data;
    if (status === 200) {
      return { starPeriodDetail };
    }
  } catch (error) {
    return { error };
  }
}

export const UPDATE_STARPERIODDETAIL = async (FormData) => {
  try {
    const res = await axios.post(`admin/master/editstarperioddetail`, FormData);

    let { status, message } = res.data;
    if (status === 200) {
      return { message };
    }
  } catch (error) {
    return { error };
  }
}

export const REMOVE_STARPERIODDETAIL = async (_id) => {
  try {
    const res = await axios.get(`admin/master/deletestarperioddetail/${_id}`);
    let { status, message } = res.data;
    if (status === 200) {
      return { message };
    }
  } catch (error) {
    return { error };
  }
}

//---------DISCOUNTTERM--------//
export const ADD_DISCOUNTTERMDETAIL = async (FormData) => {
  try {
    const res = await axios.post(`admin/master/adddiscountterms`, FormData);
    let { status, message } = res.data;
    return { status, message };
  } catch (error) {
    return { error };
  }
}

export const GET_DISCOUNTTERMLIST = async (currentPage, itemPerPage, searchData) => {
  try {
    const res = await axios.get(`admin/master/getdiscounttermslist`, { params: { currentPage, itemPerPage, searchData } });

    let { status, data, totalrecord } = res.data;
    if (status === 200) {
      return { data, totalrecord };
    }
  } catch (error) {
    return { error };
  }
}

export const GET_DISCOUNTTERMDETAIL = async (_id) => {
  try {
    const res = await axios.get(`admin/master/getdiscounttermsdetail/${_id}`);
    let { status, discData } = res.data;
    if (status === 200) {
      return { discData };
    }
  } catch (error) {
    return { error };
  }
}

export const UPDATE_DISCOUNTTERMDETAIL = async (FormData) => {
  try {
    const res = await axios.post(`admin/master/editdiscounttermsdetail`, FormData);

    let { status, message } = res.data;
    if (status === 200) {
      return { message };
    }
  } catch (error) {
    return { error };
  }
}

export const REMOVE_DISCOUNTTERMDETAIL = async (_id) => {
  try {
    const res = await axios.get(`admin/master/deletediscounttermsdetail/${_id}`);
    let { status, message } = res.data;
    if (status === 200) {
      return { message };
    }
  } catch (error) {
    return { error };
  }
}

//---------CREDITPERIOD--------//
export const ADD_CREDITPERIODDETAIL = async (FormData) => {
  try {
    const res = await axios.post(`admin/master/addcreditperiod`, FormData);
    let { status, message } = res.data;
    return { status, message };
  } catch (error) {
    return { error };
  }
}

export const GET_CREDITPERIODLIST = async (currentPage, itemPerPage, searchData) => {
  try {
    const res = await axios.get(`admin/master/getcreditperiodlist`, { params: { currentPage, itemPerPage, searchData } });

    let { status, data, totalrecord } = res.data;
    if (status === 200) {
      return { data, totalrecord };
    }
  } catch (error) {
    return { error };
  }
}

export const GET_CREDITPERIODDETAIL = async (_id) => {
  try {
    const res = await axios.get(`admin/master/getcreditperioddetail/${_id}`);
    let { status, CreditDetail } = res.data;
    if (status === 200) {
      return { CreditDetail };
    }
  } catch (error) {
    return { error };
  }
}

export const UPDATE_CREDITPERIODDETAIL = async (FormData) => {
  try {
    const res = await axios.post(`admin/master/editcreditperioddetail`, FormData);
    let { status, message } = res.data;
    if (status === 200) {
      return { message };
    }
  } catch (error) {
    return { error };
  }
}

export const REMOVE_CREDITPERIODDETAIL = async (_id) => {
  try {
    const res = await axios.get(`admin/master/deletecreditperioddetail/${_id}`);
    let { status, message } = res.data;
    if (status === 200) {
      return { message };
    }
  } catch (error) {
    return { error };
  }
}

//-----VEDIO MODEL------//
export const GET_VEDIOMODELLIST = async (currentPage, itemPerPage, searchData) => {
  try {
    const res = await axios.get(`admin/master/getvediomodellist`, { params: { currentPage, itemPerPage, searchData } });

    let { status, data, totalrecord } = res.data;
    if (status === 200) {
      return { data, totalrecord };
    }
  } catch (error) {
    return { error };
  }
}

export const GET_ACTIVATIONFORVM = async (_id, f_map) => {
  try {
    const res = await axios.get(`admin/master/updateactivationlist/${_id}/${f_map}`);
    let { status, message } = res.data;
    if (status === 200) {
      return { message };
    }
  } catch (error) {
    return { error };
  }
}

export const REMOVE_VMDETAIL = async (_id) => {
  try {
    const res = await axios.get(`admin/master/removevediomodel/${_id}`);
    let { status, message } = res.data;
    if (status === 200) {
      return { message };
    }
  } catch (error) {
    return { error };
  }
}

//-----SUBSCRIPTION------//
export const ADD_SUBPLANDDETAIL = async (FormData) => {
  try {
    const res = await axios.post(`admin/master/addsubscriptionplandetails`, FormData);
    let { status, message } = res.data;
    return { status, message };
  } catch (error) {
    return { error };
  }
}

export const GET_SUBSCRIPTIONPLANLIST = async (currentPage, itemPerPage, searchData) => {
  try {
    const res = await axios.get(`admin/master/getsubscriptionplanlist`, { params: { currentPage, itemPerPage, searchData } });

    let { status, data, totalrecord } = res.data;
    if (status === 200) {
      return { data, totalrecord };
    }
  } catch (error) {
    return { error };
  }
}

export const GET_SUBPLANDETAIL = async (_id) => {
  try {
    const res = await axios.get(`admin/master/getsubscriptionplandetails/${_id}`);
    let { status, subscriptionplandetail } = res.data;
    if (status === 200) {
      return { subscriptionplandetail };
    }
  } catch (error) {
    return { error };
  }
}

export const UPDATE_SUBPLANDDETAIL = async (FormData) => {
  try {
    const res = await axios.post(`admin/master/editsubscriptionplan`, FormData);
    let { status, message } = res.data;
    if (status === 200) {
      return { message };
    }
  } catch (error) {
    return { error };
  }
}

export const REMOVE_SUBPLANDDETAIL = async (_id) => {
  try {
    const res = await axios.get(`admin/master/removesubscriptionplan/${_id}`);
    let { status, message } = res.data;
    if (status === 200) {
      return { message };
    }
  } catch (error) {
    return { error };
  }
}

//-----AGENCIES------//
export const GET_AGENCIESLIST = async (currentPage, itemPerPage, searchData) => {
  try {
    const res = await axios.get(`admin/master/getagencieslist`, { params: { currentPage, itemPerPage, searchData } });

    let { status, data, totalrecord } = res.data;
    if (status === 200) {
      return { data, totalrecord };
    }
  } catch (error) {
    return { error };
  }
}

//------IMAGE/VIDEO SUBSCRIPTION PLAN-----//

export const ADD_IMAGEVEDIODETAIL = async (FormData) => {
  try {
    const res = await axios.post(`admin/master/addimagevediosubscription`, FormData);
    let { status, message } = res.data;
    return { status, message };
  } catch (error) {
    return { error };
  }
}

export const GET_IMAGEVEDIOLIST = async (currentPage, itemPerPage, searchData) => {
  try {
    const res = await axios.get(`admin/master/getimagevideolist`, { params: { currentPage, itemPerPage, searchData } });
    let { status, data, totalrecord } = res.data;

    if (status === 200) {
      return { data, totalrecord };
    }
  } catch (error) {
    return { error };
  }
}

export const GET_IMAGEVEDIODETAIL = async (_id) => {
  try {
    const res = await axios.get(`admin/master/getimagevideodetail/${_id}`);
    let { status, data } = res.data;
    if (status === 200) {
      return { data };
    }
  } catch (error) {
    return { error };
  }
}

export const UPDATE_IMAGEVEDIODETAIL = async (FormData) => {
  try {
    const res = await axios.post(`admin/master/editimagevideodetail`, FormData);
    let { status, message } = res.data;
    if (status === 200) {
      return { message };
    }
  } catch (error) {
    return { error };
  }
}

export const REMOVE_IMAGEVEDIODETAIL = async (_id) => {
  try {
    const res = await axios.get(`admin/master/deleteimagevideodetail/${_id}`);
    let { status, message } = res.data;
    if (status === 200) {
      return { message };
    }
  } catch (error) {
    return { error };
  }
}

//------IMAGE TYPE-----//
export const ADD_IMAGETYPEDETAIL = async (FormData) => {
  try {
    const res = await axios.post(`admin/master/addimagetypedetail`, FormData);
    let { status, message } = res.data;
    return { status, message };
  } catch (error) {
    return { error };
  }
}

export const GET_IMAGETYPELIST = async (currentPage, itemPerPage, searchData) => {
  try {
    const res = await axios.get(`admin/master/getimagetypeList`, { params: { currentPage, itemPerPage, searchData } });
    let { status, data, totalrecord } = res.data;

    if (status === 200) {
      return { data, totalrecord };
    }
  } catch (error) {
    return { error };
  }
}

export const GET_IMAGETYPEDETAIL = async (_id) => {
  try {
    const res = await axios.get(`admin/master/getimagetypedetail/${_id}`);
    let { status, data } = res.data;
    if (status === 200) {
      return { data };
    }
  } catch (error) {
    return { error };
  }
}

export const UPDATE_IMAGETYPEDETAIL = async (FormData) => {
  try {
    const res = await axios.post(`admin/master/editimagetypedetail`, FormData);
    let { status, message } = res.data;
    if (status === 200) {
      return { message };
    }
  } catch (error) {
    return { error };
  }
}

export const REMOVE_IMAGETYPEDETAIL = async (_id) => {
  try {
    const res = await axios.get(`admin/master/deletetmagetypedetail/${_id}`);
    let { status, message } = res.data;
    if (status === 200) {
      return { message };
    }
  } catch (error) {
    return { error };
  }
}

//------IMAGE SIZE-----//
export const ADD_IMAGESIZEDETAIL = async (FormData) => {
  try {
    const res = await axios.post(`admin/master/addimagesizedetail`, FormData);
    let { status, message } = res.data;
    return { status, message };
  } catch (error) {
    return { error };
  }
}

export const GET_IMAGESIZELIST = async (currentPage, itemPerPage, searchData) => {
  try {
    const res = await axios.get(`admin/master/getimagesizelist`, { params: { currentPage, itemPerPage, searchData } });
    let { status, data, totalrecord } = res.data;

    if (status === 200) {
      return { data, totalrecord };
    }
  } catch (error) {
    return { error };
  }
}

export const GET_IMAGESIZEDETAIL = async (_id) => {
  try {
    const res = await axios.get(`admin/master/getimagesizedetail/${_id}`);
    let { status, data } = res.data;
    if (status === 200) {
      return { data };
    }
  } catch (error) {
    return { error };
  }
}

export const UPDATE_IMAGESIZEDETAIL = async (FormData) => {
  try {
    const res = await axios.post(`admin/master/editimagesizedetail`, FormData);
    let { status, message } = res.data;
    if (status === 200) {
      return { message };
    }
  } catch (error) {
    return { error };
  }
}

export const REMOVE_IMAGESIZEDETAIL = async (_id) => {
  try {
    const res = await axios.get(`admin/master/deleteimagesizedetail/${_id}`);
    let { status, message } = res.data;
    if (status === 200) {
      return { message };
    }
  } catch (error) {
    return { error };
  }
}

//------SIMILAR GROUP-----//
export const ADD_SMILARGROUP = async (FormData) => {
  try {
    const res = await axios.post(`admin/master/Addsimilargroup`, FormData);
    let { status, message } = res.data;
    return { status, message };
  } catch (error) {
    return { error };
  }
}

export const GET_SMILARGROUPLIST = async (currentPage, itemPerPage, searchData) => {
  try {
    const res = await axios.get(`admin/master/getsimilargrouplist`, { params: { currentPage, itemPerPage, searchData } });
    let { status, data, totalrecord } = res.data;

    if (status === 200) {
      return { data, totalrecord };
    }
  } catch (error) {
    return { error };
  }
}

export const GET_SMILARGROUPDETAIL = async (_id) => {
  try {
    const res = await axios.get(`admin/master/getsimilargroup/${_id}`);
    let { status, data } = res.data;
    if (status === 200) {
      return { data };
    }
  } catch (error) {
    return { error };
  }
}

export const UPDATE_SMILARGROUPDETAIL = async (FormData) => {
  try {
    const res = await axios.post(`admin/master/updatesimilargroup`, FormData);
    let { status, message } = res.data;
    if (status === 200) {
      return { message };
    }
  } catch (error) {
    return { error };
  }
}

export const REMOVE_SMILARGROUPDETAIL = async (_id) => {
  try {
    const res = await axios.get(`admin/master/removesimilargroup/${_id}`);
    let { status, message } = res.data;
    if (status === 200) {
      return { message };
    }
  } catch (error) {
    return { error };
  }
}

//------PRICE DETAIL-----//
export const ADD_PRICEDETAIL = async (FormData) => {
  try {
    const res = await axios.post(`admin/master/addpricedetail`, FormData);
    let { status, message } = res.data;
    return { status, message };
  } catch (error) {
    return { error };
  }
}

export const GET_PRICEDETAILLIST = async (currentPage, itemPerPage, searchData) => {
  try {
    const res = await axios.get(`admin/master/getpricedetaillist`, { params: { currentPage, itemPerPage, searchData } });
    let { status, data, totalrecord } = res.data;

    if (status === 200) {
      return { data, totalrecord };
    }
  } catch (error) {
    return { error };
  }
}

export const GET_PRICEDETAIL = async (_id) => {
  try {
    const res = await axios.get(`admin/master/getpricedetail/${_id}`);
    let { status, data } = res.data;
    if (status === 200) {
      return { data };
    }
  } catch (error) {
    return { error };
  }
}

export const UPDATE_PRICEDETAIL = async (FormData) => {
  try {
    const res = await axios.post(`admin/master/updatepricedetail`, FormData);
    let { status, message } = res.data;
    if (status === 200) {
      return { message };
    }
  } catch (error) {
    return { error };
  }
}

export const REMOVE_PRICEDETAIL = async (_id) => {
  try {
    const res = await axios.get(`admin/master/removepricedetail/${_id}`);
    let { status, message } = res.data;
    if (status === 200) {
      return { message };
    }
  } catch (error) {
    return { error };
  }
}

//----TAX && PAYMENTSRIGHTS------//

export const GET_TAXDETAIL = async () => {
  try {
    const res = await axios.get(`admin/master/gettaxdetail`);

    let { status, data } = res.data;
    if (status === 200) {
      return { data };
    }
  } catch (error) {
    return { error };
  }
}

export const UPDATE_TAXDETAIL = async (FormData) => {
  try {
    const res = await axios.post(`admin/master/updatetaxdetails`, FormData);
    let { status, message } = res.data;
    if (status === 200) {
      return { message };
    }
  } catch (error) {
    return { error };
  }
}

export const GET_R_PAYMENTEDETAIL = async () => {
  try {
    const res = await axios.get(`admin/master/getpaymentsrights`);

    let { status, data } = res.data;
    if (status === 200) {
      return { data: data[0] };
    }
  } catch (error) {
    return { error };
  }
}

export const UPDATE_R_PAYMENTEDETAIL = async (FormData) => {
  try {
    const res = await axios.post(`admin/master/updatepaymentrights`, FormData);
    let { status, message } = res.data;
    if (status === 200) {
      return { message };
    }
  } catch (error) {
    return { error };
  }
}

//----ADMIN------//

export const POST_ADMIN = async (FormData) => {
  try {
    const res = await axios.post(`admin/master/addadmin`, FormData);
    let { status, message } = res.data;
    return { status, message }
  } catch (error) {
    return { error };
  }
}

export const GET_ADMINLIST = async (currentPage, itemPerPage, searchData) => {
  try {
    const res = await axios.get(`admin/master/getadminlist`, { params: { currentPage, itemPerPage, searchData } });
    let { status, data, totalrecord } = res.data;

    if (status === 200) {
      return { data, totalrecord };
    }
  } catch (error) {
    return { error };
  }
}

//----SUSPENDED IMAGES------//
export const GET_SUSPNDIMG = async (currentPage, itemPerPage, searchData) => {
  try {
    const res = await axios.get(`admin/master/getsuspendedimages`, { params: { currentPage, itemPerPage, F_imgid: searchData } });
    let { status, data, totalrecord } = res.data;
    if (status === 200) {
      return { data, totalrecord };
    }
  } catch (error) {
    return { error };
  }
}

export const UPDATE_SUSPENDIMG = async (FormData) => {
  try {
    const res = await axios.post(`admin/master/updatesuspendimages`, FormData);
    return { res };
  } catch (error) {
    return { error };
  }
}

//----PRICE CHANGE----//
export const GET_PRICEESLIST = async (currentPage, itemPerPage, searchData) => {
  try {
    const res = await axios.get(`admin/master/groupimageslist`, { params: { currentPage, itemPerPage, searchData } });
    let { status, data, totalrecord } = res.data;
    if (status === 200) {
      return { data, totalrecord };
    }
  } catch (error) {
    return { error };
  }
}

export const GET_PRICESDETAILS = async (_id) => {
  try {
    const res = await axios.get(`admin/master/getpricingdetail/${_id}`);

    let { status, data } = res.data;
    if (status === 200) {
      return { data };
    }
  } catch (error) {
    return { error };
  }
}

/**
 *  IMAGES
*/

export const GET_IMGLIST = async (currentPage, itemPerPage, searchData) => {
  try {
    const res = await axios.get(`admin/image/getimageslist`, { params: { currentPage, itemPerPage, searchData } });
    let { status, data, totalrecord } = res.data;
    if (status === 200) {
      return { data, totalrecord };
    }
  } catch (error) {
    return { error };
  }
}

export const GET_IMG = async (_id) => {
  try {
    const res = await axios.get(`admin/image/getimage/${_id}`);
    let { status, data } = res.data
    return { status, data };
  } catch (error) {
    return { error };
  }
}

export const EDIT_IMG = async (FormData) => {

}

export const REMOVE_IMG = async (_id) => {
  try {
    const res = await axios.get(`admin/image/removeimage/${_id}`);
    let { status, message } = res.data
    return { status, message };
  } catch (error) {
    return { error };
  }
}

/**
 * KEYWORD
*/

export const GET_VISIBLEKEYLIST = async (currentPage, itemPerPage, searchData) => {
  try {
    const res = await axios.get(`admin/keyword/getvisiblekeydetails`, { params: { currentPage, itemPerPage, searchData } });
    console.log("data", res)
    let { status, data, totalrecord } = res.data;
    if (status === 200) {
      return { data, totalrecord };
    }
  } catch (error) {
    return { error };
  }
}

export const GET_AIDVALUES = async (FormData) => {
  try {
    const res = await axios.post(`admin/keyword/getaidvalues`, FormData);
    let { status, aid } = res.data;
    if (status === 200) {
      return aid;
    }
  } catch (error) {
    return { error };
  }
}

