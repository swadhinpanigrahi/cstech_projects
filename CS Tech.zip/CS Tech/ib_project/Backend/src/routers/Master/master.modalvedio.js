const VedioModal = require("express").Router();
const {
    getVedioModelList, activedeactiveVedioModel, removeVedioModel
} = require("../../controllers/Master/master.modalvedio.controller");

VedioModal.route("/getvediomodellist").get(getVedioModelList)
VedioModal.route("/updateactivationlist/:_id/:f_map").get(activedeactiveVedioModel)
VedioModal.route("/removevediomodel/:_id").get(removeVedioModel)

module.exports = VedioModal;