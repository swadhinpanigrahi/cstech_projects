const mongoose = require("mongoose");

const forgetPassTknSchema = mongoose.Schema(
  {
    token: { type: String, required: true },
    expireAt: { type: Date, default: Date.now(), index: { expires: "5m" } },
  },
  { collection: "tbl_forget_token" }
);

module.exports = forgetPassTkn = mongoose.model(
  "tbl_forget_token",
  forgetPassTknSchema
);
