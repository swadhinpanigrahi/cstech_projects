const mongoose = require("mongoose");

const OrderDetailsSchemas = mongoose.Schema(
  {
    t_sno: { type: Number },
    t_orderid: { type: String },
    t_imageid: { type: String },
    t_price: { type: Number },
    t_quality: { type: String },
    t_disc_price: { type: Number },
    ph_paymentstatus: { type: String },
    ph_paymentdate: { type: Date, default : null },
    CS_ImgType_up: { type: String },
    f_image_type: { type: String },
    f_country: { type: String },
    f_state: { type: String },
    f_duration: { type: String, default: null },
    f_plantype: { type: String, default: null },
    f_industry: { type: String, default: null },
    t_priceAdjment: { type: Number, default : 0 },
    f_mydimension: { type: String, default :"" },
    f_groupid: { type: String, default: null },
    f_rank: { type: String }
  },
  { collection: "t_ord_details_IB_MongoDB" }
);

module.exports = orderDetailSchema = mongoose.model("t_ord_details_IB_MongoDB", OrderDetailsSchemas);
