import React, { useState, useEffect } from 'react';
import * as RB from "react-bootstrap";
import { Row } from "react-bootstrap";
import { UPDATE_STATEDETAIL } from "../../../../Utils/api"

const EditState = (
    { EditModal, setEditModal, CountryData, StateDetail, apiCall }
) => {
    const [FormData, setFormData] = useState({});
    const handleChange = (e) => {
        let { name, value } = e.target;
        console.log(name, value)
        const data = { ...FormData }
        data[name] = value
        setFormData(data)
    }
    const closeModal = () => {
        setEditModal(false)
    }
    const onSubmit = async (e) => {
        e.preventDefault();
        const res = await UPDATE_STATEDETAIL(FormData);
        let { message } = res;
        if (message) {
            apiCall();
            setEditModal(false)
        }
    }
    useEffect(() => {
        console.log(StateDetail);
        let countryCode;
        let contrydetail;
        CountryData.forEach(element => {
            if (element.f_countryid === StateDetail.f_countryid) {
                countryCode = element.f_countryid;
                contrydetail = element.f_country
            }
        })
        setFormData({ ...StateDetail, f_countryid: countryCode, f_country: contrydetail });

    }, [StateDetail])
    return (
        <div>
            <RB.Modal show={EditModal} onHide={closeModal} className="ordermanage_modal">
                <RB.Modal.Header closeButton>
                    <RB.Modal.Title>Add New State</RB.Modal.Title>
                </RB.Modal.Header>
                <RB.Modal.Body>
                    <RB.Row>
                        <RB.Col lg={12} md={12}>
                            <RB.Row>
                                <RB.Col lg={12} md={12}>
                                    <RB.Form>
                                        <RB.Form.Group as={Row} controlId="Country_id">
                                            <RB.Col lg={4} md={4}>
                                                <RB.Form.Label>Select Country :</RB.Form.Label>
                                            </RB.Col>
                                            <RB.Col lg={7} md={8}>
                                                <select className="select_customerd" name="f_countryid" onChange={handleChange}>
                                                    <option value={FormData.f_countryid}>{FormData.f_country}</option>
                                                    {CountryData.map((info, inx) => {
                                                        return (
                                                            <option value={info.f_countryid} key={`COUNTRY_DROPDOWN_${inx}`}>
                                                                {info.f_country}
                                                            </option>
                                                        )
                                                    })}
                                                </select>
                                            </RB.Col>
                                        </RB.Form.Group>
                                        <RB.Form.Group as={Row} controlId="Country_id">
                                            <RB.Col lg={4} md={4}>
                                                <RB.Form.Label>State Name :</RB.Form.Label>
                                            </RB.Col>
                                            <RB.Col lg={7} md={8}>
                                                <RB.Form.Control type="text"
                                                    name="f_state"
                                                    value={FormData.f_state}
                                                    onChange={handleChange}
                                                />
                                            </RB.Col>
                                        </RB.Form.Group>
                                        <RB.Row>
                                            <RB.Col lg={4} md={4}></RB.Col>
                                            <RB.Col lg={6} md={7}>
                                                <RB.Button
                                                    size="sm" variant="primary"
                                                    onClick={onSubmit}
                                                >
                                                    SUBMIT
                                                </RB.Button>
                                            </RB.Col>
                                        </RB.Row>
                                    </RB.Form>
                                </RB.Col>
                            </RB.Row>
                        </RB.Col>
                    </RB.Row>
                </RB.Modal.Body>
            </RB.Modal>
        </div>
    )
}

export default EditState