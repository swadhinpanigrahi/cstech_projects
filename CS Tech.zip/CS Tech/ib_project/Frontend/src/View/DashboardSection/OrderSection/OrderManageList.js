import React, { useState, useEffect } from "react";
import * as RB from "react-bootstrap";
import { Form, Button, Row, OverlayTrigger, Tooltip } from "react-bootstrap";
import { Link, useHistory } from 'react-router-dom';
import { FaRegCommentDots, FaRegFilePdf } from "react-icons/fa";
import { CgPlayListRemove } from "react-icons/cg";
import { RiPaypalLine } from "react-icons/ri";
import { RiDeleteBin6Line } from "react-icons/ri";
import { AiOutlineFolderView } from "react-icons/ai";
import { BiImageAdd, BiUserPin, BiMailSend, BiCommentEdit, BiIdCard, BiUpload, BiDownload, BiUser } from "react-icons/bi";
import brandlogoi from "../../../Images/brandlogo.png";
import {
    orderTable, fetchInvoiceDataByOrderId, fetchPaymentDetailsByOrderId, uploadPurchaseImage,
    getOrderDeatils, rejectInvoice, removeOrder, SendPaymenrMail, SendDetailMail
} from "../../../Utils/api";
import { dir } from '../../../config/dir'
import PaginationComponent from "../../../Components/Common/PaginationComponent";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import Moment from 'moment';
import OrderBounceChequeModal from "../../../Components/Models/OrderModals/OrderBounceChequeModal";
import OrderPaidProcessModal from "../../../Components/Models/OrderModals/OrderPaidProcessModal";
import OrderDetailsModel from "../../../Components/Models/OrderModals/OrderDetailsModel";
import OrderPaymentModal from "../../../Components/Models/OrderModals/OrderPaymentModal";
import OrderActionMailModal from "../../../Components/Models/OrderModals/OrderActionMailModal";
import Modal from "../../../Components/Common/Modal";
import sha256 from 'crypto-js/sha256';
// import hmacSHA512 from 'crypto-js/hmac-sha512';
// import Base64 from 'crypto-js/enc-base64';
var CryptoJS = require("crypto-js");
const OrderManageList = () => {
    const history = useHistory()
    const [Data, setData] = useState([]);
    const [SendMail, setSendMail] = useState({})
    const [currentPage, setCurrentPage] = useState(1);
    const [itemPerPage, setItemPerPage] = useState(10);
    let [searchData, setSearchData] = useState("")
    const [startDate, setStartDate] = useState(null);
    const [endDate, setEndDate] = useState(null);
    const [gotoPage, setGoToPage] = useState("");
    const [Count, setCount] = useState(0);
    const [OrderEditData, setOrderEditData] = useState({
        USER_INFO: {},
        ORDER_INFO: {},
        ORDER_LIST: []
    })
    const [paymentInfo, setPaymentInfo] = useState({});
    const [paymentPrice, setPaymentPrice] = useState({});
    const [paymentUsername, setPaymentUsername] = useState({});
    const [payemntLink, setpayemntLink] = useState();
    const [orderId, setOrderId] = useState();
    const [T_orderid, setT_orderid] = useState("")
    const [fileName, setFileName] = useState();
    const [PaidOrderId, setPaidOrderId] = useState([])


    const [Loading, setLoading] = useState(false);

    const [isOpen, setIsOpen] = useState(false);
    const [ModelMsg, setModelMsg] = useState("");

    // model states
    const [show, setShow] = useState(false);
    const [show1, setShow1] = useState(false);
    const [show2, setShow2] = useState(false);
    const [BounceChequeModel, setBounceChequeModel] = useState(false);
    const [PaidProcessModel, setPaidProcessModel] = useState(false);
    const [show5, setShow5] = useState(false);
    const [show6, setShow6] = useState(false);

    const [OrderDetailsIsOpen, setOrderDetailsIsOpen] = useState(false);
    const [OrderDataObj, setOrderDataObj] = useState({});
    const [OrderDataList, setOrderDataList] = useState([]);
    const [OrderUser, setOrderUser] = useState({});

    const [PaymentMD, setPaymentMD] = useState("")

    const CloseOrderDetails = () => setOrderDetailsIsOpen(false);
    const OrderDetailsClick = async (orderId) => {
        const res = await getOrderDeatils(orderId);
        let { OrderDetail, OrderDetailsList, userDetails } = res;
        console.log("userDetails : ", userDetails);
        setOrderDataObj(OrderDetail);
        setOrderDataList(OrderDetailsList);
        setOrderUser(userDetails)
        setOrderDetailsIsOpen(true);
    };

    const handleClose = () => setShow(false);  //M

    const handleClose1 = () => setShow1(false);//M1
    // const handleShow1 = () => setShow1(true);
    const handleClose2 = () => setShow2(false);//M2

    const OpenBounceCheque = (T_orderid) => { /*BOUNCE CHEQUE*/
        setT_orderid(T_orderid)
        setBounceChequeModel(true)
    };

    const OpenPaidProcess = () => {
        if (PaidOrderId.length > 0) {
            setPaidProcessModel(true)
        } else {
            window.alert("select at list one checkbox!")
        }
    }; /*PAID PROCESS*/
    const handleClose5 = () => setShow5(false);//M5
    const handleClose6 = () => setShow6(false);//M6

    const modelSet = () => {
        setIsOpen(true);
    };

    const handleShow1 = async (orderId) => {
        const res = await fetchPaymentDetailsByOrderId(orderId);
        console.log(res);
        const { paymentInfo } = res;
        paymentInfo === null ? setPaymentInfo({}) : setPaymentInfo(paymentInfo)
        setShow1(true)
    }
    const handleShow = async (price, username, T_orderid) => {
        setPaymentPrice(price)
        setPaymentUsername(username)
        setT_orderid(T_orderid)
        setShow(true);
    }
    const handleShow2 = async (orederId) => {
        setOrderId(orederId)
        setShow2(true)
    }
    const handleShow6 = async (orederId, price, username) => {
        //  alert("called")
        setOrderId(orederId)
        setPaymentPrice(price)
        setPaymentUsername(username)
        setShow6(true);
    }
    const handleShow5 = async (orderId) => {
        const res = await fetchInvoiceDataByOrderId(orderId);
        let { OrderInfo, OrderDetails, userInfo } = res
        const updateState = { ...OrderEditData }
        updateState.USER_INFO = userInfo
        updateState.ORDER_INFO = OrderInfo
        updateState.ORDER_LIST = OrderDetails
        setOrderEditData(updateState);
        setShow5(true)

    }

    const onChangeHandler = async (e) => {
        var fileInfo = e.target.files[0]
        setFileName(fileInfo)
        // for (let index = 0; index < payload.length; index++) {
        //     const element = payload[index];
        //     formData.append("img1" + index, element)
        // }
    }

    const onUploadImage = async (e) => {
        const formData = new FormData();
        formData.append("orderId", orderId)
        formData.append("img1", fileName)
        const res2 = await uploadPurchaseImage(formData);
        const { returnMsg } = res2
        // alert('Purchase Image uploaded sucessfully..')
        setShow2(false);
        setModelMsg("Purchase Image uploaded sucessfully..")
        modelSet()
        // apiCall()
        //  history.push('/dashboard/order/get')
        //   const res = await orderTable(currentPage, itemPerPage, startDate, endDate, searchData);
        //   let { orderData, orderCount } = res;
        //   ///console.log("Order Data : ", orderData);
        //   setData(orderData);
        //   orderCount.length === 1 ? setCount(orderCount[0].totalCount) : setCount(0)
        //   setLoading(false)

    }

    const onChangePayment = async (value) => {
        var userId = paymentUsername
        setPaymentMD(value)
        // setPaymentMD(value)
        if (value == 'Mobikwik' || value == 'HDFC' || value == 'American Express') {
            var userId = window.btoa(paymentUsername) //window.btoa(this.userId)
            var totalamnt = window.btoa(paymentPrice)
            // var getorderid = (this.getorderId + 1)
            var getorderid = window.btoa(T_orderid)
            var pgt = window.btoa(value)

            console.log(paymentUsername, paymentPrice, T_orderid, value);
            setpayemntLink('https://old.imagesbazaar.com/Betalogintest.aspx?id=' + getorderid + '&amt=' + totalamnt + '&user=' + userId + '&pgt=' + window.btoa(value))

        }
    }

    const handleChange = async (e) => {
        if (e.target.name === "email" || e.target.name === "content") {
            let { name, value } = e.target;
            const data = { ...SendMail };
            data[name] = value;
            setSendMail(data);
        } else {
            setSearchData(e.target.value);
            const res = await orderTable(currentPage, itemPerPage, startDate, endDate, searchData = e.target.value);
            let { orderData, orderCount } = res;
            setData(orderData);
            orderCount.length === 1 ? setCount(orderCount[0].totalCount) : setCount(0)
            setLoading(false)
        }
    }

    const onSearchClick = async () => {
        if (startDate && endDate) {
            setLoading(true);
            const res = await orderTable(currentPage, itemPerPage, startDate, endDate, searchData);
            let { orderData, orderCount } = res;
            setData(orderData);
            orderCount.length === 1 ? setCount(orderCount[0].totalCount) : setCount(0)
            setLoading(false)
        } else {
            window.alert("fill all fields")
        }
    }

    // const renderTooltip = (props) => (
    //     <Tooltip id="button-tooltip" {...props} className="tooltip_new">
    //         <span>
    //             <strong style={{ color: "#fff" }}>Spl remk. :</strong> Spl remk: GST Confirmed// Ambuj Goel 9971662860 left Pushpak is replaced pushpak@zoomedia.in/ GST no.and add changed as there finance is shifted to mumbai so no order will be confirmed on haryana address-Jenni-12/7/2021
    //         </span>
    //     </Tooltip>
    // );

    const handleCheck = (e, f_email) => {
        let { checked } = e.target;
        let selectedOrderId = [...PaidOrderId];
        if (checked) {
            selectedOrderId.push(f_email);
        } else {
            let delIndex = selectedOrderId.indexOf(f_email);
            selectedOrderId.splice(delIndex, 1);
        }
        setPaidOrderId(selectedOrderId);
    };

    /**
     * ACTION-BUTTON FUNCTIONS
    */

    const paymentEmailFun = async (e) => {
        e.preventDefault();
        console.log(payemntLink);

        const res = await SendPaymenrMail({ paymentUsername, paymentPrice, payemntLink, T_orderid });
        let { status, message } = res;
        if (status === 200) {
            handleClose()
            setModelMsg(message)
            modelSet()
        } else {
            handleClose()
            setModelMsg("Error while sending mail")
            modelSet()
        }
        //  console.log({ paymentUsername, paymentPrice, payemntLink, T_orderid })
    }

    const sendEmailFun = async (e) => {
        e.preventDefault();
        let { content, email } = SendMail;
        if (!content) {
            window.alert("please enter message you want to send")
        } else if (!email) {
            window.alert("Enter CC Mail")
        } else {
            const res = await SendDetailMail({ ...SendMail, orderId });
            let { status, message } = res;
            if (status === 200) {
                handleClose6()
                setModelMsg(message)
                modelSet()
            } else {
                handleClose()
                setModelMsg("Error while sending mail")
                modelSet()
            }
        }
    }
    const dileveryImage = async (orederId, price, username) => {
        window.open(`http://uatsiteadmin.imagesbazaar.com/OrderManage/Sendpage.aspx?oderid=${orederId}&userid=${username}&pagetype=down`)
        // http://ibcondl.imagesbazaar.com/IBdelivery/ibsiteadmin/Imagedelivery.aspx?oderid=cK3dOnQInRE=&userid=uWnvgqTGrLw=
    }
    const OpenPDF = async (orederId, price, username) => {
        // alert(orederId)
        var encypt = sha256(orederId)
        var ciphertext = CryptoJS.AES.encrypt(orederId, 'secret key 123').toString();
        // window.open('http://pdf.imagesbazaar.com/default.aspx?pageurl=http://siteadmin.imagesbazaar.com/OrderManage/Invoicegstnew.aspx?orderid=' + window.btoa(orederId))
        window.open('http://pdf.imagesbazaar.com/default.aspx?pageurl=https://ibadminreact.imagesbazaar.com/#/orderprint/213815')

        // http://localhost:3000/#/orderprint/213815
        //   alert(ciphertext)
    }
    const AfterPaidProccess = () => {
        setLoading(true);
        const apiCall = async () => {
            const res = await orderTable(currentPage, itemPerPage, startDate, endDate, searchData);
            let { orderData, orderCount } = res;
            setData(orderData);
            orderCount.length === 1 ? setCount(orderCount[0].totalCount) : setCount(0)
            setLoading(false);
            setPaidOrderId([])
        }
        apiCall()
    }

    const RejectInvoiceAPI = async (T_orderid) => {
        const res = await rejectInvoice(T_orderid);
        let { status, message } = res;
        if (status === 200) {
            const res = await orderTable(currentPage, itemPerPage, startDate, endDate, searchData);
            let { orderData, orderCount } = res;
            setData(orderData);
            orderCount.length === 1 ? setCount(orderCount[0].totalCount) : setCount(0);
            setModelMsg(message)
            modelSet()
        }
    }

    const RemoveOrderDetail = async (T_orderid) => {
        //      console.log(T_orderid)
        const res = await removeOrder(T_orderid);
        let { status, message } = res;
        if (status === 200) {
            const res = await orderTable(currentPage, itemPerPage, startDate, endDate, searchData);
            let { orderData, orderCount } = res;
            setData(orderData);
            orderCount.length === 1 ? setCount(orderCount[0].totalCount) : setCount(0);
            setModelMsg(message)
            modelSet()
        }
    }
    const UserLogin = async (userId) => {
        // alert(userId)
        window.open('http://testing.imagesbazaar.com/ibregistration?usr=' + window.btoa(userId))
    }
    const listData = Data.length !== 0 ? Data.map((data, inx) => {
        //   console.log(data.t_comment)
        return (
            <tr key={"ORDER_NAV_TBL" + inx}>
                <td><p className="td_pfirst"><Link to={'/dashboard/order/ordermanage/' + data.T_orderid}>{data.T_orderid} {data.f_orderType === "Plan" ? "-IVS" : ""}</Link></p></td>
                <td className="company_emmailt">{data.T_username}</td>
                <td>
                    <p className="td_pc s_notd"><span><strong>Order Date :</strong> </span></p>
                    <p className="td_pc"><span className="second_date">{Moment(data.T_orderdate).format('DD-MM-YYYY')}</span></p>




                </td>
                <td className="text-center pay_order td_payorder">
                    <p>{data.T_paymode}</p>
                    < RiPaypalLine title="Pay Online" onClick={() => handleShow(data.f_orderAmt, data.T_username, data.T_orderid)} />
                    < AiOutlineFolderView title="Payment View" onClick={() => handleShow1(data.T_orderid)} />
                </td>
                <td className="td_comments">
                    {data.T_status === "C" ?
                        // <span onClick={InvoiceRecordById(data.T_orderid)}>
                        <p className="invoice_idpdf">
                            <span>
                                <p className="td_pfirst invoice_payorder" onClick={() => handleShow5(data.T_orderid)}>
                                    {data.f_invoiceID}
                                </p>
                            </span>
                            <span>
                                < FaRegFilePdf title="PDF" onClick={() => OpenPDF(data.T_orderid, data.f_orderAmt, data.T_username)} /></span>
                        </p>
                        //  </span>
                        : ""}

                    <p className="td_pc"><span className="second_date">₹ {data.f_orderAmt}</span></p>
                </td>
                <td className="text-center">{data.T_status}</td>
                <td className="td_comments text-center">
                    {data.T_status === "C" ?
                        <p> < BiUpload title="Upload Image" onClick={() => handleShow2(data.T_orderid)} />
                            {data.uploadedImg !== "" && data.uploadedImg !== undefined ? < BiDownload title="Download Image" onClick={() => dowbloAdImg(data.uploadedImg, data.T_orderid)} /> : ""}

                            <OverlayTrigger placement="left" delay={{ show: 250, hide: 400 }}
                                overlay={
                                    <Tooltip id={`tooltip-${inx}`}>
                                        {/* Tooltip on <strong>{data.t_comment}</strong>. */}
                                        {data.t_comment}
                                    </Tooltip>
                                }
                            >
                                <FaRegCommentDots variant="success"></FaRegCommentDots>
                            </OverlayTrigger></p>


                        : ""}

                </td>
                <td className="text-center">{data.t_paymentstatus} <br />
                    {/* {data.t_paymentdate !== null ? Moment(data.t_paymentdate).format('DD-MM-YYYY') : "-"} */}

                    {data.T_status === "C" ? <div><p className="td_pc s_notd"> </p>
                        <p className="td_pc"><span className="second_date">{Moment(data.T_orderdate).format('DD-MM-YYYY')}</span></p> </div> : ""}

                </td>
                <td className="td_comments text-center">
                    < BiUser title=" User Details" onClick={(e) => UserLogin(data.T_userid)} />
                    < BiUserPin title=" Order Details" onClick={() => OrderDetailsClick(data.T_orderid)} />
                    < BiImageAdd title=" Deliver Image" onClick={() => dileveryImage(data.T_orderid, data.f_orderAmt, data.T_username)} />
                    < BiMailSend title=" Send Mail" onClick={() => handleShow6(data.T_orderid, data.f_orderAmt, data.T_username)} />
                    {data.T_status === "C" ?
                        <Link to={`/dashboard/order/invoiceedit/${data.T_orderid}`} >< BiCommentEdit title=" Invoive Edit" /></Link> : ""}
                    < BiIdCard title=" Bounce Cheque" onClick={() => OpenBounceCheque(data.T_orderid)} />
                    < CgPlayListRemove className="text-danger1" title=" Invoice Reject" onClick={() => RejectInvoiceAPI(data.T_orderid)} />
                    < RiDeleteBin6Line className="text-danger1" title=" Order Delete" onClick={() => RemoveOrderDetail(data.T_orderid)} />
                </td>
                <td>
                    {data.T_status === "C" ? <Form>
                        <Form.Group controlId="formBasicCheckbox">
                            <Form.Check
                                type="checkbox"
                                name={data.T_orderid}
                                checked={PaidOrderId.includes(data.T_orderid) || false}
                                onChange={(e) => {
                                    handleCheck(e, data.T_orderid);
                                }}
                            />
                        </Form.Group>
                    </Form> : null}

                </td>
            </tr>
        )
    }) : <tr><td class="no_records" colspan="11">No Records Found</td></tr>




    function convertImgToBase64(url, callback, outputFormat) {
        var canvas = document.createElement('CANVAS');
        var ctx = canvas.getContext('2d');
        var img = new Image;
        img.crossOrigin = 'Anonymous';
        img.onload = function () {
            canvas.height = img.height;
            canvas.width = img.width;
            ctx.drawImage(img, 0, 0);
            var dataURL = canvas.toDataURL(outputFormat || 'image/png');
            callback.call(this, dataURL);
            // Clean up
            canvas = null;
        };
        img.src = url;
    }
    // async function dowbloAdImg(imgPath) {
    const dowbloAdImg = async (imgPath, orderId) => {
        //  alert(window.location.hash)
        // alert(imgPath)
        var newPath = dir + '/profiles/' + orderId + '/' + imgPath
        // alert(newPath)
        // $('.mm-page').css('position', 'relative');

        var imageUrl = newPath;//$(this).find('input[name=url]').val();
        console.log('imageUrl', newPath);
        convertImgToBase64(imageUrl, function (base64Img) {
            // alert(base64Img)
            var a = document.createElement('a');
            a.href = base64Img;
            a.download = imageUrl;
            document.body.appendChild(a);
            a.click();
        });



    }
    const gotToPage = async () => {
        //console.log(gotoPage)
        setCurrentPage(gotoPage)
        setLoading(true);
        const res = await orderTable(gotoPage, itemPerPage, startDate, endDate, searchData);
        let { orderData, orderCount } = res;
        setData(orderData);
        orderCount.length === 1 ? setCount(orderCount[0].totalCount) : setCount(0);
        window.scroll(0, 0);
        setLoading(false);
    }

    useEffect(() => {
        setLoading(true);
        const apiCall = async () => {
            const res = await orderTable(currentPage, itemPerPage, startDate, endDate, searchData);
            let { orderData, orderCount } = res;
            ///console.log("Order Data : ", orderData);
            setData(orderData);
            orderCount.length === 1 ? setCount(orderCount[0].totalCount) : setCount(0)
            setLoading(false)
        }
        apiCall();
    }, [currentPage, itemPerPage])


    let { USER_INFO, ORDER_INFO, ORDER_LIST } = OrderEditData;
    var total = 0;
    var discount = 0;
    var tax = 0;
    var netPayable = 0

    const listOrderDetails = ORDER_LIST.length !== 0 ? ORDER_LIST.map((info, inx) => {
        total += info.t_price;
        // discount += info.t_price * USER_INFO.cs_discount / 100;
        // tax += info.t_price * 18 / 100;
        // netPayable += total - discount + tax
        if (ORDER_INFO.f_orderType === "Plan") {
            return (

                <tr className="border_btm">
                    <td className="td_first text-center">
                        {info.t_quality === 'Large Size' ? <img src="https://old.imagesbazaar.com/imagesvideoimg/images/CheckoutLARGE.png" alt="invoiceimg" /> : ""}
                        {info.t_quality === 'Web-Size' ? <img src="https://old.imagesbazaar.com/imagesvideoimg/images/CheckoutSMALL.png" alt="invoiceimg" /> : ""}
                        {info.t_quality === 'Medium-Size' ? <img src="https://old.imagesbazaar.com/imagesvideoimg/images/CheckoutMEDIUM.png" alt="invoiceimg" /> : ""}
                        {info.t_quality === 'Small-Size' ? <img src="https://old.imagesbazaar.com/imagesvideoimg/images/CheckoutSMALL.png" alt="invoiceimg" /> : ""}
                        {info.t_quality === 'XL-Size' ? <img src="https://old.imagesbazaar.com/imagesvideoimg/images/CheckoutXL.png" alt="invoiceimg" /> : ""}
                        {info.t_quality === 'XXL-Size' ? <img src="https://old.imagesbazaar.com/imagesvideoimg/images/CheckoutXXL.png" alt="invoiceimg" /> : ""}



                    </td>
                    <td className="td_first text-center">
                        <p class="mg-b-0">{info.t_quality}</p>
                    </td>
                    <td className="td_first text-center">
                        <p class="mg-b-0">{info.t_imageid}</p>
                    </td>
                    <td className="td_first text-center">
                        <p class="mg-b-0">{info.f_duration} days</p>
                    </td>
                    {/* <td className="td_first text-center">
                        <p class="mg-b-0">{info.f_mydimension}</p>
                    </td> */}
                    <td className="td_second text-right">
                        <p class="mg-b-0">{info.t_price}</p>
                    </td>
                </tr>
            )

        } else {
            return (

                <tr className="border_btm">
                    <td className="td_first text-center">
                        <img src={`https://ibcdn.imagesbazaar.com/img170/${info.f_rank}-${info.t_imageid}.jpg`} alt="invoiceimg" />
                    </td>
                    <td className="td_first text-center">
                        <p class="mg-b-0">{info.t_imageid}</p>
                    </td>
                    <td className="td_first text-center">
                        <p class="mg-b-0">{info.f_image_type}</p>
                    </td>
                    <td className="td_first text-center">
                        <p class="mg-b-0">Non Exclusive </p>
                    </td>
                    <td className="td_first text-center">
                        <p class="mg-b-0">{info.f_mydimension}</p>
                    </td>
                    <td className="td_second text-right">
                        <p class="mg-b-0">{info.t_price}</p>
                    </td>
                </tr>
            )

        }
    }) : <tr><td class="no_records" colspan="11">No Records Found</td></tr>
    discount = total * USER_INFO.cs_discount / 100;
    var a = total - discount
    tax = a * 18 / 100;
    netPayable = total - discount + tax
    return (
        <RB.Row className="rownew1">

            <RB.Col lg={12}>
                <RB.Row className="page_header1 rownew1">
                    <div className="tableHeader tableHeader1 search_new">
                        <RB.Col md={12} className="table_span">
                            <h3 className="page-title d-flex userv">
                                <span>Search Results</span>
                            </h3>
                        </RB.Col>
                    </div>
                </RB.Row>
            </RB.Col>

            <RB.Col lg={12}>
                <div className="box_detail" style={{ borderRadius: "4px" }}>
                    <div className="page-header row">
                        <RB.Col md={12}>
                            <Form className="manage_searchorder">
                                <RB.Row className="mg_row0">
                                    <RB.Col lg={6} md={6}>
                                        <RB.Row className="mg_row0">
                                            <RB.Col lg={6} md={6}>
                                                <DatePicker className="startdate"
                                                    placeholderText="Start Date"
                                                    selected={startDate}
                                                    onChange={(date) => setStartDate(date)}
                                                    dateFormat="dd-MM-yyyy"
                                                />
                                            </RB.Col>
                                            <RB.Col lg={6} md={6} className="customer_sdate order_sdate">
                                                <DatePicker className="enddate"
                                                    placeholderText="End Date"
                                                    selected={endDate}
                                                    onChange={(date) => setEndDate(date)}
                                                    dateFormat="dd-MM-yyyy"
                                                />
                                            </RB.Col>
                                        </RB.Row>
                                    </RB.Col>
                                    <RB.Col lg={2} md={2} className="customer_sdate">
                                        <RB.Col lg={12} className="customer_sdate1">
                                            <Button size="sm" className="customer_srhbtn" variant="primary" onClick={onSearchClick}>SEARCH</Button>
                                        </RB.Col>
                                    </RB.Col>
                                    <RB.Col lg={4} md={4}>
                                        <RB.Row className="mg_row0">
                                            <RB.Col lg={4}></RB.Col>
                                            <RB.Col lg={8} className="">
                                                <Form.Group>
                                                    <Form.Control type="text" placeholder="Search by Text/Order ID"
                                                        onChange={handleChange} />
                                                </Form.Group>
                                            </RB.Col>
                                        </RB.Row>
                                    </RB.Col>
                                </RB.Row>
                            </Form>
                        </RB.Col>
                    </div>
                </div>
            </RB.Col>


            {/**
             * ORDER LIST TABLE----------------(START)
            */}

            <RB.Col lg={12}>
                <RB.Row className="rownew1">
                    <div className="tableHeader tableHeader1">
                        <RB.Col lg={6} md={6} xs={5} className="table_span">
                            <h3 className="page-title d-flex userv">
                                <span>Order List</span>
                            </h3>
                        </RB.Col>
                        <RB.Col lg={6} md={6} xs={7} className="table_span">
                            <div className="float-right">
                                <RB.Button size="sm" variant="primary" onClick={OpenPaidProcess}>Paid Process</RB.Button>
                            </div>
                        </RB.Col>
                    </div>
                </RB.Row>
                <div className="box_detail table_boxdtl manage_order" style={{ marginBottom: "0px" }}>
                    <RB.Table striped bordered hover variant="dark" responsive>
                        <thead>
                            <tr class="vtable">
                                <th className="s_not">Order ID</th>
                                <th>Email</th>
                                <th>Date</th>
                                <th className="text-center">Payment Mode</th>
                                <th>Amount & Invoice ID</th>
                                <th className="text-center">Order Status</th>
                                <th className="text-center">Comments</th>
                                <th className="text-center">Payment Status</th>
                                <th className="text-center">Action</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            {Loading ? <tr><td class="loadingd" colspan="10">Loading....</td></tr> : [listData]}
                        </tbody>
                    </RB.Table>
                </div>
            </RB.Col>
            {/**
             * ORDER LIST TABLE----------------(END)
            */}
            <OrderDetailsModel
                OrderDetailsIsOpen={OrderDetailsIsOpen}
                CloseOrderDetails={CloseOrderDetails}
                OrderDataObj={OrderDataObj}
                OrderDataList={OrderDataList}
                OrderUser={OrderUser}
            />

            <OrderPaymentModal
                show={show}
                handleClose={handleClose}
                paymentUsername={paymentUsername}
                paymentPrice={paymentPrice}
                payemntLink={payemntLink}
                T_orderid={T_orderid}
                onChangePayment={onChangePayment}
                paymentEmailFun={paymentEmailFun}
            />

            <OrderActionMailModal
                show6={show6}
                handleClose6={handleClose6}
                orderId={orderId}
                paymentUsername={paymentUsername}
                handleChange={handleChange}
                sendEmailFun={sendEmailFun}
            />

            <OrderBounceChequeModal
                BounceChequeModel={BounceChequeModel}
                setBounceChequeModel={setBounceChequeModel}
                T_orderid={T_orderid}
            />
            <OrderPaidProcessModal
                PaidProcessModel={PaidProcessModel}
                setPaidProcessModel={setPaidProcessModel}
                PaidOrderId={PaidOrderId}
                AfterPaidProccess={AfterPaidProccess}
            />

            <RB.Modal show={show1} onHide={handleClose1} className="ordermanage_modal">
                <RB.Modal.Header closeButton>
                    <RB.Modal.Title>Payment Mode View</RB.Modal.Title>
                </RB.Modal.Header>
                <RB.Modal.Body>
                    <RB.Row>
                        <RB.Col lg={12}>
                            <RB.Table striped bordered hover variant="dark" responsive style={{ border: "1px solid #dee2e6" }}>
                                <thead>
                                    <tr class="vtablem">
                                        <th className="text-left">
                                            <img src={brandlogoi} width="100%" />
                                        </th>
                                        <th className="text-left">Payment Details</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td className="text-left">Order ID</td>
                                        <td className="text-left">{paymentInfo.f_orderid}</td>
                                    </tr>
                                    <tr>
                                        <td className="text-left">Order Amount</td>
                                        <td className="text-left">{paymentInfo.f_orderAmt}</td>
                                    </tr>
                                    <tr>
                                        <td className="text-left">User ID</td>
                                        <td className="text-left">{paymentInfo.f_userid}</td>
                                    </tr>
                                    <tr>
                                        <td className="text-left">Payment Mode</td>
                                        <td className="text-left">{paymentInfo.f_paymod}</td>
                                    </tr>
                                    <tr>
                                        <td className="text-left">Order Date</td>
                                        <td className="text-left">{paymentInfo.f_crdate}</td>
                                    </tr>
                                    <tr>
                                        <td className="text-left">Status</td>
                                        <td className="text-left">{paymentInfo.f_ordersatus}</td>
                                    </tr>
                                    <tr>
                                        <td className="text-left">Payment ID</td>
                                        <td className="text-left">{paymentInfo.f_paymentId}</td>
                                    </tr>
                                    <tr>
                                        <td className="text-left">Track ID</td>
                                        <td className="text-left">{paymentInfo.f_trackid}</td>
                                    </tr>
                                    <tr>
                                        <td className="text-left">Payment Amount</td>
                                        <td className="text-left">{paymentInfo.f_payamount}</td>
                                    </tr>
                                    <tr>
                                        <td className="text-left">Error Message</td>
                                        <td className="text-left">{paymentInfo.f_errormsg}</td>
                                    </tr>
                                    <tr>
                                        <td className="text-left">IP</td>
                                        <td className="text-left">{paymentInfo.f_ip}</td>
                                    </tr>
                                </tbody>
                            </RB.Table>
                        </RB.Col>
                    </RB.Row>
                </RB.Modal.Body>
            </RB.Modal>

            <RB.Modal show={show2} onHide={handleClose2} className="ordermanage_modal">
                <RB.Modal.Header closeButton>
                    <RB.Modal.Title>Purchase Order</RB.Modal.Title>
                </RB.Modal.Header>
                <RB.Modal.Body>
                    <RB.Row>
                        <RB.Col lg={12} md={12}>
                            <RB.Row>
                                <RB.Col lg={12} md={12}>
                                    <h4 className="payment_link">Upload Purchhase Order File</h4>
                                </RB.Col>
                                <RB.Col lg={12} md={12}>

                                    <RB.Form.Group as={Row} controlId="formbasicemailo">
                                        <RB.Col lg={3} md={3}>
                                            <RB.Form.Label>Choose File :</RB.Form.Label>
                                        </RB.Col>
                                        <RB.Col lg={7} md={7}>
                                            <RB.Form.File id="exampleFormControlFile1" onChange={onChangeHandler} />
                                        </RB.Col>
                                    </RB.Form.Group>
                                    <RB.Row>
                                        <RB.Col lg={3} md={3}></RB.Col>
                                        <RB.Col lg={7} md={7}>
                                            <RB.Button size="sm" variant="primary" onClick={onUploadImage}>SUBMIT</RB.Button>
                                        </RB.Col>
                                    </RB.Row>

                                </RB.Col>
                            </RB.Row>
                        </RB.Col>
                    </RB.Row>
                </RB.Modal.Body>
            </RB.Modal>

            <RB.Modal show={show5} onHide={handleClose5} id="orders_modal">
                <RB.Modal.Header closeButton>
                    <RB.Modal.Title>Tax Invoice</RB.Modal.Title>
                </RB.Modal.Header>
                <RB.Modal.Body className="invoice_modalbody">
                    <RB.Row>
                        <RB.Col lg={6} md={6}>
                            <span className="logo-invoice">
                                <img className="logoinv_img"
                                    src="http://ibcdn.imagesbazaar.com/Html2015/images/logo_imagesBazaar.png"
                                    alt="img_img1"
                                />
                            </span>
                        </RB.Col>
                        <RB.Col lg={6} md={6}>
                            <Form id="checkforminvoive" className="float-right">
                                <Form.Group controlId="formBasicCheckbox">
                                    <Form.Check type="checkbox" label="ORIGINAL FOR RECIPIENT" checked />
                                </Form.Group>
                                <Form.Group controlId="formBasicCheckbox2">
                                    <Form.Check type="checkbox" label="DUPLICATE FOR SUPPLIER" />
                                </Form.Group>
                            </Form>
                        </RB.Col>
                    </RB.Row>
                    <div className="main_orders">
                        <RB.Row className="headinv" id="invoicem">
                            <RB.Col lg={6} className="right_bordertd_detail">
                                <p>
                                    <strong>Mash Audio Visuals Private Limited</strong>
                                </p>
                                <p>505, Aggarwal Prestige Mall, Plot No. 2,</p>
                                <p>Road No. 44, Pitam Pura, New Delhi - 110034</p>
                                <p>Phone: (+91) 11 66545466 | (+91) 11 66545465</p>
                                <p class="p_txt">
                                    <strong>CIN: </strong> U92111DL2003PTC122096
                                </p>
                                <p class="p_txt">
                                    <strong>GSTIN:</strong> 07AADCM6333L1ZA
                                </p>
                                <p class="p_txt">
                                    <strong>PAN: </strong>AADCM6333L
                                </p>
                            </RB.Col>
                            <RB.Col lg={6} className="pd_0">
                                <RB.Table responsive>
                                    <tbody>
                                        <tr className="border_btm">
                                            <td className="td_first">
                                                <p class="mg-b-0">
                                                    <strong>Date: </strong> {Moment(ORDER_INFO.T_orderdate).format('DD-MM-YYYY')}
                                                </p>
                                            </td>
                                            <td className="td_second">
                                                <p class="mg-b-0">
                                                    <strong>Invoice No.:</strong>  {ORDER_INFO.f_invoiceID}
                                                </p>
                                            </td>
                                        </tr>
                                        <tr className="border_btm">
                                            <td className="td_first">
                                                <p class="mg-b-0">
                                                    <strong>Order Confirmation No.:</strong>  {ORDER_INFO.T_orderid}
                                                </p>
                                            </td>
                                            <td className="td_second">
                                                <p class="mg-b-0">
                                                    <strong>HSN/SAC:</strong> {USER_INFO.f_sno}
                                                </p>
                                            </td>
                                        </tr>
                                        <tr className="border_btm">
                                            <td className="td_first">
                                                <p class="mg-b-0">
                                                    <strong>Mode of Payment:</strong> {ORDER_INFO.T_paymode}
                                                </p>
                                            </td>
                                            <td className="td_second">
                                                <p class="mg-b-0">
                                                    <strong>State Code:</strong> 07/DL
                                                </p>
                                            </td>
                                        </tr>
                                        <tr className="border_btm">
                                            <td className="td_first">
                                                <p class="mg-b-0">
                                                    <strong>Payment Status:</strong> {ORDER_INFO.t_paymentstatus}
                                                </p>
                                            </td>
                                            <td className="td_second text-left">
                                                <p class="mg-b-0">
                                                    <strong> State:</strong>  {USER_INFO.f_state}

                                                </p>
                                            </td>
                                        </tr>
                                    </tbody>
                                </RB.Table>
                                <RB.Table responsive>
                                    <tbody>
                                        <tr>
                                            <td className="text-left">
                                                <p>
                                                    <strong>Reverse Charges Applicability:</strong> Not
                                                    Applicable
                                                </p>
                                                <p>
                                                    <strong>Place of Supply:</strong>{USER_INFO.f_state}
                                                </p>
                                            </td>
                                        </tr>
                                    </tbody>
                                </RB.Table>
                            </RB.Col>
                        </RB.Row>

                        <RB.Row className="headinv" id="invoicem">
                            <RB.Col lg={6} className="right_bordertd_detail">
                                <p>
                                    <strong>Party’s Name:</strong>
                                </p>
                                <p>{USER_INFO.f_companyname}</p>
                                <p>{USER_INFO.CS_address}</p>
                                <p>{USER_INFO.CS_pin} - {USER_INFO.f_state}, {USER_INFO.f_country}</p>
                                <p>
                                    <strong>State:</strong>  {USER_INFO.f_state}

                                </p>
                                <p>
                                    <strong>State Code:</strong> 07/DL
                                </p>
                                <p className="p_txt">
                                    <strong>GSTIN:</strong>  {USER_INFO.f_GSTIN}
                                </p>
                            </RB.Col>
                            <RB.Col lg={6} className="pd_0">
                                <RB.Table responsive>
                                    <tbody>
                                        <tr className="">
                                            <td className="text-left">
                                                <p>
                                                    <strong>Client Name:</strong> {ORDER_INFO.t_client}
                                                </p>
                                                <p>
                                                    <strong>Order By:</strong> {USER_INFO.f_fullname}
                                                </p>
                                            </td>
                                        </tr>
                                    </tbody>
                                </RB.Table>
                            </RB.Col>
                        </RB.Row>

                        <RB.Row className="headinv" id="invoice1">
                            <RB.Col lg={12} className="pd_0 invoice_new"> {/*order_modal_table*/}
                                <RB.Table responsive>
                                    <thead className="thead-dark">

                                        {ORDER_INFO.f_orderType === "Plan" ? <tr>
                                            <th className="td_first text-center">Image</th>
                                            <th className="td_first text-center">Plan Name</th>
                                            <th className="td_first text-center">No of Videos</th>
                                            <th className="td_first text-center">Validity of Package</th>
                                            {/* <th className="td_first text-center">Dimensions (Px)</th> */}
                                            <th className="text-right">Amount (Rs.)</th>
                                        </tr> : <tr>
                                            <th className="td_first text-center">Image</th>
                                            <th className="td_first text-center">Item ID</th>
                                            <th className="td_first text-center">Image Type</th>
                                            <th className="td_first text-center">Rights</th>
                                            <th className="td_first text-center">Dimensions (Px)</th>
                                            <th className="text-right">Amount (Rs.)</th>
                                        </tr>}

                                    </thead>
                                    <tbody>
                                        {listOrderDetails}
                                        <tr className="border_btm">
                                            <td className="text-right td_first" colspan="5">
                                                <p className="mg-b-0 resblock">
                                                    <strong>Total Value (INR)</strong>
                                                </p>
                                            </td>
                                            <td className="text-right">
                                                <p class="mg-b-0"><strong>{total}.00</strong></p>
                                            </td>
                                        </tr>
                                        {discount !== 0 ? <tr className="border_btm">
                                            <td className="text-right td_first" colspan="5">
                                                <p className="mg-b-0 resblock">
                                                    <strong>Discount(INR)</strong>
                                                </p>
                                            </td>
                                            <td className="text-right">
                                                <p class="mg-b-0"><strong>{discount}.00</strong></p>
                                            </td>
                                        </tr> : ""}
                                        <tr className="border_btm">
                                            <td className="text-right td_first" colspan="5">
                                                <p className="mg-b-0 resblock">
                                                    <strong>CGST Value @18% (INR)</strong>
                                                </p>
                                            </td>
                                            <td className="text-right">
                                                <p class="mg-b-0"><strong>{tax}.00</strong></p>
                                            </td>
                                        </tr>
                                        <tr className="border_btm">
                                            <td className="text-right td_first" colspan="5">
                                                <p className="mg-b-0">
                                                    <strong>
                                                        Total Amount Before GST (SGST / UGST / CGST / IGST)
                                                    </strong>
                                                </p>
                                            </td>
                                            <td className="text-right">
                                                <p className="mg-b-0"><strong>{total - discount}.00</strong></p>
                                            </td>
                                        </tr>
                                        <tr className="border_btm">
                                            <td className="text-right td_first" colspan="5">
                                                <p className="mg-b-0">
                                                    <strong>
                                                        Total Amount Payable Inclusive of GST (SGST / UGST /
                                                        CGST / IGST)
                                                    </strong>
                                                </p>
                                            </td>
                                            <td className="text-right">
                                                <p className="mg-b-0"><strong>{netPayable}.00</strong></p>
                                            </td>
                                        </tr>
                                    </tbody>
                                </RB.Table>
                                <RB.Table responsive>
                                    <tbody>
                                        <tr className="border_btm">
                                            <td className="text-left">
                                                <p className="mg-b-0">
                                                    ImagesBazaar is a unit of Mash Audio Visuals Pvt. Ltd.
                                                    Usage of content subject to Mash Rights Agreement
                                                    mentioned on <a href="#0">www.Imagesbazaar.com/licensing.aspx</a>
                                                </p>
                                            </td>
                                        </tr>
                                    </tbody>
                                </RB.Table>
                                <RB.Table responsive>
                                    <tbody>
                                        <tr>
                                            <td
                                                style={{ width: "65%" }}
                                                className="text-left td_first">
                                                <h3 style={{ fontSize: "18px", fontWeight: "600", color: "#000" }}>Terms & Conditions:</h3>
                                                <p className="mg-b-0">1. Payment must reach us before due date. Interest @24% p.a. will be levied on all delayed payments.</p>
                                                <p className="mg-b-0">2. Payment to be made in favour of <strong>Mash Audio Visuals Pvt. Ltd. payable</strong> at Delhi and send to our address mentioned above.</p>
                                                <p className="mg-b-0">3. Kindly mention on the reverse of the cheque the order Confirmation No. and Invoice No. against which the amount is paid.</p>

                                                <p className="mg-b-0" style={{ marginTop: "10px" }}>
                                                    If you have any problem with your order, please call
                                                    us at <a href="#0">+91-9911366666</a> or
                                                    <a href="#0">+91-1166545466</a> or send us a message
                                                    <a href="mailto:orders@imagesbazaar.com">
                                                        orders@imagesbazaar.com
                                                    </a>
                                                </p>
                                            </td>
                                            <td style={{ width: "35%" }}>
                                                <p className="">For Mesh Audio Visuals Pvt. Ltd.</p>
                                                <p className="mg-b-0 text-center signature">
                                                    Authorised Signatory
                                                </p>
                                            </td>
                                        </tr>
                                    </tbody>
                                </RB.Table>
                            </RB.Col>
                        </RB.Row>
                    </div>

                    <div className="col-md-12">
                        <div className="text-center">
                            <h6
                                style={{ fontWeight: "bold", color: "#000", marginTop: "10px" }}
                            >
                                WE THINK YOU FOR YOUR BUSINESS. WE VALUE YOUR PATRONAGE
                            </h6>
                        </div>
                    </div>
                </RB.Modal.Body>
            </RB.Modal>

            <PaginationComponent MOCK_DATA={Count} currentPage={currentPage} setCurrentPage={setCurrentPage} itemPerPage={itemPerPage} setItemPerPage={setItemPerPage} />

            <Modal text={ModelMsg} open={isOpen} onClose={() => setIsOpen(false)} />

        </RB.Row>
    );
};
export default OrderManageList;