import React, { useState, useEffect } from 'react';
import * as RB from 'react-bootstrap';
import { MdAddCircleOutline } from 'react-icons/md';
import { RiDeleteBin6Line } from "react-icons/ri";
import { BiCommentEdit } from "react-icons/bi";
import AddCountry from "../../../Components/Models/MasterModals/AddCountry";
import EditCountry from "../../../Components/Models/MasterModals/MasterEdit/EditCountry";

import PaginationComponent from "../../../Components/Common/PaginationComponent";

import Modal from "../../../Components/Common/Modal";

import {
  GET_COUNTRYLIST, GET_COUNTRYDETAIL, REMOVE_COUNTRYDETAIL
} from "../../../Utils/api";

export const CountryList = () => {
  const [currentPage, setCurrentPage] = useState(1);
  const [itemPerPage, setItemPerPage] = useState(20);
  let [searchData, setSearchData] = useState("");
  const [TotalCount, setTotalCount] = useState(0)

  const [show_addcountry, setShow] = useState(false);
  const [show_editcountry, setEdit] = useState(false);

  const [CountryData, setCountryData] = useState([]);
  const [userData, setUserData] = useState({});
  const [Loading, setLoading] = useState(false)

  const [Short, setShort] = useState("ascending");

  const [isOpen, setIsOpen] = useState(false);
  const [ModelMsg, setModelMsg] = useState("");

  const [Name, setName] = useState("")

  const SearchDataFun = async (e) => {
    setSearchData(e.target.value);
    const res = await GET_COUNTRYLIST(currentPage, itemPerPage, (searchData = e.target.value));
    let { data, totalrecord } = res;
    setCountryData(data);
    totalrecord.length === 1
      ? setTotalCount(totalrecord[0].totalcount)
      : setTotalCount(0);
  }

  const addcountryShow = async (id) => {
    setShow(true)
  };

  const editcountryShow = async (id) => {
    const res = await GET_COUNTRYDETAIL(id);
    let { data } = res;
    setUserData(data)
    setEdit(true)
  };

  const modelSet = async () => {
    setIsOpen(true);
  };

  const deleteCountryDetail = async (id) => {
    const res = await REMOVE_COUNTRYDETAIL(id);
    let { message } = res;
    apiCall();
    setModelMsg(message);
    modelSet();
  }

  const SortFun = (name) => {
    if (name === "f_country") {
      setName("f_country");
      if (Short === "ascending") {
        const shaloArray = [...CountryData];
        const shortedArray = shaloArray.sort((a, b) => {
          if (
            a.f_country.toLowerCase() >
            b.f_country.toLowerCase()
          )
            return 1;
          if (
            a.f_country.toLowerCase() <
            b.f_country.toLowerCase()
          )
            return -1;
          return 0;
        });
        setCountryData(shortedArray);
        setShort("descending");
      } else {
        setName("f_country");
        const shaloArray = [...CountryData];
        const shortedArray = shaloArray.sort((a, b) => {
          if (
            a.f_country.toLowerCase() >
            b.f_country.toLowerCase()
          )
            return -1;
          if (
            a.f_country.toLowerCase() <
            b.f_country.toLowerCase()
          )
            return 1;
          return 0;
        });
        setCountryData(shortedArray);
        setShort("ascending");
      }
    }
  }


  const apiCall = async () => {
    setLoading(true)
    const res = await GET_COUNTRYLIST(currentPage, itemPerPage, searchData);
    if (res) {
      let { data, totalrecord } = res;
      setCountryData(data);
      setTotalCount(totalrecord[0].totalcount)
      setLoading(false)
    }
  }

  useEffect(() => {
    apiCall()
  }, [currentPage, itemPerPage]);

  return (
    <RB.Row className="rownew1">
      <RB.Col lg={12}>
        <RB.Row className="rownew1" style={{ paddingTop: "25px" }}>
          <div className="tableHeader tableHeader1 order_btntable">
            <RB.Col md={6} xs={12} className="table_span">
              <h3 className="page-title d-flex userv">
                <span>Search Results</span>
              </h3>
            </RB.Col>
            <RB.Col md={6} xs={12} className="table_span">
              <div className="float-right responsive_floatbtn">
                <RB.Button size="sm" variant="primary" className="btn_svg" onClick={() => addcountryShow("ADD USER")}
                >
                  <MdAddCircleOutline style={{ marginRight: "3px" }} />
                  ADD COUNTRY
                </RB.Button>
              </div>
            </RB.Col>
          </div>
        </RB.Row>
      </RB.Col>

      <RB.Col lg={12}>
        <div className="box_detail" style={{ borderRadius: "4px" }}>
          <div className="page-header row">
            <RB.Col md={12}>
              <RB.Form className="manage_searchorder">
                <RB.Row className="mg_row0">
                  <RB.Col lg={12} md={12} className="customer_leftsrh">
                    <RB.Row className="mg_row0">
                      <RB.Col lg={3} md={3} className="customer_sdate">
                        <RB.Form.Group>
                          <RB.Form.Control
                            id="searchText"
                            type="text"
                            placeholder="Search by Text"
                            onChange={SearchDataFun}
                          />
                        </RB.Form.Group>
                      </RB.Col>
                    </RB.Row>
                  </RB.Col>

                </RB.Row>
              </RB.Form>
            </RB.Col>
          </div>
        </div>
      </RB.Col>

      <RB.Col lg={12}>
        <RB.Row className="rownew1">
          <div className="tableHeader tableHeader1 search_new">
            <RB.Col lg={6} md={6} className="table_span">
              <h3 className="page-title d-flex userv">
                <span>Country List</span>
              </h3>
            </RB.Col>
            <RB.Col lg={6} md={6} className="table_span total_recordt">
              <span>Total Records: {TotalCount}</span>
            </RB.Col>
          </div>
        </RB.Row>
        <div
          className="box_detail table_boxdtl manage_order"
          style={{}}
        >
          <RB.Table striped bordered hover variant="dark" responsive>
            <thead>
              <tr class="vtable">
                <th className="text-center">S. No.</th>
                <th className="" onClick={() => SortFun("f_country")}>Country Name</th>
                <th className="text-center action_align">Action</th>
              </tr>
            </thead>
            <tbody>
              {Loading ? <tr><td className="no_records" colSpan="11">Loading...</td></tr> : CountryData.length > 0 ? CountryData.map((info, inx) => {
                let { f_countryid, f_country } = info;
                return (
                  <tr key={`COUNTRYLIST_${inx}`}>
                    {/* <td className="s_notm text-center">{f_countryid}</td> */}
                    <td className="s_notm text-center">{inx + 1}</td>
                    <td className="">{f_country}</td>
                    <td className="td_comments text-center">
                      <BiCommentEdit title="Edit Country" onClick={() => editcountryShow(info._id)} />
                      <RiDeleteBin6Line title="Delete Country" className="text-danger1" onClick={() => { deleteCountryDetail(info._id) }} />
                    </td>
                  </tr>
                )
              }) : <tr><td className="no_records" colSpan="11">No Records Found</td></tr>}
            </tbody>
          </RB.Table>
        </div>
      </RB.Col>

      <PaginationComponent
        MOCK_DATA={TotalCount}
        currentPage={currentPage}
        setCurrentPage={setCurrentPage}
        itemPerPage={itemPerPage}
        setItemPerPage={setItemPerPage}
      />

      <AddCountry
        show_addcountry={show_addcountry}
        setShow={setShow}
        apiCall={apiCall}
      />

      <EditCountry
        show_editcountry={show_editcountry}
        setEdit={setEdit}
        userData={userData}
        apiCall={apiCall}
      />

      <Modal text={ModelMsg} open={isOpen} onClose={() => setIsOpen(false)} />

    </RB.Row>
  )
}

export default CountryList