import React, { useState } from 'react'
import * as RB from "react-bootstrap";
import { Row } from "react-bootstrap";
import { paidProccess } from "../../../Utils/api";

const OrderPaidProcessModal = ({ PaidProcessModel, setPaidProcessModel, PaidOrderId, AfterPaidProccess }) => {
    const [Emails, setEmails] = useState("swadhin@cstech.in")
    const ModalClose = () => setPaidProcessModel(false);

    const onSubmit = async (e) => {
        e.preventDefault();
        let FormData = { OrderIdArray: PaidOrderId, emails: Emails };
        const res = await paidProccess(FormData);
        let { status } = res;
        if (status === 200) {
            AfterPaidProccess()
            setPaidProcessModel(false)
        }
    }
    return (
        <>
            <RB.Modal show={PaidProcessModel} onHide={ModalClose} className="ordermanage_modal">
                <RB.Modal.Header closeButton>
                    <RB.Modal.Title>Order Paid Process</RB.Modal.Title>
                </RB.Modal.Header>
                <RB.Modal.Body>
                    <RB.Row>
                        <RB.Col lg={12} md={12}>
                            <RB.Row>
                                <RB.Col lg={12} md={12}>
                                    <RB.Form>
                                        <RB.Form.Group as={Row} controlId="formbasicemailo">
                                            <RB.Col lg={3} md={3}>
                                                <RB.Form.Label>Order ID :</RB.Form.Label>
                                            </RB.Col>
                                            <RB.Col lg={7} md={7}>
                                                {PaidOrderId.map((data, inx) => <p className="text_modalp add_textmodalp" key={`ORDERID_PROCESS${inx}`}>{data}</p>)}
                                            </RB.Col>
                                        </RB.Form.Group>
                                        <RB.Form.Group as={Row} controlId="formbasicemailo">
                                            <RB.Col lg={3} md={3}>
                                                <RB.Form.Label>Send CC TO :</RB.Form.Label>
                                            </RB.Col>
                                            <RB.Col lg={7} md={7}>
                                                <RB.Form.Control
                                                    type="text"
                                                    value={Emails}
                                                />
                                            </RB.Col>
                                        </RB.Form.Group>
                                        <RB.Row>
                                            <RB.Col lg={3} md={3}></RB.Col>
                                            <RB.Col lg={7} md={7}>
                                                <RB.Button
                                                    size="sm"
                                                    variant="primary"
                                                    onClick={onSubmit}
                                                >
                                                    CONFIRM
                                                </RB.Button>
                                            </RB.Col>
                                        </RB.Row>
                                    </RB.Form>
                                </RB.Col>
                            </RB.Row>
                        </RB.Col>
                    </RB.Row>
                </RB.Modal.Body>
            </RB.Modal>

        </>
    )
}

export default OrderPaidProcessModal
