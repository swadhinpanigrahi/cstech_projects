import React from "react";
import { Link } from "react-router-dom";
import $ from "jquery";
import { useTranslation } from "react-i18next";

const Topbar = () => {
  const { t } = useTranslation();

  const NAME_SECTIONS = [
    {
      name: t("change.dashboard"),
      route: "/dashboard/analytical",
    },
    {
      name: t("change.shipment"),
      route: "/dashboard/shipments/get",
    },
    {
      name: t("change.CODReports"),
      route: "/dashboard/CODReports/get",
    },
    {
      name: t("change.shipReports"),
      route: "/dashboard/statements",
    }
  ];

  const openNav = () => {
    $("#menu").addClass("resmenu");
    $(".resmenu").css("display", "block");
    $(".resmenu").css("width", "250px");
    $("#resmenun").css("display", "block");
    $(".closebtn").css("display", "block");
    $("#resmenun").addClass("mm-listview");
    $("#navm").css("margin-left", "0px");
  };

  const closeNav = () => {
    $("#menu").removeClass("resmenu");
    $("#menu").css("width", "auto");
    $("#resmenun").css("display", "npne");
    $(".mm-listview").css("display", "none");
    $(".closebtn").css("display", "none");
    $("#resmenun").removeClass("mm-listview");
    $("#navm").css("margin-left", "0px");
  };

  $("#resmenun li span a").click(function () {
    setTimeout(function () {
      $("#menu").removeClass("resmenu");
      $("#menu").css("width", "auto");
      $("#resmenun").css("display", "npne");
      $(".mm-listview").css("display", "none");
      $(".closebtn").css("display", "none");
      $("#resmenun").removeClass("mm-listview");
      $("#navm").css("margin-left", "0px");
    }, 1000);
  });
  return (
    <header className="header_in">
      <div className="container-fluid">
        <div className="row">
          <div className="col-lg-12 col-12">
            <ul id="top_menu">
              <li>
                <span>{/* <a className="helpbtn">HELP</a> */}</span>
              </li>
            </ul>

            <span className="hamber" onClick={openNav}>
              &#9776;
            </span>

            <nav id="menu" className="main-menu">
              <a
                href="javascript:void(0)"
                className="closebtn"
                onClick={closeNav}
              >
                &times;
              </a>
              <ul id="resmenun">
                {NAME_SECTIONS.map((data, inx) => {
                  let { name, route } = data;
                  return (
                    <li key={inx}>
                      <span>
                        <Link to={route}>{name}</Link>
                      </span>
                    </li>
                  );
                })}
              </ul>
              <ul id="resmenun1">
                {NAME_SECTIONS.map((data, inx) => {
                  let { name, route } = data;
                  return (
                    <li key={inx}>
                      <span>
                        <Link to={route}>{name}</Link>
                      </span>
                    </li>
                  );
                })}
              </ul>
            </nav>
          </div>
        </div>
      </div>
      <div className="layer"></div>
    </header>
  );
};

export default Topbar;
