const mongoose = require("mongoose");

const t_HighresUserListSchema = mongoose.Schema(
    {
        f_sno: { type: String },
        f_userid: { type: String },
        f_email: { type: String },
        f_status: { type: Number },
        activationdate: { type: Date },
        limit_img: { type: Number },
        ip_address: { type: String },
    },
    { collection: "t_HighresUserList" }
);

module.exports = t_HighresUserList = mongoose.model(
    "t_HighresUserList",
    t_HighresUserListSchema
);