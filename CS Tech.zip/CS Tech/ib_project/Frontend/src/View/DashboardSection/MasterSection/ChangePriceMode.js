import React, { useState } from 'react';
import * as RB from 'react-bootstrap';
import { Row } from "react-bootstrap";
import { ChangePriceForm } from "../../../Components/Forms/FormElements";
import ChangePriceListModal from "../../../Components/Models/MasterModals/ChangePriceListModal";
import { GET_PRICESDETAILS } from "../../../Utils/api";
import Modal from "../../../Components/Common/Modal";


const DropArrayS = [
    { name: "ImagesBazaar/Ingram" },
    { name: "ImagesBazaar" },
    { name: "AsiaImages/ImagesBazaar" },
    { name: "ImagesBazaar/Marinating Films" },
];

const ChangePriceMode = () => {
    const [FormData, setFormData] = useState({})
    const [OpenSearchModel, setOpenSearchModel] = useState(false);

    const [isOpen, setIsOpen] = useState(false);
    const [ModelMsg, setModelMsg] = useState("");

    const modelSet = async () => {
        setIsOpen(true);
    };

    const handleChange = (e) => {
        let { name, value } = e.target
        const data = { ...FormData };
        data[name] = value;
        setFormData(data)
    }

    const OpenSearchModal = () => setOpenSearchModel(true);

    const getId = async (_id) => {
        const res = await GET_PRICESDETAILS(_id);
        setFormData(res.data)
    }

    const onSubmit = async () => {
        let { F_group, f_pricing, nonexclusive, f_agencyname } = FormData;
        if (nonexclusive == 1) {
            const data = { ...FormData };
            FormData.nonexclusive = true
            setFormData(data)
            setModelMsg("price updated successfully!");
            modelSet();
        } else if (nonexclusive == 0 || nonexclusive == false) {
            const data = { ...FormData };
            FormData.nonexclusive = false
            setFormData(data);
            setModelMsg("price updated successfully!");
            modelSet();
        } else if (nonexclusive != 0 || nonexclusive != 0) {
            window.alert("fill 0 or 1 in Nonexclusive field!")
        } else if (!F_group || !f_pricing || !f_agencyname || !nonexclusive) {
            window.alert("fill the requirment fields!")
        }
    }

    return (
        <>
            <RB.Row className="rownew1">
                <RB.Col lg={12}>
                    <RB.Row className="rownew1" style={{ paddingTop: "25px" }}>
                        <div className="tableHeader tableHeader1 order_btntable">
                            <RB.Col md={12} xs={12} className="table_span">
                                <h3 className="page-title d-flex userv">
                                    <span>Change Price Mode</span>
                                </h3>
                            </RB.Col>
                        </div>
                    </RB.Row>
                </RB.Col>

                <div className="col-md-12" style={{ paddingTop: "7px" }}>
                    <div
                        className="box_detail"
                        style={{
                            paddingLeft: "0px",
                            paddingRight: "0px",
                            borderRadius: "4px",
                            paddingTop: "25px",
                        }}
                    >

                        <div className="form-body ">
                            <RB.Form>
                                {ChangePriceForm.map((data, inx) => {
                                    let { label, format, type, name, controlId, forms, title, icon, buttontitle } = data;
                                    return (
                                        <>
                                            {forms === "true" ?
                                                <RB.Form.Group as={Row} key={`${controlId} + ${inx}`}>
                                                    <RB.Col lg={2} md={2}>
                                                        <RB.Form.Label>{label} :</RB.Form.Label>
                                                    </RB.Col>
                                                    <RB.Col lg={3} md={4}
                                                        className="pd-r-0">
                                                        <RB.Form.Control
                                                            type={type} name={name}
                                                            value={name === "nonexclusive"
                                                                ?
                                                                FormData[name] === false ? 0 : null
                                                                :
                                                                FormData[name]}
                                                            onChange={handleChange} />
                                                    </RB.Col>
                                                    <RB.Col lg={4} md={4} className="pd-l-0">
                                                        <span className="formatn1" onClick={OpenSearchModal}>{icon}</span>
                                                        {buttontitle !== " " ?
                                                            <span className="btn_change">{buttontitle}</span>
                                                            :
                                                            <span className="btn_change1"></span>
                                                        }

                                                        <span>{title}</span>
                                                    </RB.Col>
                                                </RB.Form.Group>
                                                :
                                                <RB.Form.Group as={Row}>
                                                    <RB.Col lg={2} md={2}>
                                                        <RB.Form.Label>{label} :</RB.Form.Label>
                                                    </RB.Col>
                                                    <RB.Col lg={3} md={4} className="pd-r-0">
                                                        <RB.Form.Control name={name} as={format} value={FormData[name]} onChange={handleChange}>
                                                            <option>--select--</option>
                                                            {DropArrayS.map((data, inx) => {
                                                                let { name } = data;
                                                                return (
                                                                    <option value={name} key={`DD_${inx}`} >{name}</option>
                                                                )
                                                            })}
                                                        </RB.Form.Control>
                                                    </RB.Col>
                                                </RB.Form.Group>

                                            }
                                        </>
                                    );
                                })}
                                <RB.Row>
                                    <RB.Col lg={2} md={2}></RB.Col>
                                    <RB.Col lg={3} md={3}>
                                        <RB.Button size="sm" variant="primary"
                                            onClick={onSubmit}
                                        >
                                            SUBMIT
                                        </RB.Button>
                                    </RB.Col>
                                </RB.Row>
                            </RB.Form>
                        </div>
                    </div>
                </div>

                <ChangePriceListModal
                    OpenSearchModel={OpenSearchModel} setOpenSearchModel={setOpenSearchModel}
                    getId={getId}
                />

                <Modal text={ModelMsg} open={isOpen} onClose={() => setIsOpen(false)} />

            </RB.Row>
        </>
    )
}

export default ChangePriceMode
