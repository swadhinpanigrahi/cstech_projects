const express = require("express");

const authRouter = require("./Auth.Router");
const adminRoutes = require("./Admin.Router");
const takingRoutes = require("./Traking.Router");
const merchantRouter = require("./Merchant.Router");
const subauthRouter = require("./Subadmin.Router");
const countRouter = require("./Count.Router");

const apiRoutes = express.Router();

apiRoutes.use(`/v1/auth`, authRouter);
apiRoutes.use(`/v2/auth`, adminRoutes);
apiRoutes.use(`/v3/merchant`, merchantRouter);
apiRoutes.use(`/v4/post_shipment`, takingRoutes);
apiRoutes.use(`/v5/subadmin`, subauthRouter);
apiRoutes.use(`/v6/count`, countRouter);

module.exports = apiRoutes;
