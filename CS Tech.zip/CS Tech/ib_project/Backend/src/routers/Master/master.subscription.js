const SubscriptionPlan = require("express").Router();
const {
    addSubscription,
    getSubscriptionlList, getSubscriptionDetail,
    editSubscriptionPlan, removeSubscriptionPlan
} = require("../../controllers/Master/master.subscription.controller");

SubscriptionPlan.route("/addsubscriptionplandetails").post(addSubscription)
SubscriptionPlan.route("/getsubscriptionplandetails/:_id").get(getSubscriptionDetail)
SubscriptionPlan.route("/getsubscriptionplanlist").get(getSubscriptionlList)
SubscriptionPlan.route("/editsubscriptionplan").post(editSubscriptionPlan)
SubscriptionPlan.route("/removesubscriptionplan/:_id").get(removeSubscriptionPlan)

module.exports = SubscriptionPlan;