import React from 'react';
import { Modal, Button, Form, Row, Col } from "react-bootstrap";
import { EmailFeedbackAPI } from "../../../Utils/api";

const FeedbackReplyMailModel = ({ ReplyShow, setReplyShow, userData }) => {
    const [FormData, setFormData] = React.useState({});

    const closeModel = () => setReplyShow(false);

    const handleChange = (e) => {
        let { name, value } = e.target;
        const data = { ...FormData };
        data[name] = value;
        setFormData(data);
    }

    const onSubmit = async () => {
        console.log(FormData);
        const res = await EmailFeedbackAPI(FormData);
        let { message } = res;
        if (message) {
            closeModel();
        }
    }

    React.useEffect(() => {
        setFormData(userData)
    }, [userData])

    return (
        <>
            <Modal
                show={ReplyShow}
                onHide={closeModel}
                backdrop="static"
                keyboard={false}
            >
                <Modal.Header closeButton>
                    <Modal.Title>Modal title</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <Form>
                        <Form.Group as={Row} className="mb-3" controlId="formPlaintextId">
                            <Form.Label column sm="2">
                                Email
                            </Form.Label>
                            <Col sm="10">
                                <Form.Control plaintext readOnly defaultValue={FormData.cs_userid} />
                            </Col>
                        </Form.Group>
                        <Form.Group as={Row} className="mb-3" controlId="formPlaintextEmail">
                            <Form.Label column sm="2">
                                Password
                            </Form.Label>
                            <Col sm="10">
                                <Form.Control type="text" placeholder="Password" defaultValue={FormData.CS_username} disabled />
                            </Col>
                        </Form.Group>
                        <Form.Group as={Row} className="mb-3" controlId="formPlaintextMessage">
                            <Form.Label column sm="2">
                                Enter Message
                            </Form.Label>
                            <Col sm="10">
                                <Form.Control
                                    name="message"
                                    onChange={handleChange}
                                    type="text"
                                    placeholder="Password"
                                />
                            </Col>
                        </Form.Group>
                    </Form>
                </Modal.Body>
                <Modal.Footer>
                    <Button variant="primary" onClick={onSubmit}>Submit</Button>
                </Modal.Footer>
            </Modal>
        </>
    )
}

export default FeedbackReplyMailModel
