const mongoose = require("mongoose");

const FollowupDailySalesSchemaNew = mongoose.Schema(
    {
        f_userid: { type: String },
        f_username: { type: String },
        f_status: { type: String },
        f_desc: { type: String },
        f_createdby: { type: String },
        f_nextfollowupsdate: { type: Date },
        f_date: { type: Date },
        f_followupsby: { type: String },
        f_requirement: { type: String },
        f_contactno: { type: String },
        f_contactperson: { type: String },
    },
    { collection: "t_DailySalesEntryfollowups_sales_IB_MongoDB" }
);

module.exports = FollowupDailySalesSchema = mongoose.model(
    "t_DailySalesEntryfollowups_sales_IB_MongoDB",
    FollowupDailySalesSchemaNew
);
