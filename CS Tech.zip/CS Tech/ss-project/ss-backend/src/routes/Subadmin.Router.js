const express = require("express")
const { createValidator } = require("express-joi-validation");

const {
    getSubAdminList, deleteSubAdmin,
    getSubAdminDetails, editSubUser, activeSubUser,
    getSubCustomerDataBySearch,
    editSubUserPermissions
} = require("../controllers/Subadmin.Controller")

const validator = createValidator({ passError: true });
const subauthRouter = express.Router();

subauthRouter.route(`/getsubadmin`).get(getSubAdminList);
subauthRouter.route(`/deletesubuser/:_id`).get(deleteSubAdmin);
subauthRouter.route(`/getsubadmindetails/:_id`).get(getSubAdminDetails);
subauthRouter.route(`/editsubadmindetails/:_id`).post(editSubUser);
subauthRouter.route(`/active_deactive/:_id`).get(activeSubUser);
subauthRouter.route(`/active_deactive/:_id`).get(activeSubUser);
subauthRouter.route(`/getsubuserdatabysearch`).get(getSubCustomerDataBySearch);
subauthRouter.route(`/editpermissionforsubuser`).post(editSubUserPermissions);

module.exports = subauthRouter;