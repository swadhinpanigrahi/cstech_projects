import React from 'react';
import VideoModal from './VideoModal';
import SubscriptionPlanList from './SubscriptionPlanList';
import CountryList from './CountryList';
import StateList from './StateList';
import CityList from './CityList';
import ImagePriceType from './ImagePriceType';
import ImageSize from './ImageSize';
import ImagePriceDetails from './ImagePriceDetails';
import { Route } from "react-router-dom";
import CompanyList from "./CompanyList";
import IndustryList from "./IndustryList";
import StartSizeList from "./StartSizeList";
import StarPeriodList from "./StarPeriodList";
import DiscounttermsList from "./DiscounttermsList";
import CreditPeriodList from "./CreditPeriodList";
import AgencieList from "./AgencieList";
import TaxUpdate from "./TaxUpdate";
import SimilarGroup from "./SimilarGroup";
import PaymentRightsUpdate from "./PaymentRightsUpdate";

import ImagesVedioSubscriptionPlan from "./ImagesVedioSubscriptionPlan";

import AdminList from "./AdminList";
import SuspendImagesList from "./SuspendImagesList"

import ModelRelease from "./ModelRelease";
import ChangePriceMode from "./ChangePriceMode"

export const MasterSection = () => {
    return (
        <div>
            <Route path="/dashboard/master/get" component={VideoModal} />
            <Route path="/dashboard/master/subscription" component={SubscriptionPlanList} />
            <Route path="/dashboard/master/imagetype" component={ImagePriceType} />
            <Route path="/dashboard/master/imagedetails" component={ImagePriceDetails} />
            <Route path="/dashboard/master/imagesize" component={ImageSize} />
            <Route path="/dashboard/master/country" component={CountryList} />
            <Route path="/dashboard/master/state" component={StateList} />
            <Route path="/dashboard/master/city" component={CityList} />
            <Route path="/dashboard/master/company" component={CompanyList} />
            <Route path="/dashboard/master/industry" component={IndustryList} />
            <Route path="/dashboard/master/starsize" component={StartSizeList} />
            <Route path="/dashboard/master/starperiod" component={StarPeriodList} />
            <Route path="/dashboard/master/discountterm" component={DiscounttermsList} />
            <Route path="/dashboard/master/creditperiod" component={CreditPeriodList} />
            <Route path="/dashboard/master/agencie" component={AgencieList} />
            <Route path="/dashboard/master/imagevediosubscriptionplan" component={ImagesVedioSubscriptionPlan} />
            <Route path="/dashboard/master/taxupdate" component={TaxUpdate} />
            <Route path="/dashboard/master/similargroup" component={SimilarGroup} />
            <Route path="/dashboard/master/paymentrights" component={PaymentRightsUpdate} />
            <Route path="/dashboard/master/adminlist" component={AdminList} />
            <Route path="/dashboard/master/suspendimages" component={SuspendImagesList} />
            <Route path="/dashboard/master/modelrelease" component={ModelRelease} />
            <Route path="/dashboard/master/changepricemodel" component={ChangePriceMode} />
        </div>
    )
}

export default MasterSection