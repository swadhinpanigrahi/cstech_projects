import React, { useState, useEffect } from 'react';
import * as RB from "react-bootstrap";
import { Row } from "react-bootstrap";

import { UPDATE_IMAGETYPEDETAIL } from "../../../../Utils/api"

const EditImageType = (
    { show_editimagetype, setEdit, userData, apiCall }
) => {

    const [FormData, setFormData] = useState({})

    const closeModel = () => {
        setEdit(false)
    }

    const handleChange = (e) => {
        let { name, value } = e.target;
        const data = { ...FormData };
        data[name] = value;
        setFormData(data)
    }

    const EditImageTypeFun = async () => {
        const res = await UPDATE_IMAGETYPEDETAIL(FormData);
        let { message } = res;
        apiCall();
        closeModel();
    }

    useEffect(() => {
        setFormData(userData)
    }, [userData])

    return (
        <div>
            <RB.Modal show={show_editimagetype} onHide={closeModel} className="ordermanage_modal">
                <RB.Modal.Header closeButton>
                    <RB.Modal.Title>Edit Image Price Type</RB.Modal.Title>
                </RB.Modal.Header>
                <RB.Modal.Body>
                    <RB.Row>
                        <RB.Col lg={12} md={12}>
                            <RB.Row>
                                <RB.Col lg={12} md={12}>
                                    <RB.Form>
                                        <RB.Form.Group as={Row} controlId="image_pricet">
                                            <RB.Col lg={5} md={5}>
                                                <RB.Form.Label>Image Price Type Name :</RB.Form.Label>
                                            </RB.Col>
                                            <RB.Col lg={7} md={7}>
                                                <RB.Form.Control
                                                    type="text"
                                                    name="f_pricetypename"
                                                    value={FormData.f_pricetypename}
                                                    onChange={handleChange}
                                                />
                                            </RB.Col>
                                        </RB.Form.Group>
                                        <RB.Row>
                                            <RB.Col lg={5} md={5}></RB.Col>
                                            <RB.Col lg={7} md={7}>
                                                <RB.Button
                                                    size="sm" variant="primary"
                                                    onClick={EditImageTypeFun}
                                                >
                                                    UPDATE
                                                </RB.Button>
                                            </RB.Col>
                                        </RB.Row>
                                    </RB.Form>
                                </RB.Col>
                            </RB.Row>
                        </RB.Col>
                    </RB.Row>
                </RB.Modal.Body>
            </RB.Modal>
        </div>
    )
}

export default EditImageType