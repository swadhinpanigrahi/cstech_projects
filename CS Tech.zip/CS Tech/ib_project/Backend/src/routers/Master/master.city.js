const City = require("express").Router();
const {
    CreateCity, getCityList, getCityListBySearch, getCityDetail, editCityDetails, deleteCityDetails,
    ststeListForCity
} = require("../../controllers/Master/master.city.controller")

City.route(`/ststelistforcity`).get(ststeListForCity);
City.route(`/addcity`).post(CreateCity);
City.route(`/getcitylist`).get(getCityList);
City.route(`/getcitylistbysearch`).get(getCityListBySearch);
City.route(`/getcitydetail/:_id`).get(getCityDetail);
City.route(`/editcitydetails`).post(editCityDetails);
City.route(`/deletecitydetails/:_id`).get(deleteCityDetails);

module.exports = City;