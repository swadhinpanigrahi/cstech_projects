const jwt = require("jsonwebtoken");
const options = {
  expiresIn: "7 days",
};
const { JWT_TOKEN } = require("../config/config");

const generateToken = (tokenData) => {
  let token = jwt.sign(tokenData, JWT_TOKEN, options);
  return token;
};

const veridyEmailPassword = (token) => {
  const tknData = jwt.verify(token, JWT_TOKEN);
  return tknData
};

const checkAuthorization = (req) => {
  let { authorization } = req.headers;
  if (authorization) {
    let token = authorization.split(" ");
    token = jwt.verify(token[token.length - 1], JWT_TOKEN, options);
    return token;
  }
};

module.exports = {
  generateToken,
  checkAuthorization,
  veridyEmailPassword
};
