const mongoose = require("mongoose");

const invoiceSchemas = mongoose.Schema(
    {
        f_sno: { type: String },
        f_orderid: { type: String },
        f_HSN_ACS: { type: String },
        f_imgname: { type: String },
        cratedate: { type: Date },
        f_quality: { type: String },
        f_qty: { type: Number },
        f_price: { type: Number },
        f_totalprice: { type: Number },
        f_discount: { type: Number },
        f_tax: { type: Number },
        f_SGST: { type: Number },
        f_CGST: { type: Number },
        f_IGST: { type: Number },
        f_FinalePrice: { type: Number },
        f_imagetype: { type: String },
        CS_ImgType_up: { type: String },
        f_mydimension: { type: String },
        f_groupid: { type: String },
        f_rank: { type: String }
    },
    { collection: "t_invoice_details_IB_MongoDB" }
);

module.exports = invoiceSchema = mongoose.model("t_invoice_details_IB_MongoDB", invoiceSchemas);
