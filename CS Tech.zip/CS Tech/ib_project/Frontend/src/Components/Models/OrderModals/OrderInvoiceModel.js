import React, { useState, useEffect } from "react";
import * as RB from "react-bootstrap";
import Moment from "moment";
import { AiOutlinePrinter } from "react-icons/ai"
import { useHistory, Link } from "react-router-dom";

const OrderInvoiceModel = ({
  OrderInvoiceIsOpen,
  CloseOrderInvoice,
  OrderInvoiceObj,
  OrderInvoiceList
}) => {
  const [TotalAmount, setTotalAmount] = useState(0);
  const [Discount, setDiscount] = useState(0);
  const [TaxAmount, setTexAmount] = useState(0);
  const [FinalAmount, setFinalAmount] = useState(0);
  console.log(OrderInvoiceObj, OrderInvoiceList);
  useEffect(() => {
    let price = 0;
    let disc = 0;
    OrderInvoiceList.forEach(element => {
      price += element.f_totalprice;
      disc = + element.f_discount
    });
    setTotalAmount(price);
    setDiscount(disc);
    const tax = (price * 18) / 100;
    setTexAmount(tax)
    const finalAmount = price + tax;
    setFinalAmount(finalAmount)
  }, [OrderInvoiceList])
  return (
    <div>
      <RB.Modal
        show={OrderInvoiceIsOpen}
        onHide={CloseOrderInvoice}
        id="orders_modal"
      >
        <RB.Modal.Header closeButton>
          <RB.Modal.Title>Tax Invoice</RB.Modal.Title>
        </RB.Modal.Header>
        <RB.Modal.Body className="invoice_modalbody">
          <RB.Row>
            <RB.Col lg={6}>
              <span className="logo-invoice">
                <img
                  src="http://ibcdn.imagesbazaar.com/Html2015/images/logo_imagesBazaar.png"
                  alt="img_img1"
                />
              </span>
            </RB.Col>

              <RB.Col lg={6} className="text-right print_icon" style={{lineHeight: '60px'}}>
              <Link to="/orderprint/213815">
                <AiOutlinePrinter />
                </Link>
              </RB.Col>
            
            {/* <a href="javascript:print()" className="print_invoice">
                <i className="fa fa-print"></i>
              </a> */}
            {/* <a href="#" className="print_invoice"> */}
            {/* <i className="fa fa-print"></i> */}

            {/* </a> */}

          </RB.Row>
          <div className="main_orders">
            <RB.Row className="headinv" id="invoicem">
              <RB.Col lg={6} className="right_bordertd_detail">
                <p>
                  <strong>Mash Audio Visuals Private Limited</strong>
                </p>
                <p>505, Aggarwal Prestige Mall, Plot No. 2,</p>
                <p>Road No. 44, Pitam Pura, New Delhi - 110034</p>
                <p>Phone: (+91) 11 66545466 | (+91) 11 66545465</p>
                <p class="p_txt">
                  <strong>CIN: </strong> U92111DL2003PTC122096
                </p>
                <p class="p_txt">
                  <strong>GSTIN:</strong> 07AADCM6333L1ZA
                </p>
                <p class="p_txt">
                  <strong>PAN: </strong>AADCM6333L
                </p>
              </RB.Col>
              <RB.Col lg={6} className="pd_0">
                <RB.Table responsive>
                  <tbody>
                    <tr className="border_btm">
                      <td className="td_first">
                        <p class="mg-b-0">
                          <strong>Date:</strong>
                          {Moment(OrderInvoiceObj.invoice_date).format("DD-MM-YYYY")}
                        </p>
                      </td>
                      <td className="td_second">
                        <p class="mg-b-0">
                          <strong>Invoice No.:</strong> {OrderInvoiceObj.invoice_id}
                        </p>
                      </td>
                    </tr>
                    <tr className="border_btm">
                      <td className="td_first">
                        <p class="mg-b-0">
                          <strong>Order Confirmation No.:</strong>  {OrderInvoiceObj.orderid}
                        </p>
                      </td>
                      <td className="td_second">
                        <p class="mg-b-0">
                          <strong>HSN/SAC:</strong> 998439
                        </p>
                      </td>
                    </tr>
                    <tr className="border_btm">
                      <td className="td_first">
                        <p class="mg-b-0">
                          <strong>Mode of Payment:</strong> {OrderInvoiceObj.f_paymode}
                        </p>
                      </td>
                      {/* <td className="td_second">
                        <p class="mg-b-0">
                          <strong>State Code:</strong> 07/DL
                        </p>
                      </td> */}
                    </tr>
                    <tr className="border_btm">
                      <td className="td_first">
                        <p class="mg-b-0">
                          <strong>Payment Status:</strong> {OrderInvoiceObj.t_paymentstatus}
                        </p>
                      </td>
                      <td className="td_second">
                        <p class="mg-b-0">
                          <strong>State:</strong> {OrderInvoiceObj.f_statecrm}
                        </p>
                      </td>
                    </tr>
                  </tbody>
                </RB.Table>
                <RB.Table responsive>
                  <tbody>
                    <tr>
                      <td className="text-left">
                        <p>
                          <strong>Reverse Charges Applicability:</strong> Not
                          Applicable
                        </p>
                        <p>
                          <strong>Place of Supply:</strong> {OrderInvoiceObj.f_statecrm}
                        </p>
                      </td>
                    </tr>
                  </tbody>
                </RB.Table>
              </RB.Col>
            </RB.Row>

            <RB.Row className="headinv" id="invoicem">
              <RB.Col lg={6} className="right_bordertd_detail">
                <p>
                  <strong>Party’s Name:</strong>
                </p>
                <p>{OrderInvoiceObj.address}</p>
                <p>
                  <strong>State:</strong> {OrderInvoiceObj.f_statecrm}{" "}
                  {/* <span style={{ paddingLeft: "10px" }}>
                    <strong>State Code:</strong> 27/Mh
                  </span> */}
                </p>
                <p className="p_txt">
                  <strong>GSTIN:</strong> {OrderInvoiceObj.f_clientGSTIN_no}
                </p>
              </RB.Col>
              <RB.Col lg={6} className="pd_0">
                <RB.Table responsive>
                  <tbody>
                    <tr className="">
                      <td className="text-left">
                        <p>
                          <strong>Client Name:</strong> {OrderInvoiceObj.f_client}
                        </p>
                        <p>
                          <strong>Order By:</strong> {OrderInvoiceObj.orderby}
                        </p>
                      </td>
                    </tr>
                  </tbody>
                </RB.Table>
              </RB.Col>
            </RB.Row>

            <RB.Row className="headinv">
              <RB.Col lg={12} className="pd_0 order_modal_table">
                <RB.Table responsive>
                  <thead className="thead-dark">
                    <tr>
                      <th className="td_first text-center">Image</th>
                      <th className="td_first text-center">Item ID</th>
                      <th className="td_first text-center">Type</th>
                      <th className="td_first text-center">Dimension (Px)</th>
                      <th className="text-right">Value</th>
                    </tr>
                  </thead>
                  <tbody>
                    {OrderInvoiceList.map((data, inx) => (
                      <tr className="border_btm" key={"orderInvoice" + inx}>
                        <td className="td_first">
                          <img src={`https://ibcdn.imagesbazaar.com/img170/${data.f_rank}-${data.f_imgname}.jpg`} alt="invoiceimg" />
                        </td>
                        <td className="td_first">
                          <p class="mg-b-0">{data.f_imgname}</p>
                        </td>
                        <td className="td_first">
                          <p class="mg-b-0">{data.f_quality}</p>
                        </td>
                        <td className="td_first text-center">
                          <p class="mg-b-0">{data.f_mydimension}</p>
                        </td>
                        <td className="td_second">
                          <p class="mg-b-0">{data.f_totalprice}</p>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </RB.Table>
              </RB.Col>
            </RB.Row>
            <RB.Row className="headinv">
              <RB.Col lg={12} className="pd_0 amount_orderdtl">
                <RB.Table responsive>
                  <tbody>
                    <tr className="border_btm">
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td className="text-right td_first">
                        <p className="mg-b-0 resblock">
                          <strong>Total Value (INR)</strong>
                        </p>
                      </td>
                      <td className="text-right">
                        <p class="mg-b-0">{TotalAmount}</p>
                      </td>
                    </tr>
                    <tr className="border_btm">
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td className="text-right td_first">
                        <p className="mg-b-0 resblock">
                          <strong>IGST Value @18% (INR)</strong>
                        </p>
                      </td>
                      <td className="text-right">
                        <p class="mg-b-0">{TaxAmount}</p>
                      </td>
                    </tr>
                    <tr className="border_btm">
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td className="text-right td_first">
                        <p className="mg-b-0 resblock">
                          <strong>Discount</strong>
                        </p>
                      </td>
                      <td className="text-right">
                        <p class="mg-b-0">{Discount}</p>
                      </td>
                    </tr>
                  </tbody>
                </RB.Table>
                <RB.Table responsive>
                  <tbody>
                    <tr>
                      <td className="text-right inv_rightdtl">
                        <p className="mg-b-0">
                          <strong>
                            Total Amount Before GST (SGST / UGST / CGST / IGST)
                          </strong>
                        </p>
                      </td>
                      <td className="text-right">
                        <p className="mg-b-0">{TotalAmount}</p>
                      </td>
                    </tr>
                    <tr>
                      <td className="text-right inv_rightdtl">
                        <p className="mg-b-0">
                          <strong>
                            Total Amount Payable Inclusive of GST (SGST / UGST /
                            CGST / IGST)
                          </strong>
                        </p>
                      </td>
                      <td className="text-right">
                        <p className="mg-b-0">{FinalAmount - Discount}</p>
                      </td>
                    </tr>
                  </tbody>
                </RB.Table>
                <RB.Table responsive>
                  <tbody>
                    <tr>
                      <td className="text-left">
                        <p className="mg-b-0">
                          ImagesBazaar is a unit of Mash Audio Visuals Pvt. Ltd.
                          Usage of content subject to Mash Rights Agreement
                          mentioned on{" "}
                          <a href="#0">www.Imagesbazaar.com/licensing.aspx</a>
                        </p>
                      </td>
                    </tr>
                  </tbody>
                </RB.Table>
                <RB.Table responsive>
                  <tbody>
                    <tr>
                      <td
                        style={{ width: "65%" }}
                        className="text-left td_first"
                      >
                        <p className="mg-b-0">
                          If you have any problem with your order, please call
                          us at <a href="#0">+91-9911366666</a> or{" "}
                          <a href="#0">+91-1166545466</a> or send us a message
                          at{" "}
                          <a href="mailto:orders@imagesbazaar.com">
                            orders@imagesbazaar.com
                          </a>
                        </p>
                      </td>
                      <td style={{ width: "35%" }}>
                        <p className="">For Mesh Audio Visuals Pvt. Ltd.</p>
                        <p className="mg-b-0 text-center signature">
                          Authorised Signatory
                        </p>
                      </td>
                    </tr>
                  </tbody>
                </RB.Table>
              </RB.Col>
            </RB.Row>
          </div>

          <div className="col-md-12" style={{ marginBottom: "20px" }}>
            <div className="text-center">
              <h6
                style={{ fontWeight: "bold", color: "#000", marginTop: "10px" }}
              >
                WE THINK YOU FOR YOUR BUSINESS. WE VALUE YOUR PATRONAGE
              </h6>
            </div>
          </div>
        </RB.Modal.Body>
      </RB.Modal>
    </div>
  );
};

export default OrderInvoiceModel;
