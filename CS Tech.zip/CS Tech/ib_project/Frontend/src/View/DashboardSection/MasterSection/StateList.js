import React, { useState, useEffect } from 'react';
import * as RB from 'react-bootstrap';
import { MdAddCircleOutline } from 'react-icons/md';
import { RiDeleteBin6Line } from "react-icons/ri";
import { BiCommentEdit } from "react-icons/bi";
import AddState from "../../../Components/Models/MasterModals/AddState";

import PaginationComponent from "../../../Components/Common/PaginationComponent";

import EditState from '../../../Components/Models/MasterModals/MasterEdit/EditState';

import {
  GET_COUNTRYS, GET_STATELIST, GET_STATEDETAIL, REMOVE_STATEDETAIL
} from "../../../Utils/api";

import Modal from "../../../Components/Common/Modal";


export const StateList = () => {
  const [currentPage, setCurrentPage] = useState(1);
  const [itemPerPage, setItemPerPage] = useState(20);
  let [searchData, setSearchData] = useState("");
  const [TotalCount, setTotalCount] = useState(0);

  const [show_addstate, setShow] = useState(false);
  const [EditModal, setEditModal] = useState(false);
  const [Loading, setLoading] = useState(false)

  const [isOpen, setIsOpen] = useState(false);
  const [ModelMsg, setModelMsg] = useState("");

  const [CountryData, setCountryData] = useState([]);
  const [StateData, setStateData] = useState([]);
  const [StateDetail, setStateDetail] = useState({});

  const SearchDataFun = async (e) => {
    setSearchData(e.target.value)
    const res = await GET_STATELIST(currentPage, itemPerPage, (searchData = e.target.value));
    let { data, totalrecord } = res;
    setStateData(data);
    totalrecord.length === 1
      ? setTotalCount(totalrecord[0].totalcount)
      : setTotalCount(0);
  }

  const addstateShow = () => setShow(true);  //M

  const EditModalShow = async (id) => {
    const res = await GET_STATEDETAIL(id);
    let { stateDetail } = res;
    setStateDetail(stateDetail)
    setEditModal(true)
  };

  const modelSet = async () => {
    setIsOpen(true);
  };

  const deleteStateFun = async (id) => {
    const res = await REMOVE_STATEDETAIL(id);
    let { message } = res
    apiCall()
    setModelMsg(message);
    modelSet();
  }

  const apiCall = async () => {
    setLoading(true)
    const res = await GET_STATELIST(currentPage, itemPerPage, searchData);
    if (res) {
      let { data, totalrecord } = res;
      setStateData(data);
      setTotalCount(totalrecord[0].totalcount)
      setLoading(false)
    }
  }

  useEffect(() => {
    const apiCall = async () => {
      const res1 = await GET_COUNTRYS();
      setCountryData(res1.data);
    }
    apiCall()
  }, [])

  useEffect(() => {
    apiCall()
  }, [currentPage, itemPerPage])

  return (
    <RB.Row className="rownew1">
      <RB.Col lg={12}>
        <RB.Row className="rownew1" style={{ paddingTop: "25px" }}>
          <div className="tableHeader tableHeader1 order_btntable">
            <RB.Col md={6} xs={12} className="table_span">
              <h3 className="page-title d-flex userv">
                <span>Search Results</span>
              </h3>
            </RB.Col>
            <RB.Col md={6} xs={12} className="table_span">
              <div className="float-right responsive_floatbtn">
                <RB.Button size="sm" variant="primary" className="btn_svg" onClick={addstateShow}
                >
                  <MdAddCircleOutline style={{ marginRight: "3px" }} />
                  ADD STATE
                </RB.Button>
              </div>
            </RB.Col>
          </div>
        </RB.Row>
      </RB.Col>

      <RB.Col lg={12}>
        <div className="box_detail" style={{ borderRadius: "4px" }}>
          <div className="page-header row">
            <RB.Col md={12}>
              <RB.Form className="manage_searchorder">
                <RB.Row className="mg_row0">
                  <RB.Col lg={12} md={12} className="customer_leftsrh">
                    <RB.Row className="mg_row0">
                      <RB.Col lg={3} md={3} className="customer_sdate">
                        <RB.Form.Group>
                          <RB.Form.Control
                            id="searchText"
                            type="text"
                            placeholder="Search by Text"
                            onChange={SearchDataFun}
                          />
                        </RB.Form.Group>
                      </RB.Col>
                    </RB.Row>
                  </RB.Col>

                </RB.Row>
              </RB.Form>
            </RB.Col>
          </div>
        </div>
      </RB.Col>

      <RB.Col lg={12}>
        <RB.Row className="rownew1">
          <div className="tableHeader tableHeader1 search_new">
            <RB.Col lg={6} md={6} className="table_span">
              <h3 className="page-title d-flex userv">
                <span>State List</span>
              </h3>
            </RB.Col>
            <RB.Col lg={6} md={6} className="table_span total_recordt">
              <span>Total Records: {TotalCount}</span>
            </RB.Col>
          </div>
        </RB.Row>
        <div
          className="box_detail table_boxdtl manage_order"
          style={{}}
        >
          <RB.Table striped bordered hover variant="dark" responsive>
            <thead>
              <tr class="vtable">
                <th className="text-center">S. No.</th>
                <th className="">State Name Name</th>
                <th className="">Country Name</th>
                <th className="text-center action_align">Action</th>
              </tr>
            </thead>
            <tbody>
              {Loading ? <tr><td className="no_records" colSpan="11">Loading...</td></tr> : StateData.length > 0 ? StateData.map((info, inx) => {
                return (
                  <tr key={`MASTER_STATE-${inx}`}>
                    <td className="s_notm text-center">{inx + 1}</td>
                    <td className="">{info.f_state}</td>
                    <td className="">{info.country.f_country}</td>
                    <td className="td_comments text-center">
                      <BiCommentEdit title="Edit State" onClick={() => EditModalShow(info._id)} />
                      <RiDeleteBin6Line title="Delete State" className="text-danger1" onClick={() => deleteStateFun(info._id)} />
                    </td>
                  </tr>
                )
              }) : <tr><td className="no_records" colSpan="11">No Records Found</td></tr>}
            </tbody>
          </RB.Table>
        </div>
      </RB.Col>

      <PaginationComponent
        MOCK_DATA={TotalCount}
        currentPage={currentPage}
        setCurrentPage={setCurrentPage}
        itemPerPage={itemPerPage}
        setItemPerPage={setItemPerPage}
      />

      <AddState
        show_addstate={show_addstate}
        CountryData={CountryData}
        setShow={setShow}
        apiCall={apiCall}
      />

      <EditState
        EditModal={EditModal}
        setEditModal={setEditModal}
        CountryData={CountryData}
        StateDetail={StateDetail}
        apiCall={apiCall}
      />

      <Modal text={ModelMsg} open={isOpen} onClose={() => setIsOpen(false)} />


    </RB.Row>
  )
}

export default StateList