import React, { useState, useEffect, useRef, useCallback } from "react";
import Cookie from "js-cookie";
import PageHeaders from "../../../Components/Common/PageHeaders";
import {
  getShipmentDetailsList,
  getShipmentDropdownList,
  shipmentCODButtonFilter,
  getShipmentDetailsForView,
  getShipmentDetailsListForExport,
  shipmentCODReportsButtonFilterExport,
} from "../../../Utils/api";
import { Link } from "react-router-dom";
import { Col, Dropdown, Form } from "react-bootstrap";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import ReactExport from "react-data-export";
import ShipmentView from "../Shipments/ShipmentView";
import SingleSelect from "../../../Utils/Comp";
import SlimSelect from "slim-select";
import "../../../../node_modules/slim-select/dist/slimselect.js";
import "../../../../node_modules/slim-select/dist/slimselect.css";
import Moment from "moment";

const Reports = () => {
  const [ShipmentData, setShipmentData] = useState([]);
  const [Loading, setLoading] = useState(false);
  const [Search, setSearch] = useState("");
  let [pagination, setPagination] = useState(0);
  const [totalPage, setTotalPage] = useState("");
  const [SearchHeader, setSearchHeader] = useState({
    provider: [],
    status: [],
    company: [],
  });
  const [ButtonForm, setButtonForm] = useState({});

  let [startDate, setStartDate] = useState(0);
  let [endDate, setEndDate] = useState(0);

  const [ExportData, setExportData] = useState([]);
  const [IsExportCall, setIsExportCall] = useState(true);

  const [Short, setShort] = useState("ascending");
  const [Name, setName] = useState("");

  const [CODauth, setCODauth] = useState({
    codreports_viewlist: "",
    codreports_exportfile: "",
    codreports_track: "",
  });

  //VIEW MODAL
  const [TrakingData, setTrakingData] = useState({
    totalData: {},
    from_data: {},
    to_data: {},
  });
  const [show, setShow] = useState(false);

  let { codreports_viewlist, codreports_exportfile, codreports_track } =
    CODauth;

  const handleClose = () => setShow(false);
  const handleShow = async (tracking_number) => {
    console.log(tracking_number);
    const res = await getShipmentDetailsForView(tracking_number);
    let { status, trakingData, error } = res;
    if (!error && status === 200) {
      const updateState = { ...TrakingData };
      updateState.totalData = trakingData;
      updateState.from_data = trakingData.from_address;
      updateState.to_data = trakingData.to_address;
      setTrakingData({ ...updateState });
    } else {
      window.alert("Network Error");
    }
    setShow(true);
  };
  //VIEW MODEL

  startDate = startDate === null ? setStartDate(0) : startDate;
  endDate = endDate === null ? setEndDate(0) : endDate;

  const handleChange = async (e) => {
    setSearch(e.target.value);
    const res = await getShipmentDetailsList((pagination = 0), e.target.value);
    let { trakingDetailsList, count } = res;
    const shaloArray = [...trakingDetailsList];
    setShipmentData(shaloArray);
    setTotalPage(count);
  };

  const TotalPage = Math.ceil(totalPage / 20);
  const observer = useRef();
  const lastBookElement = useCallback(
    (node) => {
      if (observer.current) observer.current.disconnect();
      observer.current = new IntersectionObserver(async (entries) => {
        if (ShipmentData.length > 19) {
          if (entries[0].isIntersecting && pagination <= TotalPage) {
            let { shipping_method } = ButtonForm;
            if (startDate === 0 && endDate === 0 && !shipping_method) {
              setPagination((prevPageNumber) => prevPageNumber + 1);
              const res = await getShipmentDetailsList(pagination, Search);
              let { trakingDetailsList } = res;
              let mergeArray = [...ShipmentData, ...trakingDetailsList];
              if (Name !== "" && Name !== "name") {
                if (Short === "ascending") {
                  const shortedArray = mergeArray.sort((a, b) => {
                    if (a[Name] > b[Name]) return -1;
                    if (a[Name] < b[Name]) return 1;
                    return 0;
                  });
                  setShipmentData(shortedArray);
                } else {
                  const shortedArray = mergeArray.sort((a, b) => {
                    if (a[Name] > b[Name]) return 1;
                    if (a[Name] < b[Name]) return -1;
                    return 0;
                  });
                  setShipmentData(shortedArray);
                }
              } else if (Name === "name") {
                if (Short === "ascending") {
                  const shortedArray = mergeArray.sort((a, b) => {
                    if (a.from_address[Name].toLowerCase() > b.from_address[Name].toLowerCase()) return -1;
                    if (a.from_address[Name].toLowerCase() < b.from_address[Name].toLowerCase()) return 1;
                    return 0;
                  });
                  setShipmentData(shortedArray);
                } else {
                  const shortedArray = mergeArray.sort((a, b) => {
                    if (a.from_address[Name].toLowerCase() > b.from_address[Name].toLowerCase()) return 1;
                    if (a.from_address[Name].toLowerCase() < b.from_address[Name].toLowerCase()) return -1;
                    return 0;
                  });
                  setShipmentData(shortedArray);
                }
              } else {
                setShipmentData(mergeArray);
              }
            } else {
              setPagination((prevPageNumber) => prevPageNumber + 1);
              const res = await shipmentCODButtonFilter({
                ...ButtonForm,
                startDate,
                endDate,
                pagination,
              });
              let { error, filteredData } = res;
              if (!error) {
                let mergeArray = [...ShipmentData, ...filteredData];
                setShipmentData(mergeArray);
                if (Name !== "" && Name !== "name") {
                  if (Short === "ascending") {
                    const shortedArray = mergeArray.sort((a, b) => {
                      if (a[Name] > b[Name]) return -1;
                      if (a[Name] < b[Name]) return 1;
                      return 0;
                    });
                    setShipmentData(shortedArray);
                  } else {
                    const shortedArray = mergeArray.sort((a, b) => {
                      if (a[Name] > b[Name]) return 1;
                      if (a[Name] < b[Name]) return -1;
                      return 0;
                    });
                    setShipmentData(shortedArray);
                  }
                } else if (Name === "name") {
                  if (Short === "ascending") {
                    const shortedArray = mergeArray.sort((a, b) => {
                      if (a.from_address[Name].toLowerCase() > b.from_address[Name].toLowerCase())
                        return -1;
                      if (a.from_address[Name].toLowerCase() < b.from_address[Name].toLowerCase()) return 1;
                      return 0;
                    });
                    setShipmentData(shortedArray);
                  } else {
                    const shortedArray = mergeArray.sort((a, b) => {
                      if (a.from_address[Name].toLowerCase() > b.from_address[Name].toLowerCase()) return 1;
                      if (a.from_address[Name].toLowerCase() < b.from_address[Name].toLowerCase())
                        return -1;
                      return 0;
                    });
                    setShipmentData(shortedArray);
                  }
                } else {
                  setShipmentData(mergeArray);
                }
              }
            }
          }
        }
      });
      if (node) observer.current.observe(node);
    },
    [ShipmentData]
  );

  const apiCall = async () => {
    setLoading(true);
    const res = await getShipmentDetailsList(pagination, Search);
    let { error, status, trakingDetailsList, count } = res;
    if (!error && status === 200) {
      setShipmentData([...trakingDetailsList]);
      setTotalPage(count);
      setLoading(false);
    } else {
      window.alert("network error!!");
    }
  };

  const onSearch = async (e) => {
    e.preventDefault();
    setPagination(0);
    if (!ButtonForm.company_name && !ButtonForm.shipping_method && startDate == 0 && endDate == 0) {
      window.alert("select atlist one search field")
    } else {
      const s_date = Moment().format();
      console.log(startDate, endDate, s_date)
      const res = await shipmentCODButtonFilter({
        ...ButtonForm,
        startDate,
        endDate,
        pagination,
      });
      let { error, filteredData, merchantCount } = res;
      if (!error) {
        const shaloArray = [...filteredData];
        setShipmentData(shaloArray);
        merchantCount === undefined
          ? setTotalPage(0)
          : setTotalPage(merchantCount);
      }

      const ExportFilterData = await shipmentCODReportsButtonFilterExport({
        ...ButtonForm,
        startDate,
        endDate,
        pagination,
      });
      let { shipmentExport } = ExportFilterData;
      setExportData(shipmentExport);
    }
  };

  //EXPORT
  const ExcelFile = ReactExport.ExcelFile;
  const ExcelSheet = ReactExport.ExcelFile.ExcelSheet;
  const DataSet = [
    {
      columns: [
        { title: "ORDER ID" },
        { title: "PARTNER ORDERID" },
        { title: "SHIPING PROVIDER" },
        { title: "TYPE" },
        { title: "ORDER NUMBER" },
        { title: "AMOUNT (SAR)" },
        { title: "SHOP NAME" },
        { title: "SHIPING NAME" },
        { title: "ACCOUNT ID" },
        { title: "TRACKING NUMBER" },
        { title: "CREATION DATE" },
        { title: "STATUS" },
        { title: "DELIVERY DATE" },
        { title: "RETURNED DATE" },

        { title: "FROM NAME" },
        { title: "FROM COMPANY NAME" },
        { title: "FROM ADDRESS" },
        { title: "FROM EMAIL" },
        { title: "FROM CITY" },
        { title: "FROM STATE" },
        { title: "FROM ZIP" },
        { title: "FROM COUNTRY" },
        { title: "FROM PHONE" },

        { title: "TO NAME" },
        // { title: "TO COMPANY NAME" },
        // { title: "TO ADDRESS" },
        // { title: "TO EMAIL" },
        // { title: "TO CITY" },
        // { title: "TO STATE" },
        // { title: "TO ZIP" },
        // { title: "TO COUNTRY" },
        // { title: "TO PHONE" },
      ],
      data: ExportData.map((data) => [
        { value: data.order_id },
        { value: data.partner_order_id },
        { value: data.shipping_method },
        { value: "COD" },
        { value: data.order_number },
        { value: data.order_amount },
        { value: data.shop_name },
        { value: data.shipping_name },
        { value: data.account_id },
        { value: data.tracking_number },
        { value: data.createdAt.slice(0, 10) },
        { value: data.fulfillment_status },
        { value: data.t_delivery_date === null ? "" : data.t_delivery_date.slice(0, 10) },
        { value: data.t_return_date === null ? "" : data.t_return_date.slice(0, 10) },

        { value: data.from_address.name },
        { value: data.from_address.company_name },
        { value: data.from_address.address_1 },
        { value: data.from_address.email },
        { value: data.from_address.city },
        { value: data.from_address.state },
        { value: data.from_address.zip },
        { value: data.from_address.country },
        { value: data.from_address.phone },

        { value: data.to_address.name },
        // { value: data.to_address.company_name },
        // { value: data.to_address.address_1 },
        // { value: data.to_address.email },
        // { value: data.to_address.city },
        // { value: data.to_address.state },
        // { value: data.to_address.zip },
        // { value: data.to_address.country },
        // { value: data.to_address.phone },
      ]),
    },
  ];
  //EXPORT

  const countBar = () => {
    return (
      <Col md={12} className="show_count text-center">
        <p>{`showing ${pagination + 1} - ${ShipmentData.length
          } of ${totalPage} items in listing`}</p>
      </Col>
    );
  };

  const sortFun = (type) => {
    if (type === "order_number") {
      if (Short === "ascending") {
        setName("order_number");
        const shaloArray = [...ShipmentData];
        const shortedArray = shaloArray.sort((a, b) => {
          if (a.order_number > b.order_number) return 1;
          if (a.order_number < b.order_number) return -1;
          return 0;
        });
        setShipmentData(shortedArray);
        setShort("descending");
      } else {
        setName("order_number");
        const shaloArray = [...ShipmentData];
        const shortedArray = shaloArray.sort((a, b) => {
          if (a.order_number > b.order_number) return -1;
          if (a.order_number < b.order_number) return 1;
          return 0;
        });
        setShipmentData(shortedArray);
        setShort("ascending");
      }
    }

    if (type === "shipping_method") {
      if (Short === "ascending") {
        setName("shipping_method");
        const shaloArray = [...ShipmentData];
        const shortedArray = shaloArray.sort((a, b) => {
          if (a.shipping_method.toLowerCase() > b.shipping_method.toLowerCase())
            return 1;
          if (a.shipping_method.toLowerCase() < b.shipping_method.toLowerCase())
            return -1;
          return 0;
        });
        setShipmentData(shortedArray);
        setShort("descending");
      } else {
        setName("shipping_method");
        const shaloArray = [...ShipmentData];
        const shortedArray = shaloArray.sort((a, b) => {
          if (a.shipping_method.toLowerCase() > b.shipping_method.toLowerCase())
            return -1;
          if (a.shipping_method.toLowerCase() < b.shipping_method.toLowerCase())
            return 1;
          return 0;
        });
        setShipmentData(shortedArray);
        setShort("ascending");
      }
    }

    if (type === "t_delivery_date") {
      if (Short === "ascending") {
        setName("t_delivery_date");
        const shaloArray = [...ShipmentData];
        const shortedArray = shaloArray.sort((a, b) => {
          if (a.t_delivery_date > b.t_delivery_date) return 1;
          if (a.t_delivery_date < b.t_delivery_date) return -1;
          return 0;
        });
        setShipmentData(shortedArray);
        setShort("descending");
      } else {
        setName("t_delivery_date");
        const shaloArray = [...ShipmentData];
        const shortedArray = shaloArray.sort((a, b) => {
          if (a.t_delivery_date > b.t_delivery_date) return -1;
          if (a.t_delivery_date < b.t_delivery_date) return 1;
          return 0;
        });
        setShipmentData(shortedArray);
        setShort("ascending");
      }
    }

    if (type === "createdAt") {
      if (Short === "ascending") {
        setName("createdAt");
        const shaloArray = [...ShipmentData];
        const shortedArray = shaloArray.sort((a, b) => {
          if (a.createdAt > b.createdAt) return 1;
          if (a.createdAt < b.createdAt) return -1;
          return 0;
        });
        setShipmentData(shortedArray);
        setShort("descending");
      } else {
        setName("createdAt");
        const shaloArray = [...ShipmentData];
        const shortedArray = shaloArray.sort((a, b) => {
          if (a.createdAt > b.createdAt) return -1;
          if (a.createdAt < b.createdAt) return 1;
          return 0;
        });
        setShipmentData(shortedArray);
        setShort("ascending");
      }
    }

    if (type === "name") {
      if (Short === "ascending") {
        setName("name");
        const shaloArray = [...ShipmentData];
        const shortedArray = shaloArray.sort((a, b) => {
          if (
            a.from_address.name.toLowerCase() >
            b.from_address.name.toLowerCase()
          )
            return 1;
          if (
            a.from_address.name.toLowerCase() <
            b.from_address.name.toLowerCase()
          )
            return -1;
          return 0;
        });
        setShipmentData(shortedArray);
        setShort("descending");
      } else {
        setName("name");
        const shaloArray = [...ShipmentData];
        const shortedArray = shaloArray.sort((a, b) => {
          if (
            a.from_address.name.toLowerCase() >
            b.from_address.name.toLowerCase()
          )
            return -1;
          if (
            a.from_address.name.toLowerCase() <
            b.from_address.name.toLowerCase()
          )
            return 1;
          return 0;
        });
        setShipmentData(shortedArray);
        setShort("ascending");
      }
    }
  };

  const listData =
    ShipmentData.length !== 0 ? (
      ShipmentData.map((data, inx) => (
        <tr key={"reports-tbl" + inx} ref={lastBookElement}>
          <td>{data.order_number}</td>
          <td>{data.shipping_method}</td>
          <td>{data.order_amount}</td>
          <td>{data.from_address.name}</td>
          <td>{data.fulfillment_status}</td>
          <td>{data.createdAt.slice(0, 10)}</td>
          <td>{data.t_delivery_date === null ? "" : data.t_delivery_date.slice(0, 10)}</td>
          <td>{data.t_return_date === null ? "" : data.t_return_date.slice(0, 10)}</td>
          <td
            className="text-center view_mod"
            onClick={() => handleShow(data.tracking_number)}
          >
            VIEW
          </td>
          <td className="text-center">
            <Link
              to={`/dashboard/shipments/track/${data.tracking_number}`}
              target="_blank"
            >
              <i
                data-toggle="tooltip"
                data-placement="bottom"
                title="Search"
                className={
                  codreports_track === "true"
                    ? "fa fa-search iconfa"
                    : "testingggg"
                }
              ></i>
            </Link>
          </td>
        </tr>
      ))
    ) : (
      <tr>
        <td className="no_records" colSpan="9">
          NO RECORDS FOUND
        </td>
      </tr>
    );

  useEffect(() => {
    const apiCall1 = async () => {
      const res = await getShipmentDropdownList();
      let { provider, status, company } = res;
      company.sort((a, b) => {
        if (a.toLowerCase() > b.toLowerCase()) return 1;
        if (a.toLowerCase() < b.toLowerCase()) return -1;
        return 0;
      })
      const updateState = { ...SearchHeader };
      updateState.provider = [...provider];
      updateState.status = [...status];
      updateState.company = [...company];
      setSearchHeader({ ...updateState });
    };
    apiCall1();
    apiCall();
  }, []);

  useEffect(() => {
    const fun = async () => {
      const codreports_viewlist = await Cookie.get("codreports_viewlist");
      const codreports_exportfile = await Cookie.get("codreports_exportfile");
      const codreports_track = await Cookie.get("codreports_track");

      const updateState = { ...CODauth };
      updateState.codreports_viewlist = codreports_viewlist;
      updateState.codreports_exportfile = codreports_exportfile;
      updateState.codreports_track = codreports_track;
      setCODauth({ ...updateState });

      console.log(
        "COD COming => ",
        codreports_viewlist,
        codreports_exportfile,
        codreports_track
      );
    };
    if (IsExportCall) {
      const exportFun = async () => {
        const res = await getShipmentDetailsListForExport();
        let { shipmenyDetails } = res;
        console.log(shipmenyDetails);
        setExportData(shipmenyDetails);
        setIsExportCall(false);
        exportFun();
      };
    }
    fun();
    new SlimSelect({
      select: "#slim-select",
    });
  }, []);

  let { provider, company } = SearchHeader;

  const buttonHandleChange = async (e) => {
    let { name, value, type } = e.target;
    if (type === "select-one") {
      let data = { ...ButtonForm };
      data[name] = value;
      setButtonForm({ ...data });
    } else {
      // console.log(type, name, value);
      // const shaloCompanyArray = [...company]
      // const updateState = { ...SearchHeader };
      // updateState.company = shaloCompanyArray.filter(option => option.includes(value));
      // setSearchHeader({ ...updateState })
    }
  };

  return (
    <>
      <Col lg={12}>
        <PageHeaders title="COD Reports" />
        <div>
          <div className="col-md-12">
            <div
              className="box_detail"
              style={{ padding: "15px 0px 10px 0px", marginBottom: "20px" }}
            >
              <div className="col-12" style={{ padding: "0px" }}>
                <div className="page-header row no-gutters">
                  <div className="col-md-12">
                    <h3 className="page-title subtitile">FILTER OPTION</h3>
                  </div>
                  <hr style={{ marginBottom: "0px" }} />
                </div>
              </div>
              <div className="row" style={{ padding: "10px 30px 5px 30px" }}>
                <div className="col-lg-10 col-md-12">
                  <div className="row">
                    <div className="form-group col-lg-2 col-md-4 shipf customers_selectn">
                      <label className="pwdc">3PLCustomer</label>
                      {/* <SingleSelect company={company} /> */}
                      <select
                        className="form-control selectpicker"
                        id="slim-select"
                        name="company_name"
                        onChange={buttonHandleChange}
                        data-live-search="true"
                        style={{ padding: "4px 10px", color: "#000" }}
                      >
                        <option>--Select--</option>
                        {company.map((data, inx) => {
                          return (
                            <option
                              key={"CMNY-STATUS" + inx}
                              data-tokens={data}
                            >
                              {data}
                            </option>
                          );
                        })}
                      </select>
                    </div>

                    <div className="form-group col-lg-2 col-md-4 shipf">
                      <label className="pwdc">Select Provider</label>
                      <select
                        className="form-control"
                        name="shipping_method"
                        onChange={buttonHandleChange}
                        style={{ padding: "4px 10px", color: "#000" }}
                      >
                        {provider.map((data, inx) => {
                          return (
                            <option key={"SHIP-STATUS" + inx}>{data}</option>
                          );
                        })}
                      </select>
                    </div>
                    <div className="form-group col-lg-2 col-md-4 shipf padrig">
                      <label className="pwdc">Start Date</label>
                      <div
                        className="input-container form-control"
                        id="date_end"
                      >
                        <DatePicker
                          placeholderText="Start Date"
                          selected={startDate}
                          onChange={(date) => setStartDate(date)}
                          dateFormat='yyyy/MM/dd'
                        />
                      </div>
                    </div>
                    <div className="form-group col-lg-2 col-md-4 shipf padrig">
                      <label className="pwdc">End Date</label>
                      <div
                        className="input-container form-control"
                        id="date_end"
                      >
                        <DatePicker
                          placeholderText="Start Date"
                          selected={endDate}
                          onChange={(date) => setEndDate(date)}
                          dateFormat='yyyy/MM/dd'
                        />
                      </div>
                    </div>
                    <div className="col-lg-1 col-md-12 resmart1">
                      <label
                        className="pwdc new_rc"
                        style={{ color: "transparent" }}
                      >
                        Shipment
                      </label>
                      <button className="searchs" onClick={onSearch}>
                        SEARCH
                      </button>
                    </div>
                  </div>
                </div>
                <div className="form-group col-lg-2 col-md-4 shipf padrig ship_pad">
                  <div className="">
                    <label className="pwdc">OrderID / Name</label>
                    <input
                      type="text"
                      placeholder="Search by OrderID/Name"
                      onChange={handleChange}
                      className="form-control"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
          <Col md={12} className="text-right">
            <span className="count_customer">Total Records: {totalPage}</span>
            <ExcelFile
              fillename="sheet"
              element={
                ShipmentData.length !== 0 ? (
                  <button
                    className={
                      codreports_exportfile === "true"
                        ? "export_btn addbce customer_export"
                        : "display"
                    }
                  >
                    EXPORT
                  </button>
                ) : (
                  <button
                    className={
                      codreports_exportfile === "true"
                        ? "export_btn addbce1 customer_export"
                        : "display"
                    }
                    disabled
                  >
                    EXPORT
                  </button>
                )
              }
            >
              <ExcelSheet dataSet={DataSet} name="shipment reports" />
            </ExcelFile>
            {/* <span className="count_customer">{totalPage}</span> */}
          </Col>
          <Col md={12}>
            <hr />
            <div
              className="box_detail tableboxdc"
              style={{
                paddingTop: "0px",
                paddingBottom: "0px",
                marginBottom: "0px",
              }}
            >
              <table
                className="table table-bordered table-responsive"
                id="table-to-xls"
              >
                <thead className="thead-dark">
                  <tr>
                    <th
                      className="sorting"
                      onClick={() => sortFun("order_number")}
                    >
                      ORDER NUMBER
                    </th>
                    <th
                      className="sorting"
                      onClick={() => sortFun("shipping_method")}
                    >
                      SHIPING PROVIDER
                    </th>
                    <th>AMOUNT (SAR)</th>
                    <th className="sorting" onClick={() => sortFun("name")}>
                      NAME
                    </th>
                    <th>STATUS</th>
                    <th className="sorting" onClick={() => sortFun("createdAt")}>
                      CREATION DATE
                    </th>
                    <th className="sorting" onClick={() => sortFun("t_delivery_date")}>
                      DELIVERY DATE
                    </th>
                    <th className="sorting" onClick={() => sortFun("t_delivery_date")}>
                      RETURNED DATE
                    </th>
                    <th className="text-center">VIEW</th>
                    <th className="text-center">TRACK</th>
                  </tr>
                </thead>
                <tbody>
                  {Loading ? (
                    <tr>
                      <td className="no_records" colSpan="8">
                        Loading....
                      </td>
                    </tr>
                  ) : (
                    [listData]
                  )}
                </tbody>
              </table>
            </div>
          </Col>
        </div>
        {countBar()}
      </Col>
      <ShipmentView
        show={show}
        handleClose={handleClose}
        TrakingData={TrakingData}
      />
    </>
  );
};

export default Reports;
