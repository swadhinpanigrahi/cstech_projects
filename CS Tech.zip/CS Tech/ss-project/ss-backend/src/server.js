const express = require("express")
const apiRoutes = require("./routes")
const { PORT } = require("./config")
const { dbConnect } = require("./services/database")
const { APIError } = require("./utilities/APIError")
const { generateError, NOT_FOUND } = require("./utilities/errorContants")
const { errorHandler } = require("./middlewares/errorMiddleware")
const logger = require("./utilities/logger")
const cors = require("cors")

const bodyParser = express.json();
const app = express();

app.use(
  cors()
);

app.use(bodyParser);

app.use(`/api`, apiRoutes);

app.get("/", (req, res) => res.send("Health Ok"));
app.get("/test", (req, res) => res.send("Health Ok"));
app.get("/test11", (req, res) => res.send("Testing Health Ok"));

app.use((req, res, next) => {
  next(new APIError(404, NOT_FOUND));
});

app.use(errorHandler);

const startServer = async () => {
  try {
    await dbConnect();
    app.listen(PORT, () => {
      logger.info(
        `Server Started on PORT : ${PORT}, and Db Connected Successfully`
      );
    });
  } catch (error) {
    logger.error(
      `Error while starting application and connecting database server error=> ${generateError(
        error
      )}`
    );
  }
};

startServer();
