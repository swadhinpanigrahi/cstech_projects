import React, { useState } from "react";
import { changePassForm } from "../../Components/Forms/FormElements";
import { changepasswordApi, logOutApi } from "../../Utils/api";
import { Form, Row, Col, Button } from "react-bootstrap";
import PageHeaders from "../../Components/Common/PageHeaders";
import { useHistory } from "react-router-dom";
import { changePasswordFormValidation } from "../../Utils/validation";

const ChangePassword = () => {
  const history = useHistory();
  const [FormData, setFormData] = useState({});
  const [Loading, setLoading] = useState("SUBMIT");
  const [Error, setError] = useState({
    errMsg: "",
    errClr: "",
  });
  const [errors, setErrors] = useState({});

  const handleChange = (e) => {
    let { name, value } = e.target;
    const data = { ...FormData };
    data[name] = value;
    setFormData(data);
    let updateStatus = { ...Error };
    updateStatus.errCls = "";
    updateStatus.errMsg = "";
    setError({ ...updateStatus });
    let updateStatusE = { ...errors };
    updateStatusE.currPassword = "";
    updateStatusE.newPassword = "";
    updateStatusE.confirmPassword = "";
    setError({ ...updateStatusE });
    setErrors(updateStatusE);
  };

  const changeLoading = () => {
    setLoading("Loading...");
    setTimeout(() => {
      setLoading("SUBMIT");
    }, 1000);
  };

  const onSubmit = async (e) => {
    e.preventDefault();
    if (
      FormData.currPassword &&
      FormData.newPassword &&
      FormData.confirmPassword
    ) {
      const res = await changepasswordApi(FormData);
      const { error, message, updateUser } = res;
      if (!error) {
        if (updateUser) {
          let updateStatus = { ...Error };
          updateStatus.errMsg = "password changed successfully!!";
          setError({ ...updateStatus });
          await logOutApi();
          setTimeout(() => {
            history.push("/");
            window.location.reload();
          }, 2000);
        } else {
          changeLoading();
          let updateStatus = { ...Error };
          updateStatus.errMsg = message;
          setError({ ...updateStatus });
        }
      } else {
        changeLoading();
        let updateStatus = { ...Error };
        updateStatus.errMsg = "Network Error";
        setError({ ...updateStatus });
      }
    } else {
      let updateStatus = { ...Error };
      updateStatus.errCls = "border-danger";
      setError({ ...updateStatus });
      setErrors(changePasswordFormValidation(FormData));
    }
  };

  let { errMsg, errCls } = Error;

  return (
    <main className="main_afterlogin">
      <Row className="rownew1" style={{ paddingTop: "25px" }}>
        <Col lg={12}>
          <Row className="rownew1">
            <div className="tableHeader tableHeader1 search_new">
              <Col lg={12} md={12} xs={12} className="table_span">
                <h3 className="page-title d-flex userv">
                  <span>Change Password</span>
                </h3>
              </Col>
            </div>
          </Row>
        </Col>
        <Col lg={12}>
          <div className="box_detail new_boxdtl" style={{ borderRadius: "4px" }}>
            <Row>
              <Col lg={3}></Col>
              <Col lg={6}>
                <Form.Text className="text-danger error_text incorrect_err">
                  {Loading === "Loading..." ? "" : errMsg ? errMsg : ""}
                </Form.Text>
              </Col>
            </Row>

            <Form onSubmit={onSubmit} className="form_changepwd">
              {changePassForm.map((data, inx) => {
                let { type, name, placeholder, controlId, label } = data;
                return (
                  <Form.Group as={Row} controlId={controlId} key={controlId + inx}>
                    <Form.Label column lg="3">
                      {label} :
                </Form.Label>
                    <Col lg="6">
                      <Form.Control
                        type={type}
                        name={name}
                        value={FormData[name]}
                        placeholder={placeholder}
                        onChange={handleChange}
                        className={
                          Loading === "Loading..." ? "" : errCls ? errCls : ""
                        }
                      />
                      {Loading === "Loading..."
                        ? ""
                        : errors[name] && (
                          <Form.Text className="text-danger">{errors[name]}</Form.Text>
                        )}
                    </Col>
                  </Form.Group>
                );
              })}
              <Row>
                <Col lg={3}></Col>
                <Col lg={6}>
                  <Button type="submit" size="sm" variant="primary">
                    {Loading}
                  </Button>
                </Col>
              </Row>
            </Form>
          </div>
        </Col>
      </Row>
    </main>
  );
};

export default ChangePassword;
