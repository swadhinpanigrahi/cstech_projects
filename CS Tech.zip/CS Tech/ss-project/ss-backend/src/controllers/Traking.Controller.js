const logger = require("../utilities/logger");
const { Merchant, Payment, TrackData, Log, PreShipLog, DeleteShipLog } = require("../models/model.index");
const { APIError } = require("../utilities/APIError");
const Axios = require("axios")
const {
    generateError,
    ERROR_STATUS_CODE,
    INTERNAL_SERVER_ERROR,
    EMAIL_NOT_EXISTS,
    WRONG_PASSWORD,
    PERMISSION_DENIED,
    USER_ALREADY_EXISTS,
    UNEXPECTED_ERROR
} = require("../utilities/errorContants");
const { randomId } = require("../utilities/helper")
const { merchantAutoRegistrationEmail } = require("../services/nodeMailer/sendMail");

exports.postShipmentAPI = async (req, res, next) => {
    const data = req.body;
    const { shipping_method, order_id, profile, fulfillment_status,
        order_number, shop_name, account_id, partner_order_id, shipping_name,
        from_address, to_address, tracking_number, label_url, order_amount } = data;
    const { name, company_name, address_1, email, city, state, zip, country, phone } = from_address;
    try {

        const customerData = await Merchant.findOne({ email })
        if (customerData) {
            const saveShipment = await TrackData({
                userId: customerData._id, shipping_method, order_id, profile, fulfillment_status, order_number, shop_name, account_id,
                partner_order_id, shipping_name, from_address, to_address, tracking_number, label_url, order_amount
            }).save();
            const newpaymentModel = await new Payment({
                userId: customerData._id, seller_entry_name: customerData.name,
                account_number: customerData.account_number, beneficiary_name: customerData.name, bank_name: customerData.bank_name, payment_type: "Credit",
                payed_amount: saveShipment.order_amount, comment: `Credit for Order No. ${saveShipment.order_id}`, tracking_number,
            }).save();
            res.json({ status: 200, message: `shipment created successfully!`, saveShipment, newpaymentModel })
        }

        if (!customerData) {

            const checkEmail = email.split("@")
            if (checkEmail[1] === "storagestation.net") {
                const newCustomer = await new Merchant({ name, email, phone, password: checkEmail[0], companyName: company_name, address: address_1, pincode: zip, city, state, country }).save();
                const newShipment = await new TrackData({
                    userId: newCustomer._id, shipping_method, order_id, profile, fulfillment_status, order_number, shop_name, account_id,
                    partner_order_id, shipping_name, from_address, to_address, tracking_number, label_url, order_amount
                }).save();
                const newpaymentModel = await new Payment({
                    userId: newCustomer._id, seller_entry_name: newCustomer.name,
                    account_number: newCustomer.account_number, beneficiary_name: newCustomer.name, bank_name: newCustomer.bank_name, payment_type: "Credit",
                    payed_amount: newShipment.order_amount, comment: `Credit for Order No. ${newShipment.order_id}`, tracking_number,
                }).save();
                res.json({ message: "let's create password with user", newShipment, password: checkEmail[0], newpaymentModel });

            } else {

                const password = randomId("", 8, true);
                const newCustomer = await new Merchant({ name, email, phone, password: password, companyName: company_name, address: address_1, pincode: zip, city, state, country }).save()
                const newShipment = await new TrackData({
                    userId: newCustomer._id, shipping_method, order_id, profile, fulfillment_status, order_number, shop_name, account_id,
                    partner_order_id, shipping_name, from_address, to_address, tracking_number, label_url, order_amount
                }).save();
                const newpaymentModel = await new Payment({
                    userId: newCustomer._id, seller_entry_name: newCustomer.name,
                    account_number: newCustomer.account_number, beneficiary_name: newCustomer.name, bank_name: newCustomer.bank_name, payment_type: "Credit",
                    payed_amount: newShipment.order_amount, comment: `Credit for Order No. ${newShipment.order_id}`, tracking_number,
                }).save();
                merchantAutoRegistrationEmail(
                    {
                        email: newCustomer.email,
                        password: newCustomer.password,
                        name: newCustomer.name,
                    },
                    (data, error) => {
                        if (!error) {
                            logger.info(
                                `Email created successfully and this is the info () => ${data}`
                            );
                        } else {
                            logger.error(
                                `This is the error while generating emai info () => ${error}`
                            );
                        }
                    }
                );
                res.json({ message: "let's create user", newShipment, password, newpaymentModel });

            }
        }
    } catch (error) {
        logger.error(
            `Error while registering user with details ${JSON.stringify(
                req.body
            )} and error ${generateError(error)}`
        );
        return next(
            new APIError(
                ERROR_STATUS_CODE.INTERNAL_SERVER_ERROR_CODE,
                INTERNAL_SERVER_ERROR,
                error.message
            )
        );
    }
}

exports.getlogdetail = async (req, res, next) => {
    const { order_number } = req.params;
    try {
        const data = await PreShipLog.find({ order_number }).sort({ _id: -1 });
        res.json({ data })
    } catch (error) {
        logger.error(
            `Error while registering user with details ${JSON.stringify(
                req.body
            )} and error ${generateError(error)}`
        );
        return next(
            new APIError(
                ERROR_STATUS_CODE.INTERNAL_SERVER_ERROR_CODE,
                INTERNAL_SERVER_ERROR,
                error.message
            )
        );
    }
}

exports.updateShipment = async (req, res, next) => {
    const { _id, tracking_number, order_number, shipping_method } = req.body;
    try {
        const existingData = await TrackData.findOne({ _id });
        if (existingData) {
            const newObj = await new PreShipLog({
                order_number, old_tracking_number: existingData.tracking_number, tracking_number,
                old_shipping_method: existingData.shipping_method, shipping_method
            }).save();
            await Payment.updateMany({ tracking_number: existingData.tracking_number }, {
                $set: {
                    tracking_number
                }
            })
            if (newObj) {
                await TrackData.updateOne({ _id: existingData._id }, {
                    $set: {
                        tracking_number,
                        shipping_method
                    }
                })
                res.json({ status: 200, message: `successfully updated` })
            }
        }

    } catch (error) {
        logger.error(
            `Error while registering user with details ${JSON.stringify(
                req.body
            )} and error ${generateError(error)}`
        );
        return next(
            new APIError(
                ERROR_STATUS_CODE.INTERNAL_SERVER_ERROR_CODE,
                INTERNAL_SERVER_ERROR,
                error.message
            )
        );
    }
}

exports.removeShipment = async (req, res, next) => {
    const { _id } = req.params;
    try {
        const deletedData = await TrackData.findByIdAndRemove({ _id });
        await new DeleteShipLog({ removed_shipment: deletedData }).save();
        await Payment.deleteMany({ tracking_number: deletedData.tracking_number })
        res.json({ status: 200, message: "successfully removed" })
    } catch (error) {
        logger.error(
            `Error while registering user with details ${JSON.stringify(
                req.body
            )} and error ${generateError(error)}`
        );
        return next(
            new APIError(
                ERROR_STATUS_CODE.INTERNAL_SERVER_ERROR_CODE,
                INTERNAL_SERVER_ERROR,
                error.message
            )
        );
    }
}

/**
 * SINGLE-STATUS UPDATE START --- (Delivery and Return)
*/

exports.statusChangeForAll = async (req, res, next) => {
    const data = req.body;
    let { code, comment, description, location, time, waybill } = data;
    console.log(code, comment, description, location, time, waybill)
    try {
        const trakData = await TrackData.findOne({ tracking_number: waybill, fulfillment_status: { $ne: "returned" } });
        if (trakData && trakData.shipping_method === "Aramex COD") {
            if (code === "SH005" || code === "SH006" || code === "SH007" || code === "SH034"
                || code === "SH534" || code === "SH496" || code === "SH597" || code === "SH234" ||
                code === "SH154"
            ) {
                await TrackData.updateOne({ _id: trakData._id }, {
                    $set: {
                        fulfillment_status: "delivered",
                        t_delivery_date: time,
                    }
                });
                res.json({ message: "successfulyy updated!!", code })
            } else if (code === "SH069" || code === "SH407" || code === "SH559") {
                await TrackData.updateOne({ _id: trakData._id }, {
                    $set: {
                        fulfillment_status: "returned",
                        t_return_date: time,
                    }
                });
                res.json({ message: "successfulyy updated!!", code })
            }
        }

        if (trakData && trakData.shipping_method === "SMSA COD") {
            if (code === "PROOF OF DELIVERY CAPTURED") {
                await TrackData.updateOne({ _id: trakData._id }, {
                    $set: {
                        fulfillment_status: "delivered",
                        t_delivery_date: time,
                    }
                });
                res.json({ message: "successfulyy updated!!" })
            }
        }

        if (trakData && trakData.shipping_method === "Wayxpress COD") {
            if (code === "completed") {
                await TrackData.updateOne({ _id: trakData._id }, {
                    $set: {
                        fulfillment_status: "delivered",
                        t_delivery_date: time,
                    }
                });
                res.json({ message: "successfulyy updated!!" })
            }
        }

    } catch (error) {
        logger.error(
            `Error while registering user with details ${JSON.stringify(
                req.body
            )} and error ${generateError(error)}`
        );
        return next(
            new APIError(
                ERROR_STATUS_CODE.INTERNAL_SERVER_ERROR_CODE,
                INTERNAL_SERVER_ERROR,
                error.message
            )
        );
    }
}

/**
 * SINGLE-STATUS UPDATE START --- (Delivery and Return)
*/

/**
 * MULTIPLE-STATUS UPDATE START --- (Delivery and Return)
*/

//-------Delivery(START)

//--ARAMAX
exports.getARAMEXshipments = async (req, res, next) => {
    try {
        const trakingDetails = await TrackData.find(
            { shipping_method: "Aramex COD", fulfillment_status: "pending", running_status: 0 },
            { shipping_method: 1, order_id: 1, tracking_number: 1, fulfillment_status: 1 }
        ).sort({ createdAt: -1 }).limit(500)
        res.json({ trakingDetails })
    } catch (error) {
        logger.error(
            `Error while registering user with details ${JSON.stringify(
                req.body
            )} and error ${generateError(error)}`
        );
        return next(
            new APIError(
                ERROR_STATUS_CODE.INTERNAL_SERVER_ERROR_CODE,
                INTERNAL_SERVER_ERROR,
                error.message
            )
        );
    }
}

exports.statusChangeForAramex = async (req, res, next) => {
    const data = req.body;
    let { code, comment, description, location, time, waybill } = data;
    console.log(code, comment, description, location, time, waybill)
    try {
        const trakData = await TrackData.findOne({ tracking_number: waybill });
        if (trakData && trakData.shipping_method === "Aramex COD") {
            if (code === "SH005" || code === "SH006" || code === "SH007" || code === "SH034"
                || code === "SH534" || code === "SH496" || code === "SH597" || code === "SH234" ||
                code === "SH154"
            ) {
                await TrackData.updateOne({ _id: trakData._id }, {
                    $set: {
                        fulfillment_status: "delivered",
                        t_delivery_date: time,
                        running_status: 1
                    }
                });
                res.json({ message: "successfulyy updated!!", code })
            } else {
                await TrackData.updateOne({ _id: trakData._id }, {
                    $set: {
                        running_status: 1
                    }
                });
                res.json({ message: "successfulyy updated!!", code })
            }
        }
    } catch (error) {
        logger.error(
            `Error while registering user with details ${JSON.stringify(
                req.body
            )} and error ${generateError(error)}`
        );
        return next(
            new APIError(
                ERROR_STATUS_CODE.INTERNAL_SERVER_ERROR_CODE,
                INTERNAL_SERVER_ERROR,
                error.message
            )
        );
    }
}

//---SMSA
exports.getSMSAshipments = async (req, res, next) => {
    try {
        const trakingDetails = await TrackData.find(
            { shipping_method: "SMSA COD", fulfillment_status: "pending", running_status: 0 },
            { shipping_method: 1, order_id: 1, tracking_number: 1, fulfillment_status: 1 }
        ).sort({ createdAt: 1 }).limit(500)
        res.json({ trakingDetails })
    } catch (error) {
        logger.error(
            `Error while registering user with details ${JSON.stringify(
                req.body
            )} and error ${generateError(error)}`
        );
        return next(
            new APIError(
                ERROR_STATUS_CODE.INTERNAL_SERVER_ERROR_CODE,
                INTERNAL_SERVER_ERROR,
                error.message
            )
        );
    }
}

exports.statusChangeForSmsa = async (req, res, next) => {
    const data = req.body;
    let { code, comment, description, location, time, waybill } = data;
    console.log(code, comment, description, location, time, waybill)
    try {
        const trakData = await TrackData.findOne({ tracking_number: waybill });
        if (trakData && trakData.shipping_method === "SMSA COD") {
            if (code === "PROOF OF DELIVERY CAPTURED") {
                await TrackData.updateOne({ _id: trakData._id }, {
                    $set: {
                        fulfillment_status: "delivered",
                        t_delivery_date: time,
                        running_status: 1
                    }
                });
                res.json({ message: "successfulyy updated!!" })
            } else {
                await TrackData.updateOne({ _id: trakData._id }, {
                    $set: {
                        running_status: 1
                    }
                });
                res.json({ message: "successfulyy updated!!" })
            }
        }
    } catch (error) {
        logger.error(
            `Error while registering user with details ${JSON.stringify(
                req.body
            )} and error ${generateError(error)}`
        );
        return next(
            new APIError(
                ERROR_STATUS_CODE.INTERNAL_SERVER_ERROR_CODE,
                INTERNAL_SERVER_ERROR,
                error.message
            )
        );
    }
}

//---WAYPRESS
exports.getWAYXPRESSshipments = async (req, res, next) => {
    try {
        const trakingDetails = await TrackData.find(
            { shipping_method: "Wayxpress COD", fulfillment_status: "pending", running_status: 0 },
            { shipping_method: 1, order_id: 1, tracking_number: 1, fulfillment_status: 1 }
        ).sort({ createdAt: 1 }).limit(500)
        res.json({ trakingDetails })
    } catch (error) {
        logger.error(
            `Error while registering user with details ${JSON.stringify(
                req.body
            )} and error ${generateError(error)}`
        );
        return next(
            new APIError(
                ERROR_STATUS_CODE.INTERNAL_SERVER_ERROR_CODE,
                INTERNAL_SERVER_ERROR,
                error.message
            )
        );
    }
}

exports.statusChangeForWaypress = async (req, res, next) => {
    const data = req.body;
    let { code, comment, description, location, time, waybill } = data;
    console.log(code, comment, description, location, time, waybill)
    try {
        const trakData = await TrackData.findOne({ tracking_number: waybill });
        if (trakData && trakData.shipping_method === "Wayxpress COD") {
            if (code === "completed") {
                await TrackData.updateOne({ _id: trakData._id }, {
                    $set: {
                        fulfillment_status: "delivered",
                        t_delivery_date: time,
                        running_status: 1
                    }
                });
                res.json({ message: "successfulyy updated!!" })
            } else {
                await TrackData.updateOne({ _id: trakData._id }, {
                    $set: {
                        running_status: 1
                    }
                });
                res.json({ message: "successfulyy updated!!" })
            }
        }
    } catch (error) {
        logger.error(
            `Error while registering user with details ${JSON.stringify(
                req.body
            )} and error ${generateError(error)}`
        );
        return next(
            new APIError(
                ERROR_STATUS_CODE.INTERNAL_SERVER_ERROR_CODE,
                INTERNAL_SERVER_ERROR,
                error.message
            )
        );
    }
}

//------------Return Start
exports.getArmaxDeliveryData = async (req, res, next) => {
    try {
        const shipmentData = await TrackData.find(
            { fulfillment_status: { $in: ["pending", "delivered"] }, shipping_method: "Aramex COD", is_return: false },
            { shipping_method: 1, order_id: 1, tracking_number: 1, fulfillment_status: 1 }
        ).sort({ _id: -1 }).limit(100)
        res.json({ status: 200, shipmentData })
    } catch (error) {
        logger.error(
            `Error while registering user with details ${JSON.stringify(
                req.body
            )} and error ${generateError(error)}`
        );
        return next(
            new APIError(
                ERROR_STATUS_CODE.INTERNAL_SERVER_ERROR_CODE,
                INTERNAL_SERVER_ERROR,
                error.message
            )
        );
    }
}


exports.AramaxStatusUpdateToReturn = async (req, res, next) => {
    const data = req.body;
    let { code, comment, description, location, time, waybill } = data;
    try {
        const trakData = await TrackData.findOne({ tracking_number: waybill });
        if (trakData && trakData.shipping_method === "Aramex COD") {
            if (code === "SH069" || code === "SH407" || code === "SH559") {
                await TrackData.updateOne({ _id: trakData._id }, {
                    $set: {
                        fulfillment_status: "returned",
                        t_return_date: time,
                        is_return: true
                    }
                });
                res.json({ message: "successfulyy updated!!", code })
            } else {
                await TrackData.updateOne({ _id: trakData._id }, {
                    $set: {
                        is_return: true
                    }
                });
                res.json({ message: "successfulyy updated!!", code })
            }
        }
    } catch (error) {
        logger.error(
            `Error while registering user with details ${JSON.stringify(
                req.body
            )} and error ${generateError(error)}`
        );
        return next(
            new APIError(
                ERROR_STATUS_CODE.INTERNAL_SERVER_ERROR_CODE,
                INTERNAL_SERVER_ERROR,
                error.message
            )
        );
    }
}

/**
 * MULTIPLE-STATUS UPDATE END --- (Delivery and Return)
*/

exports.resetRuningStatus = async (req, res, next) => {
    try {
        await TrackData.updateMany(
            { fulfillment_status: "pending", running_status: 1 },
            {
                $set: {
                    running_status: 0
                }
            }
        )

        res.json({ message: `script is running successfully!!` })
    } catch (error) {
        logger.error(
            `Error while registering user with details ${JSON.stringify(
                req.body
            )} and error ${generateError(error)}`
        );
        return next(
            new APIError(
                ERROR_STATUS_CODE.INTERNAL_SERVER_ERROR_CODE,
                INTERNAL_SERVER_ERROR,
                error.message
            )
        );
    }
}

exports.resetDeliveryStatus = async (req, res, next) => {
    try {
        await TrackData.updateMany(
            { fulfillment_status: "delivered", is_return: true },
            {
                $set: {
                    is_return: false
                }
            }
        )

        res.json({ message: `script is running successfully!!` })
    } catch (error) {
        logger.error(
            `Error while registering user with details ${JSON.stringify(
                req.body
            )} and error ${generateError(error)}`
        );
        return next(
            new APIError(
                ERROR_STATUS_CODE.INTERNAL_SERVER_ERROR_CODE,
                INTERNAL_SERVER_ERROR,
                error.message
            )
        );
    }
}


// EXTRA APIS

exports.assiningDate = async (req, res) => {
    try {
        const undatedData = await TrackData.find(
            { fulfillment_status: "delivered", t_delivery_date: null },
            { shipping_method: 1, tracking_number: 1 }
        ).limit(100);
        undatedData.forEach(async (element) => {
            let { shipping_method, tracking_number } = element;
            const resp = await Axios.get("https://app.sky-sa.net/api/track-shipment", {
                params: { tracking_number: tracking_number, provider: shipping_method },
            });
            const { statuses } = resp.data.data;
            if (statuses) {
                statuses.forEach(async (element) => {
                    let { code, comment, description, location, time, waybill } = element;
                    const trakData = await TrackData.findOne({ tracking_number: waybill });
                    if (trakData && trakData.shipping_method === "Aramex COD") {
                        if (code === "SH005" || code === "SH006" || code === "SH007" || code === "SH034"
                            || code === "SH534" || code === "SH496" || code === "SH597" || code === "SH234" ||
                            code === "SH154"
                        ) {
                            await TrackData.updateOne({ _id: trakData._id }, {
                                $set: {
                                    t_delivery_date: time,
                                }
                            });
                        }
                    }
                    if (trakData && trakData.shipping_method === "SMSA COD") {
                        if (code === "PROOF OF DELIVERY CAPTURED") {
                            await TrackData.updateOne({ _id: trakData._id }, {
                                $set: {
                                    t_delivery_date: time,
                                }
                            });
                        }
                    }
                    if (trakData && trakData.shipping_method === "Wayxpress COD") {
                        if (code === "completed") {
                            await TrackData.updateOne({ _id: trakData._id }, {
                                $set: {
                                    t_delivery_date: time,
                                }
                            });
                        }
                    }
                })
            }
        })
        res.json({ undatedData })
    } catch (error) {
        res.json({ message: "internal server error", error: error.message })
    }
}