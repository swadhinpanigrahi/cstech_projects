const State = require("express").Router();
const {
    getStateNormal, getStateList, getStateListBySearch,
    getStateDetail, editStateDetail, deleteStateDetail, addState
} = require("../../controllers/Master/master.state.controller")

State.route(`/addstate`).post(addState);
State.route(`/getstatelistnormal`).get(getStateNormal);
State.route(`/getstatelist`).get(getStateList);
State.route(`/getstatelistbysearch`).get(getStateListBySearch);
State.route(`/getstatedetails/:_id`).get(getStateDetail);
State.route(`/editstatedetails`).post(editStateDetail);
State.route(`/deletestatedetails/:_id`).get(deleteStateDetail)

module.exports = State;