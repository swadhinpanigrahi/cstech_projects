const mongoose = require("mongoose");

const t_DailySalesEntryfollowups_sales_IB_MongoDB_Schema = mongoose.Schema(
  {
    f_sno: { type: String },
    f_userid: { type: String },
    f_username: { type: String },
    f_status: { type: String },
    f_desc: { type: String },
    f_createby: { type: String },
    f_nextfollowupsdate: { type: String },
    f_date: { type: String },
    f_followupsby: { type: String },
    f_requrement: { type: String },
    f_contactno: { type: String },
    f_contactperson: { type: String },
  },
  { collection: "t_DailySalesEntryfollowups_sales_IB_MongoDB" }
);

module.exports = t_DailySalesEntryfollowups_sales_IB_MongoDB = mongoose.model(
  "t_DailySalesEntryfollowups_sales_IB_MongoDB",
  t_DailySalesEntryfollowups_sales_IB_MongoDB_Schema
);
