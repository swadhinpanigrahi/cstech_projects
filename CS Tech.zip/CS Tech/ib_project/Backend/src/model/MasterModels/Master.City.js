const mongoose = require("mongoose");

const MasterCitySchema = mongoose.Schema(
    {
        f_cityid: { type: String },
        f_countryid: { type: String },
        f_stateid: { type: String },
        f_cityname: { type: String },
        f_status: { type: String },
        f_creationdate: { type: Date }
    },
    { collection: "t_city" }
);

module.exports = M_CITY = mongoose.model(
    "t_city",
    MasterCitySchema
);