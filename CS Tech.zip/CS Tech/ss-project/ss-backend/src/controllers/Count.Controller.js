const logger = require("../utilities/logger")
const { Merchant, Payment, TrackData } = require("../models/model.index")
const { APIError } = require("../utilities/APIError")
const {
    generateError,
    ERROR_STATUS_CODE,
    INTERNAL_SERVER_ERROR,
    EMAIL_NOT_EXISTS,
    WRONG_PASSWORD,
    PERMISSION_DENIED,
    USER_ALREADY_EXISTS,
    UNEXPECTED_ERROR
} = require("../utilities/errorContants");
const { getDateArr } = require("../utilities/helper");

exports.getTrakingDetailsByButtonSearchCount = async (req, res, next) => {
    const data = req.body;
    let { shipping_method, fulfillment_status, startDate, endDate, pagination } = data;
    if (!shipping_method) shipping_method = "All Provider"
    if (!fulfillment_status) fulfillment_status = "All Status"
    console.log(shipping_method, fulfillment_status, startDate, endDate)
    var s_date = new Date(startDate);
    var e_date = new Date(endDate);
    s_date.setHours(1);
    e_date.setHours(23);
    let pipeline;
    try {
        if (shipping_method === "All Provider" && fulfillment_status === "All Status" && startDate === 0 && endDate === 0) {
            pipeline = [{ $count: "count" }]
            const filteredData = await TrackData.aggregate(pipeline)
            res.json({ filteredData })
        }

        if (startDate == 0 && endDate == 0) {
            if (shipping_method != "All Provider" && fulfillment_status != "All Status") {
                pipeline = [{ $match: { shipping_method, fulfillment_status } }, { $count: "count" }]
            }
            if (shipping_method != "All Provider" && fulfillment_status == "All Status") {
                pipeline = [{ $match: { shipping_method } }, { $count: "count" }]
            }
            if (shipping_method == "All Provider" && fulfillment_status != "All Status") {
                pipeline = [{ $match: { fulfillment_status } }, { $count: "count" }]
            }
        }

        if (startDate != 0 && endDate != 0) {
            if (shipping_method == "All Provider" && fulfillment_status == "All Status") {
                pipeline = [
                    {
                        $match: {
                            createdAt: {
                                $gte: s_date,
                                $lte: e_date,
                            },
                        }
                    },
                    {
                        $count: "count"
                    }
                ];
            }
            if (shipping_method != "All Provider" && fulfillment_status != "All Status") {
                pipeline = [
                    {
                        $match: {
                            shipping_method,
                            fulfillment_status,
                            createdAt: {
                                $gte: s_date,
                                $lte: e_date,
                            },
                        }
                    },
                    {
                        $count: "count"
                    }
                ];
            }
            if (shipping_method != "All Provider" && fulfillment_status == "All Status") {
                pipeline = [
                    {
                        $match: {
                            shipping_method,
                            createdAt: {
                                $gte: s_date,
                                $lte: e_date,
                            },
                        }
                    },
                    {
                        $count: "count"
                    }
                ];
            }
            if (shipping_method == "All Provider" && fulfillment_status != "All Status") {
                pipeline = [
                    {
                        $match: {
                            fulfillment_status,
                            createdAt: {
                                $gte: s_date,
                                $lte: e_date,
                            },
                        }
                    },
                    {
                        $count: "count"
                    }
                ];
            }

        }
        const filteredData = await TrackData.aggregate(pipeline);
        console.log(filteredData)
        res.json({ count: filteredData[0].count })

    } catch (error) {
        logger.error(
            `Error while registering user with details ${JSON.stringify(
                req.body
            )} and error ${generateError(error)}`
        );
        return next(
            new APIError(
                ERROR_STATUS_CODE.INTERNAL_SERVER_ERROR_CODE,
                INTERNAL_SERVER_ERROR,
                error.message
            )
        );
    }
}

exports.CODbuttonSearch = async (req, res, next) => {
    const data = req.body
    let { shipping_method, startDate, endDate, pagination } = data;
    var s_date = new Date(startDate);
    var e_date = new Date(endDate);
    let limit = 20
    s_date.setHours(1);
    e_date.setHours(23);
    let pipeLine;
    try {
        if (!shipping_method && startDate == 0 && endDate == 0) {
            pipeLine = [{ $count: "count" }]
            // const filteredData = await TrackData.find({}).skip(limit * pagination).limit(20).sort({ createdAt: -1 })
            // res.json({ message: "1st", filteredData })
        } else if (shipping_method && startDate == 0 && endDate == 0) {
            pipeLine = [{ $match: { shipping_method } }, { $count: "count" }]
            const filteredData = await TrackData.find({ shipping_method }).skip(limit * pagination).limit(20).sort({ createdAt: -1 })
            if (filteredData <= 0) {
                let filteredData = await TrackData.find({}).skip(limit * pagination).limit(20).sort({ createdAt: -1 })
                res.json({ filteredData })
            } else {
                res.json({ message: "2nd", filteredData })
            }
        } else if (!shipping_method || shipping_method === "All Providers" && startDate != 0 && endDate != 0) {
            console.log(shipping_method, startDate, endDate)
            var pipeline = [
                {
                    $match: {
                        createdAt: {
                            $gte: s_date,
                            $lte: e_date,
                        },
                    },
                },
                {
                    $skip: limit * pagination
                },
                {
                    $limit: 20
                },
                {
                    $sort: { createdAt: -1 }
                }
            ];
            let filteredData = await TrackData.aggregate(pipeline);
            res.json({ message: "3st", filteredData })
        } else {
            var pipeline = [
                {
                    $match: {
                        shipping_method,
                        createdAt: {
                            $gte: s_date,
                            $lte: e_date,
                        },
                    },
                },
                {
                    $skip: limit * pagination
                },
                {
                    $limit: 20
                },
                {
                    $sort: { createdAt: -1 }
                }
            ];
            let filteredData = await TrackData.aggregate(pipeline);
            if (shipping_method === "All Providers") {
                let filteredData = await TrackData.find({}).skip(limit * pagination).limit(20).sort({ createdAt: -1 })
                res.json({ filteredData })
            } else {
                if (filteredData <= 0) {
                    var pipeline = [
                        {
                            $match: {
                                createdAt: {
                                    $gte: s_date,
                                    $lte: e_date,
                                },
                            },
                        },
                        {
                            $skip: limit * pagination
                        },
                        {
                            $limit: 20
                        },
                        {
                            $sort: { createdAt: -1 }
                        }
                    ];
                    let filteredData = await TrackData.aggregate(pipeline);
                    res.json({ message: "4st", filteredData })
                } else {
                    res.json({ message: "4st", filteredData })
                }
            }
        }
    } catch (error) {
        logger.error(
            `Error while registering user with details ${JSON.stringify(
                req.body
            )} and error ${generateError(error)}`
        );
        return next(
            new APIError(
                ERROR_STATUS_CODE.INTERNAL_SERVER_ERROR_CODE,
                INTERNAL_SERVER_ERROR,
                error.message
            )
        );
    }
}