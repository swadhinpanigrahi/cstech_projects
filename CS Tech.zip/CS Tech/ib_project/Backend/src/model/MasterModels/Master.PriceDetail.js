const mongoose = require("mongoose");

const MasterPriceDetailsSchema = mongoose.Schema(
    {
        f_id: { type: Number },
        f_refid: { type: String },
        f_refname: { type: String },
        f_typeid: { type: String },
        f_typename: { type: String },
        f_dimenation: { type: String },
        f_dpi: { type: String },
        f_outputsize: { type: String },
        f_price: { type: String },
        f_time: { type: String },
        f_showprice: { type: String },
        f_showdiscount: { type: String },
    },
    { collection: "t_pricingdetail" }
);

module.exports = M_PRICEDETAIL = mongoose.model(
    "t_pricingdetail",
    MasterPriceDetailsSchema
);