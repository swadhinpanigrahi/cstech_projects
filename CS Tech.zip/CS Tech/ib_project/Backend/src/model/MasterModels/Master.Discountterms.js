const mongoose = require("mongoose");

const MasterDiscounttermsSchema = mongoose.Schema(
    {
        f_sno: { type: String },
        f_discountterm: { type: String },
        f_description: { type: String },
    },
    { collection: "t_discountterms" }
);

module.exports = M_DISCOUNTTERMS = mongoose.model(
    "t_discountterms",
    MasterDiscounttermsSchema
);