import React, { useEffect, useState } from "react";
import { Line } from "react-chartjs-2";
import icon1 from "../../../Images/icon1.png";
import icon3 from "../../../Images/icon3.png";
import { useTranslation } from "react-i18next";

const CountCard = ({ graph, totalAmount, balanceAmount }) => {
    const { t } = useTranslation();

    const [charData, setCharData] = useState({});

    useEffect(() => {
        const Chart = () => {
            let userNum = [];
            let dateNum = [];
            for (const dataObj of graph) {
                userNum.push(parseInt(dataObj.count));
                dateNum.push(dataObj._id);
            }
            setCharData({
                labels: dateNum,
                datasets: [
                    {
                        label: t("change.totalOrder"),
                        data: userNum,
                        backgroundColor: ["rgba(75, 192, 192, 0.6)"],
                    },
                ],
            });
        }
        Chart()
    }, [t, graph])

    return (
        <>
            <Line
                data={charData}
                width={100}
                height={20}
                options={{
                    scales: { yAxes: [{ ticks: { beginAtZero: true } }] },
                }}
            />
            <div className="row" style={{ marginTop: "20px" }}>
                <div className="col-lg-6 col-md-6">
                    <div className="box_detail fstbox">
                        <div className="row mg-0">
                            <div className="col-md-4 col-12 dash_cen">
                                <img src={icon1} alt="icon1" />
                            </div>
                            <div className="col-md-8 col-12 dash_cen">
                                <h5 className="titleh5 ordnew">{t("change.tCOD")}</h5>
                                <h5 className="titleh5 count-item">{totalAmount}</h5>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="col-lg-6 col-md-6">
                    <div className="box_detail fstbox2">
                        <div className="row mg-0">
                            <div className="col-md-4 col-12 dash_cen">
                                <img src={icon3} alt="icon3" />
                            </div>
                            <div className="col-md-8 col-12 dash_cen">
                                <h5 className="titleh5u ordnew">{t("change.bCOD")}</h5>
                                <h5 className="titleh5u count-item">
                                    {balanceAmount === 0 ? totalAmount : totalAmount - balanceAmount}
                                </h5>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default CountCard
