import React, { useState, useEffect } from 'react';
import * as RB from "react-bootstrap";
import { Row } from "react-bootstrap";
import { ImageDetailsModal } from "../../../../Components/Forms/FormElements";

import { UPDATE_PRICEDETAIL } from "../../../../Utils/api"


const EditPriceDetailsModal = (
    { show_editpricedtl, setEdit, userData, apiCall }
) => {

    const [FormData, setFormData] = useState({});

    const handleChange = (e) => {
        let { name, value } = e.target;
        const data = { ...FormData }
        data[name] = value
        setFormData(data)
    }

    const closeModal = () => {
        setEdit(false)
    }

    const EditSubmit = async () => {
        const res = await UPDATE_PRICEDETAIL(FormData);
        let { message } = res;
        apiCall();
        closeModal();
    }

    useEffect(() => {
        setFormData(userData)
    }, [userData])

    return (
        <div>
            <RB.Modal show={show_editpricedtl} onHide={closeModal} className="ordermanage_modal">
                <RB.Modal.Header closeButton>
                    <RB.Modal.Title>Edit Image Price</RB.Modal.Title>
                </RB.Modal.Header>
                <RB.Modal.Body>
                    <RB.Row>
                        <RB.Col lg={12} md={12}>
                            <RB.Row>
                                <RB.Col lg={12} md={12}>
                                    <RB.Form>
                                        {ImageDetailsModal.map((data, inx) => {
                                            let { label, type, name, format, controlId, forms, dropArrays } = data;
                                            return (
                                                <>
                                                    {forms === "true" ?
                                                        <RB.Form.Group as={Row} controlId={controlId} key={controlId + inx}>
                                                            <RB.Col lg={5} md={5}>
                                                                <RB.Form.Label>{label} :</RB.Form.Label>
                                                            </RB.Col>
                                                            <RB.Col lg={6} md={6}>
                                                                <RB.Form.Control
                                                                    type={type}
                                                                    name={name}
                                                                    onChange={handleChange}
                                                                    value={FormData[name]}
                                                                    as={format}
                                                                />
                                                            </RB.Col>
                                                        </RB.Form.Group>
                                                        :
                                                        <RB.Form.Group as={Row} controlId={controlId} key={controlId + inx}>
                                                            <RB.Col lg={5} md={5}>
                                                                <RB.Form.Label>{label} :</RB.Form.Label>
                                                            </RB.Col>
                                                            <RB.Col lg={6} md={6}>
                                                                <RB.Form.Control
                                                                    name={name}
                                                                    as={format}
                                                                    onChange={handleChange}
                                                                >
                                                                    <option value={FormData[name]}>{FormData[name]}</option>
                                                                    {dropArrays.map((data, inx) => {
                                                                        let { name } = data;
                                                                        return (
                                                                            <option value={name}>{name}</option>
                                                                        )
                                                                    })}
                                                                </RB.Form.Control>
                                                            </RB.Col>
                                                        </RB.Form.Group>
                                                    }
                                                </>

                                            );

                                        })}
                                        <RB.Row>
                                            <RB.Col lg={5} md={5}></RB.Col>
                                            <RB.Col lg={6} md={6}>
                                                <RB.Button
                                                    size="sm" variant="primary"
                                                    onClick={EditSubmit}
                                                >
                                                    UPDATE
                                                </RB.Button>
                                            </RB.Col>
                                        </RB.Row>
                                    </RB.Form>
                                </RB.Col>
                            </RB.Row>
                        </RB.Col>
                    </RB.Row>
                </RB.Modal.Body>
            </RB.Modal>
        </div>
    )
}

export default EditPriceDetailsModal;