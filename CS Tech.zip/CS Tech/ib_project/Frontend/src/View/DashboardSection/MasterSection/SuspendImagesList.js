import React, { useState, useEffect } from 'react';
import * as RB from 'react-bootstrap';
import { MdAddCircleOutline } from 'react-icons/md';

import { GET_SUSPNDIMG, UPDATE_SUSPENDIMG } from "../../../Utils/api";

import PaginationComponent from "../../../Components/Common/PaginationComponent";

import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";

import Modal from "../../../Components/Common/Modal";


export const SuspendImagesList = () => {
    const [currentPage, setCurrentPage] = useState(1);
    const [itemPerPage, setItemPerPage] = useState(20);
    const [searchData, setSearchData] = useState("");
    const [TotalCount, setTotalCount] = useState(0);
    const [Loading, setLoading] = useState(false);
    const [SuspendModalOpen, setSuspendModalOpen] = useState(false);
    const [selectedEmails, setSelectedEmails] = useState([]);


    const [isOpen, setIsOpen] = useState(false);
    const [ModelMsg, setModelMsg] = useState("");

    const [SuspendedList, setSuspendedList] = useState([])

    const onSubmit = async () => {
        const res = await GET_SUSPNDIMG(currentPage, itemPerPage, searchData);
        let { data, totalrecord } = res;
        setSuspendedList(data)
        totalrecord.length === 1
            ? setTotalCount(totalrecord[0].totalcount)
            : setTotalCount(0);
    }

    const OpenSuspendedModal = () => {
        if (selectedEmails.length > 0) {
            setSuspendModalOpen(true)
        } else {
            window.alert("please select atleast one image for suspend!")
        }
    }

    useEffect(() => {
        const GET_API = async () => {
            const res = await GET_SUSPNDIMG(currentPage, itemPerPage, searchData);
            let { data, totalrecord } = res;
            setSuspendedList(data)
            totalrecord.length === 1
                ? setTotalCount(totalrecord[0].totalcount)
                : setTotalCount(0);
        }
        if (SuspendedList.length !== 0) {
            GET_API();
        }
    }, [currentPage, itemPerPage]);

    return (
        <RB.Row className="rownew1">
            <RB.Col lg={12}>
                <RB.Row className="rownew1" style={{ paddingTop: "25px" }}>
                    <div className="tableHeader tableHeader1 order_btntable">
                        <RB.Col md={6} xs={12} className="table_span">
                            <h3 className="page-title d-flex userv">
                                <span>Search Results</span>
                            </h3>
                        </RB.Col>
                        <RB.Col md={6} xs={12} className="table_span">
                            <div className="float-right responsive_floatbtn">
                                <RB.Button size="sm" variant="primary" className="btn_svg"
                                    onClick={OpenSuspendedModal}
                                >
                                    <MdAddCircleOutline style={{ marginRight: "3px" }} />
                                    SUSPENDED
                                </RB.Button>
                            </div>
                        </RB.Col>
                    </div>
                </RB.Row>
            </RB.Col>

            <RB.Col lg={12}>
                <div className="box_detail" style={{ borderRadius: "4px" }}>
                    <div className="page-header row">
                        <RB.Col md={12}>
                            <RB.Form className="manage_searchorder">
                                <RB.Row className="mg_row0">
                                    <RB.Col lg={12} md={12} className="customer_leftsrh">
                                        <RB.Row className="mg_row0">
                                            <RB.Col lg={3} md={3} className="customer_sdate">
                                                <RB.Form.Group>
                                                    <RB.Form.Control
                                                        type="text"
                                                        placeholder="Enter suspended Image ID"
                                                        name="F_imgid"
                                                        onChange={(e) => setSearchData([e.target.name] = e.target.value)}
                                                    />
                                                </RB.Form.Group>
                                            </RB.Col>
                                            <RB.Col lg={1} md={1} ></RB.Col>
                                            <RB.Col lg={2} md={2}>
                                                <RB.Button size="sm" variant="primary" className="btn_svg"
                                                    onClick={onSubmit}
                                                >
                                                    <MdAddCircleOutline style={{ marginRight: "3px" }} />
                                                    SUBMIT
                                                </RB.Button>
                                            </RB.Col>
                                        </RB.Row>
                                    </RB.Col>

                                </RB.Row>
                            </RB.Form>
                        </RB.Col>
                    </div>
                </div>
            </RB.Col>

            <RB.Col lg={12}>
                <RB.Row className="rownew1">
                    <div className="tableHeader tableHeader1 search_new">
                        <RB.Col lg={6} md={6} className="table_span">
                            <h3 className="page-title d-flex userv">
                                <span>Suspended Image List</span>
                            </h3>
                        </RB.Col>
                        <RB.Col lg={6} md={6} className="table_span total_recordt">
                            <span>Total Records: {TotalCount}</span>
                        </RB.Col>
                    </div>
                </RB.Row>
                <div
                    className="box_detail table_boxdtl manage_order">
                    <RB.Table striped bordered hover variant="dark" responsive>
                        <thead>
                            <tr class="vtable">
                                <th className="">Image ID</th>
                                <th className="">Group ID</th>
                                <th className="">Pricing</th>
                                <th className="text-center action_align">suspend Image</th>
                            </tr>
                        </thead>
                        <tbody>
                            {Loading ? <tr><td className="no_records" colSpan="11">Loading...</td></tr> : SuspendedList.length > 0 ?
                                <TableData
                                    {...{
                                        info: SuspendedList,
                                        selectedEmails,
                                        setSelectedEmails,
                                    }} /> : <tr><td className="no_records" colSpan="11">No Records Found</td></tr>}
                        </tbody>
                    </RB.Table>
                </div>
            </RB.Col>

            <PaginationComponent
                MOCK_DATA={TotalCount}
                currentPage={currentPage}
                setCurrentPage={setCurrentPage}
                itemPerPage={itemPerPage}
                setItemPerPage={setItemPerPage}
            />

            <SuspendModal
                SuspendModalOpen={SuspendModalOpen}
                setSuspendModalOpen={setSuspendModalOpen}
                selectedEmails={selectedEmails}
            />

            {/* <Modal text={ModelMsg} open={isOpen} onClose={() => setIsOpen(false)} /> */}


        </RB.Row>
    )
}

export default SuspendImagesList

const TableData = ({
    info,
    handleShow,
    selectedEmails: selectedEmail,
    setSelectedEmails,
}) => {
    const handleCheck = (e, f_email) => {
        let { checked } = e.target;
        let selectedEmailVal = [...selectedEmail];
        if (checked) {
            selectedEmailVal.push(f_email);
        } else {
            let delIndex = selectedEmailVal.indexOf(f_email);
            selectedEmailVal.splice(delIndex, 1);
        }
        setSelectedEmails(selectedEmailVal);
    };
    return info.length !== 0 ? (
        info.map((data, inx) => {
            return (
                <tr key={"UN-CUSTOMER_NAV_TBL" + inx}>
                    <td className="">{data.F_imgid}</td>
                    <td className="">{data.F_group}</td>
                    <td className="">{data.f_pricing}</td>
                    <td>
                        <RB.Form.Group className="mb-3" controlId="formBasicCheckbox">
                            <RB.Form.Check
                                type="checkbox"
                                name={data.F_imgid}
                                checked={selectedEmail.includes(data.F_imgid) || false}
                                onChange={(e) => {
                                    handleCheck(e, data.F_imgid);
                                }}
                            />
                        </RB.Form.Group>
                    </td>
                </tr>
            );
        })
    ) : (
        <tr>
            <td class="no_records" colspan="11">
                No Records Found
            </td>
        </tr>
    );
};


const SuspendModal = ({ SuspendModalOpen, setSuspendModalOpen, selectedEmails }) => {

    const [suspendate, setsuspendate] = useState(new Date())

    const closeModal = () => {
        setSuspendModalOpen(false)
    }

    const Suspend = async () => {
        const res = await UPDATE_SUSPENDIMG({ suspendate, images: selectedEmails });
        if (res) {
            closeModal()
        }
        console.log(suspendate, selectedEmails)
    }

    return (
        <>
            <RB.Modal show={SuspendModalOpen} onHide={closeModal}>
                <RB.Modal.Header closeButton>
                    <RB.Modal.Title>Modal heading</RB.Modal.Title>
                </RB.Modal.Header>
                <RB.Modal.Body>
                    {selectedEmails.map((list, inx) => {
                        return (
                            <li key={`SUSPENDNAMELST_${inx}`}>{list}</li>
                        )
                    })}
                    <DatePicker selected={suspendate} onChange={(date) => setsuspendate(date)} />
                </RB.Modal.Body>
                <RB.Modal.Footer>
                    <RB.Button variant="secondary" onClick={Suspend}>
                        Close
                    </RB.Button>
                    <RB.Button variant="primary" onClick={closeModal}>
                        Save Changes
                    </RB.Button>
                </RB.Modal.Footer>
            </RB.Modal>
        </>
    )
}