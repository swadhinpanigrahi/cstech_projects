const {
  T_Orders_IB_MongoDB,
  orderDetailSchema,
  RegistrationSchema,
  HdfcHistorySchema,
  Counter,
  PurchaseImageSchema,
  order,
  T_ShopingCart
} = require("../model");

const fs = require("fs");
const request = require('request')
const { dir } = require("../config/fileSource");
const { SQL_URL } = require('../config/config')
const {
  IBPaidProcess, IBOrderConfirmation,
  OrderPaymentActionMail,
  OrderDetailActionCCMail
} = require("../utils/nodeMailer/sendMail");
require('../config/dbContextMongo');

exports.getOrderByEmailData = async (req, res) => {
  const { T_username } = req.params;
  try {
    const data = await T_Orders_IB_MongoDB.find({ T_username });
    res.json({ data })
  } catch (error) {
    res.json({ message: `Error in Controller`, error: error.message });
  }
}

exports.getOrderData = async (req, res) => {
  let { currentPage, itemPerPage, startDate, endDate, searchData } = req.query;
  console.log(currentPage, itemPerPage, startDate, endDate, searchData);
  const num = parseInt(itemPerPage);
  const start = parseInt(currentPage);
  let pipeline;
  let orderCount;
  try {
    if (startDate === undefined && endDate === undefined && !searchData) {
      pipeline = [
        { $sort: { T_orderdate: -1 } },
        { $skip: (start - 1) * num },
        { $limit: num },
      ];
      orderCount = await T_Orders_IB_MongoDB.aggregate([
        { $count: "totalCount" },
      ]);
    }

    if (startDate !== undefined && endDate !== undefined && !searchData) {
      var s_date = new Date(startDate);
      var e_date = new Date(endDate);
      s_date.setHours(1);
      e_date.setHours(23);
      pipeline = [
        { $match: { T_orderdate: { $gte: s_date, $lte: e_date } } },
        { $sort: { T_orderdate: -1 } },
        { $skip: (start - 1) * num },
        { $limit: num },
      ];
      orderCount = await T_Orders_IB_MongoDB.aggregate([
        { $match: { T_orderdate: { $gte: s_date, $lte: e_date } } },
        { $count: "totalCount" },
      ]);
    }

    if (searchData) {
      pipeline = [
        {
          $match: {
            $or: [
              { T_orderid: { $regex: searchData } },
              { T_username: { $regex: searchData } },
              { f_orderType: { $regex: searchData } },
              { T_paymode: { $regex: searchData } },
              { t_paymentstatus: { $regex: searchData } },
              { T_status: { $regex: searchData } },
              { f_clientGSTIN_no: { $regex: searchData } },
              { t_purchaseorder: { $regex: searchData } },
            ],
          },
        },
        { $sort: { T_orderdate: -1 } },
        { $skip: (start - 1) * num },
        { $limit: num },
      ];
      orderCount = await T_Orders_IB_MongoDB.aggregate([
        { $match: { $or: [{ T_username: { $regex: searchData } }] } },
        { $count: "totalCount" },
      ]);
    }

    const orderData = await T_Orders_IB_MongoDB.aggregate(pipeline);
    res.json({ orderCount: orderCount, orderData });
  } catch (error) {
    res.json({ message: `Error in Controller`, error: error.message });
  }
};

exports.SendPaymentMail = async (req, res) => {
  let { paymentUsername, paymentPrice, payemntLink, T_orderid, PaymentMD } = req.body;
  console.log(paymentUsername, paymentPrice, payemntLink, T_orderid)
  try {
    await OrderPaymentActionMail(
      { email: paymentUsername, paymentPrice, payemntLink, T_orderid, PaymentMD },
      (data, error) => {
        if (!error) {
          console.log(data);
        } else {
          console.log(error);
        }
      }
    )
    res.json({ status: 200, message: "Mail Send Successfully!" })
  } catch (error) {
    res.json({ status: 500, message: `Error in Controller`, error: error.message });
  }
}

exports.SendOrderCCMail = async (req, res) => {
  const { content, email, orderId } = req.body;
  try {
    await OrderDetailActionCCMail(
      { email, content, orderId },
      (data, error) => {
        if (!error) {
          console.log(data);
        } else {
          console.log(error);
        }
      }
    )
    res.json({ status: 200, message: "Mail Send Successfully!" })
  } catch (error) {
    res.json({ status: 500, message: `Error in Controller`, error: error.message });
  }
}

exports.getOrderDetail = async (req, res) => {
  const { T_orderid } = req.params
  try {
    const T_OrderData = await T_Orders_IB_MongoDB.findOne({ T_orderid });
    res.json({ status: 200, T_OrderData })
  } catch (error) {
    res.json({ status: 500, message: `Error in Controller`, error: error.message });
  }
}

exports.updateBounceChequeDesc = async (req, res) => {
  const { T_orderid, f_bouncedchequedesc } = req.body;
  let status;
  let message;
  try {
    const T_OrderData = await T_Orders_IB_MongoDB.findOne({ T_orderid });
    if (T_OrderData) {
      await T_Orders_IB_MongoDB.updateOne({ _id: T_OrderData._id }, {
        $set: {
          f_bouncedchequedesc
        }
      })
      status = 200
      message = "Description Updated Successfully!!"
    } else {
      status = 304
      message = "Some Thing Went Wrong!!"
    }
    res.json({ status, message })
  } catch (error) {
    res.json({ status: 500, message: `Error in Controller`, error: error.message });
  }
}

exports.paidProcessUpdateStatus = async (req, res) => {
  const { OrderIdArray, emails } = req.body;
  try {

    OrderIdArray.forEach(async (id) => {
      const orderData = await T_Orders_IB_MongoDB.findOne({ T_orderid: id })
      if (orderData) {
        await T_Orders_IB_MongoDB.updateOne({ _id: orderData._id }, {
          $set: {
            t_paymentstatus: "Paid"
          }
        })
      }
    })

    IBPaidProcess(
      { email: emails },
      (data, error) => {
        if (!error) {
          console.log(data);
        } else {
          console.log(error);
        }
      }
    )

    res.json({ status: 200, message: "status updated successfully" })
  } catch (error) {
    res.json({ status: 500, message: `Error in Controller`, error: error.message });
  }
}

exports.rejectInvoice = async (req, res) => {
  const { T_orderid } = req.params;
  try {
    const orderDetail = await T_Orders_IB_MongoDB.findOne({ T_orderid });
    if (orderDetail) {
      await T_Orders_IB_MongoDB.updateOne({ _id: orderDetail._id }, { $set: { T_status: "R" } });

      await order.updateOne({ f_email: orderDetail.T_username }, {
        $inc: { f_order_Rejected: 1 }
      })
    }

    request({
      url: `${SQL_URL}/admin/RejectOrderMongoToSql`,
      method: "POST",
      headers: {
        "content-type": "application/json",
      },
      body: {
        "orderId": T_orderid
      },
      json: true
    }, function (err, httpResponse, body) {
      res.json({ status: 200, message: "Invoice Rejected" })
    }
    );


  } catch (error) {
    res.json({ status: 500, message: `Error in Controller`, error: error.message });
  }
}

exports.deleteOrderDetail = async (req, res) => {
  const { T_orderid } = req.params;
  try {
    const orderDetail = await T_Orders_IB_MongoDB.findOne({ T_orderid });
    const orderDetails = await orderDetailSchema.find({ t_orderid: T_orderid });
    if (orderDetail && orderDetails) {
      await T_Orders_IB_MongoDB.deleteOne({ _id: orderDetail._id })
      orderDetails.forEach(async info => {
        await orderDetailSchema.deleteOne({ _id: info._id })
      })
    }



    request({
      url: `${SQL_URL}/admin/RemoveOrderMongoToSql`,
      method: "POST",
      headers: {
        "content-type": "application/json",
      },
      body: {
        "orderId": T_orderid
      },
      json: true
    }, function (err, httpResponse, body) {
      console.log(err, body);
      res.json({ status: 200, message: "order deleted" })
    }
    );


  } catch (error) {
    res.json({ status: 500, message: `Error in Controller`, error: error.message });
  }
}

exports.FinalizeOrder = async (req, res) => {
  const {
    CS_address, CS_companynames, CS_country, CS_firstname, CS_lastname, CS_mobile,
    CS_pin, CS_state, CS_username, ImageArray, client_name, CS_userid, f_GSTIN, f_orderAmt,
    T_username, T_paymode, t_disc_price
  } = req.body;
  try {
    request({
      url: `${SQL_URL}/admin/createNewOrderMongoToSql`,
      method: "POST",
      headers: {
        "content-type": "application/json",
      },
      body: {
        "orderData": req.body
      },
      json: true
    }, async function (err, httpResponse, Resbody) {

      var newOrderId = Resbody.recordset[0].neworderid

      const f_unique_T_orderid = await Counter.findOneAndUpdate({ _id: "order_t_orderid" }, {
        $inc: { sequence: 1 }
      }, { useFindAndModify: false });

      const orderDetails = await T_Orders_IB_MongoDB({
        T_orderid: newOrderId, T_username: CS_username, T_userid: CS_userid,
        T_paymode, t_client: client_name, t_orderedby: "admin", f_clientGSTIN_no: f_GSTIN,
        f_orderAmt: f_orderAmt
      }).save()

      const f_unique_t_sno = await Counter.findOneAndUpdate({ _id: "order_t_sno" }, {
        $inc: { sequence: 1 }
      }, { useFindAndModify: false });

      const existCountData = await order.findOne({ f_email: CS_username });

      if (!existCountData) {
        const commontable = await order({
          f_sno: f_unique_t_sno.sequence, f_clientname: `${CS_firstname} ${CS_lastname}`,
          f_email: CS_username, f_mobileno: CS_mobile, f_totalamtwithGST: f_orderAmt,
          f_order_Pending: 1, f_order_total: 1
        }).save()
        console.log(commontable)
      } else {
        const updatedData = await order.updateOne({ f_email: CS_username }, {
          $inc: {
            f_order_total: 1,
            f_order_Pending: 1,
          }
        })
        console.log(updatedData)
      }



      let price = 0;

      ImageArray.forEach(async (data) => {
        price = price + data.CS_Price;
        const f_unique_t_sno = await Counter.findOneAndUpdate({ _id: "order_t_sno" }, {
          $inc: { sequence: 1 }
        }, { useFindAndModify: false });

        const t_orderdetails = await orderDetailSchema({
          t_sno: f_unique_t_sno.sequence, t_orderid: newOrderId,
          t_imageid: data.CS_imgCode, t_price: data.CS_Price, t_quality: data.CS_ImgType,
          t_disc_price, ph_paymentstatus: "Unpaid", f_rank: data.CS_imgId,
          f_country: CS_country, f_state: CS_state, f_image_type: "I", CS_ImgType_up: data.CS_ImgType,
          f_mydimension: data.f_mydimension
        }).save()


        const HDFC = await HdfcHistorySchema({
          f_orderid: newOrderId, f_orderAmt, f_userid: T_username,
          f_crdate: new Date(), f_ordersatus: "Pending", f_errormsg: null, f_payamount: null,
          f_paymentId: null, f_ip: "14.140.110.107", f_trackid: null, f_paymod: T_paymode
        }).save()

        if (t_orderdetails) {
          const removeFromCart = await T_ShopingCart.findOne({ CS_username: T_username, CS_imgCode: data.CS_imgCode });
          if (removeFromCart) {
            await T_ShopingCart.deleteOne({ _id: removeFromCart._id })
          }
        }
      });
      let tax = price * (18 / 100);
      let NetAmount = price + tax;

      IBOrderConfirmation(
        { email: "swadhin@cstech.in", ImageArray, price, tax, NetAmount },
        (data, error) => {
          if (!error) {
            console.log(data);
          } else {
            console.log(error);
          }
        }
      )

      res.json({ status: 200, message: "order created successfully", orderDetails });
    });
    return



  } catch (error) {
    res.json({ message: `Error in Controller`, error: error.message });
  }
}





/**
 * ATTI
*/

exports.getOrderDetialsForConfirm = async (req, res) => {
  try {
    var OrderInfo = await T_Orders_IB_MongoDB.findOne({
      T_orderid: req.body.orderid,
    });
    var OrderDetails = await orderDetailSchema.find({
      t_orderid: req.body.orderid,
    });
    var userInfo = await RegistrationSchema.findOne({
      f_email: OrderInfo.T_username,
    });
    var stateList = await StateSchema.find({ CountryID: 101 });
    console.log(userInfo);
    res.json({
      OrderInfo,
      OrderDetails,
      userInfo,
      stateList,
    });
  } catch (error) { }
};

exports.confirmOrderAndGenerateInvoice = async (req, res) => {
  const { orderid } = req.body
  console.log(req.body)
  // return
  try {
    // var invoiceId = Math.floor(Math.random() * 98900000999999 + 91009000000099);
    var OrderInfo = await T_Orders_IB_MongoDB.findOne({
      T_orderid: orderid,
    });
    var OrderDetails = await orderDetailSchema.find({
      t_orderid: orderid,
    });
    // console.log(OrderInfo, OrderDetails)
    var userInfo = await RegistrationSchema.findOne({
      f_email: req.body.f_email,
    });
    // return
    request({
      url: `${SQL_URL}/admin/confirmOrderMongoToSql`,
      method: "POST",
      headers: {
        "content-type": "application/json",
      },
      body: {
        "orderdata": req.body
      },
      json: true
    }, function (err, httpResponse, Resbody) {
      console.log("Response Error", err);
      console.log("Response Data ", Resbody);
      db1.collection("T_Orders_IB_MongoDB").updateOne(
        { T_orderid: orderid },
        {
          $set: {
            T_status: "C",
            t_paymentdate: new Date(),
            f_invoiceID: Resbody.recordset[0].invoiceId,
            t_comment: req.body.t_comment
          },
        },
        function (err1, updated) {
          console.log(err1);
          // console.log(updated);
        }
      );
      db1.collection("t_registration_mongoDB").updateOne(
        { f_email: req.body.f_email },
        {
          $set: {
            f_companyname: req.body.f_companyname,
            CS_address: req.body.CS_address,
            f_state: req.body.f_state,
          },
        }
      );

      db1.collection("t_invoice_IB_MongoDB", function (err, collection) {
        collection.insertOne({
          invoice_id: Resbody.recordset[0].invoiceId,
          orderid: req.body.orderid,
          invoice_date: new Date(),
          total_amt: OrderInfo.f_orderAmt,
          discount: 0,
          tax_amt: parseInt((OrderInfo.f_orderAmt * 18) / 100),
          final_amt:
            parseInt(OrderInfo.f_orderAmt) +
            parseInt((OrderInfo.f_orderAmt * 18) / 100),
          f_username: OrderInfo.T_username,
          f_paymode: OrderInfo.T_paymode,
          f_client: OrderInfo.t_client,
          f_purchaseorderno: null,
          t_paymentstatus: OrderInfo.t_paymentstatus,
          f_orderdate: OrderInfo.T_orderdate,
          f_paymentdate: OrderInfo.T_orderdate,
          Name: req.body.f_fullname,
          Companyname: req.body.f_companyname,
          address: req.body.CS_address,
          invoicereject: false,
          orderby: OrderInfo.t_client,
          t_followup_status: 0,
          T_status: "C",
          f_county: "India",
          f_statecrm: req.body.f_state,
          f_companyCrm: req.body.f_companyname,
          t_commissionamount: null,
          t_commdiscount: null,
          t_commShow: "0",
          f_comm_status: "Unpaid",
          f_comm_detail: null,
          f_discountOnInvoice: 0,
          f_clientGSTIN_no: req.body.f_GSTIN,
          t_invoiceText: null,
        });
      });

      OrderDetails.forEach((item) => {
        db1.collection(
          "t_invoice_details_IB_MongoDB",
          function (err, collection) {
            collection.insertOne({
              f_orderid: req.body.orderid,
              f_HSN_ACS: "",
              f_imgname: item.t_imageid,
              cratedate: new Date(),
              f_quality: item.t_quality,
              f_qty: 1,
              f_price: item.t_price,
              f_totalprice: item.t_price,
              f_discount: 0,
              f_tax: 18,
              f_SGST: 0,
              f_CGST: 0,
              f_IGST: parseInt((item.t_price * 18) / 100),
              f_FinalePrice:
                parseInt(item.t_price) + parseInt((item.t_price * 18) / 100),
              f_imagetype: item.f_image_type,
              CS_ImgType_up: item.CS_ImgType_up,
              f_mydimension: item.f_mydimension,
              f_groupid: item.f_groupid,
              f_rank: item.f_rank,
            });
          }
        );
      });
      // res.json({ status: 200, message: "Invoice Rejected" })
      res.json({
        updated: "updated"
      });
    }
    );







  } catch (error) {
    console.log(error);
  }
};

exports.fetchInvoiceDataByOrderId = async (req, res) => {
  console.log(req.query);
  try {
    var OrderInfo = await T_Orders_IB_MongoDB.findOne({
      T_orderid: req.query.orderid,
    });
    // var OrderDetails = await invoiceSchema.find({ "f_orderid": req.query.orderid });
    var OrderDetails = await orderDetailSchema.find({
      t_orderid: req.query.orderid,
    });
    var userInfo = await RegistrationSchema.findOne({
      f_email: OrderInfo.T_username,
    });

    // console.log(OrderInfo)
    // console.log(OrderDetails)
    // console.log(userInfo)
    res.json({
      OrderInfo,
      OrderDetails,
      userInfo,
    });
  } catch (error) {
    console.log(error);
  }
};

exports.fetchPaymentDetailsByOrderId = async (req, res) => {
  const { orderId } = req.params
  try {
    const paymentInfo = await HdfcHistorySchema.findOne({ f_orderid: orderId });
    res.json({ status: 200, paymentInfo, orderId });
  } catch (error) {
    res.json({ status: 500, message: "Internal Server Error", error: error.message })
  }
};

exports.uploadPurchaseImage = async (req, res) => {
  console.log(req.body);
  console.log(dir);
  try {
    var image_name = "";
    if (req.files != null) {
      if (!fs.existsSync(`${dir}//${req.body.orderId}`)) {
        fs.mkdirSync(`${dir}//${req.body.orderId}`);
      }
      Object.keys(req.files).forEach(function (item) {
        console.log(req.files[item].name);
        var file = req.files[item];
        image_name = Date.now() + "-" + req.files[item].name;
        file.mv(`${dir}//${req.body.orderId}//${image_name}`, async (err) => {
          if (err) throw err;
        });
      });
    }
    setTimeout(() => {
      var obj = {
        OrderId: req.body.orderId,
        PoName: image_name,
      };
      PurchaseImageSchema.create(obj, function (err, inserRes) { });
      db1.collection("T_Orders_IB_MongoDB").updateOne(
        { T_orderid: req.body.orderId },
        {
          $set: {
            uploadedImg: image_name,
          },
        },
        function (err1, updated) {
          res.json({
            returnMsg: "uploaded",
          });
        }
      );
    }, 500);
  } catch (error) {
    console.log(error);
  }
};

exports.getPendingOrderData = async (req, res) => {
  let { currentPage, itemPerPage, startDate, endDate, searchData } = req.query;
  console.log(currentPage, itemPerPage, startDate, endDate, searchData);
  const num = parseInt(itemPerPage);
  const start = parseInt(currentPage);
  let pipeline;
  let orderCount;
  try {
    if (startDate === undefined && endDate === undefined && !searchData) {
      pipeline = [
        { $match: { T_status: "P" } },
        { $sort: { T_orderdate: -1 } },
        { $skip: (start - 1) * num },
        { $limit: num },
      ];
      orderCount = await T_Orders_IB_MongoDB.aggregate([
        { $match: { T_status: "P" } },
        { $count: "totalCount" },
      ]);
    }

    if (startDate !== undefined && endDate !== undefined && !searchData) {
      var s_date = new Date(startDate);
      var e_date = new Date(endDate);
      s_date.setHours(1);
      e_date.setHours(23);
      pipeline = [
        { $match: { T_orderdate: { $gte: s_date, $lte: e_date }, T_status: "P" } },
        { $sort: { T_orderdate: -1 } },
        { $skip: (start - 1) * num },
        { $limit: num },
      ];
      orderCount = await T_Orders_IB_MongoDB.aggregate([
        { $match: { T_orderdate: { $gte: s_date, $lte: e_date }, T_status: "P" } },
        { $count: "totalCount" },
      ]);
    }

    if (searchData) {
      pipeline = [
        {
          $match: {
            T_status: "P",
            $or: [
              { T_orderid: { $regex: searchData } },
              { T_username: { $regex: searchData } },
              { f_orderType: { $regex: searchData } },
              { T_paymode: { $regex: searchData } },
              { t_paymentstatus: { $regex: searchData } },
              { T_status: { $regex: searchData } },
              { f_clientGSTIN_no: { $regex: searchData } },
              { t_purchaseorder: { $regex: searchData } },
            ],
          },
        },
        { $sort: { T_orderdate: -1 } },
        { $skip: (start - 1) * num },
        { $limit: num },
      ];
      orderCount = await T_Orders_IB_MongoDB.aggregate([
        { $match: { T_status: "P", $or: [{ T_username: { $regex: searchData } }] } },
        { $count: "totalCount" },
      ]);
    }

    const orderData = await T_Orders_IB_MongoDB.aggregate(pipeline);
    res.json({ orderCount: orderCount, orderData });

  } catch (error) {
    res.json({ message: `Error in Controller`, error: error.message });
  }
};
