const { M_PRICEDETAIL } = require("../../model");

exports.AddPriceDetail = async (req, res) => {
    const {
        f_typename, f_refname, f_dimenation, f_dpi, f_outputsize, f_price, f_time,
        f_showprice, f_showdiscount
    } = req.body;
    try {
        const existingData = await M_PRICEDETAIL.findOne({ f_refname });
        if (existingData) {
            res.json({ status: 400, message: "already exist" })
        }
        if (!existingData) {
            const Data = await new M_PRICEDETAIL({
                f_typename, f_refname, f_dimenation, f_dpi, f_outputsize, f_price, f_time,
                f_showprice, f_showdiscount
            }).save();
            if (Data) {
                res.json({ status: 200, message: "added successfully" })
            }
        }
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

exports.getPriceDetailList = async (req, res) => {
    const { currentPage, itemPerPage, searchData } = req.query;
    const num = parseInt(itemPerPage)
    const start = parseInt(currentPage);
    let pipeline;
    let countline;
    try {
        if (!searchData || searchData === "") {
            pipeline = [
                { $sort: { _id: -1 } },
                { $skip: (start - 1) * num },
                { $limit: num },
            ]
            countline = [
                { $count: "totalcount" }
            ]
        } else {
            pipeline = [
                { $match: { f_refname: { $regex: searchData, $options: "im" } } },
                { $sort: { _id: -1 } },
                { $skip: (start - 1) * num },
                { $limit: num },
            ]
            countline = [
                { $match: { f_refname: { $regex: searchData, $options: "im" } } },
                { $count: "totalcount" }
            ]
        }
        const data = await M_PRICEDETAIL.aggregate(pipeline)
        const totalrecord = await M_PRICEDETAIL.aggregate(countline)
        res.json({ status: 200, data, totalrecord })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

exports.getPriceDetail = async (req, res) => {
    const { _id } = req.params;
    try {
        const data = await M_PRICEDETAIL.findOne({ _id });
        res.json({ status: 200, data })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

exports.updatePriceDetail = async (req, res) => {
    const { _id, f_typename, f_refname, f_dimenation, f_dpi, f_outputsize, f_price, f_time,
        f_showprice, f_showdiscount
    } = req.body
    try {
        const data = await M_PRICEDETAIL.findByIdAndUpdate({ _id }, {
            $set: {
                f_typename, f_refname, f_dimenation, f_dpi, f_outputsize, f_price, f_time,
                f_showprice, f_showdiscount
            }
        });
        res.json({ status: 200, message: "updated successfully" })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

exports.removePriceDetail = async (req, res) => {
    const { _id } = req.params;
    try {
        const data = await M_PRICEDETAIL.findByIdAndRemove({ _id });
        res.json({ status: 200, message: "removed successfully" })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}