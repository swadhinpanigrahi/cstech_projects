const { M_AGENCIES } = require("../../model");

exports.addAgencies = async (req, res) => {
    const { f_ip, f_email, f_Cname, f_status } = req.body;
    try {
        const existingData = await M_AGENCIES.findOne({ f_email });
        if (existingData) {
            res.json({ status: 400, message: "star size already exist" })
        }
        if (!existingData) {
            const Data = await new M_AGENCIES({
                f_ip, f_email, f_Cname, f_status, f_createdate: Date.now()
            }).save();
            if (Data) {
                res.json({ status: 200, message: "star size added successfully" })
            }
        }
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}

exports.getAgenciesList = async (req, res) => {
    const { currentPage, itemPerPage, searchData } = req.query;
    const num = parseInt(itemPerPage)
    const start = parseInt(currentPage);
    let pipeline;
    let countline;
    try {
        if (!searchData || searchData === "") {
            pipeline = [
                { $skip: (start - 1) * num },
                { $limit: num },
                { $sort: { f_createdate: -1 } }
            ]
            countline = [
                { $count: "totalcount" }
            ]
        } else {
            pipeline = [
                { $match: { f_Cname: { $regex: searchData, $options: "im" } } },
                { $skip: (start - 1) * num },
                { $limit: num },
                { $sort: { f_createdate: -1 } }
            ]
            countline = [
                { $match: { f_Cname: { $regex: searchData, $options: "im" } } },
                { $count: "totalcount" }
            ]
        }
        const data = await M_AGENCIES.aggregate(pipeline)
        const totalrecord = await M_AGENCIES.aggregate(countline)
        res.json({ status: 200, data, totalrecord })
    } catch (error) {
        res.json({ status: 500, message: "internal server error!", error: error.message })
    }
}