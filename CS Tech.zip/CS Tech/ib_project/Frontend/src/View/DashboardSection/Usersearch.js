import React, { useState, useEffect } from "react";
import * as RB from "react-bootstrap";
import NoSearchResult from "../../Components/NoSearchResult";
import {
  getFollowupsDetails, getFollowupsDetailsTable, postNextFollowup, deleteProposalDetail,
  custom_states
} from "../../Utils/api";

import Modal from "../../Components/Common/Modal"

import FollowupCreateMoadal from "../../Components/Models/FollowupModals/FollowupCreateMoadal";
import FollowupListModal from "../../Components/Models/FollowupModals/FollowupListModal";
import ProposalViewModal from "../../Components/Models/ProposalModals/ProposalViewModal";

import {
  RegisterUserTable, RegisterCompanyTable, OrderTable, ProposalTable, FollowupTable,
} from "../../Components/Common/Tables/Tables";

const Usersearch = ({
  search,
  CustomerData,
  OrderData,
  ProposelData,
  Followups,
  spanArr,
  spanOrder,
  // setProposelData,
}) => {
  const [followFilterData, setFollowFilterData] = useState(Followups);
  const [followTable, setFollowTable] = useState([]);
  const [f_sno, setId] = useState("");
  const [FormData, setFormData] = useState({
    f_sno,
    f_EmailID: "",
    f_CompanyName: "",
    f_creationdate: "",
    f_MobileNo: "",
    f_Firstname: "",
    f_AlternateEmail: "",
    f_RequirementType: "",
    orderid: "",
    f_status: "Open",
    f_followpby: "",
    f_State: "",
    f_IbOption: "",
    f_createdby: "",
  });

  const [T_orderid, setT_orderid] = useState("")
  const [FollowupCreate, setFollowupCreate] = useState(false);
  const [FollowupList, setFollowupList] = useState(false);
  const [ProposalView, setProposalView] = useState(false);
  const [f_creationdate, setF_creationdate] = useState(new Date());

  const [isOpen, setIsOpen] = useState(false);
  const [ModelMsg, setModelMsg] = useState("");

  const [ArrayList, setArrayList] = useState({
    REG: [],
    ORD: [],
    PRO: [],
    FOL: []
  });

  const [StatesMaster, setStatesMaster] = useState([])

  const openFilter = (name) => {
    if (name === "Open") {
      const shaloFollowUpData = [...Followups];
      const FollowUpfilterData = shaloFollowUpData.filter(
        (data) => data.f_followups_status === "Open"
      );
      setFollowFilterData([...FollowUpfilterData]);
    }
    if (name === "Close") {
      const shaloFollowUpData = [...Followups];
      const FollowUpfilterData = shaloFollowUpData.filter(
        (data) => data.f_followups_status === "Close"
      );
      setFollowFilterData([...FollowUpfilterData]);
    }
    if (name === "Sold") {
      const shaloFollowUpData = [...Followups];
      const FollowUpfilterData = shaloFollowUpData.filter(
        (data) => data.f_followups_status === "Sold"
      );
      setFollowFilterData([...FollowUpfilterData]);
    }
  };

  const handleChange = (e) => {
    setFormData({ ...FormData, [e.target.name]: e.target.value });
  };

  const FollowupCreateSubmit = async (f_sno) => {
    setId(f_sno);
    const res = await getFollowupsDetails(f_sno);
    const { followupsData } = res;
    setFormData({
      f_sno,
      f_EmailID: followupsData.f_EmailID,
      f_CompanyName: followupsData.f_CompanyName,
      f_creationdate: followupsData.f_creationdate,
      f_MobileNo: followupsData.f_MobileNo,
      f_Firstname: followupsData.f_Firstname,
      f_AlternateEmail: followupsData.f_AlternateEmail,
      f_RequirementType: followupsData.f_RequirementType,
      orderid: followupsData.orderid,
      f_status: FormData.f_status,
      f_followpby: followupsData.f_followpby,
      f_State: followupsData.f_State,
      f_IbOption: followupsData.f_IbOption,
      f_createdby: followupsData.f_createdby,
    });
    setFollowupCreate(true);
  };

  const FollowupListOpen = async (f_sno) => {
    const res = await getFollowupsDetailsTable(f_sno);
    const { followupsData } = res;
    setFollowTable(followupsData);
    setFollowupList(true);
  };

  const onSubmit = async (e) => {
    e.preventDefault();
    const { discription } = FormData;
    if (!discription || discription === "") {
      window.alert("please fill description!")
    } else {
      const res = await postNextFollowup({ ...FormData, f_creationdate });
      const { message, error } = res;
      if (!error && message === "added successfully") {
        setTimeout(() => {
          setFormData({})
          setFollowupCreate(false);
        }, 1000);
      } else {
        console.log(error);
      }
    }
  };

  const GetProposalId = (T_orderid) => {
    setT_orderid(T_orderid)
    setProposalView(true)
  }

  const PROPOSAL_DELETE_FUNCTION = async (T_orderid) => {
    const res = await deleteProposalDetail(T_orderid);
    let { status, message } = res;
    if (status === 200) {
      // await GET_API()
      setModelMsg(message)
      modelSet()
    } else {
      setModelMsg(message)
      modelSet()
    }
  }

  const modelSet = () => {
    setIsOpen(true);
  };

  const filterState = (e) => {
    let shaloRegArray = CustomerData.filter((data) => data.f_state === e.target.value);
    let shaloOrdArray = CustomerData.filter((data) => data.f_state === e.target.value);
    let shaloProArray = CustomerData.filter((data) => data.f_state === e.target.value);
    let shaloFolArray = CustomerData.filter((data) => data.f_state === e.target.value);

    setArrayList({
      REG: shaloRegArray,
      ORD: shaloOrdArray,
      PRO: shaloProArray,
      FOL: shaloFolArray,
    })
  }

  useEffect(() => {
    setArrayList({
      REG: CustomerData,
      ORD: OrderData,
      PRO: ProposelData,
      FOL: Followups,
    });

    const apiCall = async () => {
      const res = await custom_states();
      let { data } = res;
      setStatesMaster(data)
    }

    apiCall();
  }, [])

  let { REG, ORD, PRO, FOL } = ArrayList

  return (
    <>
      {CustomerData.length ||
        ProposelData.length ||
        Followups.length ||
        OrderData.length ? (
        <div>
          <RB.Row style={{ paddingTop: "30px" }} className="rownew1">

            <RB.Col lg={12}>
              <div className="box_detail" style={{ borderRadius: "4px" }}>
                <div className="page-header row">
                  <RB.Col md={12}>
                    <h3
                      className="page-title new_srhpagetitle"
                      style={{ fontWeight: "bold", fontSize: "24px" }}
                    >
                      Search Results -{" "}
                      <span style={{ color: "#0081ad" }}>"{search}"</span>
                    </h3>
                    <select onChange={filterState}>
                      <option value="Delhi">Delhi</option>
                      {StatesMaster.map((info, inx) => {
                        let { _id, Name } = info;
                        return <option key={_id} value={Name}>{Name}</option>
                      })}
                    </select>
                  </RB.Col>
                </div>
                <RB.Form></RB.Form>
              </div>
            </RB.Col>

            <RegisterUserTable REG_BODY={REG} isView={true} />

            <RegisterCompanyTable REG_BODY={REG} isView={true} />

            <OrderTable
              ORDER_BODY={ORD}
              isView={true}
              spanOrder={spanOrder}
            />

            <ProposalTable PROPOSAL_BODY={PRO} isView={true}
              GetProposalId={GetProposalId} PROPOSAL_DELETE_FUNCTION={PROPOSAL_DELETE_FUNCTION} />

            <FollowupTable
              FOLLOWUP_BODY={FOL}
              isView={true}
              spanArr={spanArr}
              openFilter={openFilter}
              FollowupCreateSubmit={FollowupCreateSubmit}
              FollowupListOpen={FollowupListOpen}
            />

          </RB.Row>

          <FollowupCreateMoadal
            FollowupCreate={FollowupCreate}
            setFollowupCreate={setFollowupCreate}
            setFormData={setFormData}
            handleChange={handleChange}
            onSubmit={onSubmit}
            FormData={FormData}
            f_creationdate={f_creationdate}
            setF_creationdate={setF_creationdate}
          />

          <FollowupListModal FollowupList={FollowupList} setFollowupList={setFollowupList} followTable={followTable} />

          <ProposalViewModal ProposalView={ProposalView} setProposalView={setProposalView}
            T_orderid={T_orderid} />

          <Modal
            text={ModelMsg}
            open={isOpen}
            onClose={() => setIsOpen(false)}
          />

        </div>
      ) : (
        <NoSearchResult test={search} />
      )}
    </>
  );
};

export default Usersearch;
