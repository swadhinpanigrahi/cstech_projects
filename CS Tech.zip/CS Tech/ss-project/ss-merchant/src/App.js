import React from "react";
import { HashRouter as Router, Switch, Route } from "react-router-dom";

import Login from "./Views/LoginSection/Login"
import DashSection from "./Views/DashboardSection";
import Logout from "./Views/LogoutSection/Logout";
import ForgotSendmail from "./Views/ForgotSection/ForgotSendmail";
import ForgotSumitPass from "./Views/ForgotSection/ForgotSumitPass";

import Footer from "./Components/Headers/Footer"

function App() {
  return (
    <>
      <Router>
        <Switch>
          <Route path="/" exact component={Login} />
          <Route path="/dashboard" component={DashSection} />
          <Route path="/logout" component={Logout} />
          <Route path="/sendemailtogetlink" component={ForgotSendmail} />
          <Route path="/changepassword/:token" component={ForgotSumitPass} />
        </Switch>
        <Footer />
      </Router>
    </>
  );
}

export default App;
