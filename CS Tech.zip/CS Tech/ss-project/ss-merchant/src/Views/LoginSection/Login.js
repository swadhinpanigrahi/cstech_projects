import React, { useState } from 'react'
import Header from "../../Components/Common/Header";
import { Link, useHistory } from "react-router-dom";
import { Form, Button } from "react-bootstrap";
import { loginForm } from "../../Components/FormElement/FormElement";
import { authLoginValidetor } from "../../Utils/FormValidetor";
import { LoginApi } from "../../Utils/api";
import { useTranslation } from "react-i18next";

const Login = () => {
    const history = useHistory();
    const { t } = useTranslation();
    const [FormData, setFormData] = useState({});
    const [Errors, setErrors] = useState({
        errors: {},
        errMsg: "",
        errClr: "",
    });

    const handleChange = (e) => {
        let { name, value } = e.target;
        const data = { ...FormData };
        data[name] = value;
        setFormData(data);
        const updateError = { ...Errors };
        updateError.errors = authLoginValidetor(data);
        updateError.errMsg = "";
        updateError.errClr = "";
        setErrors({ ...updateError });
    };

    const onSubmit = async (e) => {
        e.preventDefault();
        if (FormData["username"] && FormData["password"]) {
            const res = await LoginApi(FormData);
            const { status, message, error } = res;
            if (!error) {
                if (status === 200) {
                    history.push("/dashboard/analytical");
                } else {
                    const updatedError = { ...Errors };
                    updatedError.errMsg = message;
                    setErrors({ ...updatedError });
                }
            } else {
                const updatedError = { ...Errors };
                updatedError.errMsg = "Network Error!!";
                setErrors({ ...updatedError });
            }
        } else {
            const updatedError = { ...Errors };
            updatedError.errors = authLoginValidetor(FormData);
            updatedError.errMsg = "";
            updatedError.errClr = "border-danger";
            setErrors({ ...updatedError });
        }
    }

    let { errors, errMsg, errClr } = Errors;

    return (
        <>
            <Header />
            <main className="mainl">
                <div className="container-flud">
                    <div id="signin">
                        <div className="boxes">
                            <h4 className="title text-center">{t("change.loginH")}</h4>
                            <Form.Text className="text-danger">{errMsg ? errMsg : ""}</Form.Text>
                            <Form id="form">
                                {loginForm.map((data, inx) => {
                                    let { name, type, placeholder, controlId } = data;
                                    return (
                                        <Form.Group controlId={controlId} key={"LOGINFORM" + inx}>
                                            <Form.Control name={name} type={type}
                                                placeholder={placeholder} onChange={handleChange} className={errClr ? errClr : ""}
                                            />
                                            {errors[name] && (
                                                <Form.Text className="text-danger">
                                                    {errors[name]}
                                                </Form.Text>
                                            )}
                                        </Form.Group>
                                    )
                                })}
                                <div className="form-group" style={{ marginBottom: "15px" }}>
                                    <Button className="btn-login" type="submit" onClick={onSubmit}>
                                        {t("change.submit")}
                                    </Button>
                                </div>
                                <div className="forgot">
                                    <Link to="/sendemailtogetlink">{t("change.fpassword")}</Link>
                                </div>
                            </Form>
                        </div>
                    </div>
                </div>
            </main>
        </>
    )
}

export default Login
