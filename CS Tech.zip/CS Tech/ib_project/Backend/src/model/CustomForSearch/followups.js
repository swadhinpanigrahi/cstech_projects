const mongoose = require("mongoose");

const FollowupSchema = mongoose.Schema(
  {
    f_sno: { type: String },
    f_email: { type: String },
    f_AlternateEmail: { type: String },
    f_fullname: { type: String },
    f_CompanyName: { type: String },
    f_PhoneNumber: { type: String },
    f_MobileNo: { type: String },
    f_state: { type: String },
    f_country: { type: String },
    f_usertype: { type: String },
    f_RequirementType: { type: String },
    f_followups_status: { type: String },
    f_createdby: { type: String },
    f_creationdate: { type: Date },
    f_DescriptionType: { type: String },
    f_DiscountTerms: { type: String },
    f_CreditPeriod: { type: String },
    f_AdditionalInfo: []
  },
  { collection: "t_Followup_mongoDB" }
);

module.exports = followup = mongoose.model(
  "t_Followup_mongoDB",
  FollowupSchema
);
