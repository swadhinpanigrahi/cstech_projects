import React, { useState, useEffect } from 'react';
import * as RB from 'react-bootstrap';
import { Link } from 'react-router-dom';
import Cookie from "js-cookie";

export const ProposalPrint = () => {
    const [Name, setName] = useState("");

    useEffect(() => {
        const fun = async () => {
            const username = await Cookie.get("username");
            setName(username)
        }
        fun()
    }, []);

    return (
        <>
            <RB.Row className="rownew1">
                <RB.Col lg={12}>
                    <RB.Row className="page_header1 rownew1">
                        <div className="tableHeader tableHeader1 search_new">
                            <RB.Col md={12} className="table_span">
                                <h3 className="page-title d-flex userv">
                                    <span>Confirm Proposal</span>
                                </h3>
                            </RB.Col>
                        </div>
                    </RB.Row>
                </RB.Col>

                <RB.Col lg={12}>
                    <div className="box_detail print_proposalmain" style={{ borderRadius: "4px" }}>
                        <h4 className="Client_namep">Dear {Name}</h4>
                        <p className="client_dtlp">
                            Thank you for your interest in ImagesBazaar. Please click on the link given below to view the quotation:
                        </p>
                        <p className="client_dtlp">
                            <Link to="/dashboard/proposal/get">https://imagezbazaar.com/proposalgst?id=MTk0mjY4Ng==</Link>
                        </p>
                        <p className="client_dtlp">
                            If the link above is not clickable simply cut and paste in into the location bar of your browser and press enter.
                        </p>
                        <p className="client_dtlp">
                            Kindly <Link to="/dashboard/proposal/get">click here</Link> to view the Procedure to place an order at <Link to="ImagesBazaar.com">ImagesBazaar.com</Link> Usage of images to Mash Rights Agreement mentioned on <Link to="www.imagesbazaar.com/licensing">www.imagesbazaar.com/licensing</Link>.
                        </p>
                        <p className="client_dtlpnew">
                            We appreciate your consideration and upon receipt of approval, the image(s) download link will be activated immediately.
                        </p>
                        <h4 className="Client_namep next_head">Delivery Schedules</h4>
                        <p className="client_dtlpnew">
                            For all orders placed through Credit Cards (Visa, Master Card or American Express), the link to download the image(s) gets immediately activated as soon as your transaction gets successful, whether it’s day or night, weekday or weekend.
                        </p>
                        <p className="client_dtlpnew" style={{ marginBottom: "30px" }}>
                            For orders placed through Net Banking, Cheque/Demand Draft or Electronic Fund Transfer, the link to download the image(s) gets activated as soon as we receive your payment. Orders placed after the office timings given below will be activated at 10:00 AM on the next working day. Office Timings (IST): 10:00 AM to 08:30 PM (Closed on Sunday and National Holidays of India).
                        </p>
                        <p className="client_dtlpnew" style={{ marginBottom: "20px" }}>
                            Looking forward to a long term relationship!
                            <br />
                            Best Regards
                            <br />
                            Hukum Gupta
                            <br />
                            Customer Support Team
                            <br />
                            <Link to="www.imagesbazaar.com">www.imagesbazaar.com</Link>
                        </p>
                        <p className="client_dtlp" style={{ marginBottom: "0px" }}>
                            <Link to="/dashboard/proposal/get">GO TO MY ACCOUNT</Link>
                        </p>
                    </div>
                </RB.Col>
            </RB.Row>
        </>
    )
}

export default ProposalPrint
