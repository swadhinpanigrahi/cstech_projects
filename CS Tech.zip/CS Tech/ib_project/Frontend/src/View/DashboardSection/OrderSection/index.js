import React from 'react';
import OrderManageList from "./OrderManageList";
import OrderDetail from "./OrderDetail";
import InvoiceEdit from "./InvoiceEdit";
import PendingOrders from "./PendingOrders";
import { Route } from "react-router-dom"

const OrderSection = () => {
    return (
        <div>
            <Route path="/dashboard/order/get" component={OrderManageList} />
            <Route path="/dashboard/order/ordermanage/:orderid" component={OrderDetail} />
            <Route path="/dashboard/order/invoiceedit/:f_orderid" component={InvoiceEdit} />
            <Route path="/dashboard/order/pendingorder/get" component={PendingOrders} />
        </div>
    )
}

export default OrderSection
