
import React, { useState, useEffect } from "react";
import * as RB from "react-bootstrap";
import { useParams, Link } from "react-router-dom";
import { IoIosArrowBack } from "react-icons/io";
import Moment from 'moment';
import {
  userActionApi,
  proposalDeleteAction,
  profileData,
  customerProfile
} from "../../Utils/api";
import {
  getFollowupsDetails,
  getFollowupsDetailsTable,
  postNextFollowup,
  proposalViewAction,
  getOrderDeatils,
  getOrderInvoice
} from "../../Utils/api";
import { Form, Row } from "react-bootstrap";
import { AiOutlineFileSearch } from "react-icons/ai";
import { BiCommentDetail } from "react-icons/bi";
import { IoExitOutline } from "react-icons/io5";
import { RiDeleteBin6Line } from "react-icons/ri";
import ProposalInvoiceModel from "../../Components/Models/ProposalInvoiceModel";
import OrderInvoiceModel from "../../Components/Models/OrderModals/OrderInvoiceModel";
import OrderDetailsModel from "../../Components/Models/OrderModals/OrderDetailsModel";

const UserAction = ({ spanArr }) => {
  // alert("came")
  const { f_userid, path } = useParams();

  const [Data1, setData1] = useState({});
  const [Data2, setData2] = useState({});
  const [Loading, setLoading] = useState(false);
  const [Reg, setReg] = useState({});
  const [orderData, setOrderData] = useState({
    isView: false,
    data: [],
  });
  const [filtredOrderData, setFiltredOrderData] = useState([]);

  const [proposaldata, setProposaldata] = useState({
    isView: false,
    data: [],
  });
  const [followupData, setFollowupData] = useState({
    isView: false,
    data: [],
  });
  const [followFilterData, setFollowFilterData] = useState([]);

  const [followSpan, setFollowSpan] = useState([]);
  const [orderCount, setOrderCount] = useState([]);
  const [followTable, setFollowTable] = useState([]);
  const [f_sno, setId] = useState("");
  const [FormData, setFormData] = useState({
    f_sno,
    f_EmailID: "",
    f_CompanyName: "",
    f_creationdate: "",
    f_MobileNo: "",
    f_Firstname: "",
    f_AlternateEmail: "",
    f_RequirementType: "",
    orderid: "",
    f_status: "",
    f_followpby: "",
    f_State: "",
    f_IbOption: "",
    f_createdby: "",
  });
  const [proposalInvoiceDetails, setProposalInvoiceDetails] = useState({
    table1: {},
    table2: {},
  });

  const [show, setShow] = useState(false);
  const [show1, setShow1] = useState(false);
  const [show2, setShow2] = useState(false);
  const handleClose2 = () => setShow2(false);


  const [OrderDetailsIsOpen, setOrderDetailsIsOpen] = useState(false);
  const [OrderInvoiceIsOpen, setOrderInvoiceIsOpen] = useState(false);

  const [OrderDataObj, setOrderDataObj] = useState({});
  const [OrderDataList, setOrderDataList] = useState([]);

  const [OrderInvoiceObj, setOrderInvoiceObj] = useState({});
  const [OrderInvoiceList, setOrderInvoiceList] = useState([])

  const CloseOrderDetails = () => setOrderDetailsIsOpen(false);
  const OrderDetailsClick = async (orderId) => {
    const res = await getOrderDeatils(orderId);

    let { OrderDetail, OrderDetailsList } = res;
    console.log("Get Order Detailos Obj", OrderDetail);
    setOrderDataObj(OrderDetail);
    setOrderDataList(OrderDetailsList);
    console.log(OrderDetail, OrderDetailsList);
    setOrderDetailsIsOpen(true);
  };

  const CloseOrderInvoice = () => setOrderInvoiceIsOpen(false);
  const OrderInvoiceClick = async (orderId) => {
    const res = await getOrderInvoice(orderId);
    let { OrderInvoice, OrderInvoiceList } = res;
    setOrderInvoiceObj(OrderInvoice);
    setOrderInvoiceList(OrderInvoiceList);
    // console.log(OrderInvoice, OrderInvoiceList);
    setOrderInvoiceIsOpen(true);
  };

  const handleShow2 = async (_id) => {
    const res = await proposalViewAction(_id);
    let { proposalData, tblProposalData } = res;
    let updatedData = { ...proposalInvoiceDetails };
    updatedData.table1 = proposalData;
    updatedData.table2 = tblProposalData;
    setProposalInvoiceDetails({ ...updatedData });
    console.log(_id, proposalData, tblProposalData);
    setShow2(true);
  };

  const openFilter = (name) => {
    const shaloFollowUpData = [...followupData.data];
    console.log("Followupd data : ", shaloFollowUpData);
    if (name === "Open") {
      const FollowUpfilterData = shaloFollowUpData.filter(
        (data) => data.f_followups_status === "0"
      );
      setFollowFilterData([...FollowUpfilterData]);
    }
    if (name === "Close") {
      const FollowUpfilterData = shaloFollowUpData.filter(
        (data) => data.f_followups_status === "1"
      );
      setFollowFilterData([...FollowUpfilterData]);
    }
    if (name === "Sold") {
      const FollowUpfilterData = shaloFollowUpData.filter(
        (data) => data.f_followups_status === "3"
      );
      setFollowFilterData([...FollowUpfilterData]);
    }
  };

  const handleChange = (e) => {
    setFormData({ ...FormData, [e.target.name]: e.target.value });
  };

  const handleClose = () => setShow(false);
  const handleShow = async (f_sno) => {
    alert("calling follow")
    setId(f_sno);
    const res = await getFollowupsDetails(f_sno);
    const { followupsData } = res;
    setFormData({
      f_sno,
      f_EmailID: followupsData.f_EmailID,
      f_CompanyName: followupsData.f_CompanyName,
      f_creationdate: followupsData.f_creationdate,
      f_MobileNo: followupsData.f_MobileNo,
      f_Firstname: followupsData.f_Firstname,
      f_AlternateEmail: followupsData.f_AlternateEmail,
      f_RequirementType: followupsData.f_RequirementType,
      orderid: followupsData.orderid,
      f_status: "",
      f_followpby: followupsData.f_followpby,
      f_State: followupsData.f_State,
      f_IbOption: followupsData.f_IbOption,
      f_createdby: followupsData.f_createdby,
    });
    setShow(true);
  };

  const handleClose1 = () => setShow1(false);
  const handleShow1 = async (f_sno) => {
    alert(f_sno)
    const res = await getFollowupsDetailsTable(f_sno);
    const { followupsData } = res;
    setFollowTable(followupsData);
    setShow1(true);
  };

  const onDelete = async (_id) => {
    const res = await proposalDeleteAction(_id);
    const { deleted } = res;
    if (deleted) {
      const shaloArray = [...proposaldata.data];
      const filterData = shaloArray.filter((data) => data.T_orderid !== _id);
      const updatedProposal = { ...proposaldata };
      updatedProposal.data = filterData;
      setProposaldata({ ...updatedProposal });
    }
  };

  const profileInfo = [
    {
      key: "First Name :",
      value: Data1.CS_firstname,
    },
    {
      key: "Last Name :",
      value: Data1.CS_lastname,
    },
    {
      key: "Email id :",
      value: Data1.CS_email,
    },
    {
      key: "Alternative Email id :",
      value: "--",
    },
    {
      key: "Company name :",
      value: Data2.CS_companynames,
    },
    {
      key: "Short Company name :",
      value: Data2.sortcmp_name,
    },
    {
      key: "Group name :",
      value: Data2.group_cmpname,
    },
    {
      key: "Short name :",
      value: Data2.sortcmp_name,
    },
    {
      key: "Mobile No :",
      value: Data2.CS_mobile,
    },
    {
      key: "Phone :",
      value: Data2.CS_phone,
    },
    {
      key: "Req Type :",
      value: "--",
    },
    {
      key: "Discount Terms :",
      value: Data2.cs_discount,
    },
    {
      key: "Credit Period :",
      value: "--",
    },
    {
      key: "Order Id :",
      value: "--",
    },
    {
      key: "Country :",
      value: Data2.CS_country,
    },
    {
      key: "State :",
      value: Data2.CS_state,
    },
    {
      key: "Approval Mode :",
      value: "--",
    },
    {
      key: "About IB :",
      value: "--",
    },
  ];

  const viewOrderData = () => {
    if (orderData.isView === false) {
      const updatedOrder = { ...orderData };
      updatedOrder.isView = true;
      setOrderData({ ...updatedOrder });
    } else {
      const updatedOrder = { ...orderData };
      updatedOrder.isView = false;
      setOrderData({ ...updatedOrder });
    }
  };

  const viewProposalData = () => {
    if (proposaldata.isView === false) {
      const updatedProposal = { ...proposaldata };
      updatedProposal.isView = true;
      setProposaldata({ ...updatedProposal });
    } else {
      const updatedProposal = { ...proposaldata };
      updatedProposal.isView = false;
      setProposaldata({ ...updatedProposal });
    }
  };

  const viewFollowupData = () => {
    console.log("viewFollowupData : ",followupData);
    if (followupData.isView === false) {
      const updatedFollowups = { ...followupData };
      updatedFollowups.isView = true;
      setFollowupData({ ...updatedFollowups });
    } else {
      const updatedFollowups = { ...followupData };
      updatedFollowups.isView = false;
      setFollowupData({ ...updatedFollowups });
    }
  };

  const onSubmit = async (e) => {
    e.preventDefault();
    const res = await postNextFollowup(FormData);
    const { message, error } = res;
    if (!error && message === "added successfully") {
      setTimeout(() => {
        handleClose();
      }, 1000);
    } else {
      console.log(error);
    }
  };

  const orderFilter = (name) => {
    const shaloArray = [...orderData.data];
    if (name === "Total") {
      const filteredData = [...shaloArray];
      setFiltredOrderData(filteredData);
    }

    if (name === "Confirmed") {
      const filteredData = shaloArray.filter((data) => {
        return data.T_status === "C";
      });
      setFiltredOrderData(filteredData);
    }

    if (name === "Pending") {
      const filteredData = shaloArray.filter((data) => {
        return data.T_status === "P";
      });
      setFiltredOrderData(filteredData);
    }

    if (name === "Rejected") {
      const filteredData = shaloArray.filter((data) => {
        return data.T_status === "R";
      });
      setFiltredOrderData(filteredData);
    }
  };

  useEffect(() => {
    setLoading(true)
    const profileApi = async () => {
      const res = await customerProfile(f_userid);
      let { registrationData, t_LUS, t_TUR } = res;
      console.log(registrationData, t_LUS, t_TUR)
      setData1(t_LUS);
      setData2(t_TUR);
      setReg(registrationData);
      // console.log(data1, data2, registrationData)
    };
    const apiCall = async () => {
      const res = await userActionApi(f_userid);
      const {
        T_orderData,
        proposal_data,
        followup_data,
        orderArr,
        followupsArr,
      } = res;
      const updatedOrder = { ...orderData };
      updatedOrder.data = T_orderData;
      setOrderData({ ...updatedOrder });

      const updatedProposal = { ...proposaldata };
      updatedProposal.data = proposal_data;
      setProposaldata({ ...updatedProposal });

      const updatedFollowups = { ...followupData };
      updatedFollowups.data = followup_data;
      setFollowupData({ ...updatedFollowups });
      setFollowFilterData(followup_data);

      setFiltredOrderData(T_orderData);
      setOrderCount(orderArr);
      setFollowSpan(followupsArr);
      setLoading(false)
    };
    apiCall();
    profileApi();
  }, [f_userid]);


  const orderdatalist = Loading ? <tr><td className="no_records" colSpan="11">Loading...</td></tr> : filtredOrderData.length !== 0 ? filtredOrderData.map((data, inx) => (<tr key={"userOrderInfo" + inx}>
    <td className="text-center">{inx + 1}</td>
    <td>{data.T_orderid}</td>
    <td>{data.t_client}</td>
    <td className="company_emmailta">{data.T_username}</td>
    {/* <td>1</td> */}
    <td>{Moment(data.T_orderdate).format('DD-MM-YYYY')}</td>
    {/* <td>{data.T_orderdate.slice(0, 10)}</td> */}
    <td>{data.T_status}</td>
    <td>{data.t_paymentstatus}</td>
    <td>{data.f_orderAmt}</td>
    <td>{data.t_invoiceid}</td>
    <td className="text-center td_comments">
      {/* <Link to={`/dashboard/btndata/total_data`}>
        <AiOutlineFileSearch />
      </Link> */}
      <AiOutlineFileSearch title="Order Details"
        onClick={() => {
          OrderDetailsClick(data.T_orderid);
        }}
      />
      {data.T_status === "C" ? (
        <BiCommentDetail title="Invoice Details"
          onClick={() => OrderInvoiceClick(data.T_orderid)}
        />
      ) : (
        ""
      )}
    </td>
  </tr>)) : <tr><td className="no_records" colSpan="11">No Records Found</td></tr>

  const orderdatalist1 = Loading ? <tr><td className="no_records" colSpan="11">Loading...</td></tr> : filtredOrderData.length !== 0 ? filtredOrderData.slice(0, 10).map((data, inx) => (<tr key={"userOrderInfo" + inx}>
    <td className="text-center">{inx + 1}</td>
    <td>{data.T_orderid}</td>
    <td>{data.t_client}</td>
    <td className="company_emmailta">{data.T_username}</td>
    {/* <td>1</td> */}
    <td>{Moment(data.T_orderdate).format('DD-MM-YYYY')}</td>
    {/* <td>{data.T_orderdate.slice(0, 10)}</td> */}
    <td>{data.T_status}</td>
    <td>{data.t_paymentstatus}</td>
    <td>{data.f_orderAmt}</td>
    <td>{data.t_invoiceid}</td>
    <td className="text-center td_comments">
      {/* <Link to={`/dashboard/btndata/total_data`}>
        <AiOutlineFileSearch />
      </Link> */}
      <AiOutlineFileSearch title="Order Details"
        onClick={() => {
          OrderDetailsClick(data.T_orderid);
        }}
      />
      {data.T_status === "C" ? (
        <BiCommentDetail title="Invoice Details"
          onClick={() => OrderInvoiceClick(data.T_orderid)}
        />
      ) : (
        ""
      )}
    </td>
  </tr>)) : <tr><td className="no_records" colSpan="11">No Records Found</td></tr>

  const proposaldatalist = Loading ? <tr><td className="no_records" colSpan="11">Loading...</td></tr> : proposaldata.data.length !== 0 ? proposaldata.data.map((data, inx) => (<tr key={"userProposelInfo" + inx}>
    <td className="text-center">{inx + 1}</td>
    <td>{data.T_username}</td>
    <td>{data.f_heading}</td>
    <td>{Moment(data.T_orderdate).format('DD-MM-YYYY')}</td>

    <td>1</td>
    <td>{data.f_amtpay}</td>
    <td>{data.f_discount}</td>
    <td>{data.f_finalamt}</td>
    <td>View</td>
    <td>Open</td>
    <td>{data.T_orderid}</td>
    <td className="text-center">
      {/* <Link
    to={`/dashboard/proposalview/${data.T_orderid}`}
  > */}
      <AiOutlineFileSearch
        onClick={() => handleShow2(data.T_orderid)}
      />
      {/* </Link> */}
      <RiDeleteBin6Line
        onClick={() => onDelete(data.T_orderid)}
      />
    </td>
  </tr>)) : <tr><td className="no_records" colSpan="12">No Records Found</td></tr>

  const proposaldatalist1 = Loading ? <tr><td className="no_records" colSpan="11">Loading...</td></tr> : proposaldata.data.length !== 0 ? proposaldata.data.slice(0, 10).map((data, inx) => (<tr key={"userProposelInfo" + inx}>
    <td className="text-center">{inx + 1}</td>
    <td>{data.T_username}</td>
    <td>{data.f_heading}</td>
    <td>{Moment(data.T_orderdate).format('DD-MM-YYYY')}</td>
    {/* <td>{data.T_orderdate.slice(0, 10)}</td> */}
    <td>1</td>
    <td>{data.f_amtpay}</td>
    <td>{data.f_discount}</td>
    <td>{data.f_finalamt}</td>
    <td>View</td>
    <td>Open</td>
    <td>{data.T_orderid}</td>
    <td className="text-center">
      {/* <Link
    to={`/dashboard/proposalview/${data.T_orderid}`}
  > */}
      <AiOutlineFileSearch
        onClick={() => handleShow2(data.T_orderid)}
      />
      {/* </Link> */}
      <RiDeleteBin6Line
        onClick={() => onDelete(data.T_orderid)}
      />
    </td>
  </tr>)) : <tr><td className="no_records" colSpan="12">No Records Found</td></tr>

  const followupdatalist = Loading ? <tr><td className="no_records" colSpan="11">Loading...</td></tr> : followFilterData.length !== 0 ? followFilterData.map((data, inx) => (<tr key={"userFollowupInfo" + inx}>
    <td className="text-center">{inx + 1}</td>
    <td>
      {data.f_Firstname} {data.f_lastName} <br />
      {data.f_EmailID}
      <br />
      {data.f_State}
    </td>
    <td>{data.f_CompanyName}</td>
    <td>{data.f_UserType}</td>
    <td>{data.f_createdby}</td>
    <td>Upload Image</td>
    {/* <td>Open</td> */}
    <td>{Moment(data.f_creationdate).format('DD-MM-YYYY')}</td>
    <td>{data.f_RequirementType}</td>
    <td>{data.f_Discountterms}</td>
    <td className="text-center">
      <AiOutlineFileSearch
        onClick={() => {
          handleShow(data.f_sno);
        }}
      />
      <IoExitOutline
        onClick={() => {
          handleShow1(data.f_sno);
        }}
      />
    </td>
  </tr>)) : <tr><td className="no_records" colSpan="10">No Records Found</td></tr>

  const followupdatalist1 = Loading ? <tr><td className="no_records" colSpan="11">Loading...</td></tr> : followFilterData.length !== 0 ? followFilterData.slice(0, 10).map((data, inx) => (<tr key={"userFollowupInfo" + inx}>
    <td className="text-center">{inx + 1}</td>
    <td>
      {data.f_Firstname} {data.f_lastName} <br />
      {data.f_EmailID}
      <br />
      {data.f_State}
    </td>
    <td>{data.f_CompanyName}</td>
    <td>{data.f_UserType}</td>
    <td>{data.f_createdby}</td>
    <td>Upload Image</td>
    {/* <td>Open</td> */}
    <td>{Moment(data.f_creationdate).format('DD-MM-YYYY')}</td>
    <td>{data.f_RequirementType}</td>
    <td>{data.f_Discountterms}</td>
    <td className="text-center">
      <AiOutlineFileSearch
        onClick={() => {
          handleShow(data.f_sno);
        }}
      />
      <IoExitOutline
        onClick={() => {
          handleShow1(data.f_sno);
        }}
      />
    </td>
  </tr>)) : <tr><td className="no_records" colSpan="10">No Records Found</td></tr>

  return (
    <>
      <main className="main_afterlogin">
        <div
          className="page-header row rownew1"
          style={{ paddingTop: "30px", margin: "0px" }}
        >
          <div className="col-lg-8 col-md-6 col-12">
            <h3 className="page-title">
              {Data1.CS_firstname} {Data1.CS_lastname}
            </h3>
          </div>
          <div className="col-lg-4 col-md-6 col-12">
            <div className="float-right responsive_floatbtn">
              {/* {Reg.f_registrationType === "Register" ? ( */}
              <div>
                <RB.ButtonGroup>
                  <RB.Button
                    size="sm"
                    variant="primary"
                    className="mr-2"
                  >
                    <Link to={path === "from_usersearch" ?
                      `/dashboard/useractioneditprofile/${f_userid}/form_usesearch_edit`
                      : `/dashboard/useractioneditprofile/${f_userid}/from_customerlist_edit`}
                    >
                      Edit
                    </Link>
                  </RB.Button>
                  <RB.Button
                    size="sm"
                    variant="primary"
                    className="btn_svg"
                  >
                    <Link to={path === "from_customerlist" ? "/dashboard/customer/get" : "/dashboard/searchdata"}>
                      <IoIosArrowBack />
                      Back
                    </Link>
                  </RB.Button>
                </RB.ButtonGroup>

              </div>
              {/* ) : (
                <RB.Button disabled>Edit</RB.Button>
              )} */}

              {/* <p>{Reg.f_registrationType}</p> */}
            </div>
          </div>
        </div>

        <RB.Row style={{ paddingTop: "7px" }} className="rownew1">
          <RB.Col md={12}>
            <div className="box_detail" style={{ borderRadius: "4px" }}>
              <RB.Row style={{ paddingLeft: "25px", paddingRight: "25px" }}>
                <RB.Col md={12}>
                  <div
                    className="form-group row"
                    style={{ marginBottom: "0rem" }}
                  >
                    {profileInfo.map((data, inx) => {
                      let { key, value } = data;
                      return (
                        <RB.Col
                          md={6}
                          key={"userInfo" + inx}
                          style={{ marginBottom: "1rem" }}
                        >
                          <div className="row resmar">
                            <div className="col-lg-5 col-md-6">
                              <span className="first">{key}</span>
                            </div>
                            <div className="col-lg-7 col-md-6">
                              <span className="second">{value}</span>
                            </div>
                          </div>
                        </RB.Col>
                      );
                    })}
                  </div>
                </RB.Col>
              </RB.Row>
            </div>
          </RB.Col>
        </RB.Row>

        <RB.Col md={12}>
          <RB.Row className="add_button rownew1">

            <div className="tableHeader tableHeader1 order_btntable">
              <RB.Col lg={6} md={4} className="table_span">
                <h3 className="page-title d-flex userv">
                  <span>Orders</span>
                  {
                    filtredOrderData.length > 10 ?
                      <RB.Button onClick={viewOrderData} variant="primary" size="sm"
                      // disabled={filtredOrderData.length > 10 ? false : true}
                      >
                        View All
                      </RB.Button> : null
                  }
                </h3>
              </RB.Col>
              <RB.Col lg={6} md={8} className="table_span">
                <RB.ButtonToolbar>
                  {orderCount.map((data, inx) => {
                    let { name, count } = data;
                    return (
                      <RB.ButtonGroup
                        className="mr-2"
                        key={"orderspan" + inx}
                      >
                        <RB.Button
                          onClick={() => {
                            orderFilter(name);
                          }}
                          size="sm"
                        >{`${name} - ${count}`}</RB.Button>
                      </RB.ButtonGroup>
                    );
                  })}
                </RB.ButtonToolbar>
              </RB.Col>
            </div>
          </RB.Row>

          <div className="box_detail table_boxdtl">
            <RB.Table striped bordered hover variant="dark" responsive>
              <thead>
                <tr>
                  <th className="s_not1 text-center">S. No.</th>
                  <th >Order Id</th>
                  <th>Client Name</th>
                  <th>Email</th>
                  {/* <th>Amount</th> */}
                  <th>Order Date</th>
                  <th>Status</th>
                  <th>Payment Status</th>
                  <th>Order Amt</th>
                  <th>Invoice Id</th>
                  <th className="s_not text-center">Action</th>
                </tr>
              </thead>
              <tbody>
                {orderData.isView
                  ? [orderdatalist]
                  : [orderdatalist1]}
                { }
              </tbody>
            </RB.Table>
          </div>
        </RB.Col>
        <RB.Col md={12}>
          <div className="tableHeader">
            <h3 className="page-title d-flex userv">
              <span>Proposal</span>
              {proposaldata.data.length > 10 ?
                <RB.Button onClick={viewProposalData} size="sm" variant="primary"
                // disabled={proposaldata.data.length > 10 ? false : true}
                >
                  View All
                </RB.Button> : null
              }
            </h3>
          </div>
          <div className="box_detail table_boxdtl">
            <RB.Table striped bordered hover variant="dark" responsive>
              <thead>
                <tr>
                  <th className="s_not1 text-center">S. No.</th>
                  <th>User Name</th>
                  <th>Heading</th>
                  <th>Date</th>
                  <th>Images</th>
                  <th>Amount </th>
                  <th>Discount ₹</th>
                  <th>Total Amt ₹</th>
                  <th>Proposal Updates</th>
                  <th>Status Update</th>
                  <th>Refrences ID</th>
                  <th className="s_not text-center">Action</th>
                </tr>
              </thead>
              <tbody>
                {proposaldata.isView
                  ? [proposaldatalist]
                  : [proposaldatalist1]}
              </tbody>
            </RB.Table>
          </div>
        </RB.Col>
        <RB.Col md={12}>
          <RB.Row className="add_button rownew1">
            <div className="tableHeader tableHeader1 order_btntable">
              <RB.Col lg={6} md={4} className="table_span">
                <h3 className="page-title d-flex userv">
                  <span>Followup</span>
                  {followFilterData.length > 10 ?
                    <RB.Button onClick={viewFollowupData} size="sm" variant="primary"
                    // disabled={followFilterData.length > 10 ? false : true}
                    >
                      View All
                    </RB.Button> : null
                  }
                </h3>
              </RB.Col>
              <RB.Col lg={6} md={8} className="table_span">
                <RB.ButtonToolbar>
                  {/* {spanArr.map((data, inx) => {
                    let { name, count, path } = data;
                    return (
                      <RB.ButtonGroup className="mr-2" key={"orderspan" + inx}>
                        <RB.Button
                          as={Link}
                          to={`/dashboard/btndata/${path}`}
                          size="sm"
                        >{`${name} - ${count}`}</RB.Button>
                      </RB.ButtonGroup>
                    );
                  })} */}
                  {followSpan.map((data, inx) => {
                    let { name, count } = data;
                    return (
                      <RB.ButtonGroup
                        className="mr-2"
                        key={"orderspaniugfgus" + inx}
                      >
                        <RB.Button
                          onClick={() => {
                            openFilter(name);
                          }}
                          size="sm"
                        >{`${name} - ${count}`}</RB.Button>
                      </RB.ButtonGroup>
                    );
                  })}
                </RB.ButtonToolbar>
              </RB.Col>
            </div>
          </RB.Row>
          <div className="box_detail table_boxdtl">
            <RB.Table striped bordered hover variant="dark" responsive>
              <thead>
                <tr>
                  <th className="s_not1 text-center">S. No.</th>
                  <th>User Details</th>
                  <th>Company Name</th>
                  <th>User Type</th>
                  <th>Requirement Type</th>
                  <th>User</th>
                  {/* <th>Status</th> */}
                  <th>Date</th>
                  <th>Type</th>
                  <th>Discount Terms</th>
                  <th className="s_not text-center">Action</th>
                </tr>
              </thead>
              <tbody>
                {followupData.isView
                  ? [followupdatalist]
                  : [followupdatalist1]}
              </tbody>
            </RB.Table>
          </div>
        </RB.Col>
        <RB.Modal show={show} onHide={handleClose} size="lg">
          <RB.Modal.Header closeButton className="view_create">
            <RB.Modal.Title style={{ fontWeight: "bold", fontSize: "22px" }}>
              Daily Sales Entry Follow Ups - Create
            </RB.Modal.Title>
          </RB.Modal.Header>
          <RB.Modal.Body className="show-grid view_create">
            <RB.Form>
              <RB.Form.Group as={Row} controlId="formPlaintextEmail">
                <RB.Col sm="6" className="right_mar">
                  <RB.Form.Label>Email</RB.Form.Label>
                  <RB.Form.Control
                    plaintext
                    readOnly
                    defaultValue={FormData.f_EmailID}
                  />
                </RB.Col>
                <RB.Col sm="6" className="left_mar">
                  <RB.Form.Label>Requirement followups</RB.Form.Label>
                  <RB.Form.Control
                    as="select"
                    onChange={(e) => {
                      const data = { ...FormData };
                      data.f_status = e.target.value;
                      setFormData({ ...data });
                    }}
                  >
                    <option value="Open">Open</option>
                    <option value="Close">Close</option>
                    <option value="PClose">PClose</option>
                    <option value="Sold">Sold</option>
                    <option value="UpgradeSold">Upgrade Sold</option>
                    <option value="QPackSold">QPack Sold</option>
                    <option value="DQuerySold">DQuery Sold</option>
                    <option value="DPackSold">DPack Sold</option>
                    <option value="ExcludeSold">Exclude Sold</option>
                  </RB.Form.Control>
                </RB.Col>
              </RB.Form.Group>

              <Form.Group as={Row} controlId="exampleForm.ControlTextarea1">
                <RB.Col sm="6" className="right_mar">
                  <Form.Label>Description</Form.Label>
                  <Form.Control
                    as="textarea"
                    className="textarea"
                    name="discription"
                    onChange={handleChange}
                  />
                </RB.Col>
                <RB.Col sm="6" className="left_mar">
                  <div style={{ marginBottom: "1rem" }}>
                    <Form.Label>Followups by</Form.Label>
                    <Form.Control
                      as="select"
                      onChange={(e) => {
                        const data = { ...FormData };
                        data.f_followpby = e.target.value;
                        setFormData({ ...data });
                      }}
                    >
                      <option value={`${FormData.f_followpby}`}>
                        {FormData.f_followpby}
                      </option>
                      <option value="Email">Email</option>
                      <option value="Call">Call</option>
                    </Form.Control>
                  </div>
                  <div>
                    <Form.Label>State</Form.Label>
                    <Form.Control
                      as="select"
                      onChange={(e) => {
                        const data = { ...FormData };
                        data.f_State = e.target.value;
                        setFormData({ ...data });
                      }}
                    >
                      <option value={`${FormData.f_State}`}>
                        {FormData.f_State}
                      </option>
                      <option value="Delhi">Delhi</option>
                      <option value="Goa">Goa</option>
                    </Form.Control>
                  </div>
                </RB.Col>
              </Form.Group>

              <Form.Group as={Row} controlId="formPlaintextPassword">
                <RB.Col sm="6" className="right_mar">
                  <Form.Label>How they came to know about IB</Form.Label>
                  <Form.Control
                    as="select"
                    onChange={(e) => {
                      const data = { ...FormData };
                      data.f_IbOption = e.target.value;
                      setFormData({ ...data });
                    }}
                  >
                    <option value={`${FormData.f_IbOption}`}>
                      {FormData.f_IbOption}
                    </option>
                    <option value="KnowBefore">Know before</option>
                    <option value="Google">Google</option>
                    <option value="Emailer">Emailer</option>
                    <option value="sales">Sales</option>
                  </Form.Control>
                </RB.Col>
                <RB.Col sm="6" className="left_mar">
                  <Form.Label>Company name</Form.Label>
                  <Form.Control
                    type="text"
                    placeholder="Enter Company Name"
                    name="f_CompanyName"
                    value={FormData.f_CompanyName}
                    onChange={handleChange}
                  />
                </RB.Col>
              </Form.Group>

              <Form.Group as={Row} controlId="formPlaintextEmail">
                <RB.Col sm="6" className="right_mar">
                  <Form.Label>Followups Date</Form.Label>
                  <Form.Control
                    type="text"
                    placeholder="Enter Date"
                    name="f_creationdate"
                    value={FormData.f_creationdate}
                    onChange={handleChange}
                  />
                </RB.Col>
                <RB.Col sm="6" className="left_mar">
                  <Form.Label>Contact NO.</Form.Label>
                  <Form.Control
                    type="text"
                    placeholder="Enter Mobile Number"
                    name="f_MobileNo"
                    value={FormData.f_MobileNo}
                    onChange={handleChange}
                  />
                </RB.Col>
              </Form.Group>

              <Form.Group as={Row} controlId="formPlaintextEmail">
                <RB.Col sm="6" className="right_mar">
                  <Form.Label>Contact person</Form.Label>
                  <Form.Control
                    type="text"
                    placeholder="Enter Contact Person"
                    name="f_Firstname"
                    value={FormData.f_Firstname}
                    onChange={handleChange}
                  />
                </RB.Col>
                <RB.Col sm="6" className="left_mar">
                  <Form.Label>Alternate Email</Form.Label>
                  <Form.Control
                    type="email"
                    placeholder="Enter Alternative Email"
                    name="f_AlternateEmail"
                    value={FormData.f_AlternateEmail}
                    onChange={handleChange}
                  />
                </RB.Col>
              </Form.Group>

              <Form.Group as={Row} controlId="formPlaintextEmail">
                <RB.Col sm="6" className="right_mar">
                  <Form.Label>Requirement Type</Form.Label>
                  <Form.Control
                    type="text"
                    placeholder="Enter Requirment Type"
                    name="f_RequirementType"
                    value={FormData.f_RequirementType}
                    onChange={handleChange}
                  />
                </RB.Col>
                <RB.Col sm="6" className="left_mar">
                  <Form.Label>Order Id</Form.Label>
                  <Form.Control
                    type="text"
                    placeholder="Enter Order ID"
                    name="orderid"
                    value={FormData.orderid}
                    onChange={handleChange}
                  />
                </RB.Col>
              </Form.Group>

              <Form.Group as={Row} controlId="formBasicCheckbox">
                <RB.Col sm="6" className="right_mar">
                  <Form.Label>Important follow ups</Form.Label>
                  <Form.Check type="checkbox" />
                </RB.Col>
                <RB.Col sm="6" className="left_mar">
                  <Form.Label>Created by</Form.Label>
                  <Form.Control
                    plaintext
                    readOnly
                    defaultValue={FormData.f_createdby}
                  />
                </RB.Col>
              </Form.Group>
            </RB.Form>
          </RB.Modal.Body>
          <RB.Modal.Footer>
            <RB.Button variant="primary" onClick={onSubmit}>
              SUBMIT
            </RB.Button>
          </RB.Modal.Footer>
        </RB.Modal>

        <RB.Modal
          show={show1}
          onHide={handleClose1}
          size="lg"
          className="modal_con"
        >
          <RB.Modal.Header closeButton>
            <RB.Modal.Title style={{ fontWeight: "bold", fontSize: "22px" }}>
              Daily Sales Entry FollowUps - History
            </RB.Modal.Title>
          </RB.Modal.Header>
          <RB.Modal.Body className="show-grid">
            <RB.Table
              striped
              bordered
              hover
              variant="dark"
              responsive
              className="create_table history_table"
            >
              <thead>
                <tr>
                  <th>Creation Date</th>
                  <th>Followups Date</th>
                  <th>Description</th>
                  <th>Contact Person</th>
                  <th>Contact No.</th>
                  <th>Status</th>
                  <th>Requirement Type</th>
                  <th>Create By</th>
                  <th>Follow up by</th>
                  <th>Order Id</th>
                </tr>
              </thead>
              <tbody>
                {followTable.map((data, inx) => (
                  <tr key={"follow_table_model" + inx}>
                    {/* <td>{data.f_date.slice(0, 10)}</td> */}
                    <td>{Moment(data.f_date).format('DD-MM-YYYY')}</td>
                    <td>{data.f_nextfollowupsdate.slice(0, 10)}</td>
                    <td>{data.f_desc}</td>
                    <td>{data.f_contactperson}</td>
                    <td>{data.f_contactno}</td>
                    <td>{data.f_status}</td>
                    <td>{data.f_requrement}</td>
                    <td>{data.f_createby}</td>
                    <td>{data.f_followupsby}</td>
                    <td>{data.f_followupsby}</td>
                  </tr>
                ))}
              </tbody>
            </RB.Table>
          </RB.Modal.Body>
        </RB.Modal>

        <ProposalInvoiceModel show2={show2} handleClose2={handleClose2} proposalInvoiceDetails={proposalInvoiceDetails} />

        <OrderDetailsModel
          OrderDetailsIsOpen={OrderDetailsIsOpen}
          CloseOrderDetails={CloseOrderDetails}
          OrderDataObj={OrderDataObj}
          OrderDataList={OrderDataList}
          OrderUser={OrderDataObj}
        />
        <OrderInvoiceModel
          OrderInvoiceIsOpen={OrderInvoiceIsOpen}
          CloseOrderInvoice={CloseOrderInvoice}
          OrderInvoiceObj={OrderInvoiceObj}
          OrderInvoiceList={OrderInvoiceList}
        />

      </main>
    </>
  );
};

export default UserAction;
