import React, { useState } from 'react';
import * as RB from "react-bootstrap";
import { Row } from "react-bootstrap";
import { CREATE_COUNTRYS } from "../../../Utils/api";

const AddCountry = (
    { show_addcountry, setShow, apiCall }
) => {
    const [f_country, setf_country] = useState("");
    const [ErrorMsg, setErrorMsg] = useState("")

    const closeModal = () => {
        setShow(false);
        setErrorMsg("")
    }

    const createCountry = async () => {
        const regex = /^[a-zA-Z]*$/;
        const value = regex.test(f_country);
        if (value && f_country !== "") {
            const res = await CREATE_COUNTRYS({ f_country });
            let { status, saveData, message } = res;
            if (status === 200 && saveData) {
                apiCall();
                setErrorMsg("")
                closeModal();
            } else {
                setErrorMsg(message)
            }
        } else {
            setErrorMsg("Please Enter a Valid Country Name!")
        }
    }
    return (
        <div>
            <RB.Modal show={show_addcountry} onHide={closeModal} className="ordermanage_modal">
                <RB.Modal.Header closeButton>
                    <RB.Modal.Title>Add New Country</RB.Modal.Title>
                </RB.Modal.Header>
                <RB.Modal.Body>
                    <RB.Row>
                        <RB.Col lg={12} md={12}>
                            <RB.Row>
                                <RB.Col lg={12} md={12}>
                                    {ErrorMsg === "" ? null : ErrorMsg}
                                    <RB.Form>
                                        <RB.Form.Group as={Row} controlId="Country_id">
                                            <RB.Col lg={4} md={4}>
                                                <RB.Form.Label>Country Name :</RB.Form.Label>
                                            </RB.Col>
                                            <RB.Col lg={7} md={8}>
                                                <RB.Form.Control type="text" name="f_country"
                                                    onChange={(e) => setf_country([e.target.name] = e.target.value)}
                                                />
                                            </RB.Col>
                                        </RB.Form.Group>
                                        <RB.Row>
                                            <RB.Col lg={4} md={4}></RB.Col>
                                            <RB.Col lg={6} md={7}>
                                                <RB.Button
                                                    size="sm" variant="primary"
                                                    onClick={createCountry}
                                                >
                                                    ADD
                                                </RB.Button>
                                            </RB.Col>
                                        </RB.Row>
                                    </RB.Form>
                                </RB.Col>
                            </RB.Row>
                        </RB.Col>
                    </RB.Row>
                </RB.Modal.Body>
            </RB.Modal>
        </div>
    )
}

export default AddCountry