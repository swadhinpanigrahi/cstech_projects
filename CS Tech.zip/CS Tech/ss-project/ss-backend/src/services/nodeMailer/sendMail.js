const { sendEmail } = require("./nodeMailer");
const {
  adminPasswordTemplet,
  marchantPasswordTemplet,
  merchantRegistrationTemplet,
} = require("./template/template");
//Email subject..
const NEW_REGISTRATION = `Reset Your Password!`;

const resetPassword = ({ name, email, token, endPoint }, callback) => {
  sendEmail(
    {
      mailTo: email,
      subject: "Admin Forgot Password Request on storagestation.com",
      html: adminPasswordTemplet(name, token, endPoint),
    },
    callback
  );
};

const marchantResetPassword = ({ name, email, token, endPoint }, callback) => {
  sendEmail(
    {
      mailTo: email,
      subject: "Forgot Password Request on storagestation.com",
      html: marchantPasswordTemplet(name, token, endPoint),
    },
    callback
  );
};

const merchantAutoRegistrationEmail = ({ email, password, name }, callback) => {
  console.log(email, password, name)
  sendEmail(
    {
      mailTo: email,
      subject: "Seller Registration",
      html: merchantRegistrationTemplet(email, password, name),
    },
    callback
  );
};

module.exports = {
  resetPassword,
  marchantResetPassword,
  merchantAutoRegistrationEmail,
};
