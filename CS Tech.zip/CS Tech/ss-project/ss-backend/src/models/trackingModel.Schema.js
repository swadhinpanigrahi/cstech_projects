const Mongoose = require("mongoose");

const trackingModelSchema = new Mongoose.Schema(
  {
    userId: { type: String },
    shipping_method: { type: String },
    order_id: { type: String, unique: true },
    profile: { type: String },
    fulfillment_status: { type: String, lowercase: true },
    order_number: { type: String },
    order_amount: { type: Number },
    shop_name: { type: String },
    account_id: { type: Number },
    partner_order_id: { type: String },
    shipping_name: { type: String },
    from_address: {
      name: { type: String },
      company_name: { type: String },
      address_1: { type: String },
      address_2: { type: String },
      email: { type: String },
      city: { type: String },
      state: { type: String },
      zip: { type: String },
      country: { type: String },
      phone: { type: String },
    },
    to_address: {
      name: { type: String },
      company_name: { type: String },
      address_1: { type: String },
      address_2: { type: String },
      email: { type: String },
      city: { type: String },
      state: { type: String },
      zip: { type: String },
      country: { type: String },
      phone: { type: String },
    },
    tracking_number: { type: String, unique: true },
    label_url: { type: String },
    running_status: { type: Number, default: 0 },
    t_delivery_date: { type: Date, default: null },
    t_return_date: { type: Date, default: null },
    is_return: { type: Boolean, default: false },
  },
  { timestamps: true },
  { collection: "trackingmodel_tbls" }
);

module.exports = trackingModelSchema;
