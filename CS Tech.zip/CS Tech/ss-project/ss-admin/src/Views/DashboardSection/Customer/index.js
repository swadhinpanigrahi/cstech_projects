import React from "react";
import { Route } from "react-router-dom";

import Customer from "./Customer";
import AddCustomer from "./AddCustomer";
// import EditCustomer from "./EditCustomer";
import PaymentCustomer from "./PaymentCustomer";
import StatementCustomer from "./StatementCustomer";
import StatementCustomerV2 from "./StatementCustomerV2";

const CustomerDash = () => {
  return (
    <>
      <main className="pd-b-25">
        <Route path="/dashboard/customer/get" component={Customer} />
        <Route path="/dashboard/customer/add" component={AddCustomer} />
        {/* <Route path="/dashboard/customer/edit/:_id" component={EditCustomer} /> */}
        <Route path="/dashboard/customer/paymrnt/:_id" component={PaymentCustomer} />
        <Route
          path="/dashboard/customer/statement/:_id"
          component={StatementCustomer}
        />
        <Route
          path="/dashboard/customer/statementv2/:_id"
          component={StatementCustomerV2}
        />
      </main>
    </>
  );
};

export default CustomerDash;
