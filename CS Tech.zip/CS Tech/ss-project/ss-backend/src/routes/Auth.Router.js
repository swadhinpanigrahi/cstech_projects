const express = require("express")
const { createValidator } = require("express-joi-validation")

const {
  registerValidator, authLoginValidator, updateValidator, changePasswordValidator
} = require("../validators/Auth.validators");

const {
  updateCustomerValidetor
} = require("../validators/Admin.Validator")

const { generateJwtToken } = require("../middlewares/Auth.middleware");

const {
  AuthRegistration, AuthLogin, verifyProfile, AuthGetProfile, AuthUpdateProfile, AuthChangePassword, authForgotMail, authChangePasswordByEmail,
  merchantLogin, merchantGetProfile, merchantEditProfile, merchantChangePassword, merchantForgotMail, merchantChangePassFromForgotMail
} = require("../controllers/Auth.Controller");

const validator = createValidator({ passError: true });
const authRouter = express.Router();

// AUTH
authRouter.route(`/register`).post(validator.body(registerValidator), AuthRegistration);
authRouter.route(`/login`).post(validator.body(authLoginValidator), AuthLogin);
authRouter.route(`/verifyprofile`).get(generateJwtToken, verifyProfile);
authRouter.route(`/getauthprofile`).get(generateJwtToken, AuthGetProfile);
authRouter.route(`/updateauthprofile`).post(validator.body(updateValidator), generateJwtToken, AuthUpdateProfile);
authRouter.route(`/changeauthpassword/:_id`).post(generateJwtToken, AuthChangePassword);
authRouter.route(`/authForgotMail`).post(authForgotMail);
authRouter.route(`/authemailpasswordchange`).post(authChangePasswordByEmail);

//MERCHANT
authRouter.route(`/merchantlogin`).post(validator.body(authLoginValidator), merchantLogin);
authRouter.route(`/merchantgetprofile/:_id`).get(merchantGetProfile);
authRouter.route(`/merchanteditprofile/:_id`).post(validator.body(updateCustomerValidetor), merchantEditProfile);
authRouter.route(`/merchantchangepassword/:_id`).post(validator.body(changePasswordValidator), merchantChangePassword);
authRouter.route(`/merchantForgotMail`).post(merchantForgotMail);
authRouter.route(`/merchantchangepassfromforgotMail`).post(merchantChangePassFromForgotMail);

module.exports = authRouter