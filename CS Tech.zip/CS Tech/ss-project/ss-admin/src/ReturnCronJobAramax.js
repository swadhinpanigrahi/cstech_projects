import React, { useEffect } from 'react';
import { getAramaxDeliveredShipments, trakin_details, AramaxUpdateStatusToReturn } from "./Utils/api";
//tracking_number, provider

const ReturnCronJobAramax = () => {

    const chnageStatustoReturn = async (element) => {
        await AramaxUpdateStatusToReturn(element)
    }


    useEffect(() => {
        const apiCall = async () => {
            const res = await getAramaxDeliveredShipments();
            let { status, error, shipmentData } = res;
            if (status === 200 && !error) {
                console.log(shipmentData)
                shipmentData.forEach(async (element, inx) => {
                    let { tracking_number, shipping_method } = element;
                    const trakData = await trakin_details(tracking_number, shipping_method);
                    let { statuses, error } = trakData;
                    console.log(inx, tracking_number, statuses);
                    if (!error && statuses) {
                        statuses.forEach(async (element) => {
                            if (element !== undefined) {
                                await chnageStatustoReturn(element);
                            }
                        });
                    }
                })
            } else {
                window.alert("error while fatching shipments")
            }
        }
        apiCall()
    }, []);

    return (
        <div>
            <h1>Scrip is running...</h1>
        </div>
    )
}

export default ReturnCronJobAramax
