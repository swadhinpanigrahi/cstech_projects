const mongoose = require("mongoose");

const t_BannerImgInfoSchema = mongoose.Schema(
    {
        Sno: { type: Number },
        Email: { type: String },
        Ip: { type: String },
        CreatedAt: { type: Date },
    },
    { collection: "t_BannerImgInfo" }
);

module.exports = t_BannerImgInfo = mongoose.model(
    "t_BannerImgInfo",
    t_BannerImgInfoSchema
);