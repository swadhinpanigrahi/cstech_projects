const {
  AdminLogin,
  registration,
  order,
  proposal,
  followup,
  forgetPassTkn,
  T_Orders_IB_MongoDB,
  t_orderproposal_IB_MongoDB,
  // t_DailySalesEntry_sales_IB_MongoDB,
  t_DailySalesEntryfollowups_sales_IB_MongoDB,
  t_LUS104576_IB_MongoDB,
  t_TUR0615518_IB_MongoDB,
  FollowupSchemaV2
} = require("../model");

module.exports = {
  userProfile: async (req, res) => {
    try {
      const { _id } = req.params;
      const registrationData = await registration.findOne({ _id });
      // if (registrationData.f_registrationType === "Register") {
      const data1 = await t_LUS104576_IB_MongoDB.findOne({
        CS_userid: registrationData.f_userid,
      });

      const data2 = await t_TUR0615518_IB_MongoDB.findOne({
        CS_userid: registrationData.f_userid,
      });

      res.json({ status: 200, registrationData, data1, data2 });
      //}
    } catch (error) {
      res
        .status(500)
        .json({ message: `Error in Controller`, error: error.message });
    }
  },

  testFun: async (req, res) => {
    try {
      const { f_userid } = req.params;
      const registrationData = await registration.findOne({ f_userid });
      if (!registrationData) {
        res.json({ status: 200, message: `No Record Found!!` });
      } else {
        const T_orderData = await T_Orders_IB_MongoDB.find({
          T_username: registrationData.f_email,
        });
        const proposal_data = await t_orderproposal_IB_MongoDB.find({
          T_username: registrationData.f_email,
        });
        const followup_data = await FollowupSchemaV2
          .find({
            f_EmailID: registrationData.f_email,
          })
          .sort({ f_creationdate: -1 });
        const follow_status_data = await followup.find({
          f_email: registrationData.f_email,
        });
        let total = T_orderData.length;
        let pending = 0;
        let confirmed = 0;
        let rejected = 0;
        for (let i = 0; i < T_orderData.length; i++) {
          if (T_orderData[i].T_status === "P") {
            pending = pending + 1;
          } else if (T_orderData[i].T_status === "C") {
            confirmed = confirmed + 1;
          } else if (T_orderData[i].T_status === "R") {
            rejected = rejected + 1;
          }
        }
        let orderArr = [
          { name: "Total", count: total, path: "total_data" },
          { name: "Confirmed", count: confirmed, path: "confirmed_data" },
          { name: "Pending", count: pending, path: "pending_data" },
          { name: "Rejected", count: rejected, path: "rejeced_data" },
        ];

        let open = 0;
        let close = 0;
        let sold = 0;
        for (let i = 0; i < follow_status_data.length; i++) {
          if (follow_status_data[i].f_followups_status === "Open") {
            open = open + 1;
          } else if (follow_status_data[i].f_followups_status === "Close") {
            close = close + 1;
          } else if (follow_status_data[i].f_followups_status === "Sold") {
            sold = sold + 1;
          }
        }

        let followupsArr = [
          { name: "Open", count: open },
          { name: "Close", count: close },
          { name: "Sold", count: sold },
        ];

        res.json({
          status: 200,
          T_orderData,
          orderArr,
          proposal_data,
          followup_data,
          followupsArr,
        });
      }
    } catch (error) {
      console.log({ error: error.message });
      res
        .status(500)
        .json({ message: `Error in Controller`, error: error.message });
    }
  },

  companyAction: async (req, res) => {
    try {
      const { f_userid } = req.params;
      const userData = await registration.findOne({ f_userid });
      const groupData = await t_TUR0615518_IB_MongoDB.find({
        group_cmpname: userData.f_groupname,
      });
      console.log(groupData)
      // const groupData = await t_TUR0615518_IB_MongoDB.find({
      //   CS_userid: f_userid,
      // });
      const T_orderData = await T_Orders_IB_MongoDB.find({
        T_username: userData.f_email,
      });
      const proposal_data = await t_orderproposal_IB_MongoDB.find({
        T_username: userData.f_email,
      });
      const followup_data = await FollowupSchemaV2
        .find({
          f_EmailID: userData.f_email,
        })
        .sort({ f_creationdate: -1 });

      const follow_status_data = await followup.find({
        f_email: userData.f_email,
      });

      let total = T_orderData.length;
      let pending = 0;
      let confirmed = 0;
      let rejected = 0;
      for (let i = 0; i < T_orderData.length; i++) {
        if (T_orderData[i].T_status === "P") {
          pending = pending + 1;
        } else if (T_orderData[i].T_status === "C") {
          confirmed = confirmed + 1;
        } else if (T_orderData[i].T_status === "R") {
          rejected = rejected + 1;
        }
      }
      let orderArr = [
        { name: "Total", count: total, path: "total_data" },
        { name: "Confirmed", count: confirmed, path: "confirmed_data" },
        { name: "Pending", count: pending, path: "pending_data" },
        { name: "Rejected", count: rejected, path: "rejeced_data" },
      ];

      let open = 0;
      let close = 0;
      let sold = 0;
      for (let i = 0; i < follow_status_data.length; i++) {
        if (follow_status_data[i].f_followups_status === "Open") {
          open = open + 1;
        } else if (follow_status_data[i].f_followups_status === "Close") {
          close = close + 1;
        } else if (follow_status_data[i].f_followups_status === "Sold") {
          sold = sold + 1;
        }
      }

      let followupsArr = [
        { name: "Open", count: open },
        { name: "Close", count: close },
        { name: "Sold", count: sold },
      ];

      res.json({
        status: 200,
        userData,
        groupData,
        T_orderData,
        proposal_data,
        followup_data,
        orderArr,
        followupsArr,
      });
    } catch (error) {
      console.log({ error: error.message });
      res
        .status(500)
        .json({ message: `Error in Controller`, error: error.message });
    }
  },

  proposalView: async (req, res) => {
    try {
      const { _id } = req.params;
      const proposalData = await proposal.findOne({
        f_proposal_RefrencesID: _id,
      });
      const search = parseInt(proposalData.f_proposal_RefrencesID);
      const tblProposalData = await t_orderproposal_IB_MongoDB.findOne({
        T_orderid: search,
      });
      res.json({ status: 200, proposalData, tblProposalData });
    } catch (error) {
      res
        .status(500)
        .json({ message: `Error in Controller`, error: error.message });
    }
  },

  proposalDelete: async (req, res) => {
    try {
      const { _id } = req.params;
      const proposalData = await proposal.findOne({
        f_proposal_RefrencesID: _id,
      });
      const search = parseInt(proposalData.f_proposal_RefrencesID);
      console.log(search);
      const tblProposalData = await t_orderproposal_IB_MongoDB.findOne({
        T_orderid: search,
      });
      console.log(_id, search);
      await proposal.deleteOne({ _id: proposalData._id });
      await t_orderproposal_IB_MongoDB.deleteOne({ _id: tblProposalData._id });
      res.json({ status: 200, message: "done", deleted: _id });
    } catch (error) {
      res
        .status(500)
        .json({ message: `Error in Controller`, error: error.message });
    }
  },

  getFollowupsDetail: async (req, res) => {
    const { f_sno } = req.params;
    try {
      const followupsData = await FollowupSchemaV2.findOne({
        f_sno,
      });
      res.json({ status: 200, followupsData });
    } catch (error) {
      res
        .status(500)
        .json({ message: `Error in Controller`, error: error.message });
    }
  },

  getFollowupsDetailsForTable: async (req, res) => {
    const { f_sno } = req.params;
    try {
      const followupsData =
        await t_DailySalesEntryfollowups_sales_IB_MongoDB.find({
          f_sno,
        });
      res.json({ status: 200, followupsData });
    } catch (error) {
      res
        .status(500)
        .json({ message: `Error in Controller`, error: error.message });
    }
  },

  postFollowups: async (req, res) => {
    const data = req.body;
    try {
      const newData = new t_DailySalesEntryfollowups_sales_IB_MongoDB({
        f_sno: data.f_sno,
        f_username: data.f_EmailID,
        f_status: data.f_status,
        f_desc: data.discription,
        f_createby: data.f_createdby,
        f_nextfollowupsdate: data.f_creationdate,
        f_date: data.f_creationdate,
        f_followupsby: data.f_followpby,
        f_requrement: data.f_RequirementType,
        f_contactno: data.f_MobileNo,
        f_contactperson: data.f_Firstname,
      });
      const savedData = await newData.save();
      if (savedData) {
        res.json({ status: 200, message: "added successfully" });
      } else {
        res.json({ status: 400, message: "something went wrong!!" });
      }
    } catch (error) {
      res
        .status(500)
        .json({ message: `Error in Controller`, error: error.message });
    }
  },
};
