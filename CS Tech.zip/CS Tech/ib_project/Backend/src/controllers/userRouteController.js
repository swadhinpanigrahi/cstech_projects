const {
  AdminLogin,
  registration,
  order,
  proposal,
  followup,
  forgetPassTkn,
  T_Orders_IB_MongoDB,
  invoiceSchema,
  t_invoice_IB_MongoDB,
  orderDetailSchema,
  CountrySchema,
  StateSchema,
  t_LUS104576_IB_MongoDB,
  t_TUR0615518_IB_MongoDB,
  t_orderproposal_IB_MongoDB,
  FollowupSchemaV2
} = require("../model");
const companyMasterSchema = require("../model/companyMasterSchema");
const request = require('request')
const { dir } = require("../config/fileSource");
const { SQL_URL } = require('../config/config')
const {
  generateToken,
  checkAuthorization,
  veridyEmailPassword,
} = require("../utils/jwt");
const { IBresetPassword } = require("../utils/nodeMailer/sendMail");

module.exports = {
  userLogin: async (req, res) => {
    try {
      const { username, password } = req.body;
      const userData = await AdminLogin.findOne({ email: username });
      if (userData) {
        if (userData.password === password) {
          const tokenData = {
            id: userData._id,
            username: userData.username,
            email: userData.email,
            userid: userData.userid,
          };
          const token = await generateToken(tokenData);
          res.json({ status: 200, token });
        } else {
          res.json({ status: 200, message: "incorrect password!!" });
        }
      } else {
        res.json({ status: 200, message: "user does not exist!!" });
      }
    } catch (error) {
      res
        .status(500)
        .json({ message: `Error in Controller`, error: error.message });
    }
  },

  varify: async (req, res) => {
    try {
      const tokenData = await checkAuthorization(req);
      res.json({ status: 200, tokenData });
    } catch (error) {
      res.json({ message: `Error in Controller`, error: error.message });
    }
  },

  changePassword: async (req, res) => {
    try {
      const tokenData = await checkAuthorization(req);
      if (tokenData) {
        const { currPassword, newPassword, confirmPassword } = req.body;
        const userInfo = await AdminLogin.findOne({ _id: tokenData.id });
        if (userInfo.password === currPassword) {
          if (newPassword === confirmPassword) {
            const updateUser = await AdminLogin.updateOne(
              { _id: tokenData.id },
              {
                $set: {
                  password: newPassword,
                },
              }
            );
            res.json({ status: 200, updateUser });
          } else {
            res.json({ status: 400, message: `new and confirm password did't match!!` });
          }
        } else {
          res.json({ status: 400, message: "incorrect current password!!" });
        }
      } else {
        res.json({ status: 400, message: "session expired!!" });
      }
    } catch (error) {
      res.json({ message: `Error in Controller`, error: error.message });
    }
  },
  getAdminInfo: async (req, res) => {
    try {
      var userId = req.query.userId;
      console.log(userId);
      const userInfo = await AdminLogin.findOne({ _id: userId });
      res.send(userInfo)
      console.log(userInfo);
    } catch (error) {
      res.json({ message: `Error in Controller`, error: error.message });
    }
  },
  forgetPasswordEmail: async (req, res) => {
    try {
      const { email } = req.body;
      const authData = await AdminLogin.findOne({ email });
      if (authData) {
        let tokenData = {
          id: authData._id,
          username: authData.username,
          email: authData.email,
          userid: authData.userid,
        };
        const token = generateToken(tokenData);
        let name = `${authData.username}`;
        IBresetPassword(
          {
            name,
            email,
            token,
            // endPoint: `http://localhost:3000`,
            endPoint: `http://ibadminreact.cstechns.com/#`,
          },
          (data, error) => {
            if (!error) {
              console.log(data);
            } else {
              console.log(error);
            }
          }
        );
        await new forgetPassTkn({ token }).save();
        res.json({ status: 200, message: "Email Send Successfully!" });
      } else {
        res.json({ status: 400, message: "Invalid EmailID!!" });
      }
    } catch (error) {
      res.json({ message: `Error in Controller`, error: error.message });
    }
  },

  changePasswordFromEmail: async (req, res) => {
    try {
      const { token, password, confirmPassword } = req.body;
      const isToken = await forgetPassTkn.findOne({ token });
      if (password === confirmPassword) {
        if (isToken) {
          const isValid = veridyEmailPassword(isToken.token);
          const updatedData = await AdminLogin.updateOne(
            { _id: isValid.id },
            {
              $set: {
                password,
              },
            }
          );
          await forgetPassTkn.deleteOne({ _id: isToken._id });
          res.json({
            status: 200,
            message: "Successfully Changed Your Password!!",
          });
        } else {
          res.json({ status: 400, message: `session expire!!` });
        }
      } else {
        res.json({ status: 400, message: `Password Did't Match!!` });
      }
    } catch (error) {
      res.json({ message: `Error in Controller`, error: error.message });
    }
  },
  cardCount: async (req, res) => {
    try {
      const tokenData = await checkAuthorization(req);
      const pendingOrderPipeline = [
        {
          $match: {
            T_status: {
              $eq: "P",
            },
          },
        },
        {
          $count: "pendingOrders",
        },
      ];
      const followUpPipeline = [
        {
          $match: {
            f_createdby: "admin",
          },
        },
        {
          $count: "followup_count",
        },
      ];
      const proposalPipeline = [
        {
          $match: { f_proposal_email: tokenData.email },
        },
        {
          $count: "poposalEmail",
        },
      ];
      const unregistedPipeline = [
        {
          $match: { $and: [{ f_Shortname: { $eq: null } }, { f_groupname: { $eq: null } }] }
        },
        {
          $count: "unregisted",
        }
      ]
      let arr = [];
      const pendingOrderCount = await T_Orders_IB_MongoDB.aggregate(pendingOrderPipeline);
      const followUpCount = await followup.aggregate(followUpPipeline);
      const proposalCount = await proposal.aggregate(proposalPipeline);
      const unregisteredCount = await registration.aggregate(unregistedPipeline)
      arr = [...pendingOrderCount, ...followUpCount, ...proposalCount, ...unregisteredCount];
      res.json({
        status: 200,
        arr,
      });
    } catch (error) {
      res.json({ message: `Error in Controller`, error: error.message });
    }
  },
  // cardCount: async (req, res) => {
  //   try {
  //     const tokenData = await checkAuthorization(req);
  //     const pendingOrderPipeline = [
  //       {
  //         $match: {
  //           f_order_Pending: {
  //             $gt: "0",
  //           },
  //         },
  //       },
  //       {
  //         $count: "pendingOrders",
  //       },
  //     ];
  //     const followUpPipeline = [
  //       {
  //         $match: {
  //           f_createdby: "admin",
  //         },
  //       },
  //       {
  //         $count: "followup_count",
  //       },
  //     ];
  //     const proposalPipeline = [
  //       {
  //         $match: { f_proposal_email: tokenData.email },
  //       },
  //       {
  //         $count: "poposalEmail",
  //       },
  //     ];
  //     let arr = [];
  //     const pendingOrderCount = await order.aggregate(pendingOrderPipeline);
  //     const followUpCount = await followup.aggregate(followUpPipeline);
  //     const proposalCount = await proposal.aggregate(proposalPipeline);
  //     arr = [...pendingOrderCount, ...followUpCount, ...proposalCount];
  //     res.json({
  //       status: 200,
  //       arr,
  //     });
  //   } catch (error) {
  //     res.json({ message: `Error in Controller`, error: error.message });
  //   }
  // },

  onSearchBarCustomerDetails: async (req, res) => {
    try {
      const { search } = req.body;
      const pipeLine = [
        {
          $match: {
            $or: [
              { f_fullname: { $regex: search, $options: "im" } },
              { f_email: { $regex: search, $options: "im" } },
              { f_mobileno: { $regex: search, $options: "im" } },
              { f_companyname: { $regex: search, $options: "im" } },
              { f_Shortname: { $regex: search, $options: "im" } },
              { f_groupname: { $regex: search, $options: "im" } },
            ],
          },
        },
      ];
      const userData = await registration.aggregate(pipeLine);
      console.log(userData.length);
      res.json({ status: 200, userData });
    } catch (error) {
      res.json({ message: `Error in Controller`, error: error.message });
    }
  },

  onSearchBarOrderDetails: async (req, res) => {
    try {
      const { search } = req.body;
      const pipeLine = [
        {
          $match: {
            $or: [
              { f_clientname: { $regex: search, $options: "im" } },
              { f_email: { $regex: search, $options: "im" } },
              { f_mobileno: { $regex: search, $options: "im" } },
              { f_companyname: { $regex: search, $options: "im" } },
            ],
          },
        },
      ];
      const userData = await order.aggregate(pipeLine);
      let total = 0;
      let confermed = 0;
      let pending = 0;
      let rejeced = 0;
      for (let i = 0; i < userData.length; i++) {
        if (
          userData[i].f_order_total ||
          userData[i].f_order_Confirm ||
          userData[i].f_order_Pending ||
          userData[i].f_order_Rejected
        ) {
          total += parseInt(userData[i].f_order_total);
          confermed += parseInt(userData[i].f_order_Confirm);
          pending += parseInt(userData[i].f_order_Pending);
          rejeced += parseInt(userData[i].f_order_Rejected);
        }
      }
      const countArr = [
        {
          name: "Total",
          count: total,
          path: "total_data",
        },
        {
          name: "Confirmed",
          count: confermed,
          path: "confirmed_data",
        },
        {
          name: "Pending",
          count: pending,
          path: "pending_data",
        },
        {
          name: "Rejected",
          count: rejeced,
          path: "rejeced_data",
        },
      ];
      res.json({ status: 200, userData, countArr });
    } catch (error) {
      res.json({ message: `Error in Controller`, error: error.message });
    }
  },

  onSearchBarProposalDetails: async (req, res) => {
    try {
      const { search } = req.body;
      const pipeLine = [
        {
          $match: {
            $or: [
              { T_username: { $regex: search, $options: "im" } },
              // { f_proposalheading: { $regex: search, $options: "im" } },
              // { f_mobileno: { $regex: search, $options: "im" } },
            ],
          },
        },
      ];
      const userData = await t_orderproposal_IB_MongoDB.aggregate(pipeLine);
      res.json({ status: 200, userData });
    } catch (error) {
      res.json({ message: `Error in Controller`, error: error.message });
    }
  },

  onSearchBarFollowupDetails: async (req, res) => {
    try {
      const { search } = req.body;
      const pipeLine = [
        {
          $match: {
            $or: [
              { f_email: { $regex: search, $options: "im" } },
              { f_AlternateEmail: { $regex: search, $options: "im" } },
              { f_fullname: { $regex: search, $options: "im" } },
              { f_CompanyName: { $regex: search, $options: "im" } },
              { f_PhoneNumber: { $regex: search, $options: "im" } },
              { f_MobileNo: { $regex: search, $options: "im" } },
            ],
          },
        },
        {
          $sort: {
            f_creationdate: -1,
          },
        },
      ];
      const userData = await followup.aggregate(pipeLine);
      let open = 0;
      let close = 0;
      let Sold = 0;
      for (let i = 0; i < userData.length; i++) {
        if (userData[i].f_followups_status === "Close") {
          close += 1;
        } else if (userData[i].f_followups_status === "Open") {
          open += 1;
        } else if (userData[i].f_followups_status === "Sold") {
          Sold += 1;
        }
      }
      let spanArray = [
        { name: "Open", count: open, path: "open_data" },
        { name: "Close", count: close, path: "close_data" },
        { name: "Sold", count: Sold, path: "sold_data" },
      ];
      res.json({ status: 200, userData, spanArray });
    } catch (error) {
      res.json({ message: `Error in Controller`, error: error.message });
    }
  },

  onButtonClickData: async (req, res) => {
    try {
      const { btn_search } = req.params;
      const { search } = req.body;
      if (btn_search === "total_data") {
        const pipeline = [
          {
            $match: {
              $or: [
                { f_clientname: { $regex: search, $options: "im" } },
                { f_email: { $regex: search, $options: "im" } },
                { f_mobileno: { $regex: search, $options: "im" } },
              ],
            },
          },
          {
            $project: { f_email: 1 },
          },
          {
            $lookup: {
              from: "T_Orders_IB_MongoDB",
              localField: "f_email",
              foreignField: "T_username",
              as: "T_order_tbl",
            },
          },
          {
            $unwind: { path: "$T_order_tbl" },
          },
          { $replaceRoot: { newRoot: "$T_order_tbl" } },
        ];
        const userData = await order.aggregate(pipeline);
        res.json({ status: 200, userData });
      } else if (btn_search === "confirmed_data") {
        const pipeline = [
          {
            $match: {
              $or: [
                { f_clientname: { $regex: search, $options: "im" } },
                { f_email: { $regex: search, $options: "im" } },
                { f_mobileno: { $regex: search, $options: "im" } },
              ],
            },
          },
          {
            $project: { f_email: 1 },
          },
          {
            $lookup: {
              from: "T_Orders_IB_MongoDB",
              localField: "f_email",
              foreignField: "T_username",
              as: "T_order_tbl",
            },
          },
          {
            $unwind: { path: "$T_order_tbl" },
          },
          { $replaceRoot: { newRoot: "$T_order_tbl" } },
          {
            $match: { T_status: "C" },
          },
        ];
        const userData = await order.aggregate(pipeline);
        res.json({ status: 200, userData });
      } else if (btn_search === "pending_data") {
        const pipeline = [
          {
            $match: {
              $or: [
                { f_clientname: { $regex: search, $options: "im" } },
                { f_email: { $regex: search, $options: "im" } },
                { f_mobileno: { $regex: search, $options: "im" } },
              ],
            },
          },
          {
            $project: { f_email: 1 },
          },
          {
            $lookup: {
              from: "T_Orders_IB_MongoDB",
              localField: "f_email",
              foreignField: "T_username",
              as: "T_order_tbl",
            },
          },
          {
            $unwind: { path: "$T_order_tbl" },
          },
          { $replaceRoot: { newRoot: "$T_order_tbl" } },
          {
            $match: { T_status: "P" },
          },
        ];
        const userData = await order.aggregate(pipeline);
        res.json({ status: 200, userData });
      } else if (btn_search === "rejeced_data") {
        const pipeline = [
          {
            $match: {
              $or: [
                { f_clientname: { $regex: search, $options: "im" } },
                { f_email: { $regex: search, $options: "im" } },
                { f_mobileno: { $regex: search, $options: "im" } },
              ],
            },
          },
          {
            $project: { f_email: 1 },
          },
          {
            $lookup: {
              from: "T_Orders_IB_MongoDB",
              localField: "f_email",
              foreignField: "T_username",
              as: "T_order_tbl",
            },
          },
          {
            $unwind: { path: "$T_order_tbl" },
          },
          { $replaceRoot: { newRoot: "$T_order_tbl" } },
          {
            $match: { T_status: "R" },
          },
        ];
        const userData = await order.aggregate(pipeline);
        res.json({ status: 200, userData });
      }
    } catch (error) {
      res.json({ message: `Error in Controller`, error: error.message });
    }
  },

  // userRoputeController.js  bottom

  getOrderbyOrderId: async (req, res) => {
    const { orderId } = req.params
    try {
      const OrderDetail = await T_Orders_IB_MongoDB.findOne({ T_orderid: orderId });
      const OrderDetailsList = await orderDetailSchema.find({ t_orderid: orderId });
      const userDetails = await registration.findOne({ f_email: OrderDetail.T_username });
      res.json({ status: 200, OrderDetail, OrderDetailsList, userDetails })
    } catch (error) {
      res.json({
        status: false,
        message: "Internal Server Error",
        error: error.message,
      });
    }
  },

  getOrderInvoiceOrderId: async (req, res) => {
    const { orderId } = req.params
    try {
      const OrderInvoice = await t_invoice_IB_MongoDB.findOne({ orderid: orderId });
      const OrderInvoiceList = await invoiceSchema.find({ f_orderid: orderId })
      console.log(orderId, OrderInvoice, OrderInvoiceList)
      res.json({ status: 200, OrderInvoice, OrderInvoiceList })
    } catch (error) {
      res.json({
        status: false,
        message: "Internal Server Error",
        error: error.message,
      });
    }
  },

  getUserDeatilsByUsername: async (req, res) => {
    const userData1 = await t_LUS104576_IB_MongoDB.findOne({
      CS_userid: req.params.uname,
    });
    const userData2 = await t_TUR0615518_IB_MongoDB.findOne({
      CS_userid: req.params.uname,
    });
    res.json({
      status: true,
      data: {
        userData1,
        userData2,
      },
      msg: "User Info fetched successfully..",
    });
  },
  getCountryList: async (req, res) => {
    try {
      var countryList = await CountrySchema.find({});
      res.json({
        status: false,
        CountryList: countryList,
        message: "Country data fetched successfully.."
      })
    } catch (error) {
      console.log('coming in else');
      res.json({
        status: false,
        userData: "",
        message: error
      })
    }
  },
  getStateByID: async (req, res) => {
    try {
      var stateList = await StateSchema.find({ CountryID: parseInt(req.params.CountryID) });
      res.json({
        status: false,
        stateList: stateList,
        message: "State data fetched successfully.."
      })
    } catch (error) {
      console.log('coming in else');
      res.json({
        status: false,
        userData: "",
        message: error
      })
    }
  },
  getCompanyMaster: async (req, res) => {
    try {
      var CompanyMaster = await CompanyMasterSchema.find({});
      res.json({
        status: true,
        CompanyMaster: CompanyMaster,
        message: "CompanyMaster data fetched successfully.."
      })
    } catch (error) {
      console.log('coming in else');
      res.json({
        status: false,
        userData: "",
        message: error
      })
    }
  },


  fetchCompanyDataByKeyPress: async (req, res) => {
    console.log(req.body);
    try {
      var CompanyMaster = await CompanyMasterSchema.find({ "f_companyname": { '$regex': req.body.compName } });
      console.log(CompanyMaster);
      res.json({
        status: true,
        companyData: CompanyMaster,
        message: "CompanyMaster fetched.."
      })
    } catch (error) {
      res.json({
        status: false,
        companyData: "",
        message: error
      })
    }
  },


  SubMitFollowUpRecord: async (req, res) => {
    const { AdditionalList } = req.body
    try {
      // var obj = {
      var ats = Math.floor(Math.random() * Date.now());
      // var ats = Math.random(a)
      folowData = new FollowupSchemaV2({
        f_sno: ats,
        f_email: req.body.cs_ccmail,
        f_AlternateEmail: req.body.f_AlternateEmail,
        f_fullname: req.body.CS_firstname + ' ' + req.body.CS_lastname,
        f_CompanyName: req.body.CS_companynames,
        f_PhoneNumber: req.body.CS_phone,
        f_MobileNo: req.body.CS_mobile,
        f_state: req.body.CS_state,
        f_country: 'India', //req.body.country,
        f_usertype: req.body.userType,
        f_RequirementType: req.body.f_RequirementType,
        f_followups_status: "Open",
        f_createdby: "",
        f_creationdate: Date.now(),
        f_DescriptionType: req.body.aboutIB,
        f_DiscountTerms: req.body.discountTerm,
        f_CreditPeriod: req.body.credetPeriod,
        f_OrderId: req.body.orderID,
        f_followUpType1: req.body.followUpType,
        f_followUpType2: req.body.followUpType2,
        f_followUpDescriptionType: req.body.followUpDescriptionType,
        f_followUpDescriptionType2: req.body.followUpDescriptionType2,
        f_followupDate: req.body.followupDate,
        f_followupDate2: req.body.followupDate2,
        f_followupDescription: req.body.followupDescription,
        f_followupDescription2: req.body.followupDescription2,
        f_followupOrderID: req.body.followupOrderID,
        f_followupOrderID2: req.body.followupOrderID2,
        f_AdditionalInfo: AdditionalList,
      })

      followupData = new followup({
        f_sno: ats,
        f_email: req.body.cs_ccmail,
        f_AlternateEmail: req.body.f_AlternateEmail,
        f_fullname: req.body.CS_firstname + ' ' + req.body.CS_lastname,
        f_CompanyName: req.body.CS_companynames,
        f_PhoneNumber: req.body.CS_phone,
        f_MobileNo: req.body.CS_mobile,
        f_state: req.body.CS_state,
        f_country: 'India', //req.body.country,
        f_usertype: "Existing",//req.body.userType,
        f_RequirementType: req.body.f_RequirementType,
        f_followups_status: "Open",
        f_createdby: "",
        f_creationdate: Date.now(),
        f_DescriptionType: req.body.aboutIB,
        f_DiscountTerms: req.body.f_DiscountTerms,
        f_CreditPeriod: req.body.credetPeriod,
        f_OrderId: req.body.orderID,
        f_followUpType1: req.body.followUpType,
        f_followUpType2: req.body.followUpType2,
        f_followUpDescriptionType: req.body.followUpDescriptionType,
        f_followUpDescriptionType2: req.body.followUpDescriptionType2,
        f_followupDate: req.body.followupDate,
        f_followupDate2: req.body.followupDate2,
        f_followupDescription: req.body.followupDescription,
        f_followupDescription2: req.body.followupDescription2,
        f_followupOrderID: req.body.followupOrderID,
        f_followupOrderID2: req.body.followupOrderID2,
        f_AdditionalInfo: AdditionalList,
      })
      const result = await folowData.save();
      const result1 = await followupData.save();


      setTimeout(() => {
        request({
          url: `${SQL_URL}/admin/createNewFollowUpMongoToSql`,
          method: "POST",
          headers: {
            "content-type": "application/json",
          },
          body: {
            "userInfo": req.body
          },
          json: true
        }, function (err, httpResponse, body) {
          console.log(err, body);
          //  res.json({ status: 200, message: "Invoice Rejected" })
          res.json({
            status: true,
            data: result,
            msg: "Followup data created successfully.."
          })
        }
        );
      }, 500);



    } catch (error) {
      console.log(error);
      res.json({
        status: false,
        data: "",
        msg: error
      })
    }
  },


  updateUserActionEdit: async (req, res) => {
    console.log(req.body);
    // t_LUS104576_IB_MongoDB
    // t_TUR0615518_IB_MongoDB
    console.log(req.body.userInfoEdit1.CS_userid);
    await t_LUS104576_IB_MongoDB.update({ CS_userid: '58504' },
      {
        $set: {
          CS_username: req.body.userInfoEdit1.CS_username,
          CS_password: req.body.userInfoEdit1.CS_password,
          CS_email: req.body.userInfoEdit1.CS_email,
          CS_firstname: req.body.userInfoEdit1.CS_firstname,
          CS_lastname: req.body.userInfoEdit1.CS_lastname,
          CS_status: req.body.userInfoEdit1.CS_status,
          CS_IPAddress: req.body.userInfoEdit1.CS_IPAddress,
          cs_active: req.body.userInfoEdit1.cs_active,
          cs_refid: req.body.userInfoEdit1.cs_refid,
          cs_ecashamt: req.body.userInfoEdit1.cs_ecashamt,
          f_EcashSetUp: req.body.userInfoEdit1.f_EcashSetUp,
          CS_companynames: req.body.userInfoEdit1.CS_companynames,
          cs_date: req.body.userInfoEdit1.cs_date,
          CS_mobile: req.body.userInfoEdit1.CS_mobile,
          cs_followups_status: req.body.userInfoEdit1.cs_followups_status,
          f_GSTIN: req.body.userInfoEdit1.f_GSTIN,
          f_ISDNo: req.body.userInfoEdit1.f_ISDNo,
          f_userAttempt: req.body.userInfoEdit1.f_userAttempt,
          f_attemptTime: req.body.userInfoEdit1.f_attemptTime
        }
      });
    await t_TUR0615518_IB_MongoDB.updateOne({ CS_userid: req.body.userInfoEdit2.CS_userid },
      {
        $set: req.body.userInfoEdit2
      });


    // res.send('updated');


  },

  customerProfile: async (req, res) => {
    let { f_userid } = req.params;
    f_userid = f_userid.toString();
    console.log(f_userid)
    try {
      const registrationData = await registration.findOne({ f_userid });

      const t_LUS = await t_LUS104576_IB_MongoDB.findOne({
        CS_userid: registrationData.f_userid,
      });

      const t_TUR = await t_TUR0615518_IB_MongoDB.findOne({
        CS_userid: registrationData.f_userid,
      });
      if (registrationData && t_LUS && t_TUR) {
        res.json({ status: 200, registrationData, t_LUS, t_TUR });
      } else {
        res.json({ status: 400, message: "Data missmacthed while fatching from DB" })
      }

    } catch (error) {
      res.json({ status: 500, error: error.message, message: "internal server error" })
    }
  },

  editCustomerProfile: async (req, res) => {
    const data = req.body;
    const { f_userid } = req.params;
    const { _id, CS_username, CS_password, CS_email, CS_firstname, CS_lastname, CS_IPAddress,
      cs_active, CS_active, cs_refid, cs_ecashamt, f_EcashSetUp, CS_companynames, CS_mobile, cs_followups_status,
      f_GSTIN, f_ISDNo, f_userAttempt, f_attemptTime, f_sno, CS_jobdesc, CS_businesstype, CS_country, CS_address,
      CS_state, CS_pin, CS_phone, CS_subscribe, CS_lightboxname, CS_comment, f_Identify_User,
      cs_info, CS_status, cs_gold, cs_ccmail, cs_proposal, cs_performaUser, cs_Commission, cs_subscriptionccmail,
      cs_SubscriptionDiscount, f_Subscriptionconnectedto, sortcmp_name, Identify_User, group_cmpname,
      Identify_date, f_exclude, act_highres, ip_address, limit_img, f_addcmpname, f_pan, ivs_download,
      cs_discount
    } = data
    try {
      const registrationData = await registration.findOne({ f_userid });
      const t_LUS = await t_LUS104576_IB_MongoDB.findOne({ CS_userid: registrationData.f_userid });
      const t_TUR = await t_TUR0615518_IB_MongoDB.findOne({ CS_userid: registrationData.f_userid });
      // console.log(registrationData, t_LUS, t_TUR)
      if (registrationData && t_LUS && t_TUR) {
        await registration.updateOne({ f_userid }, {
          $set: {
            f_fullname: `${CS_firstname} ${CS_lastname}`, f_email: CS_email,
            f_mobileno: CS_mobile, f_companyname: CS_companynames, f_Shortname: sortcmp_name,
            f_groupname: group_cmpname, f_Identify_User: f_Identify_User, CS_phone: CS_phone,
            f_address: CS_address, f_state: CS_state, f_country: CS_country, f_commissionpolicy: cs_Commission
          }
        })
        await t_LUS104576_IB_MongoDB.updateOne({ CS_userid: t_LUS.CS_userid }, {
          $set: {
            CS_username, CS_password, CS_email, CS_firstname, CS_lastname, CS_status, CS_IPAddress, cs_active,
            cs_refid, cs_ecashamt, f_EcashSetUp, CS_companynames, CS_mobile, cs_followups_status,
            f_GSTIN, f_ISDNo, f_userAttempt
          }
        })
        await t_TUR0615518_IB_MongoDB.updateOne({ CS_userid: t_TUR.CS_userid }, {
          $set: {
            CS_firstname, CS_lastname, CS_companynames, cs_ecashamt, CS_businesstype, CS_country, CS_address,
            CS_state, CS_state, CS_pin, CS_mobile, CS_comment, sortcmp_name, Identify_User, ip_address,
            f_GSTIN, f_userAttempt, group_cmpname, CS_jobdesc, CS_phone, CS_lightboxname,
            cs_ccmail, f_pan, f_Subscriptionconnectedto, cs_discount, limit_img, f_addcmpname,
            cs_subscriptionccmail, cs_proposal, cs_performaUser, cs_Commission, cs_SubscriptionDiscount, f_exclude,
            ivs_download, act_highres, CS_active
          }
        })
        setTimeout(() => {
          request({
            url: `${SQL_URL}/admin/updateUserInfo`,
            method: "POST",
            headers: {
              "content-type": "application/json",
            },
            body: {
              "userInfo": data,
              "f_userid": f_userid
            },
            json: true
          }, function (err, httpResponse, body) {
            console.log(err, body);
            //  res.json({ status: 200, message: "Invoice Rejected" })
            res.json({ status: 200, message: "user updated successfully!!" });
          }
          );
        }, 500);


      } else {
        res.json({ status: 400, message: "Data missmacthed while fatching from DB" })
      }

    } catch (error) {
      res.json({ status: 500, error: error.message, message: "internal server error" })
    }
  },

  fetchEmailDataByKeyPress: async (req, res) => {
    console.log(req.body);
    try {
      var emailList = await t_TUR0615518_IB_MongoDB.find({ "cs_ccmail": { '$regex': req.body.emailId } }).limit(20)
      console.log(emailList);
      res.json({
        status: true,
        EmailData: emailList,
        message: "Email List fetched.."
      })
    } catch (error) {
      console.log(error);
      res.json({
        status: false,
        EmailData: "",
        message: error
      })
    }
  },

  getDailySalesEntryLists: async (req, res) => {

    let { currentPage, itemPerPage, searchData } = req.query;
    console.log(currentPage, itemPerPage, searchData);
    const num = parseInt(itemPerPage);
    const start = parseInt(currentPage);
    let pipeline;
    let proposalCount;
    try {
      if (!searchData) {
        pipeline = [
          { $sort: { _id: -1 } },
          { $skip: (start - 1) * num },
          { $limit: num },
        ];
        proposalCount = await followup.aggregate([
          { $count: "totalCount" },
        ]);
      }

      if (searchData) {
        pipeline = [
          {
            $match: {
              $or: [
                { f_email: { $regex: searchData, "$options": "i" } },
                { f_fullname: { $regex: searchData, "$options": "i" } },
                { f_CompanyName: { $regex: searchData, "$options": "i" } },
                { f_MobileNo: { $regex: searchData, "$options": "i" } },
                { f_DiscountTerms: { $regex: searchData, "$options": "i" } },
                { f_CreditPeriod: { $regex: searchData, "$options": "i" } },
                { f_RequirementType: { $regex: searchData, "$options": "i" } },
                { f_AlternateEmail: { $regex: searchData, "$options": "i" } },
                { f_createdby: { $regex: searchData, "$options": "i" } },
                { f_followups_status: { $regex: searchData, "$options": "i" } },
              ],
            },
          },
          { $sort: { _id: -1 } },
          { $skip: (start - 1) * num },
          { $limit: num },
        ];
        proposalCount = await followup.aggregate([
          {
            $match: {
              $or: [
                { f_email: { $regex: searchData, "$options": "i" } },
                { f_fullname: { $regex: searchData, "$options": "i" } },
                { f_CompanyName: { $regex: searchData, "$options": "i" } },
                { f_MobileNo: { $regex: searchData, "$options": "i" } },
                { f_DiscountTerms: { $regex: searchData, "$options": "i" } },
                { f_CreditPeriod: { $regex: searchData, "$options": "i" } },
                { f_RequirementType: { $regex: searchData, "$options": "i" } },
                { f_AlternateEmail: { $regex: searchData, "$options": "i" } },
                { f_createdby: { $regex: searchData, "$options": "i" } },
                { f_followups_status: { $regex: searchData, "$options": "i" } },
              ],
            },
          },
          { $count: "totalCount" },
        ]);
      }

      const proposalData = await followup.aggregate(pipeline);
      res.json({ proposalCount: proposalCount, proposalData });
    } catch (error) {
      res.json({ message: `Error in Controller`, error: error.message });
    }
  },
  getFollowupsDetailsTableByIDs: async (req, res) => {

    const { f_sno } = req.query;
    console.log(f_sno);
    try {
      const followupsData =
        await t_DailySalesEntryfollowups_sales_IB_MongoDB.find({
          f_sno,
        });
      res.json({ status: 200, followupsData });
    } catch (error) {
      res
        .status(500)
        .json({ message: `Error in Controller`, error: error.message });
    }
  },
  getFollowupsDetailsByIds: async (req, res) => {
    const { f_sno } = req.query;
    console.log(f_sno);
    try {
      const followupsData = await followup.findOne({ f_sno })
      console.log(followupsData);
      res.json({ status: 200, followupsData });
    } catch (error) {
      console.log(error);
      res
        .status(500)
        .json({ message: `Error in Controller`, error: error.message });
    }
  },
  getDailySalesEntryListByFilter: async (req, res) => {
    try {
      console.log(req.body);
      // var data = await followup.find({}).sort({ _id: -1 }).limit(100);
      // //console.log(data.data);
      let pipeline;
      let searchData = req.body.qry

      pipeline = [
        {
          $match: {
            $or: [
              { f_email: { $regex: searchData, "$options": "i" } },
              { f_fullname: { $regex: searchData, "$options": "i" } },
              { f_CompanyName: { $regex: searchData, "$options": "i" } },
              { f_MobileNo: { $regex: searchData, "$options": "i" } },
              { f_DiscountTerms: { $regex: searchData, "$options": "i" } },
              { f_CreditPeriod: { $regex: searchData, "$options": "i" } },
              { f_RequirementType: { $regex: searchData, "$options": "i" } },
              { f_AlternateEmail: { $regex: searchData, "$options": "i" } },
              { f_createdby: { $regex: searchData, "$options": "i" } },
              { f_followups_status: { $regex: searchData, "$options": "i" } },

              // { category: { $regex: searchData } },
            ]
          }
        },
        { $sort: { _id: -1 } },

      ]
      const data = await followup.aggregate(pipeline).limit(100);
      console.log(data.length);
      res.json({
        status: 200,
        message: "Data fetched",
        data: data
      })
    } catch (error) {
      res.json({
        status: 500,
        message: "Some internal error : " + error,
        data: []
      })
    }
  },

  getmasterstatecustom: async (req, res) => {
    try {
      const data = await StateSchema.find({}, { Name: 1 });
      res.json({ status: 200, data })
    } catch (error) {
      res.json({
        status: 500,
        message: "Some internal error : " + error,
        data: []
      })
    }
  }
};
