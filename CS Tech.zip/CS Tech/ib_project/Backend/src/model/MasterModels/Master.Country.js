const mongoose = require("mongoose");

const MasterCountrySchema = mongoose.Schema(
    {
        f_countryid: { type: String },
        f_country: { type: String },
        f_creationdate: { type: Date },
        f_status: { type: Boolean },
        f_state_available: { type: Boolean }
    },
    { collection: "t_country" }
);

module.exports = M_COUNTRY = mongoose.model(
    "t_country",
    MasterCountrySchema
);