const mongoose = require("mongoose");

const MasterTaxSchema = mongoose.Schema(
    {
        f_totservicetax: { type: Number },
        f_servicetax: { type: Number },
        f_cess: { type: Number },
        f_shecess: { type: Number },
        f_usaprice: { type: Number },
        f_CMP_GSTIN: { type: String },
    },
    { collection: "t_tax" }
);

module.exports = M_TAX = mongoose.model(
    "t_tax",
    MasterTaxSchema
);