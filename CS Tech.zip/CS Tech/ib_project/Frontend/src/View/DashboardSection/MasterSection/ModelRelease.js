import React, { useState, useEffect } from 'react';
import * as RB from 'react-bootstrap';
import { MdAddCircleOutline } from 'react-icons/md';
import { RiDeleteBin6Line } from "react-icons/ri";
import { BiCommentEdit } from "react-icons/bi";

import PaginationComponent from "../../../Components/Common/PaginationComponent";

import Modal from "../../../Components/Common/Modal";


export const ModelRelease = () => {
    const [currentPage, setCurrentPage] = useState(1);
    const [itemPerPage, setItemPerPage] = useState(20);
    let [searchData, setSearchData] = useState("");
    const [TotalCount, setTotalCount] = useState(0);

    const [show_addvideo, setShow] = useState(false);
    const [ReleaseModelArray, setReleaseModelArray] = useState([]);
    const [Loading, setLoading] = useState(false)


    const [isOpen, setIsOpen] = useState(false);
    const [ModelMsg, setModelMsg] = useState("");

    const addvideoShow = () => setShow(true);  //M

    const SearchDataFun = async (e) => {
        setSearchData(e.target.value)
        // const res = await GET_VEDIOMODELLIST(currentPage, itemPerPage, (searchData = e.target.value));
        // let { data, totalrecord } = res;
        // setVedioModelList(data);
        // totalrecord.length === 1
        //   ? setTotalCount(totalrecord[0].totalcount)
        //   : setTotalCount(0);
    }

    const modelSet = async () => {
        setIsOpen(true);
    };

    const ActiveDeactive = async (id, f_map) => {
        // const res = await GET_ACTIVATIONFORVM(id, f_map);
        // const { message } = res;
        // apiCall();
        // setModelMsg(message);
        // modelSet();
    }

    const RemoveVedioModel = async (id) => {
        // const res = await REMOVE_VMDETAIL(id);
        // const { message } = res;
        // apiCall();
        // setModelMsg(message);
        // modelSet();
    }

    const apiCall = async () => {
        setLoading(true)
        // const res = await GET_VEDIOMODELLIST(currentPage, itemPerPage, searchData);
        // console.log(res)
        // let { data, totalrecord } = res;
        // setVedioModelList(data);
        // setTotalCount(totalrecord[0].totalcount)
        // setLoading(false)
    }

    useEffect(() => {
        apiCall()
    }, [currentPage, itemPerPage]);

    return (
        <RB.Row className="rownew1">
            <RB.Col lg={12}>
                <RB.Row className="rownew1" style={{ paddingTop: "20px" }}>
                    <div className="tableHeader tableHeader1 order_btntable">
                        <RB.Col md={6} xs={12} className="table_span">
                            <h3 className="page-title d-flex userv">
                                <span>Search Results</span>
                            </h3>
                        </RB.Col>
                        <RB.Col md={6} xs={12} className="table_span">
                            <div className="float-right responsive_floatbtn">
                                <RB.Button size="sm" variant="primary" className="btn_svg" onClick={addvideoShow}
                                >
                                    <MdAddCircleOutline style={{ marginRight: "3px" }} />
                                    ADD NEW RECORDS
                                </RB.Button>
                            </div>
                        </RB.Col>
                    </div>
                </RB.Row>
            </RB.Col>

            <RB.Col lg={12}>
                <div className="box_detail" style={{ borderRadius: "4px" }}>
                    <div className="page-header row">
                        <RB.Col md={12}>
                            <RB.Form className="manage_searchorder">
                                <RB.Row className="mg_row0">
                                    <RB.Col lg={12} md={12} className="customer_leftsrh">
                                        <RB.Row className="mg_row0">
                                            <RB.Col lg={3} md={3} className="customer_sdate">
                                                <RB.Form.Group>
                                                    <RB.Form.Control
                                                        id="searchText"
                                                        type="text"
                                                        placeholder="Search by Text"
                                                        onChange={SearchDataFun}
                                                    />
                                                </RB.Form.Group>
                                            </RB.Col>
                                        </RB.Row>
                                    </RB.Col>

                                </RB.Row>
                            </RB.Form>
                        </RB.Col>
                    </div>
                </div>
            </RB.Col>

            <RB.Col lg={12}>
                <RB.Row className="rownew1">
                    <div className="tableHeader tableHeader1 search_new">
                        <RB.Col lg={6} md={6} className="table_span">
                            <h3 className="page-title d-flex userv">
                                <span>Model Release List</span>
                            </h3>
                        </RB.Col>
                        <RB.Col lg={6} md={6} className="table_span total_recordt">
                            <span>Total Records: {TotalCount}</span>
                        </RB.Col>
                    </div>
                </RB.Row>
                <div
                    className="box_detail table_boxdtl manage_order"
                    style={{}}
                >
                    <RB.Table striped bordered hover variant="dark" responsive>
                        <thead>
                            <tr class="vtable">
                                <th className="text-center">S. No.</th>
                                <th className="text-center">Still Folder</th>
                                <th className="text-center">Video Floder</th>
                                <th className="text-center action_align">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            {Loading ? <tr><td className="no_records" colSpan="11">Loading...</td></tr> : ReleaseModelArray.length > 0 ? ReleaseModelArray.map((info, inx) => {
                                return (
                                    <tr key={`VDO_MODEL${inx}`}>
                                        <td className="s_notm text-center">{inx + 1}</td>
                                        <td className="text-center"><a href="#0">{info.f_still_folder}</a></td>
                                        <td className="text-center"><a href="#0">{info.f_video_floder}</a></td>
                                        <td className="td_comments text-center">
                                            <BiCommentEdit title="Edit Video" onClick={() => ActiveDeactive(info._id, info.f_map)} />
                                            <RiDeleteBin6Line title="Delete Video" className="text-danger1"
                                                onClick={() => RemoveVedioModel(info._id)}
                                            />
                                        </td>
                                    </tr>
                                )
                            }) : <tr><td className="no_records" colSpan="11">No Records Found</td></tr>}
                        </tbody>
                    </RB.Table>
                </div>
            </RB.Col>

            <PaginationComponent
                MOCK_DATA={TotalCount}
                currentPage={currentPage}
                setCurrentPage={setCurrentPage}
                itemPerPage={itemPerPage}
                setItemPerPage={setItemPerPage}
            />

            <Modal text={ModelMsg} open={isOpen} onClose={() => setIsOpen(false)} />

        </RB.Row>


    )
}

export default ModelRelease;
