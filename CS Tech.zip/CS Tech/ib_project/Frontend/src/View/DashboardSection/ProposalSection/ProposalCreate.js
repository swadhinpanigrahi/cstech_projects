import React, { useState, useEffect } from 'react';
import * as RB from "react-bootstrap";
import { MdAddShoppingCart } from "react-icons/md";
import { RiDeleteBin6Line } from "react-icons/ri";
import { Link, useHistory } from "react-router-dom";
import { FaRegCreditCard } from "react-icons/fa";
import { AiOutlineShoppingCart } from "react-icons/ai";
import {
    getImageDetailsForProposal, getSizingDropData,
    getCartDetails_FATCH, AddtoCartAPI_FATCH, DeleteFromCart,
} from "../../../Utils/api";
import Cookie from "js-cookie";
import validation from "../../../Utils/validation"


export const ProposalCreate = () => {
    const history = useHistory();

    const [ImageSearch, setImageSearch] = useState("");
    const [CatchEmail, setCatchEmail] = useState("")
    const [ImageArray, setImageArray] = useState([]);
    const [CS_ImgType, setCS_ImgType] = useState("MEDIUM");
    const [AddItemInCart, setAddItemInCart] = useState([]);
    const [errors, setErrors] = useState({});
    const [show, setShow] = useState(false);

    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);

    const onSearch = async (e) => {
        e.preventDefault();
        setCS_ImgType("MEDIUM")
        const res = await getImageDetailsForProposal({ f_imgid: ImageSearch });
        let { imageData } = res;
        let array = [];
        for (let i = 0; i < imageData.length; i++) {
            const res = await getSizingDropData(imageData[i].f_pricing);
            let { imageSize } = res;
            imageData[i].sizeArray = imageSize;
            imageData[i].showprice = imageSize[0].f_price;
            array.push(imageData[i])
        }
        setImageArray(array);
    }

    const onSelectHandleChange = async (e, F_imgid) => {
        e.target.name = setCS_ImgType(e.target.value);
        const shaloArray = [...ImageArray];
        for (let i = 0; i < shaloArray.length; i++) {
            if (shaloArray[i].F_imgid === F_imgid) {
                const DropSizeArray = shaloArray[i].sizeArray;
                for (let j = 0; j < DropSizeArray.length; j++) {
                    if (DropSizeArray[j].f_typename === e.target.value) {
                        shaloArray[i].showprice = DropSizeArray[j].f_price
                        shaloArray[i].f_dimenation = DropSizeArray[j].f_dimenation
                        shaloArray[i].f_dpi = DropSizeArray[j].f_dpi
                        shaloArray[i].f_outputsize = DropSizeArray[j].f_outputsize
                    }
                }
            }
        }
        setImageArray(shaloArray)
    }


    const AddtoCard = async (imageDetail) => {
        const email = Cookie.get("email");
        const CS_userid = Cookie.get("userid");
        let FormData;
        if (CS_ImgType === "MEDIUM") {
            FormData = {
                CS_ImgType: "MEDIUM",
                CS_Price: "22000",
                CS_id: imageDetail.f_sno,
                CS_imgCode: imageDetail.F_imgid,
                CS_imgId: imageDetail.F_rank,
                CS_userid,
                CS_username: email,
                f_dimenation: "3600 X 5400",
                f_dpi: "300DPI",
                f_outputsize: "12” x 18” at 300 dpi",
            }
        } else {
            FormData = {
                CS_username: email, CS_imgCode: imageDetail.F_imgid,
                CS_imgId: imageDetail.F_rank, CS_id: imageDetail.f_sno, CS_userid,
                CS_ImgType: CS_ImgType, CS_Price: imageDetail.showprice,
                f_dimenation: imageDetail.f_dimenation,
                f_dpi: imageDetail.f_dpi, f_outputsize: imageDetail.f_outputsize
            };

        }

        const AddToCartRes = await AddtoCartAPI_FATCH(FormData);
        const { status, message } = AddToCartRes;
        if (status === 200) {
            const CS_username = Cookie.get("email");
            const res = await getCartDetails_FATCH(CS_username);
            let { ImageDetails } = res;
            setAddItemInCart(ImageDetails)
        } else {
            window.alert(message)
        }
    }

    const DeleteCart = async (imageDetail) => {
        const email = Cookie.get("email");
        const FormData = { CS_username: email, CS_imgCode: imageDetail.CS_imgCode };
        const res = await DeleteFromCart(FormData);
        let { status, message } = res
        if (status === 200) {
            const CS_username = Cookie.get("email");
            const res = await getCartDetails_FATCH(CS_username);
            let { ImageDetails } = res;
            setAddItemInCart(ImageDetails)
        }
    }

    const validateEmail = (e) => {
        e.target.name = setCatchEmail(e.target.value)
        setErrors(validation({ username: e.target.value }));
    }

    const onSubmit = async () => {
        if (!errors.username) {
            history.push(`/dashboard/proposal/ordercheckout/${CatchEmail}`)
        }
    }

    const setFun = (data) => {
        console.log(data)
    }

    useEffect(() => {
        const getDetails = async () => {
            const CS_username = Cookie.get("email");
            const res = await getCartDetails_FATCH(CS_username);
            let { ImageDetails } = res;
            setFun(ImageDetails.sizeArray)
            setAddItemInCart(ImageDetails)
        }
        getDetails();
    }, []);

    return (
        <>
            <RB.Row className="rownew1">
                <RB.Col lg={12}>
                    <RB.Row className="page_header1 rownew1">
                        <div className="tableHeader tableHeader1 search_new">
                            <RB.Col md={12} className="table_span">
                                <h3 className="page-title d-flex userv">
                                    <span>Proposal Search Order</span>
                                </h3>
                            </RB.Col>
                            {/* <RB.Col md={6} className="table_span text-right">
                                <RB.Button
                                    as={Link}
                                    to="/dashboard/Proposal/create"
                                    className="back_proposal btn btn-sm"
                                ><AiOutlineArrowLeft />BACK
                                </RB.Button>
                            </RB.Col> */}
                        </div>
                    </RB.Row>
                </RB.Col>

                <RB.Col lg={12}>
                    <div className="box_detail" style={{ borderRadius: "4px" }}>
                        <div className="page-header row">
                            <RB.Col md={12}>
                                <RB.Form className="manage_searchorder">
                                    <RB.Row className="mg_row0">
                                        <RB.Col lg={7} md={12}>
                                            <RB.Row className="mg_row0">
                                                <RB.Col lg={3} md={4}>
                                                    <label>Search Image ID:</label>
                                                </RB.Col>
                                                <RB.Col lg={6} md={6} className="proposal_crtd">
                                                    <RB.Form.Group>
                                                        <RB.Form.Control
                                                            id="searchText"
                                                            type="text"
                                                            name="f_imgid"
                                                            onChange={(e) => e.target.name = setImageSearch(e.target.value)}
                                                            placeholder="Enter Image ID..."
                                                        />
                                                    </RB.Form.Group>
                                                </RB.Col>
                                                <RB.Col lg={2} md={2} className="customer_sdate">
                                                    <RB.Col lg={12} className="customer_sdate1" style={{ padding: "0px" }}>
                                                        <RB.Button size="sm" className="customer_srhbtn"
                                                            variant="primary" onClick={onSearch}>SEARCH</RB.Button>
                                                    </RB.Col>
                                                </RB.Col>
                                            </RB.Row>
                                        </RB.Col>
                                    </RB.Row>
                                </RB.Form>
                            </RB.Col>
                        </div>
                    </div>
                </RB.Col>

                <RB.Col lg={6}>
                    <div className="box_detail"
                        style={{
                            paddingLeft: "0px",
                            paddingRight: "0px",
                            borderRadius: "4px",
                            paddingTop: "0px",
                        }}>
                        <div className="page-header row no-gutters inside_header">
                            <div className="col-md-12">
                                <h3
                                    className="page-title"
                                    style={{
                                        color: "#000",
                                        marginBottom: "0px",
                                        paddingBottom: "0px",
                                        fontSize: "1.5rem",
                                    }}>
                                    Image Details
                                </h3>
                            </div>
                        </div>
                        <hr className="m-t-25 m-b-25" />
                        <div className="table_proposalscroll">
                            <table className="table table-bordered proposal_createtable">
                                <thead className="thead-dark">
                                    <th
                                        className="text-center"
                                        style={{ borderRight: "1px solid #707070", borderLeft: "1px solid #707070" }}  >
                                        <p className="mg-b-0">
                                            <strong>Image</strong>
                                        </p>
                                    </th>
                                    <th
                                        style={{ borderRight: "1px solid #707070" }}
                                    >
                                        <p className="mg-b-0">
                                            <strong>Type</strong>
                                        </p>
                                    </th>
                                    <th
                                        className=""
                                        style={{ borderRight: "1px solid #707070" }}
                                    >
                                        <p className="mg-b-0">
                                            <strong>Amount</strong>
                                        </p>
                                    </th>
                                    <th className="text-center"
                                        style={{ borderRight: "1px solid #707070" }}
                                    >
                                        <p className="mg-b-0">
                                            <strong>Action</strong>
                                        </p>
                                    </th>
                                </thead>
                                <tbody className="proposal_createtbody">
                                    {ImageArray.length > 0 ? ImageArray.map((data, inx) => {
                                        return (
                                            <tr
                                                style={{ borderBottom: "1px solid #707070" }}
                                                key={`PROP_GET_IMAGEID${inx}`}
                                            >
                                                <td className="text-center" >
                                                    <img className="img_dtlimg" src={`https://ibcdn.imagesbazaar.com/img170/${data.F_rank}-${data.F_imgid}.jpg`} alt="dyc_im2" />
                                                    <p>{data.F_imgid}</p>
                                                </td>
                                                <td>
                                                    <select className="form-control" id="propTD"
                                                        name="CS_ImgType"
                                                        value={CS_ImgType}
                                                        onChange={(e) => onSelectHandleChange(e, data.F_imgid)}
                                                    >
                                                        {/* <option value="MEDIUM">MEDIUM</option> */}
                                                        {data.sizeArray.map((data, inx) => <option key={`PRICE_DROP${inx}`} value={data.f_typename}>{data.f_typename}</option>)}
                                                    </select>
                                                </td>
                                                <td>{CS_ImgType === "MEDIUM" ? 22000 : data.showprice}</td>
                                                <td className="text-center td_comments">
                                                    <MdAddShoppingCart title="Proposal Add" onClick={() => AddtoCard(data)} />
                                                </td>
                                            </tr>
                                        )
                                    }) : <tr><td className="no_records" colSpan="11">No Records Found</td></tr>}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </RB.Col>

                <RB.Col lg={6}>
                    <div className="box_detail"
                        style={{
                            paddingLeft: "0px",
                            paddingRight: "0px",
                            borderRadius: "4px",
                            paddingTop: "0px",
                        }}>
                        <div className="page-header row no-gutters inside_header">
                            <div className="col-md-12">
                                <h3
                                    className="page-title"
                                    style={{
                                        color: "#000",
                                        marginBottom: "0px",
                                        paddingBottom: "0px",
                                        fontSize: "1.5rem",
                                    }}>
                                    Already Added Item In Cart
                                </h3>
                            </div>
                        </div>
                        <hr className="m-t-25 m-b-25" />
                        <div className="table_proposalscroll">
                            <table className="table table-bordered proposal_createtable">
                                <thead className="thead-dark">
                                    <th
                                        className="text-center"
                                        style={{ borderRight: "1px solid #707070", borderLeft: "1px solid #707070" }}
                                    >
                                        <p className="mg-b-0">
                                            <strong>Image</strong>
                                        </p>
                                    </th>
                                    <th
                                        className=""
                                        style={{ borderRight: "1px solid #707070" }}
                                    >
                                        <p className="mg-b-0">
                                            <strong>Item Details</strong>
                                        </p>
                                    </th>
                                    <th className="text-center"
                                        style={{ borderRight: "1px solid #707070" }}
                                    >
                                        <p className="mg-b-0">
                                            <strong>Action</strong>
                                        </p>
                                    </th>
                                </thead>
                                <tbody className="proposal_createtbody">
                                    {AddItemInCart.length > 0 ? AddItemInCart.map((data, inx) => {
                                        return (
                                            <tr style={{ borderBottom: "1px solid #707070" }} key={`ALREDY_ADDED_CART${inx}`}>
                                                <td className="text-center propTD" >
                                                    <img className="img_dtlimg" src={`https://ibcdn.imagesbazaar.com/img170/${data.CS_imgId}-${data.CS_imgCode}.jpg`} alt="dyc_im2" />
                                                </td>
                                                <td className="addcart_imgdtl">
                                                    <span>ImageBazzar ID : </span>
                                                    <strong>{data.CS_imgCode}</strong><br />
                                                    <span>Type : </span>
                                                    <strong>{data.CS_ImgType}</strong><br />
                                                    <span>Price : </span>
                                                    <strong>{data.CS_Price}</strong><br />
                                                    <span>File Type :

                                                        {data.CS_ImgType === "LARGE" || data.CS_ImgType === "MEDIUM" ? <strong> TIFF</strong> : ""}
                                                        {data.CS_ImgType === "SMALL" || data.CS_ImgType === "WEB" ? <strong> JPEG</strong> : ""}



                                                    </span>
                                                </td>
                                                <td className="text-center td_comments">
                                                    < RiDeleteBin6Line className="text-danger1" title="Proposal Delete" onClick={() => DeleteCart(data)} />
                                                </td>
                                            </tr>
                                        )
                                    }) : <tr><td className="no_records" colSpan="11">No Items In Cart</td></tr>}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </RB.Col>

                <RB.Col lg={12}>
                    <div className="demo-btn-group col-md-12 pd-r-0 float-right" id="probtnt">
                        <RB.Button size="sm" variant="primary" className="btn_svg btn-chk" onClick={handleShow}>
                            <FaRegCreditCard style={{ marginRight: "4px" }} />Checkout
                        </RB.Button>
                        <RB.Button size="sm" variant="primary" className="btn_svg btn-chk1">
                            <Link to="/dashboard/proposal/checkout">
                                <AiOutlineShoppingCart style={{ marginRight: "3px" }} />Finalize Proposal Order
                            </Link>
                        </RB.Button>
                    </div>
                </RB.Col>

            </RB.Row>

            <RB.Modal show={show} onHide={handleClose} className="ordermanage_modal send_proposalmail">
                <RB.Modal.Header closeButton>
                    <RB.Modal.Title>Verify Your Email Id</RB.Modal.Title>
                </RB.Modal.Header>
                <RB.Modal.Body>
                    <RB.Row>
                        <RB.Col lg={12} md={12}>
                            <RB.Row>
                                <RB.Col lg={12} md={12}>
                                    <RB.Form>
                                        <RB.Form.Group as={RB.Row} style={{ marginBottom: "0px" }}>
                                            <RB.Col lg={12} md={12}>
                                                <RB.Form.Control
                                                    type="text"
                                                    placeholder="Enter your email address.."
                                                    onChange={validateEmail}
                                                    email="email"
                                                />
                                                {errors.username && (
                                                    <RB.Form.Text className="text-danger">
                                                        {errors.username}
                                                    </RB.Form.Text>
                                                )}
                                            </RB.Col>
                                        </RB.Form.Group>
                                    </RB.Form>
                                </RB.Col>
                            </RB.Row>
                        </RB.Col>
                    </RB.Row>
                </RB.Modal.Body>

                <RB.Modal.Footer>
                    <RB.Button variant="primary" size="sm" onClick={onSubmit}>
                        SUBMIT
                    </RB.Button>
                </RB.Modal.Footer>
            </RB.Modal>
        </>
    )
}

export default ProposalCreate
