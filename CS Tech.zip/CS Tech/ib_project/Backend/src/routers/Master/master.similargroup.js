const SimilarGroup = require("express").Router();

const {
    AddSimilarGroup, getSimilarGroupList, getSimilarGroup,
    updateSimilarGroup, removeSimilarGroup
} = require("../../controllers/Master/master.similargroup.controller");

SimilarGroup.route("/Addsimilargroup").post(AddSimilarGroup);
SimilarGroup.route("/getsimilargrouplist").get(getSimilarGroupList);
SimilarGroup.route("/getsimilargroup/:_id").get(getSimilarGroup);
SimilarGroup.route("/updatesimilargroup").post(updateSimilarGroup);
SimilarGroup.route("/removesimilargroup/:_id").get(removeSimilarGroup);


module.exports = SimilarGroup;