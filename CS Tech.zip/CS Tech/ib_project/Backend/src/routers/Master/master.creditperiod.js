const Creditperiod = require("express").Router();
const {
    addCreditPeriod, getCreditPeriodList, getCreditPeriodDetail, editCreditPeriodDetail, deleteCreditPeriodDetail
} = require("../../controllers/Master/master.creditperiod.controller");

Creditperiod.route("/addcreditperiod").post(addCreditPeriod);
Creditperiod.route("/getcreditperiodlist").get(getCreditPeriodList);
Creditperiod.route("/getcreditperioddetail/:_id").get(getCreditPeriodDetail);
Creditperiod.route("/editcreditperioddetail").post(editCreditPeriodDetail);
Creditperiod.route("/deletecreditperioddetail/:_id").get(deleteCreditPeriodDetail)

module.exports = Creditperiod;